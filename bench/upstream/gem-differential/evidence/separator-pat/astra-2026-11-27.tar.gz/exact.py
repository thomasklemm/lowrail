import os, pathlib, subprocess, re, sys
from matrix import ROOT, environment

repo = ROOT.parents[3]
text = (repo/'bench/upstream/gem-differential/evidence/separator-pat/redmine.md').read_text()
script = re.findall(r'```\n(.*?)```', text, re.S)[1]
kept = (repo/'bench/upstream/gem-differential/evidence/separator-pat/redmine-repro.sh').read_text()
assert script == kept, (script, kept)
(ROOT/'exact-body.sh').write_text(script)
for ruby in sys.argv[1:]:
    for repeat in [1, 2]:
        work = ROOT/f'exact/{ruby}-{repeat}'
        work.mkdir(parents=True)
        env = environment(ruby)
        env['GEM_HOME'] = str(work/'gems')
        env['GEM_PATH'] = str(work/'gems')
        with (ROOT/f'logs/exact-{ruby}-{repeat}.log').open('w') as log:
            subprocess.run(['ruby','-v'], env=env, stdout=log, stderr=subprocess.STDOUT)
            p = subprocess.run(['bash','-x',str(ROOT/'exact-body.sh')], cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
            log.write(f'\nEXIT={p.returncode}\n')
        print(ruby, repeat, p.returncode, flush=True)
