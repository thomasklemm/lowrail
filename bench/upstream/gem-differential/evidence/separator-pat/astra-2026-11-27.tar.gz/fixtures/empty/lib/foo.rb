module Foo; end
