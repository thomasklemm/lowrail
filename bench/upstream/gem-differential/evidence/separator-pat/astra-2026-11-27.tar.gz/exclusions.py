import json
from matrix import ROOT, environment, fixture, run

rows = []
for shape in ['path-exe','git-exe']:
    work = ROOT/'exclusions'/shape
    fixture(work, shape, '2.6.9')
    gemfile = work/'Gemfile'
    source, gem = gemfile.read_text().splitlines()
    gemfile.write_text(source+'\ngroup :tools do\n  '+gem+'\nend\n')
    env = environment('master')
    env['BUNDLE_PATH'] = str(work/'vendor/bundle')
    env['BUNDLE_WITHOUT'] = 'tools'
    with (ROOT/f'logs/excluded-{shape}.log').open('w') as log:
        log.write(gemfile.read_text()+'\nBUNDLE_WITHOUT=tools\n')
        row = {'shape': shape, 'install': run(['bundle','install','--local'],work,env,log)}
        row['check'] = run(['bundle','check'],work,env,log)
        row['exec'] = run(['bundle','exec','ruby','-e','puts "EXEC_OK:#{Bundler::VERSION}"'],work,env,log)
        rows.append(row)
(ROOT/'logs/exclusions.json').write_text(json.dumps(rows, indent=2)+'\n')
