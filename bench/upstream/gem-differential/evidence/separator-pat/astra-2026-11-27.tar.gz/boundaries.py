import json, pathlib, re
from matrix import ROOT, environment, fixture, run

rows = []
for shape in ['path-exe','path-noexe','git-exe','git-noexe','rubygems-exe','rubygems-noexe']:
    for mode in ['normal','frozen','deployment']:
        for strategy in ['system', 'update', 'installed']:
            ident = f'{shape}-{mode}-{strategy}'
            work = ROOT/'boundaries'/ident
            original = fixture(work, shape, '2.6.9')
            env = environment('master')
            env['BUNDLE_PATH'] = str(work/'vendor/bundle')
            if mode == 'frozen': env['BUNDLE_FROZEN'] = 'true'
            if mode == 'deployment': env['BUNDLE_DEPLOYMENT'] = 'true'
            row = {'shape': shape, 'mode': mode, 'strategy': strategy}
            with (ROOT/f'logs/boundary-{ident}.log').open('w') as log:
                row['fresh_check'] = run(['bundle','check'], work, env, log)
                row['fresh_exec'] = run(['bundle','exec','ruby','-e','puts "EXEC_OK:#{Bundler::VERSION}"'],work,env,log)
                if strategy == 'system':
                    env['BUNDLE_VERSION'] = 'system'
                    row['install'] = run(['bundle','install','--local'],work,env,log)
                    row['exec'] = run(['bundle','exec','ruby','-e','puts "EXEC_OK:#{Bundler::VERSION}"'],work,env,log)
                elif strategy == 'update':
                    row['update'] = run(['bundle','update','--bundler'],work,env,log)
                    row['install'] = run(['bundle','install','--local'],work,env,log)
                else:
                    env['BUNDLE_VERSION'] = 'system'
                    row['seed_install'] = run(['bundle','install','--local'],work,env,log)
                    del env['BUNDLE_VERSION']
                    (work/'Gemfile.lock').write_text(original)
                    row['install'] = run(['bundle','install','--local'],work,env,log)
                row['lock_after'] = (work/'Gemfile.lock').read_text()
                row['lock_changed'] = row['lock_after'] != original
                log.write('\nLOCK AFTER:\n'+row['lock_after'])
            rows.append(row)
            print(ident, row.get('update'), row['install'], flush=True)
(ROOT/'logs/boundaries.json').write_text(json.dumps(rows, indent=2)+'\n')
