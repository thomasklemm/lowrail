import collections, json
from matrix import ROOT, VERSIONS

rows = json.loads((ROOT/'logs/matrix-summary.json').read_text())
assert len(rows) == 3870, len(rows)
keys = [tuple(r[k] for k in ['ruby','version','shape','mode']) for r in rows]
assert len(set(keys)) == len(keys)
for ruby in ['master', 'ruby4010']:
    main = [r for r in rows if r['ruby']==ruby and not r['shape'].endswith('empty')]
    assert len(main) == 101*6*3
    assert set(r['version'] for r in main) == set(VERSIONS)
for row in rows:
    if row['version'] == '2.3.0': expected = 'did_you_mean'
    elif row['ruby'] == 'master' and row['version'] != '4.0.12' and row['shape'] in ['path-exe','path-noexe','git-exe','git-noexe']:
        expected = 'separator'
    else: expected = 'ok'
    assert row['install']['result'] == expected, row
    for cmd in ['check','exec']:
        assert row[cmd]['result'] == ('did_you_mean' if row['version']=='2.3.0' else 'ok'), row
    if 'executable' in row: assert row['executable']['result'] == 'ok', row
    if row['mode'] != 'normal': assert not row['lock_changed'], row
print('PASS: 3870 distinct cases; complete 101-release matrix on both Ruby builds; no unexplained outcomes.')
for ruby in ['master','ruby4010','patched']:
    print(ruby, dict(collections.Counter(r['install']['result'] for r in rows if r['ruby']==ruby)))
boundaries = json.loads((ROOT/'logs/boundaries.json').read_text())
assert len(boundaries)==54
for row in boundaries:
    if row['strategy']=='system':
        assert row['install']['exit']==row['exec']['exit']==0
        if row['mode']!='normal': assert not row['lock_changed']
    if row['strategy']=='update':
        assert row['update']['exit']==(0 if row['mode']=='normal' else 16)
    if row['strategy']=='installed':
        assert row['seed_install']['exit']==0
        assert row['install']['result']==('ok' if row['shape'].startswith('rubygems') else 'separator')
print('PASS: bypass, update/frozen/deployment and already-installed boundaries.')
for ruby in ['master','ruby4010','patched']:
    for rep in [1,2]:
        log=(ROOT/f'logs/exact-{ruby}-{rep}.log').read_text()
        expected=1 if ruby=='master' else 0
        assert log.rstrip().endswith(f'EXIT={expected}')
        assert ('uninitialized constant Pathname::SEPARATOR_PAT' in log) == (ruby=='master')
print('PASS: exact text reproduced twice per build, before and after restoration.')
for flag, count in [('default',0), ('off',0), ('on',5)]:
    log=(ROOT/f'logs/patch-probe-patched-{flag}.log').read_text()
    assert log.count('SEPARATOR_PAT is deprecated')==count
    assert '{ractor: [true, true, true]}' in log
    assert log.count('input:')==13
    assert 'error:' not in log
print('PASS: deprecated warnings off/on; /o input probes; frozen, shareable Ractor access.')
revised = json.loads((ROOT/'logs/revised-workaround.json').read_text())
assert len(revised) == 24
for row in revised:
    assert row['update']['exit'] == (0 if row['mode']=='normal' else 16), row
    assert row['lock_changed'] == (row['mode']=='normal'), row
exact_updates = json.loads((ROOT/'logs/exact-update.json').read_text())
assert len(exact_updates) == 4
for row in exact_updates:
    expected = 'separator' if row['ruby']=='master' and row['strategy']=='plain' else 'ok'
    assert row['update']['result'] == expected, row
print('PASS: revised-head explicit update; frozen/deployment rejection; plain-update context boundary.')
