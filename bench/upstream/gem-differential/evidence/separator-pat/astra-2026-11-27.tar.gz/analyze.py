import collections, json, pathlib
from matrix import ROOT

all_rows = []
for path in sorted((ROOT/'logs').glob('matrix-*.jsonl')):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    all_rows.extend(rows)
    print(path.name, len(rows))
    for command in ['install', 'check', 'exec', 'executable']:
        print(command, dict(collections.Counter(x[command]['result'] for x in rows if command in x)))
unexpected = []
for row in all_rows:
    for command in ['install', 'check', 'exec', 'executable']:
        if row.get(command, {}).get('result') != 'other': continue
        path = ROOT/'logs/matrix'/('-'.join(row[k] for k in ['ruby','version','shape','mode'])+'.log')
        if row['version'] == '2.3.0' and 'uninitialized constant DidYouMean::SPELL_CHECKERS' in path.read_text():
            row[command]['result'] = 'did_you_mean'
        else:
            unexpected.append((path.name, command, row[command]))
print('UNEXPLAINED', unexpected)
for ruby in sorted(set(row['ruby'] for row in all_rows)):
    print(ruby)
    for shape in sorted(set(row['shape'] for row in all_rows)):
        print(shape, dict(collections.Counter(x['install']['result'] for x in all_rows if x['ruby']==ruby and x['shape']==shape)))
(ROOT/'logs/matrix-summary.json').write_text(json.dumps(all_rows, indent=2)+'\n')
