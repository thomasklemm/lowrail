require "pathname"
puts RUBY_DESCRIPTION
puts "deprecated=#{Warning[:deprecated]}"
begin
  separator = Pathname::SEPARATOR_PAT
  p source: separator.source, options: separator.options, encoding: separator.encoding.name,
    frozen: separator.frozen?, shareable: Ractor.shareable?(separator)
  def old_bundler(path)
    /\A#{Pathname::SEPARATOR_PAT}/o.match?(path)
  end
  inputs = ["/usr", "relative", "", "\\foo", "C:/foo", "C:\\foo", "//host/share", "é", "/é", "/x".b, "\xff".b,
    Class.new(String).new("/subclass"), Object.new.tap { |o| def o.to_str; "/coerced"; end }]
  inputs.each_with_index do |input, index|
    p input: index, result: old_bundler(input)
  rescue => e
    p input: index, error: e.class.name, message: e.message
  end
  p ractor: Ractor.new { [Pathname::SEPARATOR_PAT.frozen?, Ractor.shareable?(Pathname::SEPARATOR_PAT),
    /\A#{Pathname::SEPARATOR_PAT}/o.match?("/worker")] }.value
rescue => e
  p error: e.class.name, message: e.message
end

[nil, "\\"].each do |alt|
  sep = "/"
  list = alt ? Regexp.quote("#{alt}#{sep}") : Regexp.quote(sep)
  original = alt ? /[#{list}]/ : /#{list}/
  original.freeze
  restored = alt ? /[#{Regexp.quote(alt + sep)}]/ : /#{Regexp.quote(sep)}/
  raise "different value" unless original == restored
  ["/foo", "\\foo", "C:/foo", "C:\\foo", "//host/share", "\\\\host\\share", "relative", ""].each do |path|
    before = /\A#{original}/.match?(path)
    after = /\A#{restored}/.match?(path)
    raise "different match" unless before == after
    p alt: alt, path: path, original: before, restored: after
  end
end
