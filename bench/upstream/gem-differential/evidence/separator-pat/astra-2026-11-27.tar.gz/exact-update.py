import json
from matrix import ROOT, environment, run

rows=[]
for ruby in ['master','patched']:
    for rep, strategy in [(1,'plain'),(2,'explicit')]:
        work=ROOT/f'exact/{ruby}-{rep}'
        env=environment(ruby)
        env['GEM_HOME']=env['GEM_PATH']=str(work/'gems')
        with (ROOT/f'logs/exact-update-{ruby}-{strategy}.log').open('w') as log:
            log.write('Continues the exact reproduction in its original foo directory.\n')
            row={'ruby':ruby,'strategy':strategy}
            cmd=['bundle']+(['_4.1.1_'] if strategy=='explicit' else [])+['update','--bundler']
            row['update']=run(cmd,work/'foo',env,log)
            log.write('\nLOCK AFTER:\n'+(work/'foo/Gemfile.lock').read_text())
            rows.append(row)
(ROOT/'logs/exact-update.json').write_text(json.dumps(rows,indent=2)+'\n')
