import concurrent.futures, itertools, json, os, pathlib, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent
VERSIONS = json.loads((ROOT/'logs/versions.json').read_text())

def run(cmd, cwd, env, log):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env, text=True, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=90)
        output, code = p.stdout, p.returncode
    except subprocess.TimeoutExpired as e:
        output, code = str(e.stdout), 124
    log.write('$ '+ ' '.join(cmd)+'\n'+output+f'\nEXIT={code}\n')
    if 'uninitialized constant Pathname::SEPARATOR_PAT' in output:
        result = 'separator'
    elif 'undefined method' in output and 'match' in output and 'Gem::Platform' in output:
        result = 'platform_match'
    elif code == 0:
        result = 'ok'
    else:
        result = 'other'
    return {'exit': code, 'result': result}

def environment(ruby):
    env = {k:v for k,v in os.environ.items() if not k.startswith(('BUNDLE','GEM_','RUBY'))}
    env.update(PATH=str(ROOT/f'builds/rubies/{ruby}/bin')+':/usr/bin:/bin',
               GEM_HOME=str(ROOT/'gemhome'), GEM_PATH=str(ROOT/'gemhome'),
               BUNDLE_SILENCE_ROOT_WARNING='true', BUNDLE_USER_HOME=str(ROOT/'userhome'),
               BUNDLE_GIT_ALLOW_LOCAL='true')
    return env

def fixture(path, shape, version):
    path.mkdir(parents=True)
    source, variant = shape.split('-')
    (path/'vendor/cache').mkdir(parents=True)
    if source == 'rubygems':
        name, v = ('rake', '13.3.1') if variant == 'exe' else ('ruby-progressbar','1.13.0')
        shutil.copyfile(ROOT/f'gems/{name}-{v}.gem', path/f'vendor/cache/{name}-{v}.gem')
        (path/'Gemfile').write_text(f'source "https://rubygems.org"\ngem "{name}", "{v}"\n')
        lock = f'GEM\n  remote: https://rubygems.org/\n  specs:\n    {name} ({v})\n'
        dep = f'{name} (= {v})'
    else:
        repo = ROOT/f'fixtures/{variant}'
        if source == 'path':
            (path/'Gemfile').write_text(f'source "https://rubygems.org"\ngem "foo", path: "{repo}"\n')
            lock = f'PATH\n  remote: {repo}\n  specs:\n    foo (0.1.0)\n'
        else:
            sha = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
            (path/'Gemfile').write_text(f'source "https://rubygems.org"\ngem "foo", git: "file://{repo}"\n')
            lock = f'GIT\n  remote: file://{repo}\n  revision: {sha}\n  specs:\n    foo (0.1.0)\n'
        lock += '\nGEM\n  remote: https://rubygems.org/\n  specs:\n'
        dep = 'foo!'
    lock += f'\nPLATFORMS\n  ruby\n  x86_64-linux\n\nDEPENDENCIES\n  {dep}\n\nBUNDLED WITH\n   {version}\n'
    (path/'Gemfile.lock').write_text(lock)
    return lock

def setup():
    for variant in ['exe', 'noexe', 'empty']:
        repo = ROOT/f'fixtures/{variant}'
        repo.mkdir(parents=True, exist_ok=True)
        (repo/'lib').mkdir(exist_ok=True)
        (repo/'exe').mkdir(exist_ok=True)
        (repo/'lib/foo.rb').write_text('module Foo; end\n')
        (repo/'exe/foo').write_text('#!/usr/bin/env ruby\nputs "FOO_EXEC_OK"\n')
        files = '[]' if variant == 'empty' else '["lib/foo.rb"]'
        extra = 's.bindir="exe"; s.executables=["foo"];' if variant == 'exe' else ''
        (repo/'foo.gemspec').write_text('Gem::Specification.new do |s|\n'
            's.name="foo"; s.version="0.1.0"; s.summary="foo"; s.authors=["x"];\n'
            f's.files={files}; {extra}\nend\n')
        subprocess.run(['git','init','-q'], cwd=repo, check=True)
        subprocess.run(['git','add','.'], cwd=repo, check=True)
        subprocess.run(['/usr/bin/git','-c','user.name=Thomas Klemm','-c','user.email=github@tklemm.eu',
                        '-c','commit.gpgsign=false','commit','-qm','Fixture'], cwd=repo, check=True)

def case(args):
    ruby, version, shape, mode = args
    ident = '-'.join(args)
    path = ROOT/'work'/ident
    lock = fixture(path, shape, version)
    env = environment(ruby)
    env['BUNDLE_PATH'] = str(path/'vendor/bundle')
    if mode == 'frozen': env['BUNDLE_FROZEN'] = 'true'
    if mode == 'deployment': env['BUNDLE_DEPLOYMENT'] = 'true'
    result = dict(zip(['ruby','version','shape','mode'], args))
    with (ROOT/f'logs/matrix/{ident}.log').open('w') as log:
        log.write(json.dumps({k:v for k,v in env.items() if k.startswith(('BUNDLE','GEM_','RUBY'))})+'\n')
        log.write(lock+'\n')
        result['install'] = run(['bundle','install','--local'], path, env, log)
        result['check'] = run(['bundle','check'], path, env, log)
        result['exec'] = run(['bundle','exec','ruby','-e','puts "EXEC_OK:#{Bundler::VERSION}"'], path, env, log)
        if shape.endswith('-exe') and result['install']['exit'] == 0:
            cmd = ['bundle','exec','rake','--version'] if shape.startswith('rubygems') else ['bundle','exec','foo']
            result['executable'] = run(cmd, path, env, log)
        result['lock_changed'] = (path/'Gemfile.lock').read_text() != lock
    return result

if __name__ == '__main__':
    if sys.argv[1] == 'setup':
        setup()
    else:
        (ROOT/'logs/matrix').mkdir(exist_ok=True)
        rubies = sys.argv[1].split(',')
        versions = VERSIONS if len(sys.argv) < 3 else sys.argv[2].split(',')
        shapes = ['path-exe','path-noexe','git-exe','git-noexe','rubygems-exe','rubygems-noexe']
        if len(sys.argv) > 3: shapes = sys.argv[3].split(',')
        cases = list(itertools.product(rubies, versions, shapes, ['normal','frozen','deployment']))
        suffix = '-custom' if len(sys.argv) > 3 else ''
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool, (ROOT/f'logs/matrix-{sys.argv[1]}-{len(versions)}{suffix}.jsonl').open('w') as summary:
            for i, result in enumerate(pool.map(case, cases), 1):
                summary.write(json.dumps(result)+'\n'); summary.flush()
                if i % 30 == 0: print(i, '/',len(cases), flush=True)
