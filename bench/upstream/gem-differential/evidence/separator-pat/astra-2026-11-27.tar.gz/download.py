import concurrent.futures, json, pathlib, urllib.request

root = pathlib.Path(__file__).resolve().parent
versions = sorted([v['number'] for v in json.loads((root/'logs/bundler-versions.json').read_text())
                   if not v['prerelease'] and ((v['number'].startswith('2.') and int(v['number'].split('.')[1]) >= 3)
                   or (v['number'].startswith('4.0.') and int(v['number'].split('.')[2]) <= 12))],
                  key=lambda s: tuple(map(int,s.split('.'))))
(root/'logs/versions.json').write_text(json.dumps(versions, indent=2)+'\n')
(root/'gems').mkdir(exist_ok=True)
def download(name):
    path = root/'gems'/f'{name}.gem'
    urllib.request.urlretrieve(f'https://rubygems.org/downloads/{name}.gem', path)
    return name
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    for name in pool.map(download, [f'bundler-{v}' for v in versions]+['rake-13.3.1','ruby-progressbar-1.13.0']):
        print(name, flush=True)
