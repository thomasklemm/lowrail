import json, subprocess, re
from matrix import ROOT, environment, fixture, run

repo = ROOT.parents[3]
text = subprocess.check_output(['git','show','37fab2de5e861797efb7ed1a3c8ac2c42bb23b49:bench/upstream/gem-differential/evidence/separator-pat/redmine.md'], cwd=repo, text=True)
(ROOT/'logs/revised-redmine.md').write_text(text)
assert re.findall(r'```\n(.*?)```', text, re.S)[1] == (ROOT/'exact-body.sh').read_text()
rows=[]
for state in ['only-old', 'all-versions']:
    for shape in ['path-noexe', 'git-noexe']:
        for mode in ['normal','frozen','deployment']:
            for strategy in ['plain','explicit']:
                ident=f'{state}-{shape}-{mode}-{strategy}'
                work=ROOT/'revised'/ident
                original=fixture(work,shape,'2.6.9')
                env=environment('master')
                env['BUNDLE_PATH']=str(work/'vendor/bundle')
                if state=='only-old':
                    env['GEM_HOME']=env['GEM_PATH']=str(ROOT/'exact/master-1/gems')
                if mode=='frozen': env['BUNDLE_FROZEN']='true'
                if mode=='deployment': env['BUNDLE_DEPLOYMENT']='true'
                row=dict(state=state,shape=shape,mode=mode,strategy=strategy)
                with (ROOT/f'logs/revised-{ident}.log').open('w') as log:
                    log.write(json.dumps({k:v for k,v in env.items() if k.startswith(('GEM_','BUNDLE'))})+'\n')
                    run(['gem','list','bundler','--local'],work,env,log)
                    cmd=['bundle']+(['_4.1.1_'] if strategy=='explicit' else [])+['update','--bundler']
                    row['update']=run(cmd,work,env,log)
                    row['lock_after']=(work/'Gemfile.lock').read_text()
                    row['lock_changed']=row['lock_after']!=original
                    log.write('\nLOCK AFTER:\n'+row['lock_after'])
                rows.append(row)
                print(ident,row['update'],flush=True)
(ROOT/'logs/revised-workaround.json').write_text(json.dumps(rows,indent=2)+'\n')
