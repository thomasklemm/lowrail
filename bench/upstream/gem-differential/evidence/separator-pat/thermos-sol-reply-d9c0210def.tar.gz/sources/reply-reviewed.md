Draft reply on ruby/ruby#16909, answering eregon's question of 2026-11-06. Not posted.

---

On master (80343e1cf5), Bundler 4.1.1 still switches to the version in `BUNDLED WITH`. With a lockfile written by Bundler 4.0.11 and a `gemspec` Gemfile:

```
Bundler 4.1.1 is running, but your lockfile was generated with 4.0.11. Installing Bundler 4.0.11 and restarting using that version.
NameError: uninitialized constant Pathname::SEPARATOR_PAT
```

The default is still `lockfile` ([settings.rb#L91](https://github.com/ruby/ruby/blob/80343e1cf52997cbfcb0a279ee5c330cd630d029/lib/bundler/settings.rb#L91)). @nobu, is turning off the autoswitch still planned for 4.1?
