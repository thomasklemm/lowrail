import json
from pathlib import Path

root = Path(__file__).resolve().parent
results = [json.loads(line) for name in ['results.jsonl', 'gemexec-controls.jsonl']
           for line in (root / 'logs' / name).read_text().splitlines()]
assert len(results) == 20
for row in results:
    log = (root / 'logs' / (row['name'] + '.log')).read_text()
    assert 'ruby 4.1.0dev (2026-11-27T14:39:46Z HEAD 80343e1cf5)' in log
    if row['system']:
        assert row['exit'] == 0 and not row['separator'] and not row['announcement']
        assert row['lock_unchanged'] == row['frozen']
        assert 'Bundle complete! 1 Gemfile dependency, 1 gem now installed.' in log
    else:
        assert row['exit'] == 1 and row['lock_unchanged']
        assert row['announcement'] == (not row['installed'])
        separator = row['launcher'] == 'bundle' or (row['launcher'] == 'gemexec' and row['installed'])
        assert row['separator'] == separator
        if not separator:
            assert 'Please specify at least one gem name (Gem::CommandLineError)' in log

draft = (root / 'reviewed-reply.md').read_text()
quoted = draft.split('```')[1].strip().splitlines()
fresh = (root / 'logs/bundle-False-False-False.log').read_text()
assert len(quoted) == 2 and all(line in fresh for line in quoted)
source = (root / 'logs/settings-permalink.rb').read_text()
assert source.splitlines()[90].strip() == '"BUNDLE_VERSION" => "lockfile",'
assert source == (root / 'sources/ruby/settings.rb').read_text()
assert '"BUNDLE_VERSION" => "lockfile",' in (root / 'logs/release-4.1-settings.rb').read_text()
assert '"BUNDLE_VERSION" => "lockfile",' in (root / 'sources/rubygems/settings.rb').read_text()
print('PASS: 20 isolated outcomes, exact quoted output, frozen lockfiles, bypass controls, and settings permalink')
