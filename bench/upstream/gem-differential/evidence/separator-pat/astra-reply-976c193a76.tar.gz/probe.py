import concurrent.futures
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'astra'
PREFIX = OLD / 'builds/rubies/reply-master'

def environment(work, prefix=PREFIX):
    env = {k: v for k, v in os.environ.items() if not k.startswith(('BUNDLE', 'GEM_', 'RUBY', 'XDG_'))}
    env.update(PATH=f'{prefix}/bin:/usr/bin:/bin', HOME=str(work / 'home'),
               GEM_HOME=str(work / 'gems'), GEM_PATH=str(work / 'gems'),
               GEMRC=str(work / 'gemrc'), BUNDLE_USER_HOME=str(work / 'bundle-home'),
               BUNDLE_SILENCE_ROOT_WARNING='true')
    return env

def run(cmd, work, env, log):
    log.write('$ ' + ' '.join(cmd) + '\n')
    log.flush()
    result = subprocess.run(cmd, cwd=work, env=env, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=120)
    log.write(result.stdout + f'\nEXIT={result.returncode}\n')
    log.flush()
    return {'exit': result.returncode, 'separator': 'uninitialized constant Pathname::SEPARATOR_PAT' in result.stdout,
            'announcement': 'Installing Bundler 4.0.11 and restarting using that version.' in result.stdout}

def setup():
    fixture = ROOT / 'fixture'
    (fixture / 'lib').mkdir(parents=True)
    (fixture / 'lib/foo.rb').write_text('module Foo; end\n')
    (fixture / 'foo.gemspec').write_text('Gem::Specification.new do |s|\n'
        '  s.name = "foo"; s.version = "0.1.0"; s.summary = "foo"; s.authors = ["x"]; s.files = ["lib/foo.rb"]\nend\n')
    (fixture / 'Gemfile').write_text('source "https://rubygems.org"\ngemspec\n')
    env = environment(fixture, OLD / 'builds/rubies/ruby4010')
    env['GEM_HOME'] = env['GEM_PATH'] = str(OLD / 'gemhome')
    with (ROOT / 'logs/fixture.log').open('w') as log:
        assert run(['ruby', '-v'], fixture, env, log)['exit'] == 0
        assert run(['bundle', '_4.0.11_', 'lock'], fixture, env, log)['exit'] == 0
        log.write((fixture / 'Gemfile.lock').read_text())

def case(args):
    launcher, installed, frozen, system = args
    name = f'{launcher}-{installed}-{frozen}-{system}'
    work = ROOT / 'cases' / name
    shutil.copytree(ROOT / 'fixture', work)
    env = environment(work)
    if frozen:
        env['BUNDLE_FROZEN'] = 'true'
    if system:
        env['BUNDLE_VERSION'] = 'system'
    commands = {'bundle': ['bundle', 'install'],
                'gemexec': ['gem', 'exec', '-g', 'bundler', 'bundle', 'install'],
                'gemexec-pinned': ['gem', 'exec', '-g', 'bundler', '-v', '4.1.1', 'bundle', 'install']}
    with (ROOT / f'logs/{name}.log').open('w') as log:
        log.write(json.dumps({k:v for k,v in env.items() if k.startswith(('BUNDLE', 'GEM_')) or k == 'HOME'}) + '\n')
        run(['ruby', '-v'], work, env, log)
        if installed:
            assert run(['gem', 'install', '--local', '--no-document', str(OLD / 'gems/bundler-4.0.11.gem')], work, env, log)['exit'] == 0
        run(['gem', 'list', '--local', '^bundler$'], work, env, log)
        original = (work / 'Gemfile.lock').read_bytes()
        log.write('LOCK BEFORE:\n' + original.decode())
        result = run(commands[launcher], work, env, log)
        run(['gem', 'list', '--local', '^bundler$'], work, env, log)
        run(['bundle', '-v'], work, env, log)
        current = (work / 'Gemfile.lock').read_bytes()
        log.write('LOCK AFTER:\n' + current.decode())
    return dict(name=name, launcher=launcher, installed=installed, frozen=frozen, system=system,
                lock_unchanged=original == current, **result)

if __name__ == '__main__':
    setup()
    cases = list(itertools.product(['bundle', 'gemexec', 'gemexec-pinned'], [False, True], [False, True], [False]))
    cases += [('bundle', i, f, True) for i in [False, True] for f in [False, True]]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool, (ROOT / 'logs/results.jsonl').open('w') as out:
        for result in pool.map(case, cases):
            print(json.dumps(result), flush=True)
            out.write(json.dumps(result) + '\n')
            out.flush()
