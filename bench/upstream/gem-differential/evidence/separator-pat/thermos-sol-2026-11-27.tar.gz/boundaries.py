import os
import pathlib
import subprocess

WORK = pathlib.Path(__file__).resolve().parent
ROOT = WORK.parents[2]
template = (ROOT / 'bench/upstream/gem-differential/evidence/separator-pat/redmine-repro.sh').read_text()
with (WORK / 'logs/version-boundaries.log').open('w') as log:
    for label, prefix in [('release', '/home/user/.local/share/mise/installs/ruby/4.0.10'),
                          ('base', str(WORK / 'rdiff/rubies/sep-base')),
                          ('fixed', str(WORK / 'rdiff/rubies/sep-fixed'))]:
        for version in ['2.0.2', '2.1.4', '2.2.34', '2.3.0', '2.3.27']:
            directory = WORK / 'fixtures' / f'boundary-{label}-{version}'
            directory.mkdir()
            env = os.environ.copy()
            env.update(PATH=f'{prefix}/bin:/usr/bin:/bin', HOME=str(WORK),
                       GEM_HOME=str(directory / 'gems'), GEM_PATH=str(directory / 'gems'),
                       BUNDLE_PATH=str(directory / 'vendor'))
            source = template.replace('2.6.9', version)
            log.write(f'\n=== {label} {version} ===\n{source}\n')
            log.flush()
            result = subprocess.run(['bash', '-x'], input=source, text=True,
                                    cwd=directory, env=env, stdout=log, stderr=subprocess.STDOUT)
            log.write(f'EXIT={result.returncode}\n')
            print(label, version, 'exit=', result.returncode, flush=True)
