import json
import os
import pathlib
import subprocess

WORK = pathlib.Path(__file__).resolve().parent
RUBIES = {'release': pathlib.Path('/home/user/.local/share/mise/installs/ruby/4.0.10/bin/ruby'),
          'base': WORK / 'rdiff/rubies/sep-base/bin/ruby',
          'fixed': WORK / 'rdiff/rubies/sep-fixed/bin/ruby'}
results = {}
with (WORK / 'logs/exactness.log').open('w') as log:
    for label, ruby in RUBIES.items():
        args = [str(ruby), '-W:no-deprecated', str(WORK / 'exactness.rb')]
        run = subprocess.run(args, text=True, capture_output=True)
        log.write(f'COMMAND {args}\nEXIT {run.returncode}\nSTDOUT\n{run.stdout}\nSTDERR\n{run.stderr}\n')
        if run.returncode == 0:
            results[label] = json.loads(run.stdout)
    assert results['release'] == results['fixed'], 'constant behaviour differs'
    log.write('PASS: release and patched constant behaviour is identical\n')
    for label, ruby in RUBIES.items():
        for warning in [[], ['-W:no-deprecated'], ['-W:deprecated'], ['-W0'], ['-w']]:
            code = 'require "pathname"; def f(p); /\\A#{Pathname::SEPARATOR_PAT}/o.match?(p); end; p [f("/x"), f("rel")]; p Pathname::SEPARATOR_PAT.source'
            args = [str(ruby), *warning, '-e', code]
            run = subprocess.run(args, text=True, capture_output=True)
            log.write(f'COMMAND {args}\nEXIT {run.returncode}\nSTDOUT\n{run.stdout}\nSTDERR\n{run.stderr}\n')
            if label != 'base':
                assert run.returncode == 0
                assert '[true, false]' in run.stdout
                should_warn = label == 'fixed' and warning in [['-W:deprecated'], ['-w']]
                assert ('is deprecated' in run.stderr) == should_warn
    old = (WORK / 'old-pathname.rb').read_text()
    new = (WORK / 'fixed-pathname.rb').read_text()
    old_block = old[old.index('  if File::ALT_SEPARATOR\n'):old.index('  if File.dirname(\'A:\')')]
    new_block = next(line for line in new.splitlines() if line.strip().startswith('SEPARATOR_PAT ='))
    for alternate in [None, '\\']:
        prefix = 'require "json"; fake = Module.new; fake.const_set(:ALT_SEPARATOR, ' + ('nil' if alternate is None else '"\\\\"') + '); fake.const_set(:SEPARATOR, "/"); mod = Module.new; mod.const_set(:File, fake); '
        inspect = '; r = mod.const_get(:SEPARATOR_PAT); puts JSON.generate([r.source, r.options, r.encoding.name, r.frozen?, Ractor.shareable?(r), ["/x", "\\\\x", "a/x", "C:/x", "C:\\\\x"].map { |s| /\\A#{r}/o.match?(s) }])'
        outputs = []
        for source in [old_block, new_block]:
            code = prefix + 'mod.module_eval(STDIN.read)' + inspect
            args = [str(RUBIES['fixed']), '-e', code]
            run = subprocess.run(args, input=source, text=True, capture_output=True)
            log.write(f'WINDOWS_MODEL ALT_SEPARATOR={alternate!r}\nCOMMAND {args}\nEXIT {run.returncode}\n{run.stdout}\n{run.stderr}\n')
            assert run.returncode == 0
            outputs.append(json.loads(run.stdout))
        assert outputs[0] == outputs[1], 'alternate separator model differs'
    log.write('PASS: POSIX and Windows ALT_SEPARATOR source-expression models agree; not a Windows runtime test\n')
print('PASS: old/patched exactness, warnings, POSIX/Windows expression models; logs/exactness.log')
