import os
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[3]
WORK = pathlib.Path(__file__).resolve().parent
EVIDENCE = ROOT / 'bench/upstream/gem-differential/evidence/separator-pat'
REPROS = ROOT / 'bench/upstream/gem-differential/repros'
LABEL = sys.argv[1]
PREFIX = pathlib.Path(sys.argv[2]).resolve()
FIXTURES = WORK / 'fixtures' / LABEL
FIXTURES.mkdir(parents=True, exist_ok=True)
LOG = WORK / 'logs' / f'matrix-{LABEL}.log'

def run(name, source, *, workaround=False):
    directory = FIXTURES / name
    directory.mkdir()
    env = os.environ.copy()
    env.update(PATH=f'{PREFIX}/bin:/usr/bin:/bin', HOME=str(WORK),
               GEM_HOME=str(directory / 'gems'), GEM_PATH=str(directory / 'gems'),
               BUNDLE_PATH=str(directory / 'vendor'), FIXTURES=str(FIXTURES))
    for key in ['RUBYOPT', 'BUNDLE_GEMFILE', 'BUNDLER_VERSION', 'BUNDLE_VERSION']:
        env.pop(key, None)
    with LOG.open('a') as log:
        log.write(f'\n=== {LABEL} {name} ===\nPREFIX={PREFIX}\n{source}\n')
        log.flush()
        result = subprocess.run(['bash', '-x'], input=source, cwd=directory,
                                env=env, stdout=log, stderr=subprocess.STDOUT, text=True)
        log.write(f'\nSHELL_EXIT={result.returncode}\n')
    print(f'{LABEL} {name} shell_exit={result.returncode}', flush=True)
    if workaround:
        run_source = 'cd foo\nprintf "BEFORE\\n"; tail -3 Gemfile.lock\nbundle update --bundler\nprintf "AFTER\\n"; tail -3 Gemfile.lock\nbundle install\n'
        with LOG.open('a') as log:
            log.write('\n=== bundle update --bundler workaround ===\n' + run_source)
            log.flush()
            result = subprocess.run(['bash', '-x'], input=run_source, cwd=directory,
                                    env=env, stdout=log, stderr=subprocess.STDOUT, text=True)
            log.write(f'\nWORKAROUND_EXIT={result.returncode}\n')

wrapper = '''
mktemp() {
  local args=("$@")
  args[-1]="$FIXTURES/${args[-1]##*/}"
  command mktemp "${args[@]}"
}
export -f mktemp
'''
for version in ['2.4.2', '2.6.9', '4.0.7', '4.0.11', '4.0.12']:
    script = REPROS / 'separator_pat_gemspec.sh'
    run(f'gemspec-{version}', wrapper + f'bash -x {script} {PREFIX} {version}\n')
run('git-2.6.9', wrapper + f'bash -x {REPROS}/separator_pat_git.sh {PREFIX} 2.6.9\n')
for version in ['2.4.2', '2.6.9', '4.0.11']:
    run(f'rubygems-only-{version}', wrapper + f'bash -x {REPROS}/separator_pat_rubygems_only.sh {PREFIX} {version}\n')
quoted = (EVIDENCE / 'redmine-repro.sh').read_text()
run('redmine-as-written', quoted, workaround=LABEL == 'base')
run('empty-path-files', quoted.replace('s.files = ["lib/foo.rb"]', 's.files = []'))
git_source = (REPROS / 'separator_pat_git.sh').read_text()
git_source = git_source.replace('s.files = ["lib/foo.rb"]', 's.files = []')
run('empty-git-files', wrapper + f'set -- {PREFIX} 2.6.9\n' + git_source)
if LABEL == 'base':
    for version in ['2.0.0', '2.1.4', '2.2.34', '2.3.27', '2.7.2', '4.0.0']:
        run(f'old-path-{version}', quoted.replace('2.6.9', version))
    run('explicit-system-bundler', 'export BUNDLE_VERSION=system\n' + quoted)
print(LOG)
