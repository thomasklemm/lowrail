require 'pathname'
require 'json'

def result
  { value: yield }
rescue Exception => error
  { error: error.class.name, message: error.message }
end

def old_bundler_once(path)
  /\A#{Pathname::SEPARATOR_PAT}/o.match?(path)
end

def another_once(path)
  /\A#{Pathname::SEPARATOR_PAT}/o.match?(path)
end

value = Pathname::SEPARATOR_PAT
data = { value: { source: value.source, options: value.options,
                  encoding: value.encoding.name, frozen: value.frozen?,
                  shareable: Ractor.shareable?(value) } }
inputs = ['', '/', '/usr', '//server/share', '\\usr', 'C:/usr', 'C:\\usr',
          "a/b", "\n/usr", '/é', "\xff".b, "/\xff".b,
          '/x'.encode('UTF-16LE'), nil, 1, false]
data[:matches] = inputs.map do |input|
  [input.inspect, result { old_bundler_once(input) }, result { value =~ input },
   result { input.is_a?(String) ? input.gsub(value, '#').inspect : nil }]
end
string_class = Class.new(String)
subclass = string_class.new('/subclass')
def subclass.to_str = raise('should not convert a String subclass')
subclass.freeze
data[:string_subclass] = result { old_bundler_once(subclass) }
data[:duck_types] = [false, true].map do |private_conversion|
  calls = []
  object = Object.new
  object.define_singleton_method(:to_str) { calls << :to_str; '/duck'.freeze }
  object.singleton_class.send(:private, :to_str) if private_conversion
  answer = result { old_bundler_once(object) }
  [private_conversion, answer, calls]
end
data[:dynamic_conversions] = [:extend, :prepend, :missing, :raises, :fiber].map do |kind|
  calls = []
  object = Object.new
  conversion = Module.new do
    define_method(:to_str) { calls << :to_str; '/dynamic' }
  end
  case kind
  when :extend
    object.extend(conversion)
  when :prepend
    object.singleton_class.prepend(conversion)
  when :missing
    object.define_singleton_method(:respond_to_missing?) { |name, _| name == :to_str }
    object.define_singleton_method(:method_missing) { |name, *| calls << name; '/dynamic' }
  when :raises
    object.define_singleton_method(:to_str) { calls << :to_str; raise ArgumentError, 'conversion failed' }
  when :fiber
    object.define_singleton_method(:to_str) { calls << :to_str; Fiber.yield(:suspended); '/dynamic' }
  end
  answer = if kind == :fiber
    fiber = Fiber.new { result { old_bundler_once(object) } }
    [fiber.resume, fiber.resume]
  else
    result { old_bundler_once(object) }
  end
  [kind, answer, calls]
end
data[:ractor] = result { Ractor.new { [Pathname::SEPARATOR_PAT.source, Ractor.shareable?(Pathname::SEPARATOR_PAT)] }.value }
data[:enumerated_public] = Pathname.constants(false).include?(:SEPARATOR_PAT)
data[:private_after_cache] = result do
  Pathname.private_constant(:SEPARATOR_PAT)
  old_bundler_once('/cached')
end
data[:private_uncached] = result { another_once('/private') }
data[:private_reflection] = result { Pathname.const_get(:SEPARATOR_PAT).source }
Pathname.public_constant(:SEPARATOR_PAT)
data[:public_again] = result { another_once('/public') }
data[:require_again] = result { require 'pathname' }
data[:replacement_cached] = result do
  Pathname.send(:remove_const, :SEPARATOR_PAT)
  Pathname.const_set(:SEPARATOR_PAT, /x/)
  [old_bundler_once('/cached'), old_bundler_once('x')]
end
puts JSON.pretty_generate(data)
