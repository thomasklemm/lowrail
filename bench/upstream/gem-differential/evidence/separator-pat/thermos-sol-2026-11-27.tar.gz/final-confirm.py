import os
import pathlib
import subprocess

WORK = pathlib.Path(__file__).resolve().parent
ROOT = WORK.parents[2]
source = (ROOT / 'bench/upstream/gem-differential/evidence/separator-pat/redmine-repro.sh').read_text()
with (WORK / 'logs/final-confirm-0a0321e2.log').open('w') as log:
    for name in ['system', 'update-normal', 'update-frozen', 'update-deployment']:
        directory = WORK / 'fixtures' / f'final-{name}'
        directory.mkdir()
        env = os.environ.copy()
        env.update(PATH=f'{WORK}/rdiff/rubies/sep-tip/bin:/usr/bin:/bin', HOME=str(WORK),
                   GEM_HOME=str(directory / 'gems'), GEM_PATH=str(directory / 'gems'),
                   BUNDLE_PATH=str(directory / 'vendor'))
        for key in ['BUNDLE_VERSION', 'BUNDLER_VERSION', 'BUNDLE_FROZEN', 'BUNDLE_DEPLOYMENT', 'RUBYOPT']:
            env.pop(key, None)
        log.write(f'\n=== {name} setup ===\n{source}\n')
        log.flush()
        setup = subprocess.run(['bash', '-x'], input=source, text=True, cwd=directory,
                               env=env, stdout=log, stderr=subprocess.STDOUT)
        assert setup.returncode == 1, setup.returncode
        gemfile = directory / 'foo' / 'Gemfile.lock'
        before = gemfile.read_text()
        if name == 'system':
            env['BUNDLE_VERSION'] = 'system'
            command = ['bundle', 'install']
        else:
            command = ['bundle', '_4.1.1_', 'update', '--bundler']
            if name == 'update-frozen':
                env['BUNDLE_FROZEN'] = 'true'
            if name == 'update-deployment':
                env['BUNDLE_DEPLOYMENT'] = 'true'
        log.write(f'COMMAND {command}; flags: BUNDLE_VERSION={env.get("BUNDLE_VERSION")}, BUNDLE_FROZEN={env.get("BUNDLE_FROZEN")}, BUNDLE_DEPLOYMENT={env.get("BUNDLE_DEPLOYMENT")}\n')
        log.flush()
        result = subprocess.run(command, cwd=directory / 'foo', env=env,
                                stdout=log, stderr=subprocess.STDOUT)
        after = gemfile.read_text()
        log.write(f'EXIT={result.returncode}; LOCK_UNCHANGED={before == after}\nLOCKFILE:\n{after}\n')
        if name in ['system', 'update-normal']:
            assert result.returncode == 0
            if name == 'update-normal':
                assert '4.1.1' in after
                log.write('COMMAND: bundle install after pinned update\n')
                log.flush()
                install = subprocess.run(['bundle', 'install'], cwd=directory / 'foo', env=env,
                                         stdout=log, stderr=subprocess.STDOUT)
                assert install.returncode == 0
                log.write(f'INSTALL_EXIT={install.returncode}\n')
        else:
            assert result.returncode == 16
        print(name, result.returncode, flush=True)
print('PASS: final paragraph confirms on built master 09cfdea5da')
