#!/usr/bin/env bash
set -euo pipefail
source /home/user/workspace/repo/.amp/in/orb-backup/fh2-review/env.sh
for tree in main head main; do
  export REVIEW_RAILS="$REVIEW_ROOT/$tree"
  out="$REVIEW_ROOT/size-$tree-$(date +%s)"
  mkdir -p "$out"
  valgrind --tool=callgrind --collect-atstart=no --toggle-collect=rb_ary_cycle --dump-after=rb_ary_cycle \
    --callgrind-out-file="$out/cg" ruby -rbundler/setup "$REVIEW_ROOT/size_ir.rb" "$REVIEW_RAILS" 3 > "$out/stdout" 2> "$out/stderr"
  python3 - "$tree" "$out" <<'PY'
import sys, pathlib
tree, out = sys.argv[1], pathlib.Path(sys.argv[2])
labels = [l.removeprefix('scenarios: ') for l in (out/'stderr').read_text().splitlines() if l.startswith('scenarios: ')][0].split(',')
parts = sorted(out.glob('cg.*'), key=lambda p: int(p.suffix[1:]))
values = [int(next(l.split()[1] for l in p.read_text().splitlines() if l.startswith(('summary:', 'totals:')))) for p in parts]
assert len(values) == len(labels)+1, (len(values), len(labels))
for label, value in zip(labels, values[1:]):
    print(tree, label, (value-values[0])/3)
PY
done
