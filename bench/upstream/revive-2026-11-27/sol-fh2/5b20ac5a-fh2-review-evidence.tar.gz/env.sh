export PATH=/home/user/.local/share/mise/installs/ruby/4.0.9/bin:/home/user/.local/bin:$PATH
export GEM_HOME=/home/user/workspace/repo/.amp/in/orb-backup/fh2-review/gems
export GEM_PATH=$GEM_HOME:/home/user/workspace/repo/.lowrail/gate-gems/4.0.7-x86_64-linux-229531a6cfbf07e3caef30dbac24a2a3f3fed482:/home/user/.local/share/mise/installs/ruby/4.0.9/lib/ruby/gems/4.0.0
export BUNDLE_GEMFILE=/home/user/workspace/repo/.amp/in/orb-backup/fh2-review/Gemfile
export REVIEW_ROOT=/home/user/workspace/repo/.amp/in/orb-backup/fh2-review
export REVIEW_RAILS=$REVIEW_ROOT/main
