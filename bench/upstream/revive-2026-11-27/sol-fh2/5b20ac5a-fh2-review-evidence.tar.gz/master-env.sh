source /home/user/workspace/repo/.amp/in/orb-backup/fh2-review/env.sh
export PATH="$REVIEW_ROOT/ruby-master/bin:$PATH"
export RUBY="$REVIEW_ROOT/ruby-master/bin/ruby"
export GEM_HOME="$REVIEW_ROOT/master-gems"
export GEM_PATH="$GEM_HOME:$REVIEW_ROOT/ruby-master/lib/ruby/gems/4.1.0+6"
export BUNDLE_GEMFILE="$REVIEW_ROOT/MasterGemfile"
