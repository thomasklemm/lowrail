# frozen_string_literal: true
require "active_record"
require "action_view"
ActionView::Helpers::Tags::Base.class_eval do
  private
  def value_before_type_cast
    return unless object

    method_before_type_cast = @method_name + "_before_type_cast"

    if value_came_from_user? && object.respond_to?(method_before_type_cast)
      object.public_send(method_before_type_cast)
    else
      value
    end
  end
end
ActionView::Helpers::Tags::Translator.class_eval do
  def initialize(object, object_name, method_and_value, scope:)
    @object_name = object_name.gsub(/\[(.*)_attributes\]\[\d+\]/, '.\1')
    @method_and_value = method_and_value
    @scope = scope
    @model = object.respond_to?(:to_model) ? object.to_model : nil
  end
end
