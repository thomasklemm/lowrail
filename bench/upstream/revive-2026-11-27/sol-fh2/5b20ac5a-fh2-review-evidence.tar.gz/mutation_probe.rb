require "active_record"
require "action_view"

ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
ActiveRecord::Schema.verbose = false
ActiveRecord::Schema.define { create_table(:posts) { |t| t.string :title; t.string :body } }
class Post < ActiveRecord::Base; end
view = ActionView::Base.empty

method_name = +"title"
post = Post.new(title: "title raw", body: "body raw")
post.title
post.define_singleton_method(:title_came_from_user?) { method_name.replace("body"); super() }
puts "came_from_user: #{view.text_field(:post, method_name, object: post)}"

scope = +"post"
post = Post.new(title: "title raw")
post.define_singleton_method(:to_model) { scope.replace("other"); self }
I18n.backend.store_translations(:en, helpers: { label: { post: { title: "Original label" }, other: { title: "Changed label" } } })
puts "to_model: #{view.label(scope, :title, object: post)}"
