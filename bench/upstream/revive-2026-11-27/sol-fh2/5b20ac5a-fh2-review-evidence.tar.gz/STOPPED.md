# FH2 review stopped: parked

Verdict on `7401f9dac7495aef0e0588f0e1ff5f06f3203a22`: **changes; do not open**. Both Thermos rubrics were applied in this thread, without subagents. Review and the remaining YJIT control stopped when the coordinator reported FH2 parked. No branch edits, commits, pushes, PRs or GitHub comments were made.

## Independently reproduced exactness breaks

1. In `tags/base.rb:53–55`, moving method-name construction after `title_came_from_user?` changes the snapshot across a public callback. With an ordinary mutable method-name String, main renders `value="title raw"`; head renders `value="body raw"`.
2. In `tags/translator.rb:10`, retaining the caller's name on a miss lets public `to_model` mutate the translation scope. Main renders `Original label`; head renders `Changed label` with the same `for="post_title"`.

These are adversarial public-callback probes, not reported production incidents, private Tags overrides, core monkey-patches or custom String subclasses. `mutation_probe.rb` uses real Active Record models. Main/head/main outputs are retained and the two main outputs match byte for byte. Both differences also reproduce with Ruby master f3e180b5eb and ZJIT.

Exact source replacements if revisited: restore the main methods below and remove `Translator::NESTED_ATTRIBUTES_INDEX`. Do not add compatibility guards. Keep PH's bare `super` and the owned-copy SV operations unchanged.

```ruby
def value_before_type_cast
  return unless object

  method_before_type_cast = @method_name + "_before_type_cast"

  if value_came_from_user? && object.respond_to?(method_before_type_cast)
    object.public_send(method_before_type_cast)
  else
    value
  end
end
```

```ruby
def initialize(object, object_name, method_and_value, scope:)
  @object_name = object_name.gsub(/\[(.*)_attributes\]\[\d+\]/, '.\1')
  @method_and_value = method_and_value
  @scope = scope
  @model = object.respond_to?(:to_model) ? object.to_model : nil
end
```

`restore_boundaries.rb` overlays these original methods without changing the branch. The minimized probe then matches main.

## Additional completed evidence

* Body allocation script, Ruby 4.0.9, main/head/main: `17/18/21/90 → 15/16/19/86 → 17/18/21/90` for text_field/text_area/radio_button/label. The reduced PH+SV overlay gives `16/17/19/88`; that is not certification of a new head.
* Interpreter Callgrind main/head/main/main: text_area −1.306% against median main, A/A spread 0.164%, rather than the body's −2.0%. The body claims need remeasurement on any replacement head, not transfer.
* Valid doubly nested label: +2.19% interpreter instructions, A/A 0.015%; placeholder field: +1.66%, A/A 0.062%. Worst tested Translator input, match followed by 1 MiB padding: +47.625%, A/A 0.0000235%. These are instructions, not time or request-speed changes. The extra regexp scan explains the affected path.
* Action View suite passes on both trees: 2,982 + 252 + 177 runs, zero failures/errors/skips. Changed files pass Rails-configured RuboCop. Earlier public content_tag prepend failure is fixed. One commit, both identities Thomas Klemm <github@tklemm.eu>, no trailers, no added comments. No separate structural maintainability blocker was found; PH/SV are L0, V/TR at most L1.
* Independent probe: 3,576 observations per tree; recorded review probe: 202,330; fuzz sweep: 86,726. Main A/A outputs are identical. Recorded known Symbol and custom-String boundaries remain distinct from the new public-callback findings.
* At 2026-11-27T12:40:39Z, main was still `088fc0cf61e4ba0c7987decafacc69adb3e22eec` and the fork branch still the reviewed head. Read-only ownership search and the saved 1,289-open-PR scan found no covering change. Comparable November 26 merges were confirmed read-only.

The interpreter and ZJIT four-run counter files completed. YJIT has two main controls and one head; the third main control was explicitly stopped at the coordinator's request. Do not present it as the completed three-main A/A cohort. The JIT wrapper retains per-scenario compilation counts but not final OOM counters; separate native main/head checks returned `compile_error_out_of_memory=0`. No new JIT percentage claim is made here.

The coordinator reports that Lowrail main `55a3c173` parks the reduced exact PH+SV remainder because its form-level effect is within noise. This review did not independently rerun that replacement head and does not approve or recommend opening it.

## Commands behind the findings

```bash
source .amp/in/orb-backup/fh2-review/env.sh
for t in main head main; do
  REVIEW_RAILS="$REVIEW_ROOT/$t" bundle exec ruby "$REVIEW_ROOT/mutation_probe.rb"
done
REVIEW_RAILS="$REVIEW_ROOT/head" bundle exec ruby -r"$REVIEW_ROOT/restore_boundaries.rb" "$REVIEW_ROOT/mutation_probe.rb"
for t in main head main; do
  REVIEW_RAILS="$REVIEW_ROOT/$t" bundle exec ruby bench/upstream/revive-2026-11-27/fh2_body.rb
done
bash "$REVIEW_ROOT/size_run.sh"
bash "$REVIEW_ROOT/rerun.sh"
source "$REVIEW_ROOT/master-env.sh"
for t in main head main main; do
  REVIEW_RAILS="$REVIEW_ROOT/$t" bash bench/upstream/revive-2026-11-27/revive_jit.sh "$REVIEW_ROOT/$t" zjit 500
done
```

`size_run.sh` retains its Callgrind dumps; `size.txt` has the extracted counts. `interp.txt`, `yjit.txt`, and `zjit.txt` contain the original rerun counter output and JIT windows. Environment scripts, bundle locks, runtime configurations, probes, outputs, metrics, suite logs, lint output, reviewed patch, item and revival record are in the archive. All comparisons stay on one Ruby pin per cohort.
