require "flog"
require "rubocop"
require "json"
rails = ARGV.fetch(0)
files = %w[base placeholderable translator].map { |f| File.join(rails, "actionview/lib/action_view/helpers/tags/#{f}.rb") }
flog = Flog.new(all: true)
flog.flog(*files)
flog.totals.each { |name, value| puts [name, value].join("\t") if name.match?(/(initialize|value_before_type_cast|sanitized_value)$/) }
puts "lines: #{files.map { |f| [File.basename(f), File.readlines(f).size] }.to_h}"
config = RuboCop::Config.new({"AllCops"=>{"TargetRubyVersion"=>3.3}, "Metrics/MethodLength"=>{"Max"=>0}, "Metrics/AbcSize"=>{"Max"=>0}, "Metrics/CyclomaticComplexity"=>{"Max"=>0}, "Metrics/PerceivedComplexity"=>{"Max"=>0}})
team = RuboCop::Cop::Team.new([RuboCop::Cop::Metrics::MethodLength, RuboCop::Cop::Metrics::AbcSize, RuboCop::Cop::Metrics::CyclomaticComplexity, RuboCop::Cop::Metrics::PerceivedComplexity].map { |cop| cop.new(config) }, config)
files.each do |f|
  processed = RuboCop::ProcessedSource.from_file(f, 3.3)
  team.investigate(processed).offenses.each { |o| puts [File.basename(f), o.line, o.cop_name, o.message].join("\t") }
end
