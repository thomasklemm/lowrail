rails, n = ARGV
require "active_support/all"
require "active_record"
require "action_view"
require "action_controller"

v = ActionView::Base.empty
post = Struct.new(:title, :body, :category).new("t", "b", "news")
scenarios = {}
[4, 64, 1_048_576].each do |size|
  {
    "absent" => "x" * size,
    "early" => "p[c_attributes][0]" + "x" * size,
    "late" => "x" * size + "[c_attributes][0]"
  }.each do |position, name|
    scenarios["translator/#{size}/#{position}"] = -> { ActionView::Helpers::Tags::Translator.new(nil, name, "title", scope: "helpers.label") }
  end
end
["post", "post[comments_attributes][0]", "post[comments_attributes][0][replies_attributes][12]"].each_with_index do |name, i|
  scenarios["label/nesting#{i}"] = -> { v.label(name, :title, object: post) }
  scenarios["placeholder/nesting#{i}"] = -> { v.text_field(name, :title, object: post, placeholder: true) }
end
tag = ActionView::Helpers::Tags::Base.new(:post, :category, v, object: post)
["", "A.B C!", "x" * 1_048_576, "A." + "x" * 1_048_576, "x" * 1_048_576 + "A."].each_with_index do |value, i|
  scenarios["sanitized/#{i}"] = -> { tag.send(:sanitized_value, value) }
end
scenarios.each_value { |fn| fn.call }
GC.start
GC.disable
[-> {}].cycle(0, &:call)
scenarios.each_value { |fn| [fn].cycle(Integer(n), &:call) }
$stderr.puts "scenarios: #{scenarios.keys.join(",")}"
