#!/usr/bin/env bash
set -euo pipefail
source /home/user/workspace/repo/.amp/in/orb-backup/fh2-review/env.sh
cd /home/user/workspace/repo
for mode in interp yjit; do
  for tree in main head main main; do
    export REVIEW_RAILS="$REVIEW_ROOT/$tree"
    echo "$mode $tree" >&2
    if [ "$mode" = interp ]; then
      bash bench/upstream/revive-2026-11-27/revive_ir.sh "$REVIEW_RAILS" "$mode" 500
    else
      bash bench/upstream/revive-2026-11-27/revive_jit.sh "$REVIEW_RAILS" "$mode" 500
    fi | sed "s/^/$tree /" >> "$REVIEW_ROOT/$mode.txt"
  done
done
