rails = ENV.fetch("REVIEW_RAILS")
require "active_support/all"
require "active_record"
require "action_view"
require "json"

V = ActionView::Base.empty
LOG = []
Post = Struct.new(:title, :body, :category)

def check(label)
  LOG.clear
  result = begin
    value = yield
    if value.is_a?(String)
      [value.b.unpack1("H*"), value.encoding.name, value.class.name, value.frozen?, value.html_safe?]
    else
      value
    end
  rescue Exception => e
    [e.class.name, e.message.gsub(/0x[0-9a-f]+/, "0x")]
  end
  puts JSON.generate([label, result, LOG])
end

class Record
  attr_accessor :source
  def initialize(source) = @source = source
  def title = (LOG << "title"; "cast")
  def title_before_type_cast = (LOG << "title_before_type_cast"; "uncast")
  def title_came_from_user? = (LOG << "title_came_from_user?"; source)
  def respond_to?(name, priv = false) = (LOG << "respond_to:#{name}:#{priv}"; super)
end

class Duck
  def initialize(source) = @source = source
  def respond_to_missing?(name, priv = false)
    LOG << "respond_to_missing:#{name}:#{priv}"
    %i[title title_came_from_user? title_before_type_cast].include?(name) || super
  end
  def method_missing(name, *)
    LOG << "method_missing:#{name}"
    return @source if name == :title_came_from_user?
    return "raw" if name == :title_before_type_cast
    return "cast" if name == :title
    super
  end
end

[true, false, nil, 0].each do |source|
  [Record.new(source), Duck.new(source)].each do |obj|
    %w[title missing].each do |name|
      check("record #{obj.class} #{source.inspect} #{name}") { V.text_field(:post, name.freeze, object: obj) }
      check("record textarea #{obj.class} #{source.inspect} #{name}") { V.text_area(:post, name, object: obj) }
    end
  end
end

obj = Record.new(true)
obj.singleton_class.prepend(Module.new do
  def title_came_from_user? = (LOG << "prepend"; super)
  private
  def title_before_type_cast = "private"
end)
check("record prepend private") { V.text_field(:post, :title, object: obj) }
obj = Record.new(false).extend(Module.new do
  def title = (LOG << "extend"; super)
end)
check("record extend") { V.text_area(:post, :title, object: obj.freeze) }

names = [nil, :post, 4, "post", "post[comments_attributes][12]", "post[a_attributes][1][b_attributes][2]",
         "<script> & x", "été", "post\xff".b, "post\xff".force_encoding("UTF-8"), "post".encode("UTF-16LE")]
values = [nil, false, 12, "", "-A.B C!", "İ Σ ẞ", "x\0y", "<img src=x onerror=1>", "foo".html_safe,
          "foo".freeze, "a\xff b".b, "a\xff".force_encoding("UTF-8"), "a b".encode("UTF-16LE")]
class SubString < String; end
class SubHash < Hash; end
class SubArray < Array; end
record = Post.new("<T>", "body", "A.B C!")
names.each_with_index do |name, i|
  [name, (SubString.new(name) if name.is_a?(String))].compact.each_with_index do |n, j|
    [{}, { placeholder: true }, { placeholder: "<PH>" }.freeze, SubHash[class: "s"],
     ActiveSupport::HashWithIndifferentAccess.new(placeholder: true)].each_with_index do |options, k|
      values.each_with_index do |value, m|
        check("radio #{i} #{j} #{k} #{m}") { V.radio_button(n, :category, value, options.merge(object: record)) }
        check("label #{i} #{j} #{k} #{m}") { V.label(n, :category, options.merge(object: record, value: value)) }
        check("textarea #{i} #{j} #{k} #{m}") { V.text_area(n, :body, options.merge(object: record, value: value)) }
      end
    end
  end
end

class Converted
  def initialize(s) = @s = s
  def to_s = (LOG << "to_s"; @s)
end
values.each_with_index do |v, i|
  next unless v.is_a?(String)
  check("converted #{i}") { V.radio_button("post", :category, Converted.new(v), object: record) }
end

module CaptureArgs
  def initialize(*args, **kw, &block)
    LOG << ["prepend initialize", args.length, kw.keys.map(&:to_s), !block.nil?]
    super
  end
end
ActionView::Helpers::Tags::Placeholderable.prepend(CaptureArgs)
[[], [:post], [:post, :title], [:post, :title, V], [:post, :title, V, {}], [:post, :title, V, {}, 5]].each do |args|
  check("arity #{args.size}") { ActionView::Helpers::Tags::TextField.new(*args).render }
end
check("keywords/block") { ActionView::Helpers::Tags::TextField.new(:post, :title, V, object: record, placeholder: true) {}.render }

module PublicTagPrepend
  def content_tag(name, *args, &block)
    options = args.extract_options!
    super(name, *args, options.merge(data: { marker: name }), &block)
  end
end
ActionView::Helpers::TagHelper.prepend(PublicTagPrepend)
check("public prepend textarea") { V.text_area(:post, :title, object: record) }
check("public prepend label") { V.label(:post, :title, object: record) }

names.each_with_index do |name, i|
  check("translator direct #{i}") { ActionView::Helpers::Tags::Translator.new(nil, name, :title, scope: "helpers.label").translate }
end

mutable_name = +"title"
mutator = Record.new(true)
mutator.define_singleton_method(:title_came_from_user?) { mutable_name.replace("body"); true }
mutator.define_singleton_method(:body_before_type_cast) { "changed raw" }
check("mutation during came_from_user") { V.text_field(:post, mutable_name, object: mutator) }

mutable_scope = +"post"
mutator = Post.new("t", "b", "c")
mutator.define_singleton_method(:model_name) { ActiveModel::Name.new(Post) }
mutator.define_singleton_method(:to_model) { mutable_scope.replace("other"); self }
I18n.backend.store_translations(:en, helpers: { label: { post: { title: "Original" }, other: { title: "Changed" } } })
check("mutation during to_model") { V.label(mutable_scope, :title, object: mutator) }
