ROOT=/home/user/workspace/repo
REVIEW=$ROOT/.amp/in/orb-backup/lbl1-review
export PATH=$HOME/.local/share/mise/installs/ruby/4.0.9/bin:$PATH
export GEM_PATH=$ROOT/.lowrail/gate-gems/4.0.7-x86_64-linux-229531a6cfbf07e3caef30dbac24a2a3f3fed482:$HOME/.local/share/mise/installs/ruby/4.0.9/lib/ruby/gems/4.0.0
rr() {
  local tree=$1
  shift
  local libs=$REVIEW/gems/gems/i18n-active_record-1.4.1/lib:$REVIEW/gems/gems/perpetuity-1.0.1/lib
  for c in activesupport activemodel activerecord actionview actionpack; do libs=$REVIEW/$tree/$c/lib:$libs; done
  RUBYLIB=$libs ruby "$@"
}
