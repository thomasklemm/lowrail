require "active_record"
require "action_view"
class Post
  include ActiveModel::Model
  attr_accessor :title
end
I18n.available_locales = [:en]
I18n.backend.store_translations(:en, helpers: {
  label: { post: { title: "Post title" }, article: { title: "Article title" } },
  placeholder: { post: { title: "Post placeholder" }, article: { title: "Article placeholder" } }
})
view = ActionView::Base.empty
render = ->(f) { f.label(:title) + f.text_field(:title, placeholder: true) }
puts view.form_for(Post.new, as: :article, url: "/posts", &render)
puts view.form_with(model: Post.new, scope: :article, url: "/posts", &render)
puts view.form_with(model: Post.new, scope: :post, url: "/posts", &render)
