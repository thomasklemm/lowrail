#!/usr/bin/env bash
set -euo pipefail
source /home/user/workspace/repo/.amp/in/orb-backup/lbl1-review/env.sh
mode=$1 tree=$2 label=$3
out=$REVIEW/cg-$mode-$label
mkdir -p "$out"
libs=
for c in activesupport activemodel activerecord actionview actionpack; do libs=$REVIEW/$tree/$c/lib:$libs; done
export RUBYLIB=$libs
flags=()
harness=$ROOT/bench/upstream/revive-2026-11-27/revive_ir.rb
n=1000
if [[ $mode = yjit ]]; then
  flags=(--yjit)
  harness=$ROOT/bench/upstream/revive-2026-11-27/revive_jit.rb
  n=500
fi
valgrind --tool=callgrind --collect-atstart=no --toggle-collect=rb_ary_cycle --dump-after=rb_ary_cycle --smc-check=all --callgrind-out-file="$out/cg" ruby "${flags[@]}" "$harness" "$REVIEW/$tree" "$n" > "$out/stdout" 2> "$out/stderr"
ruby - "$out" "$n" <<'RUBY'
out, n = ARGV
log = File.read("#{out}/stderr")
labels = log[/^scenarios: (.*)/, 1].split(",")
skip = log[/^skip_parts: (\d+)/, 1].to_i
files = Dir["#{out}/cg.*"].sort_by { _1.split(".").last.to_i }
ir = files.map { File.read(_1)[/^(?:summary|totals): (\d+)/, 1].to_i }
raise "parts #{ir.size}" unless ir.size == 1 + skip + labels.size
labels.each_with_index { |name, i| puts "#{name}: #{(ir[1 + skip + i] - ir[0]) / n.to_i}" }
puts log.lines.grep(/^jit_window:/)
RUBY
