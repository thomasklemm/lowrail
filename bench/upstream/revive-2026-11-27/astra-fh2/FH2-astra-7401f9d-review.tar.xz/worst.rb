rails = ARGV.fetch(0)
$LOAD_PATH.unshift File.join(rails, "actionview/lib")
require "action_view/helpers/tags/translator"
require "json"
require "benchmark"

klass = ActionView::Helpers::Tags::Translator
sizes = [32, 256, 1024 * 1024]
sizes.each do |size|
  ["absent", "early", "late", "long_capture"].each do |position|
    suffix = "[items_attributes][0]"
    name = case position
    when "absent" then "x" * size
    when "early" then suffix + "x" * (size - suffix.size)
    when "late" then "x" * (size - suffix.size) + suffix
    when "long_capture" then "[" + "x" * (size - suffix.size) + "items_attributes][0]"
    end.freeze
    run = -> { klass.new(nil, name, "title", scope: "helpers.label") }
    count = size > 1000 ? 40 : 100_000
    100.times { run.call }
    values = 5.times.map do
      GC.start
      Benchmark.realtime { count.times { run.call } } / count
    end
    puts JSON.generate(size: size, position: position, seconds: values, best_ns: values.min * 1e9)
  end
end
