rails = ARGV.fetch(0)
%w[activesupport actionview actionpack activemodel activerecord].each { |c| $LOAD_PATH.unshift(File.join(rails, c, "lib")) }
require "active_record"
require "action_view"
require "json"

class ReviewModel
  include ActiveModel::Model
  attr_accessor :title
end

view = ActionView::Base.empty
I18n.backend.store_translations(:en, helpers: { label: { post: { title: "Original label" }, other: { title: "Other label" } } })
def record(label)
  puts JSON.generate([label, yield])
rescue => e
  puts JSON.generate([label, e.class.name, e.message])
end

record("method name mutated by public model callback") do
  name = +"title"
  model = Object.new
  model.define_singleton_method(:title_came_from_user?) { name.replace("body"); true }
  model.define_singleton_method(:title_before_type_cast) { "original title" }
  model.define_singleton_method(:body_before_type_cast) { "other body" }
  view.text_field("post", name, object: model)
end

record("object name mutated by public to_model") do
  name = +"post"
  model = ReviewModel.new(title: "title")
  model.define_singleton_method(:to_model) { name.replace("other"); self }
  view.label(name, :title, object: model)
end

record("frozen value and safe buffer") do
  ["İstanbul Ä Σ <&>".freeze, "İstanbul Ä Σ <&>".html_safe.freeze].map do |value|
    [view.radio_button("post", :title, value), value, value.frozen?]
  end
end

Encoding.list.each do |enc|
  ["Ab Z.ü", "", "A\x00\xff".b].each_with_index do |bytes, i|
    record("encoding #{enc.name} #{i}") do
      value = bytes.dup.force_encoding(enc).freeze
      result = view.radio_button("post", :title, value)
      [result.bytes, result.encoding.name, value.bytes]
    end
  end
end

record("public content_tag prepend") do
  mod = Module.new do
    def content_tag(name, *args, &block)
      options = args.extract_options!
      super(name, *args, options, &block)
    end
  end
  ActionView::Helpers::TagHelper.prepend(mod)
  [view.text_area(:post, :title), view.label(:post, :title)]
end
