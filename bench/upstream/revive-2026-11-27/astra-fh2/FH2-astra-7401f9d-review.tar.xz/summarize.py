import glob
import json
import statistics

data = {
    p: [json.loads(line) for line in open(p)]
    for p in sorted(glob.glob("worst-*.jsonl"))
}
for i in range(12):
    row = next(rows[i] for rows in data.values() if len(rows) > i)
    main = [rows[i]["best_ns"] for p, rows in data.items() if "main" in p]
    head = [rows[i]["best_ns"] for p, rows in data.items() if "head" in p]
    median = statistics.median(main)
    print(f'{row["size"]} {row["position"]}: main_ns={main} head_ns={head} '
          f'delta={100 * (min(head) / median - 1):.2f}% '
          f'AA={100 * (max(main) / min(main) - 1):.2f}%')

counts = {}
for path in sorted(glob.glob("ir-*.txt")):
    for line in open(path):
        _, _, *name, value = line.split()
        counts.setdefault(" ".join(name), {}).setdefault(
            "main" if "main" in path else "head", []).append(int(value))
for name, runs in counts.items():
    if "head" not in runs:
        continue
    main = runs["main"]
    median = statistics.median(main)
    print(f'{name}: main={main} head={runs["head"]} '
          f'delta={100 * (runs["head"][0] / median - 1):.2f}% '
          f'AA={100 * (max(main) / min(main) - 1):.2f}%')
