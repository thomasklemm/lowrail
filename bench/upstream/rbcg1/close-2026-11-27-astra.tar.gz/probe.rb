require File.join(ENV.fetch('BENCH_ROOT'), 'harness/callgrind')

mode = ENV.fetch('PROBE_MODE', 'plain')
iteration = 0
if mode == 'pool'
  jobs = Queue.new
  results = Queue.new
  workers = 2.times.map do
    Thread.new do
      while jobs.pop
        results << 300.times.sum { |i| i * i }
      end
    end
  end
end

begin
  run_benchmark(5) do
    iteration += 1
    case mode
    when 'threads'
      2.times.map { Thread.new { 300.times.sum { |i| i * i } } }.each(&:value)
    when 'pool'
      2.times { jobs << true }
      2.times { results.pop }
    when 'chdir'
      Dir.chdir(ENV.fetch('CHDIR_TARGET'))
      300.times.sum { |i| i * i }
    when 'fail'
      300.times.sum { |i| i * i }
      raise 'expected measured iteration failure' if iteration == 4
    else
      300.times.sum { |i| i * i }
    end
  end
ensure
  if workers
    2.times { jobs << false }
    workers.each(&:join)
  end
end
