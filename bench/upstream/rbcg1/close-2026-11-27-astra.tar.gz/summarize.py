import csv
import json
import re
from pathlib import Path

root = Path(__file__).parent
rows = []
for run in sorted((root / 'runs').iterdir()):
    dumps = []
    for path in sorted(run.glob('cg.out.*')):
        text = path.read_text()
        summary = re.search(r'^summary: (\d+)$', text, re.M)
        totals = re.search(r'^totals: (\d+)$', text, re.M)
        if not summary or not totals:
            raise RuntimeError(f'incomplete dump: {path}')
        part = path.name.split('.')[3:]
        summary, totals = int(summary[1]), int(totals[1])
        rows.append([run.name, path.name, part[0] if part else 'exit', summary, totals, summary - totals])
        if part:
            dumps.append((int(part[0]), totals))
    result = run / 'result.json'
    if result.exists() and run.name.startswith('581-'):
        instructions = json.loads(result.read_text())['metrics']['instructions']['bench']
        assert instructions == [total for part, total in sorted(dumps)], run.name
    if '-fail-' in run.name:
        assert not result.exists(), run.name

with (root / 'summary.csv').open('w') as stream:
    writer = csv.writer(stream)
    writer.writerow(['run', 'dump', 'part', 'summary', 'totals', 'summary_minus_totals'])
    writer.writerows(rows)
for prefix in ['579-', '581-', 'fib-review579-', 'fib-review581-']:
    group = [row for row in rows if row[0].startswith(prefix) and row[2] != 'exit']
    print(prefix, 'numbered dumps', len(group), 'mismatches', sum(row[-1] != 0 for row in group))
print('All successful #581 probe JSON instruction samples equal numbered dump totals; failures wrote no result JSON.')
