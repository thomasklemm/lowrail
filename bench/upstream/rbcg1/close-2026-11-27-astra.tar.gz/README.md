# RBCG1 adversarial closure review, 2026-11-27

Verdict: changes on the proposed decision's full-supersession rationale. The exact
closing sentence is factually true and passes etiquette, but #581 does not provide
#579's exact summary/totals guarantee. Do not record the two as equivalent. Closing
anyway means deliberately retiring that guarantee in favor of the per-iteration
design, not demonstrating that the guarantee is superseded. No zero_stats follow-up
to #579 is recommended: the tested minimal edit still conflicts with #581.

Exact proposed sentence:

> Closing in favor of #581, which zeroes before each iteration and dumps before stopping.

If the coordinator deliberately accepts the remaining discrepancy and closes,
a less suggestive sentence is:

> Closing in favor of the per-iteration Callgrind reporting in #581.

## Pins and scope

- #579: d1ab8607b70bf0330e69bb81560e7647ac467af3.
- #581: 6942c05fcf444b302a7fa8fe05c9381edc6c729c.
- Both GitHub heads rechecked at the end of execution, unchanged; #581 remains draft.
- Ruby 4.0.9, revision 3e93b23afc, x86_64-linux; Valgrind 3.24.0;
  valgrind gem 0.0.2. The task explicitly requested this Ruby pin.
- Read Lowrail AGENTS.md, docs/DECISIONS.md, RBCG1 record, current PR metadata,
  maintainer comments, both harnesses and their diffs.
- No upstream writes, new threads, or subagents. No upstream product code changed.

## Executed evidence

`bash matrix.sh`: 28 runs: both exact heads, each repeated A/A, five measured
iterations after one warmup. Cases: plain interpreter, YJIT with call threshold 1,
instr-atstart=yes, failure on measured iteration 3, two new threads per iteration,
two persistent worker threads, chdir in warmup and measurements. Every successful
case returned results; both heads propagated the intended failure with a partial
dump and no result JSON. Absolute output paths were used.

Eight further runs used the author's run.sh unchanged (kept as author-run.sh),
both exact heads, three measured fib iterations after one warmup, interpreter and
ordinary --yjit, each repeated A/A. Invocation from the original review directory:

    RB_REPO=$ROOT/ruby-bench RB_WT_ROOT=$ROOT MIN_BENCH_ITRS=3 \
      bash $ROOT/author-run.sh review579 $ROOT/runs/fib-review579-interp-a

Repeat for review581, --yjit, and the aa directories. review579/review581 are local
refs fetched from refs/pull/579/head and refs/pull/581/head; the exact pins above
were checked against the worktrees. matrix.sh records its own execution settings.

`python3 summarize.py` validates successful #581 JSON instruction samples against
numbered dumps and failure JSON absence, and produces summary.csv. Decisive output:

    579- numbered dumps 14 mismatches 0
    581- numbered dumps 66 mismatches 66
    fib-review579- numbered dumps 4 mismatches 0
    fib-review581- numbered dumps 12 mismatches 12

These are correctness comparisons of fields in each dump, not performance claims
or like-for-like aggregate-versus-per-iteration instruction-count comparisons.
All runs have a repeated same-head control; thread/JIT totals can vary across A/A.

Demonstrated examples, summary / totals:

- #581 plain second iteration: 366717 / 366735 (same in A/A).
- #581 ordinary YJIT fib second iteration: 458218064 / 458218082 (same in A/A).
- #581 early-compiling YJIT probe second iteration: 828751 / 832129;
  repeat: 832373 / 835753. This is not just a display-rounding difference.
- #579 measured dumps match exactly in all cases above; it emits one aggregate
  measured dump rather than one per iteration, so compare equality, not totals.
- #581 exit dumps wrap near 2^64, including normal single-threaded fib. #579 exits
  0/0 for the single-threaded cases, but also has wrapped exit summaries when
  worker threads ran. Neither head makes every possible exit dump reliable.

`callgrind_annotate --auto=no` was run on all dumps in four representative probe
directories (579 plain, 581 plain, 581 YJIT, 581 pool); outputs are alongside dumps.
It reports 366717 PROGRAM TOTALS for the #581 dump whose totals is 366735.
Numbered dumps remained interpretable, without the old near-2^64 denominator.

Fetched and executed ZJITCallgrind.instruction_count from ruby/ruby's still-open
proposal at 3500842d155618c4461aabff27fb064882580ac4. It returns 366717 and 828751
for the #581 examples, versus totals 366735 and 832129. Its proposed workflow is
not deployed evidence: it remains pinned to older ruby-bench 01e54d3307d4bf4687fbef3538258dad46bccabd.
The direct parser test proves the effect on summary consumers, not adoption of
#581 by that workflow. Source and command output are retained.

## Merge experiment

`git merge-tree --write-tree review579 review581` exits 1 with conflicts in
harness/callgrind.rb and test/callgrind_harness_test.rb (merge-original.txt).

Moved #579's pre-start zero_stats to immediately before block.call, leaving its
existing single start/stop pair and final dump/zero behavior intact. This is a
minimal interpretation of the maintainer suggestion, not a proposed finished fix.
Kept suggestion.patch and a synthetic local commit's full diff in sources/.
`git merge-tree --write-tree HEAD review581` from that worktree again exits 1 on
both files (merge-suggestion.txt). Both sides now zero immediately before the
block; #581 also moves dumping to each iteration and reads totals. The minimal
edit alone would not preserve an aggregate multi-iteration counter and was not
run as a candidate fix.

## Text, relevance, and limits

#581 explicitly calls zero_stats before each measured block, dumps in that block's
ensure, and stops instrumentation in the outer ensure. The proposed sentence
does not literally promise equality or say the draft has merged. It is short,
neutral, on our PR, with no ping, credit claim, internal reference, or filler thanks.
The unresolved issue is the reason for closing, not these literal code-order facts.

Only cited project: ruby/ruby-bench, the target repository and location of the
replacement, directly relevant. Live API: 119 stars, unarchived, last pushed
2026-11-25T22:28:17Z. It is a benchmark repository, not a distributed gem;
RubyGems download/version checks do not apply. No project ordering issue.

No full suite or performance claim was needed for this read-only decision review.
Exactness probes covered the relevant changed execution boundaries: iteration
count, errors, threads, instrumentation configuration, JIT and chdir. No blanket
guarantee for other workloads or Valgrind versions is inferred.
