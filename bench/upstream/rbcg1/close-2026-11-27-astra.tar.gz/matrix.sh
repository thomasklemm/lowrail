#!/bin/bash
set -u
ROOT=/home/user/workspace/repo/.amp/in/orb-backup/rbcg1
export PATH=/home/user/.local/share/mise/installs/ruby/4.0.9/bin:$PATH
mkdir -p "$ROOT/runs" "$ROOT/chdir-target"
for head in 579 581; do
  for spec in plain:normal plain:yjit plain:atstart fail:normal threads:normal pool:normal chdir:normal; do
    mode=${spec%:*}; option=${spec#*:}
    for control in a aa; do
      out="$ROOT/runs/$head-$mode-$option-$control"
      mkdir -p "$out"
      flags=(); start=no
      [ "$option" = yjit ] && flags=(--yjit --yjit-call-threshold=1)
      [ "$option" = atstart ] && start=yes
      BENCH_ROOT="$ROOT/wt$head" PROBE_MODE="$mode" CHDIR_TARGET="$ROOT/chdir-target" \
        WARMUP_ITRS=1 MIN_BENCH_ITRS=5 HARNESS=callgrind RESULT_JSON_PATH="$out/result.json" \
        VALGRIND_OPTS="--callgrind-out-file=$out/cg.out.%p" \
        valgrind --tool=callgrind --instr-atstart="$start" ruby "${flags[@]}" "$ROOT/probe.rb" \
        > "$out/stdout" 2> "$out/stderr"
      echo $? > "$out/status"
      echo "$head $mode $option $control exit $(cat "$out/status")"
    done
  done
done
