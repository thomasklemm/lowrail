require ENV.fetch('HARNESS_PATH')

scenario = ENV.fetch('SCENARIO')
calls = 0
jobs = Queue.new
done = Queue.new
workers = if scenario == 'pool'
  2.times.map do |i|
    Thread.new do
      while n = jobs.pop
        sum = 0
        (n * 3000).times { |j| sum += j % (i + 3) }
        done << sum
      end
    end
  end
else
  []
end

begin
  run_benchmark(4) do
    calls += 1
    sum = 0
    3000.times { |i| sum += i % 7 }
    case scenario
    when 'threads'
      sums = 2.times.map do |n|
        Thread.new do
          x = 0
          ((n + 1) * 3000).times { |i| x += i % 3 }
          x
        end
      end.map(&:value)
      raise 'wrong thread result' unless sums == [3000, 6000]
    when 'pool'
      jobs << 1 << 2
      2.times { done.pop }
    when 'failure'
      raise 'deliberate mid-iteration failure' if calls == 3
    else
      raise "unknown scenario #{scenario}"
    end
    raise 'wrong main result' unless sum == 8994
  end
ensure
  workers.size.times { jobs << nil }
  workers.each(&:join)
end
