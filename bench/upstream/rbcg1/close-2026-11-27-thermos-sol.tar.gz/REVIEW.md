# RBCG1 closure review

**Verdict: nits on the closing line; approve closing the competing implementation, with a required correction to the internal rationale.** #581 replaces the profiling approach and removes the huge wrapped summaries from the measured iteration dumps in these probes. It does **not** provide #579's exact `summary: == totals:` result. Closing is reasonable as yielding to the maintainer's replacement design, not as certifying equivalent behavior.

## Exact scope and text

Reviewed on 2026-11-27, applying both Thermos correctness/security and maintainability rubrics myself, without subagents or other threads, as requested. This is the requested thermos-sol pass on the closure decision and text, not approval to merge the whole of #581. Nothing was posted upstream, no PR was closed, and no tracked repository files were changed.

- Lowrail rules read from `AGENTS.md` and `docs/DECISIONS.md`; helper and author's archive read from Lowrail `origin/main` after fetching (resolved to `ee485c134cb7ad6edd39bc766a8274238e2127db`, including `568d6474`).
- ruby-bench main: `43d41e22d7fa42e15d07b44e8c78c44960a3feac`. Its Callgrind harness is byte-identical to #579's base, `0e67be03ef1bb943fe8e077b6482baaaf9784363`.
- #579: `d1ab8607b70bf0330e69bb81560e7647ac467af3`.
- #581: `6942c05fcf444b302a7fa8fe05c9381edc6c729c`.
- Both PR heads were re-read with `gh api` at the end and still matched those pins. #579 was open; #581 was open and draft. Draft status is not evidence that the replacement has landed.

Exact proposed line:

> Closing in favor of #581, which zeroes before each iteration and dumps before stopping.

The mechanism is true for **measured** iterations at the reviewed head: zero immediately precedes `block.call`, the inner `ensure` dumps even when that block raises, and the outer `ensure` stops instrumentation afterwards. Warmup is not zeroed per iteration. A precision nit is to add one word:

> Closing in favor of #581, which zeroes before each measured iteration and dumps before stopping.

Both lines are approved in their profiling context; the second is preferred. Neither line claims exact summary equality, a clean exit dump, merge readiness, or that every Valgrind mode works. Both are one neutral line, contain no I/we, ping, internal detail, credit claim, unrequested measurement, or request for action. The reference to the replacement belongs on our PR; no comment on #581 is needed. An added thank-you is not necessary for this concise closing fact.

## Correctness: the replacement is not an exact fix

Installed `valgrind` gem 0.0.2 under mise Ruby 4.0.9 (`3e93b23afc`, Linux x86-64); Valgrind/Callgrind 3.24.0. Ran **66 independent Valgrind processes** across all three heads, interpreter and `--yjit`. The author's dumps were not used as my measurement results; inspected afterwards, they also show the -2/-18 discrepancies.

`run_matrix.py` records each command, environment used for the benchmark, SHA, exit status, stdout, stderr, JSON results, and every raw dump. The standard command shape was:

```sh
WARMUP_ITRS=1 MIN_BENCH_ITRS=2 HARNESS=callgrind \
RESULT_JSON_PATH="$OUT/results.json" \
VALGRIND_OPTS="--callgrind-out-file=$OUT/cg.out.%p" \
valgrind --tool=callgrind --instr-atstart=no ruby [--yjit] benchmarks/fib.rb
```

Representative A-side results, written as `summary / totals`:

| Head | Interpreter | YJIT |
| --- | --- | --- |
| main, two iterations in .1 | 18446744073709549754 / 3919337446 | 18446744073709549427 / 916398292 |
| #579, two iterations in .1 | 3919339161 / 3919339161 | 916400153 / 916400153 |
| #581, first iteration in .1 | 1959700585 / 1959700587 | 458232283 / 458232285 |
| #581, second iteration in .2 | 1959687797 / 1959687815 | 458218064 / 458218082 |

Fresh A/A repeats were retained for all three heads in both modes. Main and #579 repeated those counts exactly. #581 did not repeat absolute counts exactly: interpreter first-iteration totals 1959700587 versus 1959700109, YJIT 458232285 versus 461756627. These are diagnostic correctness observations, not performance prices or speed claims; do not derive a claimed optimization from them. The conclusion that #581's measured summaries are non-wrapped but unequal to totals held in both repeats.

Across all probes, #579's **22/22 explicit measured dumps matched exactly**; #581's **0/64 matched exactly**, including the numbered main-thread dumps produced before its separate-thread runs failed. For #581, measured summary-minus-totals ranged from **-69 to +988 Ir**. These counts exclude process-exit dumps and the empty root file Callgrind creates with separate-thread output.

`analyze.py` verified every exit status, deliberate failure message, absence of result JSON on workload failure, and that every successful #581 JSON instruction series equals the corresponding raw dump **totals**. This verifies the new harness's own count source without treating that as a fix to all external readers of `summary:`.

`callgrind_annotate --threshold=99` was executed on main/#579/#581 A-side .1 dumps in both modes, and its text retained. Interpreter PROGRAM TOTALS changed from main's 18,446,744,073,709,549,754 to #579's 3,919,339,161 and #581's per-iteration 1,959,700,585. Main's `vm_exec_core` row showed 0.00%; meaningful percentages returned with both branches. #581's denominator remains its slightly incorrect summary, not its totals.

### Boundary probes and attribution

- **More iterations:** original `benchmarks/fib.rb` with five measured iterations, both modes. #579's one aggregate dump matched exactly. #581 produced five non-wrapped dumps, with first summary 2 below totals and later summaries 18 below totals.
- **Instrumentation already on:** original fib with `--instr-atstart=yes`, both modes. #579 remained exact; #581 still differed by -2/-18. This does not depend on remembering `--instr-atstart=no`.
- **Failure in the second measured iteration:** a deliberate exception after nontrivial integer work, with one warmup, both modes and both atstart settings. All heads propagated the original deliberate error and wrote no result JSON. #579's aggregate partial profile matched. #581 retained the completed iteration and a partial failing iteration; its failing-iteration summary was 23 below totals. The exit dump shows no continued benchmark instrumentation, consistent with the outer ensure.
- **Threads:** two new workers per iteration and a persistent two-worker pool, four measured iterations, both modes and both atstart settings. All default-output runs completed. #579 explicit dumps matched. #581 summaries differed, including +988 Ir in a new-worker YJIT iteration and -64 Ir in later persistent-pool iterations. Thus exact equality is not a general thread invariant of #581.
- **Exit dump:** #581's unsuffixed file still wraps. One interpreter fib example is summary 18446744069789922844, totals 139769. This is newly nonempty/wrapped versus main and single-thread #579 (both 0/0). #579 itself already has wrapped exit summaries after worker-thread activity despite zero exit totals; its current-thread reset does not promise a universally clean threaded exit profile.
- **`--separate-threads=yes`:** additional probe, both modes. Main and #579 complete. #581 exits 1 after producing `.1-01` because its new reader expects `.1`; the error wrongly tells the caller to pass the output option through `VALGRIND_OPTS`, which this run already did. This is a demonstrated #581 readback regression at `harness/callgrind.rb:47-49`, not an existing main bug and not evidence of malicious/security behavior.

The exit dump is not a measured iteration and should not be used as one. I also read ruby/ruby PR 19851's `zjit_callgrind.rb` at `3500842d155618c4461aabff27fb064882580ac4`: it explicitly selects `.1` and excludes the process-exit file. That WIP consumer separately still expects the output option as a command-line token, whereas #581 moves it inside an environment assignment; this is not certification that the two WIP PRs compose unchanged.

These gaps would matter to an approval of #581 as a universal replacement with identical behavior. They do not justify maintaining our now-competing profiling implementation while the maintainer rewrites this area. No upstream follow-up on #581 is proposed.

## Maintainability: do not add a competing zeroing commit

`git merge-tree --write-tree d1ab8607b70bf0330e69bb81560e7647ac467af3 6942c05fcf444b302a7fa8fe05c9381edc6c729c` exited **1**, with content conflicts in `harness/callgrind.rb` and `test/callgrind_harness_test.rb`; complete output retained in `merge-tree.txt`.

The maintainer's suggestion, verified from the two 2026-11-18 comments on #579, is already present in #581: start once, zero immediately before each measured block, and dump before the final stop. Adding that mechanism to #579 would duplicate #581's lifecycle work rather than supply a missing independent concern. The exact original branches already conflict; no hypothetical zero_stats commit was fabricated or merged.

Not preserved from #579: one aggregate profile for all measured iterations, hoisting the benchmark name out of the measured region, a post-stop zero for the current thread, exact measured summary equality, and compatibility with separate-thread filenames. #581 deliberately adopts a different per-iteration contract and reads totals itself. Keeping a second implementation and its sequence tests open has no maintainability advantage over closing ours and keeping these limitations in the internal record.

Cold read: #579 zeroes once before the measured region and dumps once before stopping; #581 zeroes and dumps inside each iteration while keeping instrumentation enabled across iterations. This is direct lifecycle code with no reason for a new abstraction in our branch. No security issue was identified in the closure/text scope. This review does not authorize #581's unrelated metric-rendering changes to merge.

Flog 4.10.0 and RuboCop 1.93.0 Metrics results retained: `run_benchmark` flog main 39.8, #579 39.6, #581 42.6; #581's `callgrind_dump_ir` 10.7. ABC sizes 29.07, 29.29, 31.08; method lengths 26, 28, 34. The increase reflects per-iteration dump/readback and result-series responsibilities and does not argue for adding more lifecycle logic to #579. The #581 harness is 99 lines; its results-table test file is already over 1000 lines on the base, so there is no newly crossed threshold there.

## Checks and limitations

- Targeted command on each head: `BUNDLE_WITHOUT=graph mise exec ruby@4.0.9 -- bundle exec ruby -Itest test/callgrind_harness_test.rb`. Main: 8 runs, 27 assertions; #579: 8 runs, 27 assertions; #581: 11 runs, 36 assertions. All had 0 failures, 0 errors, 0 skips.
- A broader #581 suite run excluding the graph-renderer test file still reached an indirect graph-rendering test: **373 runs, 1351 assertions, 0 failures, 1 error, 17 skips**. The error was inability to build the auto-installed rmagick native extension, not a demonstrated PR regression. Earlier direct non-Bundler suite attempts were invalid because of missing graph dependencies / competing Minitest versions; those logs are retained, not claimed green. No full-suite green claim is made.
- This is a Linux x86-64 Ruby 4.0.9 diagnostic reproduction, not another Ruby/Valgrind/platform certification, wall-time measurement, JIT-flat performance gate, or exhaustive proof for arbitrary benchmark overrides. The relevant exactness boundaries here were measured-region entry/exit, exceptions, extra iterations, thread lifetimes, readback filenames, and caller-selected instrumentation state; no production object-transform optimization was proposed.
- Re-run entry points: `python3 run_matrix.py interp`, `python3 run_matrix.py yjit`, and the same commands with `boundaries` or `separate` as a second argument, then `python3 analyze.py`. Use a fresh results directory and fetch the recorded ruby-bench heads first. Each run's `command.json` is the exact invocation used here.

**Required record correction:** replace “#581 guarantees each summary equals totals / fully covers the exact purpose” with “#581 supersedes this implementation and removes the wrapped measured summaries in the reproduced cases; exact summary equality and all output modes are not covered.” The original closing line has no must-fix beyond that internal rationale; adding “measured” is a precision nit. No zero_stats commit is requested.
