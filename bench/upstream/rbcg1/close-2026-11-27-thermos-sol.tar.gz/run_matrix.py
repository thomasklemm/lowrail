import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
RUBY = Path('/home/user/.local/share/mise/installs/ruby/4.0.9/bin')
HEADS = {
    'main': '43d41e22d7fa42e15d07b44e8c78c44960a3feac',
    'pr579': 'd1ab8607b70bf0330e69bb81560e7647ac467af3',
    'pr581': '6942c05fcf444b302a7fa8fe05c9381edc6c729c',
}

mode = sys.argv[1]
group = sys.argv[2] if len(sys.argv) > 2 else 'fib'
out = ROOT / 'results' / f'{group}-{mode}'
out.mkdir(parents=True, exist_ok=False)
if group == 'fib':
    cases = [('fib-a', 'no', 2, None), ('fib-aa', 'no', 2, None)]
elif group == 'boundaries':
    cases = [('fib-five', 'no', 5, None), ('fib-atstart', 'yes', 2, None)]
    cases += [(case, atstart, 4, None)
              for case in ['failure', 'threads', 'pool']
              for atstart in ['no', 'yes']]
elif group == 'separate':
    cases = [('threads', 'no', 3, '--separate-threads=yes')]
else:
    raise ValueError(group)

rows = []
for case, atstart, iterations, option in cases:
    for name, head in HEADS.items():
        worktree = ROOT / f'wt-{name}'
        if not worktree.exists():
            subprocess.run(['git', '-C', str(ROOT / 'ruby-bench'), 'worktree', 'add',
                            '--quiet', '--detach', str(worktree), head], check=True)
        dest = out / f'{case}-{atstart}-{name}'
        dest.mkdir()
        env = os.environ.copy()
        for key in ['RUBYOPT', 'BUNDLE_GEMFILE', 'BUNDLER_SETUP', 'GEM_HOME', 'GEM_PATH']:
            env.pop(key, None)
        env.update(PATH=f'{RUBY}:{env["PATH"]}', WARMUP_ITRS='1',
                   MIN_BENCH_ITRS=str(iterations), HARNESS='callgrind',
                   RESULT_JSON_PATH=str(dest / 'results.json'),
                   VALGRIND_OPTS=f'--callgrind-out-file={dest}/cg.out.%p',
                   HARNESS_PATH=str(worktree / 'harness/callgrind.rb'), SCENARIO=case)
        bench = 'benchmarks/fib.rb' if case.startswith('fib') else str(ROOT / 'boundary.rb')
        cmd = ['valgrind', '--tool=callgrind', f'--instr-atstart={atstart}']
        if option:
            cmd.append(option)
        cmd += ['ruby'] + (['--yjit'] if mode == 'yjit' else []) + [bench]
        (dest / 'command.json').write_text(json.dumps({'head': head, 'cmd': cmd,
            'cwd': str(worktree), 'env': {k: env[k] for k in ['WARMUP_ITRS',
            'MIN_BENCH_ITRS', 'HARNESS', 'RESULT_JSON_PATH', 'VALGRIND_OPTS',
            'HARNESS_PATH', 'SCENARIO']}}, indent=2))
        print(f'RUN {mode} {case} atstart={atstart} {name}', flush=True)
        with (dest / 'stdout').open('w') as stdout, (dest / 'stderr').open('w') as stderr:
            result = subprocess.run(cmd, cwd=worktree, env=env, stdout=stdout, stderr=stderr)
        (dest / 'exit-status').write_text(str(result.returncode) + '\n')
        dumps = []
        for path in sorted(dest.glob('cg.out.*')):
            data = path.read_text()
            summary = re.search(r'^summary: (.*)$', data, re.M)
            totals = re.search(r'^totals: (.*)$', data, re.M)
            row = {'file': path.name, 'summary': summary[1] if summary else None,
                   'totals': totals[1] if totals else None}
            if summary and totals:
                row['delta'] = int(summary[1].split()[0]) - int(totals[1].split()[0])
            dumps.append(row)
        rows.append({'case': case, 'atstart': atstart, 'head': name,
                     'status': result.returncode, 'dumps': dumps})
        print(json.dumps(rows[-1]), flush=True)
        (out / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
