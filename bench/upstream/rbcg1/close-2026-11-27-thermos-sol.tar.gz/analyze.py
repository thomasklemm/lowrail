import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
all_rows = []
for path in sorted((root / 'results').glob('*/summary.json')):
    rows = json.loads(path.read_text())
    print(path.parent.name, 'runs=', len(rows))
    for row in rows:
        case_dir = path.parent / f'{row["case"]}-{row["atstart"]}-{row["head"]}'
        err = (case_dir / 'stderr').read_text()
        expected = 1 if row['case'] == 'failure' or (
            path.parent.name.startswith('separate') and row['head'] == 'pr581') else 0
        assert row['status'] == expected, (case_dir, row['status'], expected)
        if row['case'] == 'failure':
            assert 'deliberate mid-iteration failure' in err, case_dir
            assert not (case_dir / 'results.json').exists(), case_dir
        if path.parent.name.startswith('separate') and row['head'] == 'pr581':
            assert 'callgrind dump not found' in err, case_dir
        if (case_dir / 'results.json').exists() and row['head'] == 'pr581':
            result = json.loads((case_dir / 'results.json').read_text())
            measured = [dump for dump in row['dumps']
                        if re.search(r'\.\d+\.\d+$', dump['file'])]
            counts = [int(dump['totals']) for dump in measured]
            assert result['primary_metric'] == 'instructions'
            assert result['metrics']['instructions']['bench'] == counts, case_dir
        row['group'] = path.parent.name
        all_rows.append(row)

print('total runs:', len(all_rows))
for head in ['main', 'pr579', 'pr581']:
    rows = [row for row in all_rows if row['head'] == head]
    measured = [dump for row in rows for dump in row['dumps']
                if re.search(r'\.\d+\.\d+(?:-01)?$', dump['file'])]
    deltas = [dump['delta'] for dump in measured]
    print(head, 'measured dumps=', len(measured), 'exact matches=', deltas.count(0),
          'delta range=', [min(deltas), max(deltas)])

for mode in ['interp', 'yjit']:
    rows = [row for row in all_rows if row['group'] == f'fib-{mode}']
    print('A/A', mode)
    for head in ['main', 'pr579', 'pr581']:
        selected = [row for row in rows if row['head'] == head]
        print(head, [[(dump['summary'], dump['totals']) for dump in row['dumps']
                      if re.search(r'\.\d+\.\d+$', dump['file'])]
                     for row in selected])

(root / 'results' / 'combined-summary.json').write_text(json.dumps(all_rows, indent=2) + '\n')
