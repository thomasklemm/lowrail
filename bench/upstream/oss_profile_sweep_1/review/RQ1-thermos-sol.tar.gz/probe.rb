require "open3"
require "rqrcode_core"

repo = ARGV.fetch(0)
util = RQRCodeCore::QRUtil
head = util.method(:rszf)
base_source, status = Open3.capture2("git", "-C", repo, "show", "ca75f7a55a29ecb990fc70f1a372a5c9724ae02d:lib/rqrcode_core/qrcode/qr_util.rb")
abort "git show failed" unless status.success?
util.class_eval(base_source[/    def self\.rszf\(num, count\).*?^    end/m])
base = util.method(:rszf)
bits = util::ARCH_BITS
values = (-1024..1024).to_a
([0, 1, 2, 30, 31, 32, 62, 63, 64, 65, 127, 128, 255, 256, 1024, 4096] + [bits - 1, bits, bits + 1]).uniq.each do |power|
  next if power < 0
  (-3..3).each do |delta|
    values << (1 << power) + delta
    values << -((1 << power) + delta)
  end
end
values.uniq!
counts = ((-80..100).to_a + [bits - 1, bits, bits + 1, 255, 256, 1024, 4096, 1 << 100]).uniq
checked = 0
values.each do |n|
  counts.each do |c|
    a, b = base.call(n, c), head.call(n, c)
    abort "DIFF bits=#{bits} n=#{n} c=#{c}: #{a} != #{b}" unless a == b
    checked += 1
  end
end
rng = Random.new(80231)
100_000.times do
  n = rng.rand(-(1 << 256)..(1 << 256))
  c = rng.rand(-80..300)
  abort "random difference #{[bits, n, c]}" unless base.call(n, c) == head.call(n, c)
  checked += 1
end
puts "ARCH_BITS=#{bits}: #{checked} integer pairs equal"

if bits == 64
  n = (1 << 63) | 3
  [0.5, 1.5, Rational(3, 2)].each do |c|
    puts "fractional count #{c.inspect}, n=#{n}: base=#{base.call(n, c)}, head=#{head.call(n, c)}"
  end
  duck = Object.new
  def duck.>>(count) = 11 >> count
  begin
    result = head.call(duck, 1)
  rescue => error
    result = "#{error.class}: #{error.message.lines.first.strip}"
  end
  puts "shift duck: base=#{base.call(duck, 1)}, head=#{result}"
  [base, head].each_with_index do |implementation, side|
    begin
      result = implementation.call(0, -(1 << 100))
    rescue => error
      result = "#{error.class}: #{error.message}"
    end
    puts "enormous negative count, num=0, #{side.zero? ? 'base' : 'head'}=#{result}"
  end
end
