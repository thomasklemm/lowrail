require "open3"
require "fileutils"
root = File.expand_path("../../../..", __dir__)
worker_path = File.join(root, "script/upstream-bench")
worker = File.read(worker_path).sub("3000.times { call.call }", "300.times { call.call }").sub("[1000, 2000]", "[100, 200]").sub("(counts[1] - counts[0]) / 1000.0", "(counts[1] - counts[0]) / 100.0")
scratch_worker = File.join(__dir__, "bounded-worker.rb")
File.write(scratch_worker, worker)
bench = File.join(root, "bench/upstream/oss_profile_sweep_1/rq1_body.rb")
env = {
  "RUBYOPT" => nil, "RUBY_YJIT_ENABLE" => nil, "BUNDLE_GEMFILE" => nil,
  "RUBY_GC_HEAP_0_INIT_SLOTS" => "1000000", "RUBY_GC_HEAP_1_INIT_SLOTS" => "250000",
  "RUBY_GC_HEAP_2_INIT_SLOTS" => "100000", "RUBY_GC_HEAP_3_INIT_SLOTS" => "20000",
  "RUBY_GC_HEAP_4_INIT_SLOTS" => "10000"
}
File.open(File.join(__dir__, "bounded-objects.log"), "w") do |log|
  log.puts RUBY_DESCRIPTION
  log.puts "Original objects worker: 300 warmup calls; 100/200 measured calls instead of 3000; 1000/2000 (4 GiB orb OOM). Same fixed heap; GC disabled in both measured windows. Objects only."
  [64, 32].each do |bits|
    [[], ["--yjit"]].each do |flags|
      %w[base rqrcode_core base].each_with_index do |side, index|
        dir = File.join(__dir__, side)
        output, status = Open3.capture2e(env.merge("RQRCODE_CORE_ARCH_BITS" => bits.to_s), RbConfig.ruby, *flags, "-I#{dir}/lib", scratch_worker, "--worker", "objects", bench)
        abort output unless status.success?
        line = "bits=#{bits} mode=#{flags.empty? ? 'interp' : 'yjit'} side=#{side} run=#{index}: #{output.strip}"
        puts line
        log.puts line
        log.flush
      end
    end
  end
end
