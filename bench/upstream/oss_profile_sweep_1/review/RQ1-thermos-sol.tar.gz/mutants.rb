require "rqrcode_core"
util = RQRCodeCore::QRUtil
bits = util::ARCH_BITS
mutants = {
  original: util.method(:rszf),
  bare_shift: ->(num, count) { num >> count },
  no_upper_bound: ->(num, count) { (num >= 0) ? num >> count : (num >> count) & ((1 << (bits - count)) - 1) },
  no_sign_guard: ->(num, count) { (num < (1 << bits)) ? num >> count : (num >> count) & ((1 << (bits - count)) - 1) },
  inclusive_limit: ->(num, count) { (num >= 0 && num <= (1 << bits)) ? num >> count : (num >> count) & ((1 << (bits - count)) - 1) },
  fixed_32_bit_mask: ->(num, count) { (num >> count) & ((1 << (32 - count)) - 1) },
  javascript_modulo_count: ->(num, count) { (num >> (count % bits)) & ((1 << (bits - count % bits)) - 1) }
}
require "test_helper"
require File.join(ARGV.fetch(0), "test/rqrcode_core/rqrcode_test")
mutants.each do |name, implementation|
  util.define_singleton_method(:rszf, implementation)
  test = RQRCodeCore::BaseTest.new("test_rszf_zero_fills_outside_the_architecture_range")
  result = test.run
  puts "#{name}: #{result.passed? ? 'SURVIVES' : 'KILLED'}"
end
util.define_singleton_method(:rszf, mutants.fetch(:original))
Minitest.class_variable_set(:@@installed_at_exit, true) if Minitest.class_variable_defined?(:@@installed_at_exit)
exit! 0
