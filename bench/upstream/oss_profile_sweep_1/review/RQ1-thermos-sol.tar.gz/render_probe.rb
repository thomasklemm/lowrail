require "open3"
require "digest"
require "rqrcode"
util = RQRCodeCore::QRUtil
head = util.method(:rszf)
source, status = Open3.capture2("git", "-C", ARGV.fetch(0), "show", "ca75f7a55a29ecb990fc70f1a372a5c9724ae02d:lib/rqrcode_core/qrcode/qr_util.rb")
abort "git show failed" unless status.success?
util.class_eval(source[/    def self\.rszf\(num, count\).*?^    end/m])
base = util.method(:rszf)
count = 0
digest = Digest::SHA256.new
%i[l m q h].each do |level|
  ["", "01234567890123", "Hello 世界", "otpauth://totp/Redmine:jsmith%40somenet.foo?secret=ABCDEFGHIJKLMNOPQRSTUVWXYZ234567&issuer=Redmine"].each do |data|
    bytes = [base, head].map do |implementation|
      util.define_singleton_method(:rszf, implementation)
      qr = RQRCode::QRCode.new(data, level: level)
      [qr.to_s, qr.as_svg, qr.as_ansi, qr.as_png(size: 211).to_s]
    end
    abort "render difference" unless bytes[0] == bytes[1]
    digest.update(Marshal.dump(bytes[0]))
    count += 1
  end
end
puts "rqrcode=#{RQRCode::VERSION}, ARCH_BITS=#{util::ARCH_BITS}: #{count} cases x text/SVG/ANSI/PNG byte-identical; SHA256=#{digest.hexdigest}"
