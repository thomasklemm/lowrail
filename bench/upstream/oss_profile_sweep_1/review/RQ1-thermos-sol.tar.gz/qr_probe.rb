require "open3"
require "digest"
require "rqrcode_core"

repo = ARGV.fetch(0)
util = RQRCodeCore::QRUtil
head = util.method(:rszf)
base_source, status = Open3.capture2("git", "-C", repo, "show", "ca75f7a55a29ecb990fc70f1a372a5c9724ae02d:lib/rqrcode_core/qrcode/qr_util.rb")
abort "git show failed" unless status.success?
util.class_eval(base_source[/    def self\.rszf\(num, count\).*?^    end/m])
base = util.method(:rszf)

cases = []
%i[l m q h].each do |level|
  ["", "0", "012345678901234567890123456789", "HELLO 19 / QR", "x", "Hello 世界 😀", "otpauth://totp/Redmine:jsmith%40somenet.foo?secret=ABCDEFGHIJKLMNOPQRSTUVWXYZ234567&issuer=Redmine", (0..255).to_a.pack("C*"), "z" * 1200].each do |text|
    cases << [text, {level: level}]
  end
  [1, 2, 7, 10, 20, 40].each { |size| cases << ["QR3", {size: size, level: level}] }
  cases << [[{data: "123456789012", mode: :number}, {data: "a!", mode: :byte_8bit}], {level: level}]
end
rng = Random.new(3881)
100.times do
  cases << [Array.new(rng.rand(1..120)) { rng.rand(32..126).chr }.join, {level: %i[l m q h].sample(random: rng)}]
end

digest = Digest::SHA256.new
cases.each_with_index do |(data, options), index|
  util.define_singleton_method(:rszf, base)
  old_qr = RQRCodeCore::QRCode.new(data, **options)
  util.define_singleton_method(:rszf, head)
  new_qr = RQRCodeCore::QRCode.new(data, **options)
  old_bytes = Marshal.dump([old_qr.version, old_qr.modules, old_qr.to_s])
  new_bytes = Marshal.dump([new_qr.version, new_qr.modules, new_qr.to_s])
  abort "QR difference at #{index}" unless old_bytes == new_bytes
  digest.update(old_bytes)
end
puts "ARCH_BITS=#{util::ARCH_BITS}: #{cases.size} QR matrices and text byte-identical; SHA256=#{digest.hexdigest}"
