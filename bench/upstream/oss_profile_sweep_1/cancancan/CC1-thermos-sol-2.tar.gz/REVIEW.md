# CC1 candidate review

Verdict: **nits**. The code and test trim are approved; no dropped spec must stay. Remove one unnecessary upstream-body sentence and correct the evidence README's count of removed specs. Both exact editorial edits below are approved.

Reviewed on 2026-11-27 in orb `T-01a21d34-07d6-72b5-adf5-2542f9808e5b`. Both Thermos rubrics were applied directly by this reviewer, as requested. No independent second reviewer, subagent or other review thread was used.

## The three removed specs guard code this PR no longer changes

The candidate is [cd1f37066b](https://github.com/thomasklemm/cancancan/commit/cd1f37066ba0ce0515a09346264eb33ea1bf38d9) on fork branch `thomasklemm/rule-construction-allocations-review`. Its only parent is upstream main [021b13cf76](https://github.com/coorasse/cancancan/commit/021b13cf762ba95784bf00a467c0ce86120fdf12). Both remote refs were checked again at the end of the audit and still had these values.

Relative to [cb5768e493](https://github.com/thomasklemm/cancancan/commit/cb5768e493042c026ef4d808e8574a9db68aeecd), the sole change is deletion of the three named specs. `lib/` has tree ID `17caa289d6591ca865ab958e7806444a467cb4e1` in both heads; `CHANGELOG.md` has blob ID `ca1c030d46eb47b7df770893b813bbf0493dcd30` in both.

The dropped nil-equality, Array-subclass iteration and mutation-during-indexing specs are behavioral, not implementation assertions. Nevertheless, they protect the rejected index optimization rather than the remaining parser-only change. `Ability::Rules#add_rule_to_index` is identical to base, including the detached `compact` result and empty-list fallback. DECISIONS requires tests for plausible behavioral regressions in the change, not permanent tests for every rejected design. Dropping these three is the right scope reduction.

Keep both remaining specs. The first detects changed authorization when attribute conversion mutates the actions array; the second detects an attribute-conversion exception incorrectly replacing `BlockAndConditionsError`. They exercise `can` and `can?`, assert observable behavior and have no allocation or private-helper assertions.

As a negative control, all five former added specs were loaded from the previous head and run against base, candidate and rejected original head [2a5e8c71d1](https://github.com/thomasklemm/cancancan/commit/2a5e8c71d19569d43c7fec09dfb7012721f792e2): base 5/0, candidate 5/0, original 5/5. The original failures are precisely those five examples. No checked-out source file was modified to run this control.

## Every body claim and table cell is supported

The queue item was read from Lowrail `origin/main` at [cda18f878d](https://github.com/thomasklemm/lowrail/commit/cda18f878d370151cbc4d419258247b9d5ee9657); the audited body ends before `## For Thomas`.

| Body sentence or number | Audit |
| --- | --- |
| Title, “Allocate less when a rule is defined” | Accurate: the temporary parser-result pair is removed. |
| “Applications that build an ability per request pay the cost of defining its rules each time.” | Accurate conditional statement; the public `can`/`cannot` methods immediately construct a Rule, and the supplied initializer defines the rules on each instantiation. No claim that all applications build an ability per request. |
| “`Rule#initialize` gets the parsed attributes and conditions back from a helper in a temporary two-element array, then immediately unpacks it.” | Base `Rule#initialize` and `parse_attributes_from_extra_args` show exactly this. |
| “Read those arguments directly instead, keeping validation and conversion in their existing order.” | Verified by the diff and differential probes. Validation, action normalization, subject conversion and attribute conversion retain their order. The repeated `extra_args.first` reads an owned splat Array, not a user-provided Array. |
| “This saves one array per rule, five for this ability:” | Base creates one result pair for each Rule. The example has four `can` calls and one `cannot`, all executed. Replayed object counts confirm five fewer objects. |
| Script | Byte-identical to `body/CC1-objects/objects.rb`. Ran as printed, without warming or changing it, using Ruby 4.0.9 revision `3e93b23afc`. Base/head/base prints 57/52/57 in interpreter and YJIT modes. |
| Table caption | Correct unit, per `Ability.new`, and correct Ruby version. |
| Objects 57 / 52 | Independently replayed as above, also agrees with the kept allocation-worker record. |
| No-JIT Callgrind 82,753 / 79,547 | Recomputed from committed raw totals using `(N2000 - N0) / 2000`, then the mean of the two base runs and rounding. Base runs 82,752.8055 and 82,753.3695; candidate 79,546.7275. A/A 0.0006815%. |
| YJIT Callgrind 42,921 / 41,418 | Same computation: base runs 42,930.23 and 42,911.1235; candidate 41,417.6625. Mean base 42,920.67675; A/A 0.0445158%. All six raw JIT windows have unchanged compilation and invalidation counters. |
| “benchmark-ips could not resolve a wall-time difference.” | Factually supported, but remove from the upstream body as unnecessary methodology. All three paired effects fall inside their A/A spread: -0.0511% vs 5.7897%, +10.6585% vs 11.2685%, +2.7333% vs 4.6683%. Individual dispersion is 12.0–15.5%. Keep these facts in the record. |

The retained Callgrind data is applicable because the measured library tree, Ruby pin and five-rule workload are unchanged. This review audited the raw totals, A/A and JIT-flat windows; it did **not** run a new Callgrind cohort or a new benchmark-ips cohort. Instruction counts are not presented as time. The deterministic allocation script is more useful here than restoring an unresolved throughput example.

## Suites and differential checks pass on the exact head

Installed the prebuilt Ruby 3.4.13 with `MISE_RUBY_COMPILE=false`; Ruby 4.0.9 was already installed and verified. Restored the same dependency lock into both disposable checkouts. Active Record is 8.1.4.1, RuboCop 1.31.2; both locks have SHA-256 `037e164b6c2b3ab03bd794059d715c9db42936bf3e9915ba356bebff7ddcfb01`.

On base and candidate, with `BUNDLE_GEMFILE=gemfiles/activerecord_8.1.0.gemfile`, `DB=sqlite`:

| Executed check | Base | Candidate |
| --- | --- | --- |
| `bundle exec rspec --seed 1234` | 716 examples, 0 failures, 3 pending | 718 examples, 0 failures, 3 pending |
| `bundle exec rubocop --format simple` | 64 files, no offenses | 64 files, no offenses |
| Previous 127-case differential, Ruby 3.4.13 | Matches candidate byte-for-byte | Matches base byte-for-byte |
| Additional 34 public parser-boundary cases, Ruby 4.0.9, interpreter and YJIT | Matches candidate in each mode | Matches base in each mode |

Compared all suite outcomes with multiplicity by full description, status, pending message and exception details. No base outcome was removed or changed; the only additions are the two passing initializer-order specs. Existing bundled-gem and rubocop-ast deprecation warnings print on both sides; they are not failures.

The 127-case probe covers ordinary signatures, aliases, SQL/scope/Hash/block conditions, nil and empty inputs, shared arrays, frozen inputs, copy/aliasing behavior, `can?`, `accessible_by`, permissions and the three dropped index cases. The additional probe covers singleton methods, prepends, Array/Hash/String subclasses, public/private `to_ary`, `method_missing`/`respond_to_missing?`, conversion call traces, raising and invalid conversions, mutation while fibers are suspended inside conversions, frozen results/receivers and exception classes/messages. Standalone `require 'cancancan'` and Active-Record-first load order were both exercised. No configuration read changes. Private Rule-method overrides, global core redefinitions and ObjectSpace access to internal arrays remain outside the adopted contract.

## The parser-only change remains simple

Cold read: take optional attributes, validate the conditions/block combination, normalize actions, wrap subjects and attributes, and store conditions and block. There is no new helper, guard, ownership-sensitive reuse, scan or input-dependent loop. This is L0; the input-size stress that exposed the rejected index scan no longer applies.

The initializer's local metrics rise because parsing is inlined: flog 17.5 → 20.7; ABC 14.35 → 17.2; cyclomatic and perceived complexity 6 → 7. The removed parser scored flog 5.3, ABC 4.58 and complexity 2; whole-file flog falls 123.5 → 121.3. Ordinary RuboCop passes. Rule shrinks 141 → 135 lines, and the spec file remains below 1,000 lines at 983. No added Ruby comment, size-crossing, abstraction or security finding.

The CHANGELOG has the required Unreleased entry and contributor link. The commit message is accurate sentence by sentence, including why the unchanged subjects snapshot is retained. Author and committer are both `Thomas Klemm <github@tklemm.eu>`, verified from the raw commit object. There is one commit over base and no trailers. `git diff --check` passes.

## Exact editorial edits

1. In the upstream body, delete this complete sentence and its following blank line, with no replacement:

   > benchmark-ips could not resolve a wall-time difference.

   The body should end at the table. This is an editorial nit, not a false-claim or performance blocker.

2. In `bench/upstream/oss_profile_sweep_1/body/CC1-objects/README.md`, replace `two of the five` with `three of the five`. The remaining two specs were retained, not dropped.

No code, test, commit-message or table replacement is requested.

## Pass entry and delivery state

```yaml
- {reviewer: thermos-sol, head: "cd1f37066ba0ce0515a09346264eb33ea1bf38d9", date: 2026-11-27, orb: "T-01a21d34-07d6-72b5-adf5-2542f9808e5b", verdict: nits, open: "No code/test blockers. Delete the body sentence 'benchmark-ips could not resolve a wall-time difference.'; in CC1-objects/README.md replace 'two of the five' with 'three of the five'. Both Thermos rubrics run directly by this reviewer; no independent second reviewer claimed."}
```

The upstream PR remains open and draft at [cb5768e493](https://github.com/thomasklemm/cancancan/commit/cb5768e493042c026ef4d808e8574a9db68aeecd); the review candidate is only on the separate review branch. No tracked Lowrail or CanCanCan file was changed, and nothing was committed, pushed, posted or written upstream. PostgreSQL and other Ruby/Active Record combinations were not rerun in this pass. Fresh review receipts are retained in this orb's `.amp/in/orb-backup/cc1-review/` and packaged as `receipts.tar.gz` there.
