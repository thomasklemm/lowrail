require 'json'
$LOAD_PATH.unshift File.join(ARGV.fetch(0), 'lib')
require 'cancancan'

def capture
  yield
rescue StandardError => error
  ['error', error.class.name, error.message]
end

def ability_for(behavior)
  ability = Object.new.extend(CanCan::Ability)
  ability.can :manage, :all if behavior == :cannot
  ability
end

def permissions(ability)
  [:read, :destroy].product([Integer, String], [nil, :to_s, :odd?]).map do |action, subject, attribute|
    capture { ability.can?(action, subject, attribute) }
  end
end

results = {}
[:can, :cannot].each do |behavior|
  results["#{behavior}-conversion-trace"] = capture do
    events = []
    token = Object.new
    token.define_singleton_method(:to_sym) { events << 'action.to_sym'; :read }
    actions = Object.new
    actions.define_singleton_method(:to_ary) { events << 'actions.to_ary'; [token] }
    subjects = Object.new
    subjects.define_singleton_method(:to_ary) { events << 'subjects.to_ary'; [Integer] }
    attributes = [:to_s]
    attributes.define_singleton_method(:all?) { |&block| events << 'attributes.all?'; super(&block) }
    attributes.define_singleton_method(:to_ary) { events << 'attributes.to_ary'; self }
    conditions = {}
    conditions.define_singleton_method(:is_a?) { |klass| events << "conditions.is_a?(#{klass})"; super(klass) }
    ability = ability_for(behavior)
    ability.public_send(behavior, actions, subjects, attributes, conditions)
    [events.dup, permissions(ability)]
  end

  [:actions, :subjects, :attributes].each do |boundary|
    results["#{behavior}-suspended-#{boundary}"] = capture do
      ability = ability_for(behavior)
      actions, subjects, attributes = [:read], [Integer], [:to_s]
      target = { actions: actions, subjects: subjects, attributes: attributes }.fetch(boundary)
      target.define_singleton_method(:to_ary) { Fiber.yield boundary.to_s; self }
      fiber = Fiber.new { ability.public_send(behavior, actions, subjects, attributes); 'finished' }
      before = fiber.resume
      actions.replace([:destroy])
      subjects.replace([String])
      attributes.replace([:odd?])
      after = fiber.resume
      [before, after, permissions(ability)]
    end
  end

  [false, true].each do |private_conversion|
    results["#{behavior}-private-to-ary-#{private_conversion}"] = capture do
      calls = 0
      subjects = Object.new
      subjects.define_singleton_method(:to_ary) { calls += 1; [Integer] }
      subjects.singleton_class.send(:private, :to_ary) if private_conversion
      ability = ability_for(behavior)
      ability.public_send(behavior, :read, subjects)
      [calls, permissions(ability)]
    end
  end

  results["#{behavior}-method-missing-conversion"] = capture do
    events = []
    subjects = Object.new
    subjects.define_singleton_method(:respond_to_missing?) { |name, *| events << "respond_to_missing:#{name}"; name == :to_ary }
    subjects.define_singleton_method(:method_missing) { |name, *| events << "method_missing:#{name}"; name == :to_ary ? [Integer] : super(name) }
    ability = ability_for(behavior)
    ability.public_send(behavior, :read, subjects)
    [events.dup, permissions(ability)]
  end

  results["#{behavior}-prepended-attribute-conversion"] = capture do
    actions = [:read]
    attributes = [:to_s]
    interceptor = Module.new do
      define_method(:to_ary) { actions.replace([:destroy]); super() }
    end
    attributes.singleton_class.prepend(interceptor)
    ability = ability_for(behavior)
    ability.public_send(behavior, actions, Integer, attributes)
    permissions(ability)
  end

  [nil, :not_an_array, 7].each do |converted|
    results["#{behavior}-conversion-result-#{converted.inspect}"] = capture do
      subjects = Object.new
      subjects.define_singleton_method(:to_ary) { converted }
      ability = ability_for(behavior)
      ability.public_send(behavior, :read, subjects)
      permissions(ability)
    end
  end

  [:actions, :subjects, :attributes].each do |boundary|
    results["#{behavior}-raising-#{boundary}"] = capture do
      actions, subjects, attributes = [:read], [Integer], [:to_s]
      target = { actions: actions, subjects: subjects, attributes: attributes }.fetch(boundary)
      target.define_singleton_method(:to_ary) { raise ArgumentError, "#{boundary} conversion" }
      ability_for(behavior).public_send(behavior, actions, subjects, attributes)
    end
  end

  results["#{behavior}-frozen-conversion-result"] = capture do
    action_type = Class.new(String) { def to_sym; :read; end }
    actions = [action_type.new('destroy')].freeze
    subjects = Object.new
    subjects.define_singleton_method(:to_ary) { [Integer].freeze }
    attrs = Class.new(Array) { def to_ary; [:to_s].freeze; end }.new([:odd?]).freeze
    conditions = Class.new(Hash).new.freeze
    ability = ability_for(behavior)
    ability.public_send(behavior, actions, subjects, attrs, conditions)
    permissions(ability)
  end

  results["#{behavior}-frozen-ability"] = capture do
    ability = ability_for(behavior)
    ability.define_singleton_method(:inspect) { '#<FrozenAbility>' }
    ability.freeze.public_send(behavior, :read, Integer, [:to_s].freeze, {}.freeze)
  end

  results["#{behavior}-validation-error-message"] = capture do
    ability_for(behavior).public_send(behavior, :read, Integer, [:to_s], { odd?: true }) { true }
  end
end

puts JSON.pretty_generate(results)
