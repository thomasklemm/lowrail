require 'cancancan'
path = File.join(ENV.fetch('TREE'), 'lib/cancan/rule.rb')
source = File.read(path)
line = "      @attributes = wrap(attributes)\n"
raise 'unexpected source' unless source.scan(line).length == 1
source = source.sub(line, '')
anchor = case ENV.fetch('MUTANT')
         when 'actions' then '      @actions = wrap(action).map(&:to_sym)'
         when 'validation' then '      condition_and_block_check(extra_args.first, block, action, subject)'
         end
raise 'missing anchor' unless source.include?(anchor)
source = source.sub(anchor, line + anchor)
eval(source, TOPLEVEL_BINDING, path)
