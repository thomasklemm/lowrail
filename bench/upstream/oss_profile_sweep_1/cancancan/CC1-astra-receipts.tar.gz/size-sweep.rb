require 'json'
require 'cancancan'
class Product; end
out = {}
[0, 1, 16, 150_000].each do |size|
  [:absent, :first, :last].each do |invalid|
    next if size == 0 && invalid != :absent
    attrs = Array.new(size, :name)
    attrs[0] = 'name' if invalid == :first
    attrs[-1] = 'name' if invalid == :last
    attrs.freeze
    n = size > 100 ? 100 : 20_000
    100.times { Object.new.extend(CanCan::Ability).can(:read, Product, attrs) }
    GC.start
    objects = GC.stat(:total_allocated_objects)
    time = Process.clock_gettime(Process::CLOCK_MONOTONIC)
    n.times { Object.new.extend(CanCan::Ability).can(:read, Product, attrs) }
    time = Process.clock_gettime(Process::CLOCK_MONOTONIC) - time
    out["#{size}-#{invalid}"] = {objects: (GC.stat(:total_allocated_objects) - objects).fdiv(n), seconds: time, n: n}
  end
end
puts JSON.pretty_generate(out)
