require 'json'
require 'active_record'
require 'cancancan'

ActiveRecord::Base.establish_connection(adapter: 'sqlite3', database: ':memory:')
ActiveRecord::Schema.verbose = false
ActiveRecord::Schema.define do
  create_table(:widgets) { |t| t.integer :owner; t.string :name }
end
class Widget < ActiveRecord::Base; end
Widget.create!(owner: 1, name: 'one')
Widget.create!(owner: 2, name: 'two')
class WeirdArray < Array; end
class WeirdHash < Hash; end
class WeirdString < String; end

def capture
  yield
rescue StandardError => e
  [e.class.name, e.message.gsub(/0x[0-9a-f]+/, 'ADDRESS')]
end

def public_state(ability)
  {
    checks: [:read, :show, :preview, :update, :destroy, :manage].product(
      [Widget, Widget.first, Widget.last, :all], [nil, :name, :owner]
    ).map { |a, s, attr| [capture { ability.can?(a, s, attr) }, capture { ability.cannot?(a, s, attr) }] },
    records: [:read, :update, :destroy].map { |action| capture { Widget.accessible_by(ability, action).order(:id).pluck(:name) } },
    permissions: capture { ability.permissions }
  }
end

out = {}
shapes = {
  none: -> { [] }, nil: -> { [nil] }, nil_condition: -> { [nil, {owner: 1}] },
  attributes: -> { [[:name]] }, symbol: -> { [:name] },
  frozen: -> { [[:name].freeze, {owner: 1}.freeze] },
  empty: -> { [[], {}] }, false: -> { [false] },
  hash: -> { [{owner: 1}] }, scope: -> { [Widget.where(owner: 1)] },
  sql: -> { ['owner = 1'] }, sql_array: -> { [['owner = ?', 1]] },
  ignored: -> { [[:name], {owner: 1}, {owner: 2}] },
  subclass: -> { [WeirdArray.new([:name]), WeirdHash[owner: 1]] },
  sql_subclass: -> { [WeirdString.new('owner = 1')] },
  mixed: -> { [[:name, 'owner']] }, number: -> { [23] }
}
shapes.each do |name, shape|
  [:can, :cannot].product([false, true]).each do |verb, block|
    ability = Object.new.extend(CanCan::Ability)
    ability.alias_action :preview, to: :read
    ability.can :manage, :all if verb == :cannot
    out["shape-#{name}-#{verb}-#{block}"] = capture do
      ability.public_send(verb, [:read, :update].freeze, [Widget].freeze, *shape.call,
                          &(block ? proc { |w| w.owner == 1 } : nil))
      public_state(ability)
    end
  end
end

[:can, :cannot].each do |verb|
  [:action, :subject, :attribute, :condition].each do |position|
    [:to_ary, :nil?, :is_a?, :all?, :==, :hash, :to_a, :to_hash].each do |method|
      ability = Object.new.extend(CanCan::Ability)
      ability.can :manage, :all if verb == :cannot
      actions, subjects, attributes, conditions = [:read], [Widget], [:name], {owner: 1}
      values = {action: actions, subject: subjects, attribute: attributes, condition: conditions}
      object = values.fetch(position)
      calls = []
      original = object.method(method) if object.respond_to?(method)
      object.define_singleton_method(method) do |*args, &block|
        calls << [position, method]
        conditions[:owner] = 2
        original ? original.call(*args, &block) : nil
      end
      out["callback-#{verb}-#{position}-#{method}"] = [capture do
        ability.public_send(verb, actions, subjects, attributes, conditions)
        public_state(ability)
      end, calls]
    end
  end
end

[:private, :missing, :prepend, :extend, :fiber, :raise, :bad_result, :shared].each do |mode|
  ability = Object.new.extend(CanCan::Ability)
  actions, attributes, conditions = [:read], [:name], {owner: 1}
  calls = []
  case mode
  when :private
    attributes.define_singleton_method(:to_ary) { calls << 'private'; actions.replace([:destroy]); self }
    attributes.singleton_class.send(:private, :to_ary)
  when :missing
    attributes.singleton_class.send(:undef_method, :to_ary)
    attributes.define_singleton_method(:respond_to_missing?) { |name, *| name == :to_ary }
    attributes.define_singleton_method(:method_missing) do |name, *|
      calls << name
      actions.replace([:destroy])
      self
    end
  when :prepend, :extend
    mod = Module.new do
      define_method(:to_ary) { calls << mode; actions.replace([:destroy]); self }
    end
    mode == :prepend ? attributes.singleton_class.prepend(mod) : attributes.extend(mod)
  when :fiber
    attributes.define_singleton_method(:to_ary) { Fiber.yield('converted'); self }
  when :raise
    attributes.define_singleton_method(:to_ary) { raise ArgumentError, 'conversion failed' }
  when :bad_result
    attributes.define_singleton_method(:to_ary) { 23 }
  when :shared
    attributes = actions
  end
  out["conversion-#{mode}"] = capture do
    if mode == :fiber
      fiber = Fiber.new { ability.can(actions, Widget, attributes, conditions); 'done' }
      calls << fiber.resume
      actions.replace([:destroy])
      attributes << :owner
      conditions[:owner] = 2
      calls << fiber.resume
    else
      ability.can(actions, Widget, attributes, conditions)
    end
    [public_state(ability), calls]
  end
end

[:can, :cannot].each do |verb|
  [nil, [], [nil], :all, [:all, Widget]].each_with_index do |subject, i|
    out["all-nil-#{verb}-#{i}"] = capture do
      ability = Object.new.extend(CanCan::Ability)
      ability.public_send(verb, :read, subject)
      public_state(ability)
    end
  end
end

puts JSON.pretty_generate(out)
