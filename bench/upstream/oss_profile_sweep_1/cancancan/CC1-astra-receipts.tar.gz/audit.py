import json
import pathlib
import re
from collections import Counter

root = pathlib.Path('/home/user/workspace/repo')
results = root / '.amp/in/orb-backup/cc1/results'
def outcomes(side):
    examples = json.loads((results / f'{side}-suite.json').read_text())['examples']
    return Counter(json.dumps([e['full_description'], e['status'], e.get('pending_message'), e.get('exception')], sort_keys=True) for e in examples)
base, head = outcomes('base'), outcomes('head')
assert not base - head
assert sum((head - base).values()) == 2
print('Suite: all 716 existing example outcomes identical; exactly two new passing examples')
for outcome in head - base:
    name, status, *_ = json.loads(outcome)
    assert status == 'passed'
    print('Added:', name)
for harness in ('prior', 'adversarial'):
    b = json.loads((results / f'base-{harness}.json').read_text())
    h = json.loads((results / f'head-{harness}.json').read_text())
    assert b == h
    print(f'{harness}: {len(b)} cases identical')

raw = root / 'bench/upstream/oss_profile_sweep_1/body/CC1-repair/raw'
record = json.loads((raw.parent / 'results.json').read_text())
for mode in ('interp', 'yjit'):
    values = {}
    for side in ('base', 'candidate', 'base2'):
        totals = []
        for n in (0, 2000):
            path = raw / f'ir-{mode}-1-Ability_new_user_-{side}-n{n}.callgrind'
            text = path.read_text()
            summary = int(re.search(r'^summary: (\d+)', text, re.M)[1])
            total = int(re.search(r'^totals: (\d+)', text, re.M)[1])
            assert summary == total
            totals.append(total)
            if mode == 'yjit':
                log = path.with_suffix('.log').read_text()
                pairs = re.findall(r'(compiled_iseq_count|compiled_block_count|invalidation_count)=(\d+)>(\d+)', log)
                assert len(pairs) == 3
                assert all(a == b for _, a, b in pairs)
        values[side] = (totals[1] - totals[0]) / 2000
    mean = (values['base'] + values['base2']) / 2
    cell = record['instructions'][f'{mode} Ability.new(user)']
    assert mean == cell['base']
    assert values['candidate'] == cell['candidate']
    print(mode, values, 'body rounded:', round(mean), round(values['candidate']))
print('All six YJIT instruction windows flat; Callgrind record audited, not remeasured')
print('benchmark-ips raw reports:')
for p in sorted(raw.glob('ips-*.log')):
    print(p.name, next(line.strip() for line in p.read_text().splitlines() if ' i/s ' in line))
