require 'bundler/setup'
Bundler.require

if ENV.fetch('CC1_MUTANT') == 'drop-conditions'
  CanCan::Rule.prepend(Module.new do
    def initialize(*)
      super
      @conditions = {}
    end
  end)
elsif ENV.fetch('CC1_MUTANT') == 'drop-empty-index'
  CanCan::Ability::Rules.prepend(Module.new do
    private

    def add_rule_to_index(rule, position)
      return if rule.subjects.compact.empty?

      super
    end
  end)
end
