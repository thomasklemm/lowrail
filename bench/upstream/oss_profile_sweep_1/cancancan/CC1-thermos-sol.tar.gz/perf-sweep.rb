require 'json'
$LOAD_PATH.unshift File.join(ARGV.fetch(0), 'lib')
require 'cancan'

rows = []
[[1, 50000], [10, 10000], [1000, 500], [150000, 10]].each do |size, n|
  [:absent, :early, :late].each do |position|
    subjects = Array.new(size, :dashboard)
    subjects.unshift(nil) if position == :early
    subjects << nil if position == :late
    run = -> { Object.new.extend(CanCan::Ability).can(:read, subjects) }
    5.times { run.call }
    samples = 3.times.map do
      GC.start
      start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      n.times { run.call }
      (Process.clock_gettime(Process::CLOCK_MONOTONIC) - start) / n
    end
    rows << { size: size, nil: position, n: n, seconds: samples }
  end
end
puts JSON.pretty_generate(rows)
