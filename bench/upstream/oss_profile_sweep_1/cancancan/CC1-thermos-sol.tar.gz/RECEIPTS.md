# CC1 Thermos-sol review receipts

Date: 2026-11-25. Reviewer orb: T-01a214c3-c62d-7481-8ea4-cb7c4ef33065.
Both rubrics were run by this reviewer directly, without another agent or thread.
The human-readable report and sentence-by-sentence body audit are in the Lowrail CC1 queue item.

Base: 021b13cf762ba95784bf00a467c0ce86120fdf12 (CanCanCommunity/cancancan main, 3.7.1).
Head: 2a5e8c71d19569d43c7fec09dfb7012721f792e2 (thomasklemm/cancancan branch
thomasklemm/rule-construction-allocations).

## Files

* `3.*-{base,cancancan}-{sqlite,postgres}.{json,log}`: successful full suites, seed 1234.
  JSON retains individual example identity and outcome, not just totals.
* `outcomes.txt`: per-example base/head comparisons in all four cells.
* `gemfiles/*.lock`: actual dependency locks used identically for base and head.
* `differential.rb`, `diff-{33,34}-{base,cancancan,fix-check}.json`: 120 ordinary shapes and 7
  mutation/override cases. Types are tagged in JSON so Symbols and Strings cannot compare equal accidentally.
* `differences.txt`: the five demonstrated differences, with base/head values.
* `proposed-fix.patch`: minimal repair relative to the reviewed head, tested only in a disposable worktree.
* `proposed-fix-suite.{json,log}`: repaired scratch tree, Ruby 3.3.14/AR 7.2.4, SQLite.
* `suite-mutant.rb`, `mutant-*`: executed negative controls on the existing Ability specs.
* `objects-40-*`: allocation-worker replays on Ruby 4.0.9, interpreter and YJIT; parser-only repair is diagnostic.
* `raw-audit.txt`: independently recomputed instruction totals/A/A from the original committed Callgrind
  dumps and checked all six YJIT logs for flat compile/invalidation counters. No fresh Callgrind cohort ran.
* `flog-*`, `metrics*`, `rubocop*`: code metrics and lint output.
* `perf-sweep.rb`, `perf-*.json`: core-1 pinned, no-JIT base/head/base native-time stress diagnostics;
  best of three samples per row, not fixed-heap/gated speed evidence or an upstream claim.
* `open-{prs,issues}.json`: complete direct GitHub REST lists (empty). Search returned HTTP 422;
  ownership also checked with `script/ownership CC1`, recorded in the queue item.
* `versions.txt`, `head.txt`, `original.patch`: environment/pins and exact reviewed source diff.

## Reproduce

Use two checkouts at the full pins above; restore the matching lock into each checkout's `gemfiles/`.
On Ruby 3.3.14 set `BUNDLE_GEMFILE=gemfiles/activerecord_7.2.0.gemfile`; on Ruby 3.4.13 use
`gemfiles/activerecord_8.1.0.gemfile`. Run `bundle install` and the following from each checkout:

```sh
DB=sqlite bundle exec rspec --seed 1234 --format progress --format json --out RESULTS.json
DB=postgres PGPORT=55432 bundle exec rspec --seed 1234 --format progress --format json --out RESULTS.json
bundle exec rubocop --format simple
bundle exec ruby /path/to/differential.rb "$PWD"
```

The PostgreSQL specs drop and recreate `cancan_postgresql_spec` repeatedly: point PGPORT at a **disposable**
local UTF-8 cluster with a postgres superuser, the initial database already created, and local trust auth.
Do not use a production or shared cluster. Runs against PostgreSQL were sequential. SQLite uses memory.

For a mutant, add `CC1_MUTANT=drop-conditions` or `CC1_MUTANT=drop-empty-index` and invoke
`bundle exec rspec spec/cancan/ability_spec.rb --require /path/to/suite-mutant.rb --seed 1234 --format json`.

To validate the proposed repair, apply `proposed-fix.patch` in a third disposable checkout of head and rerun
the differential and suite commands. This archive does not represent a new published CanCanCan head.
The unchanged original benchmark, full Callgrind dumps, heap settings and commands remain committed at
`bench/upstream/oss_profile_sweep_1/body/CC1` in Lowrail. For object replays this review used that original
`cc1_body.rb` with `script/upstream-bench --worker objects` and `-I CHECKOUT/lib` (no app dependencies).

No upstream write was made. Only Lowrail's review record and this archive are intended for publication.
