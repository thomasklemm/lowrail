require 'json'
require 'active_record'
$LOAD_PATH.unshift File.join(ARGV.fetch(0), 'lib')
require 'cancan'

ActiveRecord::Base.establish_connection(adapter: 'sqlite3', database: ':memory:')
ActiveRecord::Schema.verbose = false
ActiveRecord::Schema.define do
  create_table(:products) { |t| t.integer :owner_id; t.string :name }
  create_table(:orders) { |t| t.integer :owner_id; t.string :name }
end
class Product < ActiveRecord::Base; end
class Order < ActiveRecord::Base; end
Product.create!(owner_id: 7, name: 'allowed')
Product.create!(owner_id: 9, name: 'other')

def norm(value)
  case value
  when ActiveRecord::Relation then ['scope', value.to_sql]
  when Module then ['class', value.name]
  when Symbol then ['symbol', value.to_s]
  when String then ['string', value]
  when Array then value.map { |v| norm(v) }
  when Hash then value.map { |k, v| [norm(k), norm(v)] }
  when Proc then 'block'
  else value
  end
end

def result
  yield
rescue StandardError => error
  ['error', error.class.name, error.message]
end

def snapshot(ability)
  {
    rules: ability.send(:rules).map do |r|
      [r.base_behavior, r.actions, r.subjects, r.attributes, r.conditions, !!r.block,
       r.instance_variable_get(:@match_all)]
    end,
    index: ability.instance_variable_get(:@rules_index),
    queries: [:read, 'read', :show, :preview, :update, :destroy, :manage].product(
      [Product.first, Product.last, Product, Order, :dashboard, 'dashboard'], [nil, :name, 'name', :owner_id]
    ).map { |action, subject, attr| result { ability.can?(action, subject, attr) } },
    accessible: result { Product.accessible_by(ability).order(:id).pluck(:name) },
    permissions: result { ability.permissions }
  }
end

out = {}
factories = [
  -> { [:read, Product] }, -> { ['read', Product] }, -> { [[:read, 'update'], [Product, Order]] },
  -> { [:manage, :all] }, -> { [:read, [:all, Product, nil]] }, -> { [] }, -> { [nil, nil] },
  -> { [:read, [Product, nil, Order]] }, -> { [:read, [nil]] }, -> { [:read, []] },
  -> { [:read, [Product, Product]] }, -> { [:read, :dashboard] }, -> { [:read, 'dashboard'] },
  -> { [:update, Product, :name] }, -> { [:update, Product, [:name, :owner_id]] },
  -> { [:update, Product, [:name], { owner_id: 7 }] }, -> { [:read, Product, { owner_id: 7 }] },
  -> { [:update, Product, nil, { owner_id: 7 }] }, -> { [:update, Product, [], { owner_id: 7 }] },
  -> { [:read, Product, 'owner_id = 7'] }, -> { [:read, Product, ['owner_id = ?', 7]] },
  -> { [:read, Product, Product.where(owner_id: 7)] }, -> { [:read, Product, 'name'] },
  -> { [:read, Product, ['name']] }, -> { [:read, Product, false] },
  -> { [:read, Product, [:name], nil, :ignored] }, -> { [:read, nil] },
  -> { [:read, [nil, Product, nil].freeze, [:name].freeze, { owner_id: 7 }.freeze] },
  -> { [[:read, 'update'].freeze, [Product, Order].freeze] },
  -> { [:read, [].freeze, [].freeze] }
]

factories.each_with_index do |factory, i|
  [:can, :cannot].product([false, true]).each do |behavior, with_block|
    ability = Object.new.extend(CanCan::Ability)
    ability.alias_action :preview, to: :read
    ability.can :manage, :all if behavior == :cannot
    args = factory.call
    block = with_block ? proc { |record, *| record.respond_to?(:owner_id) && record.owner_id == 7 } : nil
    out["shape-#{i}-#{behavior}-#{with_block}"] = result do
      ability.public_send(behavior, *args, &block)
      snapshot(ability)
    end
  end
end

out['caller-mutation-after-return'] = result do
  ability = Object.new.extend(CanCan::Ability)
  actions = [:read]
  subjects = [Product]
  attrs = [:name]
  conditions = { owner_id: 7 }
  ability.can(actions, subjects, attrs, conditions)
  before = JSON.parse(JSON.generate(norm(snapshot(ability))))
  actions << :destroy
  subjects << Order
  attrs << :owner_id
  conditions[:owner_id] = 9
  after = snapshot(ability)
  rule = ability.send(:rules).last
  [before, after, [rule.actions.equal?(actions), rule.subjects.equal?(subjects),
                  rule.attributes.equal?(attrs), rule.conditions.equal?(conditions)]]
end

out['attribute-conversion-order'] = result do
  ability = Object.new.extend(CanCan::Ability)
  actions = [:read]
  attrs = [:name]
  attrs.define_singleton_method(:to_ary) { actions.replace([:destroy]); self }
  ability.can(actions, Product, attrs)
  [ability.can?(:read, Product), ability.can?(:destroy, Product)]
end

out['attribute-conversion-before-validation'] = result do
  ability = Object.new.extend(CanCan::Ability)
  attrs = [:name]
  attrs.define_singleton_method(:to_ary) { raise 'attribute conversion' }
  ability.can(:read, Product, attrs, { owner_id: 7 }) { true }
end

out['subject-equality-call'] = result do
  subject = Class.new
  subject.define_singleton_method(:==) { |other| raise 'nil equality' if other.nil?; super(other) }
  ability = Object.new.extend(CanCan::Ability)
  ability.can(:read, subject)
  ability.can?(:read, subject.new)
end

out['subject-array-subclass-each'] = result do
  list_type = Class.new(Array) do
    def each
      super { |subject| yield subject unless subject == Product }
    end
  end
  ability = Object.new.extend(CanCan::Ability)
  ability.can(:read, list_type.new([Product, Order]))
  [ability.can?(:read, Product), ability.can?(:read, Order)]
end

out['subject-hash-mutates-source'] = result do
  subjects = []
  subject = Class.new
  subject.define_singleton_method(:hash) { subjects << Order unless subjects.include?(Order); 123 }
  subjects << subject
  ability = Object.new.extend(CanCan::Ability)
  ability.can(:read, subjects)
  [ability.can?(:read, Order), ability.instance_variable_get(:@rules_index).key?(Order)]
end

out['shared-action-attribute-array'] = result do
  args = [:read, :update]
  ability = Object.new.extend(CanCan::Ability)
  ability.can(args, Product, args)
  args.replace([:destroy])
  r = ability.send(:rules).last
  [r.actions, r.attributes, ability.can?(:read, Product, :destroy), ability.can?(:destroy, Product)]
end

puts JSON.pretty_generate(out.transform_values { |value| norm(value) })
