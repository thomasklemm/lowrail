#!/usr/bin/env bash
# Full cancancan suites on the repaired head, sequential, seed 1234.
cd ~/oss/up/cancancan
for cell in "3.3.14 7.2.0" "3.4.13 8.1.0"; do
  set -- $cell
  for db in sqlite postgres; do
    DB=$db PGPORT=55432 BUNDLE_GEMFILE=gemfiles/activerecord_$2.gemfile mise exec ruby@$1 -- bundle exec rspec --seed 1234 --format progress --format json --out ~/cc1-run/$1-head-$db.json > ~/cc1-run/$1-head-$db.log 2>&1
    echo "$1 $db exit $? $(grep -E '^[0-9]+ examples' ~/cc1-run/$1-head-$db.log)"
  done
done
BUNDLE_GEMFILE=gemfiles/activerecord_8.1.0.gemfile mise exec ruby@3.4.13 -- bundle exec rubocop --format simple > ~/cc1-run/rubocop.log 2>&1; echo "rubocop exit $? $(grep -E 'files inspected' ~/cc1-run/rubocop.log)"
