# Per-example outcomes of head against Thermos-sol's base runs, keyed by file and full description.
require "json"
new_specs = ["reads the actions of a rule before its attributes", "rejects conditions with a block before reading the attributes",
  "does not compare the subjects of a rule with nil", "indexes every subject of an array subclass",
  "indexes the subjects given to a rule, not those added while indexing"].map { "CanCan::Ability #{_1}" }
key = ->(e) { [e["file_path"], e["full_description"]] }
val = ->(e) { [e["status"], e["pending_message"], e.dig("exception", "class"), e.dig("exception", "message")] }
%w[3.3.14 3.4.13].product(%w[sqlite postgres]).each do |ruby, db|
  base = JSON.parse(File.read(File.expand_path("~/cc1-receipts/#{ruby}-base-#{db}.json")))["examples"]
  head = JSON.parse(File.read(File.expand_path("~/cc1-run/#{ruby}-head-#{db}.json")))["examples"]
  b = base.to_h { [key.(_1), val.(_1)] }
  h = head.to_h { [key.(_1), val.(_1)] }
  added = h.keys - b.keys
  diff = b.keys.reject { h[_1] == b[_1] }
  dups = [base.size - b.size, head.size - h.size]
  puts "#{ruby} #{db}: base #{base.size}, head #{head.size}, differing #{diff.size}, added #{added.map(&:last).sort == new_specs.sort ? 'the 5 new specs' : added.inspect} (#{added.map { h[_1].first }.uniq.join}), duplicate keys #{dups}"
end
# Multiset check, since five descriptions repeat within a suite.
%w[3.3.14 3.4.13].product(%w[sqlite postgres]).each do |ruby, db|
  base = JSON.parse(File.read(File.expand_path("~/cc1-receipts/#{ruby}-base-#{db}.json")))["examples"].map { [key.(_1), val.(_1)] }.sort_by(&:inspect)
  head = JSON.parse(File.read(File.expand_path("~/cc1-run/#{ruby}-head-#{db}.json")))["examples"].map { [key.(_1), val.(_1)] }.reject { new_specs.include?(_1[0][1]) }.sort_by(&:inspect)
  puts "#{ruby} #{db}: multiset equal #{base == head}"
end
