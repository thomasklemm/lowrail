# Attribution worker: the E2 paired.rb fixture, public foreign_keys, as in the wall_noise worker, but per window it
# records every JIT counter that moved, GC counts, and which ISEQs (ZJIT log) or blocks (YJIT log) compiled.
# Env: WARM windows of 1,000 calls, WINDOWS timed windows of CALLS calls, GCMODE on|off,
# SAMPLE=1: per call, read GC.count and the compile counter, and keep the call index of each change.
# ZLOG=path: the --zjit-log-compiled-iseqs file of this process (read incrementally per window).
require "active_record"
require "json"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.transaction do
  1000.times do |i|
    c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, "noidx" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id")))
    c.execute %(CREATE INDEX "index_t#{i}_on_parent_id" ON "t#{i}" ("parent_id"))
  end
  100.times { |i| c.execute %(CREATE TABLE "u#{i}" ("id" integer PRIMARY KEY, "value" integer)) }
end
tables = 1000.times.map { "t#{_1}" }
raise unless c.foreign_keys("t500").map(&:name) == ["fk_t500"]

warm = Integer(ENV.fetch("WARM", "3"))
nwin = Integer(ENV.fetch("WINDOWS", "20"))
calls = Integer(ENV.fetch("CALLS", "200"))
gcoff = ENV.fetch("GCMODE", "on") == "off"
sample = ENV["SAMPLE"] == "1"
zlog = ENV["ZLOG"]
# TRIGGER: none | file (one File.read per window, a T_FILE for GC to sweep) | finalizer (one ObjectSpace finalizer per window)
trigger = case ENV.fetch("TRIGGER", "none")
when "file" then -> { File.read("/proc/self/stat") }
when "finalizer" then -> { ObjectSpace.define_finalizer(Object.new, proc {}) }
else -> {}
end
zjit = defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?
yjit = defined?(RubyVM::YJIT) && RubyVM::YJIT.enabled?
stats = if zjit then -> { RubyVM::ZJIT.stats }
elsif yjit then -> { RubyVM::YJIT.runtime_stats }
else -> { {} }
end
ckey = zjit ? :compiled_iseq_count : :compiled_block_count
compiled = if zjit then -> { RubyVM::ZJIT.stats(ckey) }
elsif yjit then -> { RubyVM::YJIT.runtime_stats(ckey) }
else -> { 0 }
end
ylog = yjit && RubyVM::YJIT.respond_to?(:log) && RubyVM::YJIT.log_enabled? rescue false
zpos = zlog && File.exist?(zlog) ? File.size(zlog) : 0
new_names = lambda do
  if zlog && File.exist?(zlog)
    s = File.size(zlog)
    names = s > zpos ? File.open(zlog) { |f| f.seek(zpos); f.read }.lines.map(&:chomp) : []
    zpos = s
    names
  else
    []
  end
end
diff = ->(a, b) { b.each_with_object({}) { |(k, v), h| d = v.is_a?(Integer) && a[k].is_a?(Integer) ? v - a[k] : nil; h[k] = d if d && d != 0 } }
gckeys = %i[heap_final_slots count minor_gc_count major_gc_count compact_count time total_allocated_objects total_freed_objects heap_live_slots]

i = 0
200.times { stats.(); compiled.(); GC.stat; GC.count }
window = lambda do |n, record|
  if gcoff
    GC.start
    GC.disable
  end
  trigger.()
  new_names.() if record
  t_start = Time.now
  g0 = GC.stat.slice(*gckeys); s0 = stats.()
  ev = []
  k = 0
  if sample
    gc_prev = GC.count; cc_prev = compiled.()
    while k < n
      c.foreign_keys(tables[i % 1000])
      i += 1
      gcn = GC.count; ccn = compiled.()
      ev << [k, gcn - gc_prev, ccn - cc_prev] if record && (gcn != gc_prev || ccn != cc_prev)
      gc_prev = gcn; cc_prev = ccn
      k += 1
    end
  else
    while k < n
      c.foreign_keys(tables[i % 1000])
      i += 1
      k += 1
    end
  end
  s1 = stats.(); g1 = GC.stat.slice(*gckeys)
  GC.enable if gcoff
  next unless record
  names = zjit ? new_names.() : []
  names = RubyVM::YJIT.log.select { |t, _| t >= t_start }.map(&:last) if ylog
  { gc: g1.to_h { |kk, v| [kk, v - g0[kk]] }, jit: diff.(s0, s1), compiled: names, events: ev }
end
warm.times { window.(1000, false) }
new_names.()
GC.start
windows = nwin.times.map { window.(calls, true) }
puts JSON.generate(ruby: RUBY_DESCRIPTION, zjit: zjit, yjit: yjit, pid: Process.pid, windows: windows)
