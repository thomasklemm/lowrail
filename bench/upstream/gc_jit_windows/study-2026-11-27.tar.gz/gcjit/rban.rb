# rban.rb FILE.jsonl [SKIP]: steady state (iterations >= SKIP, default 15) per label and process: GCs, compiles,
# invalidations per 1,000 requests, JIT-flat iterations, the request distance from GC to compile, top compiled names.
require "json"
file, skip = ARGV
skip = Integer(skip || 15)
rows = File.foreach(file).map { JSON.parse(_1) }
per1k = ->(x, req) { req.zero? ? 0 : 1000.0 * x / req }
rows.group_by { [_1["bench"], _1["label"]] }.sort.each do |(bench, label), ps|
  z = ps.first["zjit"]
  ckey = z ? "compiled_iseq_count" : "compiled_block_count"
  ikey = z ? "invalidation_time_ns" : "invalidation_count"
  procs = ps.map do |p|
    its = p["itrs"].select { _1["itr"] >= skip }
    late = its.last(10)
    req = its.sum { _1["req"] }; lreq = late.sum { _1["req"] }
    s = ->(set, k) { set.sum { _1["jit"][k] || 0 } }
    { req: req, gc: per1k.(its.sum { _1["gc"]["count"] }, req), comp: per1k.(s.(its, ckey), req),
      comp_late: per1k.(s.(late, ckey), lreq), entry: per1k.(s.(its, "compiled_iseq_entry"), req),
      inv: z ? s.(its, ikey) / 1e6 : per1k.(s.(its, ikey), req), flat: its.count { (_1["jit"][ckey] || 0).zero? && (_1["jit"][ikey] || 0).zero? },
      n: its.size, ms: its.map { _1["ms"] }.sort[its.size / 2] }
  end
  printf("%-10s %-9s | per 1k req: GC %s | compiles %s (last 10 itrs %s)%s | %s | JIT-flat itrs %s | median itr ms %s\n",
    bench, label, procs.map { "%.2f" % _1[:gc] }.join("/"), procs.map { "%.3f" % _1[:comp] }.join("/"),
    procs.map { "%.3f" % _1[:comp_late] }.join("/"),
    z ? "" : " | iseq entries #{procs.map { "%.3f" % _1[:entry] }.join("/")}",
    z ? "invalidation ms #{procs.map { "%.2f" % _1[:inv] }.join("/")}" : "invalidations/1k #{procs.map { "%.3f" % _1[:inv] }.join("/")}",
    procs.map { "#{_1[:flat]}/#{_1[:n]}" }.join(" "), procs.map { _1[:ms] }.join("/"))
  # Request distance from the latest GC to each compile event in steady state.
  gaps = ps.flat_map do |p|
    p["itrs"].select { _1["itr"] >= skip }.flat_map do |it|
      last = nil
      (it["events"] || []).filter_map do |k, g, c|
        last = k if g > 0
        next unless c > 0
        g > 0 ? 0 : last ? k - last : nil
      end
    end
  end
  dist = gaps.map { |d| d.nil? ? "no GC before in itr" : d == 0 ? "same request" : d <= 3 ? "1-3 after" : ">3 after" }.tally
  # Base rate: share of requests that had a GC.
  greq = ps.sum { |p| p["itrs"].select { _1["itr"] >= skip }.sum { |it| (it["events"] || []).count { _1[1] > 0 } } }
  treq = ps.sum { |p| p["itrs"].select { _1["itr"] >= skip }.sum { _1["req"] } }
  puts "    compile events #{gaps.size}: #{dist}; requests with a GC: #{(100.0 * greq / [treq, 1].max).round(1)}%"
  names = ps.flat_map { |p| p["itrs"].select { _1["itr"] >= skip }.flat_map { _1["compiled"] } }.map { _1.sub(/ \(index: \d+\)/, "").sub(%r{\A(.*)@.*/gems/}, '\1@') }.tally.sort_by { -_2 }
  puts "    top compiled: #{names.first(6).map { "#{_2}× #{_1}" }.join("; ")}" unless names.empty?
end
