#!/bin/bash
# Part 2c, after the timed cohorts: lobsters for 120 iterations (13,680 requests), last 60 counted, GC on/off, 2 processes each.
cd "$(dirname "$0")"; until grep -q VAL-DONE /tmp/validate.log; do sleep 30; done
H=$PWD/rb_harness.rb; O=$PWD/data/lobsters-long.jsonl
Y=$(mise where ruby@4.0.10)/bin/ruby; C=$HOME/w/ruby-cur/bin/ruby
one() { local cpu=$1 label=$2 r=$3 fl=$4; shift 4
  for k in 1 2; do local log=/tmp/zl-long-$label-$k.txt; rm -f $log
    (cd ~/w/ruby-bench && env PATH=$(dirname $r):$PATH OUT=$O LABEL=$label ZLOG=$log ITRS=120 SAMPLE=1 "$@" \
      taskset -c $cpu $r ${fl//%LOG%/$log} -r$H benchmarks/lobsters/benchmark.rb > /tmp/long-$label-$k.log 2>&1) || echo "FAIL $label $k"; done; }
one 2 zcur-on $C "--zjit --zjit-log-compiled-iseqs=%LOG%" GCMODE=on &
one 4 zcur-off $C "--zjit --zjit-log-compiled-iseqs=%LOG%" GCMODE=off &
one 6 zcur-on-stats $C "--zjit --zjit-stats=quiet" GCMODE=on &
one 8 zcur-off-stats $C "--zjit --zjit-stats=quiet" GCMODE=off &
one 10 y4010-on $Y "--yjit --yjit-log=quiet" GCMODE=on &
one 12 y4010-off $Y "--yjit --yjit-log=quiet" GCMODE=off &
one 14 ycur-on $C "--yjit --yjit-log=quiet" GCMODE=on &
wait; echo LONG-DONE
