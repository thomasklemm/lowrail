#!/bin/bash
# Part 2: steady-state compiles/invalidations per 1,000 requests in ruby-bench railsbench and lobsters.
# 3 processes (A/A) per config, ITRS iterations each; iterations after the first 15 count as steady state.
cd "$(dirname "$0")"; H=$PWD/rb_harness.rb; O=$PWD/data/rb.jsonl
Y=$(mise where ruby@4.0.10)/bin/ruby; C=$HOME/w/ruby-cur/bin/ruby; P=$HOME/w/ruby-master/bin/ruby
one() { # cpu app label ruby flags env...
  local cpu=$1 app=$2 label=$3 r=$4 fl=$5; shift 5
  for k in 1 2 3; do
    local log=/tmp/zl-$app-$label-$k.txt; rm -f $log
    (cd ~/w/ruby-bench && env PATH=$(dirname $r):$PATH OUT=$O LABEL=$label ZLOG=$log ITRS=${ITRS:-40} SAMPLE=1 "$@" \
      taskset -c $cpu $r ${fl//%LOG%/$log} -r$H benchmarks/$app/benchmark.rb > /tmp/rb-$app-$label-$k.log 2>&1) || echo "FAIL $app $label $k"
  done
}
zf="--zjit --zjit-log-compiled-iseqs=%LOG%"; yf="--yjit --yjit-log=quiet"
for app in railsbench lobsters; do
  base=$([ $app = railsbench ] && echo 11 || echo 0)
  one $((base+0)) $app zcur-on $C "$zf" GCMODE=on &
  one $((base+1)) $app zcur-off $C "$zf" GCMODE=off &
  one $((base+2)) $app zpin-on $P "$zf" GCMODE=on &
  one $((base+3)) $app ycur-on $C "$yf" GCMODE=on &
  one $((base+4)) $app y4010-on $Y "$yf" GCMODE=on &
  [ $app = railsbench ] && { one 5 $app y4010-off $Y "$yf" GCMODE=off & } || { one 7 $app y4010-off $Y "$yf" GCMODE=off & }
done
wait; echo RB-DONE
