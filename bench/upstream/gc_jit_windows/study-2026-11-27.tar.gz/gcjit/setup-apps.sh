#!/bin/bash
# Install each ruby-bench app's bundle for each Ruby with the once harness.
cd ~/w/ruby-bench
for app in railsbench lobsters; do
  ( for r in $HOME/w/ruby-cur/bin/ruby $HOME/w/ruby-master/bin/ruby $(mise where ruby@4.0.10)/bin/ruby; do
      echo "== $app $r"; PATH=$(dirname $r):$PATH HARNESS=once $r benchmarks/$app/benchmark.rb 2>&1 | tail -n 3
    done ) > /tmp/setup-$app.log 2>&1 &
done
wait; echo SETUP-DONE
