# ruby-bench harness for steady-state JIT bookkeeping: load with -r before benchmarks/X/benchmark.rb.
# Env: ITRS total iterations, GCMODE on|off (off: GC.start, then GC.disable around each iteration),
# SAMPLE=1 (per request: GC.count and the compile counter, keeping each change's request index),
# ZLOG (the --zjit-log-compiled-iseqs path), OUT (JSONL file to append the process record to).
require "/home/user/w/ruby-bench/lib/harness"


def run_benchmark(_hint, **)
  require "json"
  itrs = Integer(ENV.fetch("ITRS", "40"))
  gcoff = ENV.fetch("GCMODE", "on") == "off"
  sample = ENV["SAMPLE"] == "1"
  zlog = ENV["ZLOG"]
  zjit = defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?
  yjit = defined?(RubyVM::YJIT) && RubyVM::YJIT.enabled?
  stats = zjit ? -> { RubyVM::ZJIT.stats } : yjit ? -> { RubyVM::YJIT.runtime_stats } : -> { {} }
  ckey = zjit ? :compiled_iseq_count : :compiled_block_count
  compiled = zjit ? -> { RubyVM::ZJIT.stats(ckey) } : yjit ? -> { RubyVM::YJIT.runtime_stats(ckey) } : -> { 0 }
  ylog = yjit && RubyVM::YJIT.log_enabled?
  zpos = 0
  new_names = lambda do
    next [] unless zlog && File.exist?(zlog)
    s = File.size(zlog)
    names = s > zpos ? File.open(zlog) { |f| f.seek(zpos); f.read }.lines.map(&:chomp) : []
    zpos = s
    names
  end
  diff = ->(a, b) { b.each_with_object({}) { |(k, v), h| d = v.is_a?(Integer) && a[k].is_a?(Integer) ? v - a[k] : nil; h[k] = d if d && d != 0 } }
  gckeys = %i[count minor_gc_count major_gc_count time total_allocated_objects heap_live_slots]

  # Count requests, and per request read GC.count and the compile counter when sampling.
  state = { n: 0, ev: nil, gc: 0, cc: 0 }
  Rails.application.singleton_class.prepend(Module.new do
    define_method(:call) do |env|
      r = super(env)
      state[:n] += 1
      if (ev = state[:ev])
        g = GC.count; c = compiled.()
        ev << [state[:n], g - state[:gc], c - state[:cc]] if g != state[:gc] || c != state[:cc]
        state[:gc] = g; state[:cc] = c
      end
      r
    end
  end)

  out = []
  itrs.times do |k|
    if gcoff
      GC.start
      GC.disable
    end
    new_names.()
    t0 = Time.now
    g0 = GC.stat.slice(*gckeys); s0 = stats.(); n0 = state[:n]
    if sample
      state[:ev] = []; state[:gc] = GC.count; state[:cc] = compiled.()
    end
    m0 = Process.clock_gettime(Process::CLOCK_MONOTONIC)
    yield
    m1 = Process.clock_gettime(Process::CLOCK_MONOTONIC)
    ev = state[:ev]; state[:ev] = nil
    s1 = stats.(); g1 = GC.stat.slice(*gckeys)
    GC.enable if gcoff
    names = zjit ? new_names.() : ylog ? RubyVM::YJIT.log.select { |t, _| t >= t0 }.map(&:last) : []
    out << { itr: k, ms: ((m1 - m0) * 1000).round(1), req: state[:n] - n0, gc: g1.to_h { |kk, v| [kk, v - g0[kk]] },
             jit: diff.(s0, s1), compiled: names, events: ev }
    $stderr.puts "itr #{k} #{out.last[:ms]}ms gc #{out.last[:gc][:count]} jit #{out.last[:jit][ckey.to_s] || out.last[:jit][ckey] || 0}"
  end
  File.open(ENV.fetch("OUT"), "a") do |f|
    f.puts JSON.generate(label: ENV["LABEL"], bench: File.basename(Dir.pwd), ruby: RUBY_DESCRIPTION, zjit: zjit, yjit: yjit,
      opts: ENV["JITOPTS"], pid: Process.pid, itrs: out)
  end
end
