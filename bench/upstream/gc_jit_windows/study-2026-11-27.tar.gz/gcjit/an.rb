# an.rb FILE.jsonl [LABEL...]: per label, windows that compiled, their overlap with GC, invalidations,
# the compiled names, and (sampled runs) calls from the latest GC to each compile.
require "json"
file, *only = ARGV
rows = File.foreach(file).map { JSON.parse(_1) }
rows.select! { only.include?(_1["label"]) } unless only.empty?
rows.group_by { _1["label"] }.each do |label, ps|
  z = ps.first["r"]["zjit"]
  ckey = z ? "compiled_iseq_count" : "compiled_block_count"
  ikey = z ? "invalidation_time_ns" : "invalidation_count"
  ws = ps.flat_map { |p| p["r"]["windows"] }
  comp = ws.select { (_1["jit"][ckey] || 0) > 0 }
  inv = ws.select { (_1["jit"][ikey] || 0) > 0 }
  gcw = ws.count { _1["gc"]["count"] > 0 }
  printf("%-16s procs %2d windows %4d | GC windows %4d (%.0f%%) | compiled %3d, with GC %3d (%.0f%%) | invalidated %3d, with GC %3d | compiles total %d\n",
    label, ps.size, ws.size, gcw, 100.0 * gcw / ws.size, comp.size, comp.count { _1["gc"]["count"] > 0 },
    comp.empty? ? 0 : 100.0 * comp.count { _1["gc"]["count"] > 0 } / comp.size, inv.size, inv.count { _1["gc"]["count"] > 0 },
    comp.sum { _1["jit"][ckey] })
  inv_keys = ws.flat_map { _1["jit"].select { |k, v| k.start_with?("invalidat") && v > 0 }.keys }.tally
  puts "  invalidation keys moved (windows): #{inv_keys}" unless inv_keys.empty?
  names = comp.flat_map { _1["compiled"] }.map { _1.sub(/ \(index: \d+\)/, "") }.tally.sort_by { -_2 }
  puts "  compiled: #{names.first(12).map { "#{_2}× #{_1}" }.join("; ")}" unless names.empty?
  other = ws.flat_map { _1["jit"].keys }.tally.reject { |k, _| k =~ /time_ns|size|bytes|alloc|side_exit_count|context|yjit_active|count\z/ }
  puts "  other jit keys moved (windows): #{other.sort_by { -_2 }.first(10).to_h}" unless other.empty?
  # Sampled: for each compile event, calls since the latest GC event in the same window (nil: no GC before it).
  ev = ws.select { _1["events"]&.any? }
  next if ev.empty?
  gaps = ev.flat_map do |w|
    last_gc = nil
    w["events"].filter_map do |k, g, cc|
      last_gc = k if g > 0
      next unless cc > 0
      [k, g > 0 ? 0 : last_gc ? k - last_gc : nil]
    end
  end
  dist = gaps.map { |_, d| d.nil? ? "noGC" : d == 0 ? "same call" : d <= 5 ? "1-5 after" : d <= 50 ? "6-50 after" : ">50 after" }.tally
  puts "  sampled compile events #{gaps.size}: #{dist}"
end
