#!/bin/bash
# build.sh SRC PREFIX
set -e
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.9/bin:$HOME/.cargo/bin:$PATH"
src=$1; prefix=$2; b=$prefix-build
cd $src; [ -x configure ] || ./autogen.sh
rm -rf $b; mkdir -p $b; cd $b
$src/configure --prefix=$prefix --enable-yjit --enable-zjit --disable-install-doc > configure.log 2>&1
make -j7 > make.log 2>&1
make install > install.log 2>&1
$prefix/bin/ruby --zjit -v
echo BUILD-DONE
