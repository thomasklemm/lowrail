# Noise-study worker: the E2 paired.rb fixture (1,000 + 100 SQLite tables), public foreign_keys on the loaded tree.
# Env: WARM windows of 1,000 calls, then WINDOWS timed windows of CALLS calls (tables rotate). GCMODE on|off
# (off: GC.start then GC.disable around every timed window). Prints one JSON line with every window.
require "active_record"
require "json"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.transaction do
  1000.times do |i|
    c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, "noidx" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id")))
    c.execute %(CREATE INDEX "index_t#{i}_on_parent_id" ON "t#{i}" ("parent_id"))
  end
  100.times { |i| c.execute %(CREATE TABLE "u#{i}" ("id" integer PRIMARY KEY, "value" integer)) }
end
tables = 1000.times.map { "t#{_1}" }
raise unless c.foreign_keys("t500").map(&:name) == ["fk_t500"]

warm = Integer(ENV.fetch("WARM", "2"))
nwin = Integer(ENV.fetch("WINDOWS", "20"))
calls = Integer(ENV.fetch("CALLS", "200"))
gcoff = ENV.fetch("GCMODE", "on") == "off"
zjit = defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?
yjit = defined?(RubyVM::YJIT) && RubyVM::YJIT.enabled?
zkeys = %i[compiled_iseq_count failed_iseq_count compiled_side_exit_count invalidation_count side_exit_count]
ykeys = %i[compiled_iseq_count compiled_block_count invalidation_count side_exit_count]
jit = if zjit then -> { RubyVM::ZJIT.stats.values_at(*zkeys) }
elsif yjit then -> { s = RubyVM::YJIT.runtime_stats; ykeys.map { s[_1] } }
else -> { [] }
end
cpu = File.read("/proc/self/stat").split[38].to_i
steal = -> { File.foreach("/proc/stat").find { _1.start_with?("cpu#{cpu} ") }.split[8].to_i }
# Busy ticks (user+nice+system+irq+softirq) of the other vCPUs, which share one SMT core with ours.
other = -> { File.foreach("/proc/stat").grep(/\Acpu\d+ /).reject { _1.start_with?("cpu#{cpu} ") }.sum { |l| f = l.split; [1, 2, 3, 6, 7].sum { f[_1].to_i } } }
ctx = -> { File.read("/proc/self/status")[/^nonvoluntary_ctxt_switches:\s+(\d+)/, 1].to_i }
mono = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
tcpu = -> { Process.clock_gettime(Process::CLOCK_THREAD_CPUTIME_ID) }

i = 0
# REF=1: before every window, two fixed reference workloads (an integer loop and a sort of 50k floats) are timed, so
# a window can be divided by the host's speed at that moment.
ref = ENV["REF"] == "1"
floats = Random.new(1).then { |r| Array.new(50_000) { r.rand } }
ref_loop = -> { x = 0; j = 0; while j < 200_000; x += j & 7; j += 1; end; x }
ref_sort = -> { floats.dup.sort! }
30.times { ref_loop.(); ref_sort.() } if ref
# Harness lambdas run 200 times first and warm-up windows run the timed block itself, so nothing compiles in a timed window.
200.times { jit.(); steal.(); other.(); ctx.(); mono.(); tcpu.(); GC.stat }
window = lambda do |n|
  if gcoff
    GC.start
    GC.disable
  end
  if ref
    r0 = tcpu.(); ref_loop.(); r1 = tcpu.(); ref_sort.(); r2 = tcpu.()
  end
  ts = Time.now.to_f
  g0 = GC.stat; j0 = jit.(); s0 = steal.(); o0 = other.(); x0 = ctx.(); c0 = tcpu.(); t0 = mono.()
  k = 0
  while k < n
    c.foreign_keys(tables[i % 1000])
    i += 1
    k += 1
  end
  t1 = mono.(); c1 = tcpu.(); x1 = ctx.(); s1 = steal.(); o1 = other.(); j1 = jit.(); g1 = GC.stat
  GC.enable if gcoff
  { ts: ts, te: Time.now.to_f, ref_loop: ref && r1 - r0, ref_sort: ref && r2 - r1, wall: t1 - t0, cpu: c1 - c0, steal: s1 - s0, other: o1 - o0, nvcsw: x1 - x0, gc: g1[:count] - g0[:count], major: g1[:major_gc_count] - g0[:major_gc_count],
    gc_ms: g1[:time] - g0[:time], alloc: g1[:total_allocated_objects] - g0[:total_allocated_objects], jit: j1.zip(j0).map { _1.to_i - _2.to_i } }
end
warm.times { window.(1000) }
GC.start
windows = nwin.times.map { window.(calls) }
puts JSON.generate(ruby: RUBY_DESCRIPTION, zjit: zjit, yjit: yjit, cpu: cpu, pid: Process.pid,
  maps: File.foreach("/proc/self/maps").first(1).map { _1[/\A\h+/] } + File.foreach("/proc/self/maps").grep(/\[heap\]|sqlite3_native/).first(2).map { _1[/\A\h+/] },
  jit_keys: zjit ? zkeys : yjit ? ykeys : [],
  windows: windows, ylog: (yjit && RubyVM::YJIT.log_enabled? ? RubyVM::YJIT.log.map { [_1.to_f, _2] } : nil))
