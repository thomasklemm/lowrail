#!/bin/bash
cd "$(dirname "$0")"
export WARM=3 WINDOWS=20 CALLS=200
RUBY=/home/user/.local/share/mise/installs/ruby/4.0.10/bin/ruby /home/user/.local/share/mise/installs/ruby/4.0.9/bin/ruby drive.rb ../data/orig.jsonl y-base-log 8 "main:--yjit --yjit-log=quiet" "main:--yjit --yjit-log=quiet" -- taskset -c 10
RUBY=/home/user/.local/share/mise/installs/ruby/4.0.10/bin/ruby /home/user/.local/share/mise/installs/ruby/4.0.9/bin/ruby drive.rb ../data/orig.jsonl y-base 8 main:--yjit main:--yjit -- taskset -c 10
echo ORIG-DONE
