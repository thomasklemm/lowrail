# drive.rb OUT.jsonl LABEL PAIRS ARM_A ARM_B [-- PREFIX...]
# Fresh process per run, ABBA order across pairs. An arm is "tree:flags" with tree main|head|plant, e.g. main:--zjit.
# RUBY (executable), EXTRA_ENV ("K=V K=V") and the worker's env (WARM, WINDOWS, CALLS, GCMODE) pass through.
require "json"
require "open3"
require "shellwords"
out, label, pairs, a, b, *rest = ARGV
prefix = rest.first == "--" ? rest.drop(1) : []
ruby = ENV.fetch("RUBY")
trees = { "main" => "#{Dir.home}/w/rails-main", "head" => "#{Dir.home}/w/rails-e2", "plant" => "#{Dir.home}/w/rails-plant" }
worker = File.expand_path("worker.rb", __dir__)
extra = (ENV["EXTRA_ENV"] || "").split.to_h { _1.split("=", 2) }
File.open(out, "a") do |f|
  Integer(pairs).times do |k|
    (k.even? ? [["A", a], ["B", b]] : [["B", b], ["A", a]]).each do |arm, spec|
      tree, flags = spec.split(":", 2)
      ver = File.basename(File.dirname(File.dirname(ruby)))
      env = { "BUNDLE_GEMFILE" => "#{Dir.home}/w/gf/#{ver}-#{tree}/Gemfile", "RUBYOPT" => nil, "PATH" => "#{File.dirname(ruby)}:#{ENV["PATH"]}" }.merge(extra)
      cmd = [*prefix, ruby, *flags.to_s.split, "-rbundler/setup", worker]
      t = Time.now
      res, err, st = Open3.capture3(env, *cmd, chdir: trees.fetch(tree))
      abort "#{cmd.shelljoin} failed: #{err}" unless st.success?
      f.puts JSON.generate(label: label, pair: k, arm: arm, spec: spec, prefix: prefix, env: extra, at: t.to_f, r: JSON.parse(res.lines.last))
      f.flush
    end
  end
end
