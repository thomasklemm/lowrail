#!/bin/bash
# Part 3: --wall-gc validation, one cohort at a time on core 1 (sibling 0 idle). Output under bench/upstream/gc_jit_windows/.
cd ~/workspace/repo
C=$HOME/w/ruby-cur/bin/ruby
B=bench/upstream/gc_jit_windows
cohort() { # name ruby mode candidate [extra...]
  local name=$1 r=$2 m=$3 cand=$4; shift 4
  echo "$(date +%T) $name"
  mise exec ruby@4.0.10 -- script/upstream-bench --out $B/$name --base ~/w/rails-main --candidate ~/w/rails-$cand --ruby $r \
    --wall-mode $m --names main,$cand --gems activesupport,activemodel,activerecord --with sqlite3 --modes "" --wall 30 "$@" \
    bench/upstream/wall_noise/e2_fk.rb > /tmp/val-$name.log 2>&1 || echo "FAIL $name"
  grep "^- wall" $B/$name/table.md
}
cohort zjit-gc-aa $C zjit aa --wall-gc
cohort zjit-gc-plant $C zjit plant --wall-gc
cohort zjit-gc-plant75 $C zjit plant75 --wall-gc
cohort zjit-plant $C zjit plant
cohort yjit-gc-aa $C yjit aa --wall-gc
cohort yjit-gc-plant $C yjit plant --wall-gc
cohort y4010-gc-aa 4.0.10 yjit aa --wall-gc
cohort y4010-gc-plant 4.0.10 yjit plant --wall-gc
echo VAL-DONE
