#!/bin/bash
# Part 1 reproduction: 16 processes x 20 windows x 200 calls, WARM=3, GC on and off, plain and per-call sampled.
cd "$(dirname "$0")"
D=$(mise where ruby@4.0.9)/bin/ruby; Y=$(mise where ruby@4.0.10)/bin/ruby
C=$HOME/w/ruby-cur/bin/ruby; P=$HOME/w/ruby-master/bin/ruby
O=data/rep.jsonl; mkdir -p data
run() { local cpu=$1; shift; CPU=$cpu $D adrive.rb "$@" WARM=3 WINDOWS=20 CALLS=200; }
( run 2 $O zcur-on 16 $C "--zjit --zjit-log-compiled-iseqs=%LOG%" GCMODE=on; run 2 $O zcur-on-s 16 $C "--zjit --zjit-log-compiled-iseqs=%LOG%" GCMODE=on SAMPLE=1; run 2 $O zcur-off 16 $C "--zjit --zjit-log-compiled-iseqs=%LOG%" GCMODE=off ) &
( run 4 $O zpin-on 16 $P "--zjit --zjit-log-compiled-iseqs=%LOG%" GCMODE=on; run 4 $O zpin-on-s 16 $P "--zjit --zjit-log-compiled-iseqs=%LOG%" GCMODE=on SAMPLE=1; run 4 $O zpin-off 16 $P "--zjit --zjit-log-compiled-iseqs=%LOG%" GCMODE=off ) &
( run 6 $O ycur-on 16 $C "--yjit --yjit-log=quiet" GCMODE=on; run 6 $O ycur-on-s 16 $C "--yjit --yjit-log=quiet" GCMODE=on SAMPLE=1; run 6 $O ycur-off 16 $C "--yjit --yjit-log=quiet" GCMODE=off ) &
( run 8 $O y4010-on 16 $Y "--yjit --yjit-log=quiet" GCMODE=on; run 8 $O y4010-on-s 16 $Y "--yjit --yjit-log=quiet" GCMODE=on SAMPLE=1; run 8 $O y4010-off 16 $Y "--yjit --yjit-log=quiet" GCMODE=off; run 8 $O y4010-nolog-on 16 $Y "--yjit" GCMODE=on ) &
wait; echo REP-DONE
