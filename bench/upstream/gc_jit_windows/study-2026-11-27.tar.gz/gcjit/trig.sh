#!/bin/bash
# Part 1 mechanism test: TRIGGER none/file/finalizer x {ZJIT cur, ZJIT pin, YJIT cur, YJIT 4.0.10}, GC on, sampled; plus the original worker on master.
cd "$(dirname "$0")"
D=$(mise where ruby@4.0.9)/bin/ruby; Y=$(mise where ruby@4.0.10)/bin/ruby
C=$HOME/w/ruby-cur/bin/ruby; P=$HOME/w/ruby-master/bin/ruby
O=data/trig.jsonl
run() { local cpu=$1; shift; CPU=$cpu $D adrive.rb "$@" WARM=3 WINDOWS=20 CALLS=200 GCMODE=on SAMPLE=1; }
zf="--zjit --zjit-log-compiled-iseqs=%LOG%"; yf="--yjit --yjit-log=quiet"
( for t in file finalizer; do run 2 $O zcur-$t 16 $C "$zf" TRIGGER=$t; done; run 2 $O zcur-finalizer-stats 8 $C "$zf --zjit-stats=quiet" TRIGGER=finalizer; run 2 $O zcur-none-stats 8 $C "$zf --zjit-stats=quiet" TRIGGER=none ) &
( for t in file finalizer; do run 4 $O zpin-$t 16 $P "$zf" TRIGGER=$t; done ) &
( for t in file finalizer; do run 6 $O ycur-$t 16 $C "$yf" TRIGGER=$t; done; run 6 $O ycur-finalizer-stats 8 $C "$yf --yjit-stats=quiet" TRIGGER=finalizer ) &
( for t in file finalizer; do run 8 $O y4010-$t 16 $Y "$yf" TRIGGER=$t; done; run 8 $O y4010-file-stats 8 $Y "$yf --yjit-stats=quiet" TRIGGER=file; run 8 $O y4010-none-stats 8 $Y "$yf --yjit-stats=quiet" TRIGGER=none ) &
( cd orig; export WARM=3 WINDOWS=20 CALLS=200
  RUBY=$C $D drive.rb ../data/orig.jsonl zcur-orig 8 main:--zjit main:--zjit -- taskset -c 10
  RUBY=$C $D drive.rb ../data/orig.jsonl ycur-orig 8 "main:--yjit --yjit-log=quiet" "main:--yjit --yjit-log=quiet" -- taskset -c 10 ) &
wait; echo TRIG-DONE
