#!/bin/bash
# Part 2b: interrupt exits per 1,000 requests with --zjit-stats / --yjit-stats, GC on vs off, 2 processes each.
cd "$(dirname "$0")"; H=$PWD/rb_harness.rb; O=$PWD/data/rbstats.jsonl
Y=$(mise where ruby@4.0.10)/bin/ruby; C=$HOME/w/ruby-cur/bin/ruby
one() { local cpu=$1 app=$2 label=$3 r=$4 fl=$5; shift 5
  for k in 1 2; do (cd ~/w/ruby-bench && env PATH=$(dirname $r):$PATH OUT=$O LABEL=$label ITRS=30 "$@" \
      taskset -c $cpu $r $fl -r$H benchmarks/$app/benchmark.rb > /tmp/rbs-$app-$label-$k.log 2>&1) || echo "FAIL $app $label $k"; done; }
for app in railsbench lobsters; do
  b=$([ $app = railsbench ] && echo 9 || echo 13)
  one $b $app zcur-on-stats $C "--zjit --zjit-stats=quiet" GCMODE=on &
  one $((b+1)) $app zcur-off-stats $C "--zjit --zjit-stats=quiet" GCMODE=off &
  one $((b+2)) $app y4010-on-stats $Y "--yjit --yjit-stats=quiet" GCMODE=on &
done
wait; echo RBS-DONE
