# adrive.rb OUT.jsonl LABEL PROCS RUBY FLAGS [K=V ...]
# Runs attr.rb PROCS times in fresh processes on the Rails main tree, pinned with taskset -c $CPU (default 3).
# FLAGS is one string; "%LOG%" in it becomes a per-process ZJIT compile-log path. K=V pairs go into the env.
require "json"
require "open3"
out, label, procs, ruby, flags, *kv = ARGV
ver = File.basename(File.dirname(File.dirname(ruby)))
ver = "4.0.10" if ruby.include?("mise")
worker = File.expand_path("attr.rb", __dir__)
extra = kv.to_h { _1.split("=", 2) }
cpu = ENV.fetch("CPU", "3")
File.open(out, "a") do |f|
  Integer(procs).times do |k|
    log = "/tmp/zlog-#{label}-#{k}-#{Process.pid}.txt"
    File.delete(log) if File.exist?(log)
    fl = flags.gsub("%LOG%", log).split
    env = { "BUNDLE_GEMFILE" => "#{Dir.home}/w/gf/#{ver}-main/Gemfile", "RUBYOPT" => nil,
            "PATH" => "#{File.dirname(ruby)}:#{ENV["PATH"]}" }.merge(extra)
    env["ZLOG"] = log if flags.include?("%LOG%")
    cmd = ["taskset", "-c", cpu, ruby, *fl, "-rbundler/setup", worker]
    res, err, st = Open3.capture3(env, *cmd, chdir: "#{Dir.home}/w/rails-main")
    abort "#{cmd.join(" ")} failed: #{err}" unless st.success?
    f.puts JSON.generate(label: label, proc: k, flags: flags, env: extra, r: JSON.parse(res.lines.last))
    f.flush
  end
end
