import json
from collections import Counter
from pathlib import Path

root = Path(__file__).parent
head = "ef3b274bdaebd031ca5e3002a65d3818b5e63a7b"
base = json.loads((root / "nits-review-be311bb-probe.json").read_text())["scenarios"]
candidate = json.loads((root / "nits-review-ef3b274-probe.json").read_text())["scenarios"]
assert len(base) == len(candidate) == 27 and base.keys() == candidate.keys()
for name in base:
    for field in ("results", "hashie_calls", "allocations"):
        assert base[name][field] == candidate[name][field], (name, field)
    assert all(sum(calls.values()) > 0 for calls in base[name]["hashie_calls"])
print("PASS: 27 old/new definitions match results, measured Hashie Ruby/C call counts and direct allocation samples")

aa = json.loads((root / "nits-review-ef3b274-aa.json").read_text())
assert aa["duel_version"] == "0.3.1"
assert aa["baseline"]["commit"] == aa["candidate"]["commit"] == head
assert aa["candidate"]["uncommitted_changes"] is False
assert aa["settings"]["force"] is True
assert aa["settings"]["processes"] == 24
assert aa["settings"]["jobs"] == 1
assert len(aa["benchmarks"]) == 27 and aa["status"] == "passed" and aa["exit"] == 0
assert all(row["timed"]["cpu"]["limit"] == 1.05 for row in aa["benchmarks"])
print("A/A:", aa["seconds"], "seconds;", dict(Counter(row["verdict"] for row in aa["benchmarks"])))
print("Unsettled:", [row["name"] for row in aa["benchmarks"] if row["verdict"] == "unsettled"])
print("Across:", aa["across"])

filtered = json.loads((root / "nits-review-gemfile-only.json").read_text())
assert filtered["baseline"]["commit"] == filtered["candidate"]["commit"] == head
assert filtered["candidate"]["uncommitted_changes"] is True
assert filtered["settings"]["force"] is False
assert len(filtered["benchmarks"]) == 1 and filtered["status"] == "passed" and filtered["exit"] == 0
print("PASS: actual Gemfile-only diff runs a non-forced comparison")
