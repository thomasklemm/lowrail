# frozen_string_literal: true

require 'json'
require 'duel'
require 'duel/context'
require 'hashie'

root = File.expand_path(ARGV.fetch(0))
raise 'wrong Hashie checkout loaded' unless $LOADED_FEATURES.include?(File.join(root, 'lib/hashie.rb'))
config = Duel.load_config(File.join(root, '.duel.rb'))
TOPLEVEL_BINDING.receiver.extend(Duel::DSL)
config.benchmark_files.each { |file| load file }
raise 'wrong discovery count' unless Duel.benchmarks.size == 27

def check(condition, message)
  raise message unless condition
end

def normalized(object)
  case object
  when Hash then [object.class.name, object.map { |key, value| [normalized(key), normalized(value)] }]
  when Array then object.map { |value| normalized(value) }
  when Class then ['Class', object.superclass.name, object.included_modules.map(&:name).compact.sort]
  when Symbol then ['Symbol', object.to_s]
  when String then ['String', object.dup, object.frozen?]
  when Numeric, true, false, nil then object
  else raise "unexpected result type: #{object.class}"
  end
end

def container_ids(object)
  case object
  when Hash then [object.object_id] + object.values.flat_map { |value| container_ids(value) }
  when Array then [object.object_id] + object.flat_map { |value| container_ids(value) }
  else []
  end
end

def graph(object)
  case object
  when Hash
    [object.object_id, object.singleton_class.ancestors, object.map { |key, value| [key, graph(value)] }]
  when Array
    [object.object_id, object.singleton_class.ancestors, object.map { |value| graph(value) }]
  when String then [object.object_id, object.class.name, object.dup]
  else [object.object_id, object.class.name, object]
  end
end

$probe_parses = []
JSON.singleton_class.prepend(Module.new do
  def parse(*args, **options)
    if args.first.equal?(REPOSITORY_JSON)
      raise 'JSON parsing during measurement' if Duel.measuring?
      super.tap { |input| $probe_parses << input }
    else
      super
    end
  end
end)

global_before = graph(REPOSITORY) if defined?(REPOSITORY)
settled_inputs = []
used_ids = {}
rows = {}
allocations = Duel::Metrics::Allocations.new
allocations.settings = Duel::Metrics::Allocations.settings({})
allocations.open

Duel.benchmarks.each_value do |definition|
  first_parse = $probe_parses.size
  harness = Duel::Harness.new(definition, config.hooks)
  original = harness.instance_variable_get(:@body)
  result = nil
  harness.instance_variable_set(:@body, ->(*args) { result = original.call(*args) })
  harness.prepare
  harness.trial
  results = []
  traces = []
  [1, 17, 1].each do |n|
    calls = Hash.new(0)
    trace = TracePoint.new(:call, :c_call) do |event|
      next unless Duel.measuring? && event.path.start_with?(File.join(root, 'lib/'))
      owner = event.defined_class.to_s.gsub(/0x[0-9a-f]+/, 'ADDRESS')
      key = [event.event, event.path.delete_prefix(root), event.lineno, event.method_id, owner].join(':')
      calls[key] += 1
    end
    trace.enable { harness.run(n, Duel::Trial.new) }
    results << normalized(result)
    traces << calls.sort.to_h
  end
  harness.instance_variable_set(:@body, original)
  counts = 3.times.map do
    sample = harness.sample([allocations], n: 100)
    harness.run(100, sample)
    sample.counted.fetch('allocations').fdiv(100)
  end
  harness.finish

  settled_inputs.each { |input, before| check(graph(input) == before, "cross-scenario mutation: #{definition.name}") }
  $probe_parses.drop(first_parse).each do |input|
    container_ids(input).each do |id|
      check(!used_ids.key?(id), "shared parsed container: #{definition.name}")
      used_ids[id] = definition.name
    end
    settled_inputs << [input, graph(input)]
  end
  check(graph(REPOSITORY) == global_before, "global fixture mutation: #{definition.name}") if defined?(REPOSITORY)
  rows[definition.name] = { results: results, hashie_calls: traces, allocations: counts }
end
allocations.close

fresh = method(:repository) if respond_to?(:repository, true)
if fresh
  left, right = fresh.call, fresh.call
  right_before = normalized(right)
  left['owner']['login'].replace('changed')
  left['licenses'][1]['spdx_id'].replace('changed')
  check(normalized(right) == right_before, 'nested strings shared between copies')
  check(normalized(fresh.call) == right_before, 'canonical JSON changed')
  Duel::Context.check
end

def deep_freeze(object)
  case object
  when Hash then object.each { |key, value| deep_freeze(key); deep_freeze(value) }
  when Array then object.each { |value| deep_freeze(value) }
  end
  object.freeze
end

soft = JSON.parse(REPOSITORY_JSON)
hard = deep_freeze(JSON.parse(REPOSITORY_JSON))
soft_mash, hard_mash = Hashie::Mash.new(soft), Hashie::Mash.new(hard)
soft_deep, hard_deep = DeepHash.new(soft), DeepHash.new(hard)
check(soft_mash == hard_mash && soft_deep == hard_deep, 'freezing changed fixture values')
check(!soft_mash.name.frozen? && hard_mash.name.frozen?, 'expected retained Mash string mutability difference')
check(!soft_deep['owner'].frozen? && hard_deep['owner'].frozen?, 'expected retained DeepHash nested mutability difference')
check(soft_deep.deep_find('login') == hard_deep.deep_find('login'), 'frozen DeepFind changed value')
check(soft_deep.deep_fetch('licenses', 1, 'spdx_id') == hard_deep.deep_fetch('licenses', 1, 'spdx_id'), 'frozen DeepFetch changed value')

puts JSON.pretty_generate({
  root: root, scenarios: rows, parsed_inputs: settled_inputs.size,
  parser_boundary: 'no parse while measuring', fixture_ownership: 'distinct nested containers; no cross-scenario mutation',
  frozen_input: 'equal values; retained Mash strings and DeepHash nested containers become frozen'
})
