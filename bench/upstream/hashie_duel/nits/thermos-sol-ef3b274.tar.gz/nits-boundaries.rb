# frozen_string_literal: true

require 'duel'
require 'duel/runner'
require 'duel/baseline'

raise 'expected Gemfile-only diff' unless IO.popen(%w[git diff --name-only HEAD], &:read).lines.map(&:chomp) == ['Gemfile']
config = Duel.load_config('.duel.rb')
settings = Duel::Settings.defaults
settings.base = 'HEAD'
baseline = Duel::Baseline.new(config, settings)
raise 'Gemfile-only change is skipped' if baseline.unchanged?
puts "with fix: watched=#{baseline.watched.inspect}; unchanged?=#{baseline.unchanged?}"
config.watch.delete('Gemfile')
raise 'negative control did not skip' unless baseline.unchanged?
puts "without watch: watched=#{baseline.watched.inspect}; unchanged?=#{baseline.unchanged?}"
