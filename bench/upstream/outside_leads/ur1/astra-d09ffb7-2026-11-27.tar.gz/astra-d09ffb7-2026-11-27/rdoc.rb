require 'rdoc/rdoc'
r = RDoc::RDoc.new
r.document(['--quiet','--dry-run','--op',File.join(__dir__,'rdoc-output'),ARGV.fetch(0)])
u = r.store.find_class_or_module('URI')
m = u.method_list.find { |m| m.name == 'decode_uri_component' }
p [RDoc::VERSION,m.name,m.document_self,m.comment.to_s]
