import json
from pathlib import Path
root = Path(__file__).parent / 'results'
engines = ['2.5.9','4.0.10','pure','master','master-zjit','truffleruby-40.0.0','jruby-10.1.3.0']
for engine in engines:
    directory = root / engine
    a = [json.loads(line) for line in (directory / 'base-values.jsonl').read_text().splitlines()]
    b = [json.loads(line) for line in (directory / 'head-values.jsonl').read_text().splitlines()]
    assert len(a) == len(b) == 3
    assert a[1:] == b[1:], engine
    for method in ['decode_www_form_component','decode_uri_component']:
        assert 'cases; 0 differences;' in (directory / f'head-independent-{method}.txt').read_text()
    for revision in ['base','head']:
        suite = (directory / f'{revision}-suite.txt').read_text()
        assert '94 tests,' in suite and '0 failures, 0 errors' in suite, (engine,revision)
    a = [json.loads(line) for line in (directory / 'base-concurrency.jsonl').read_text().splitlines()]
    b = [json.loads(line) for line in (directory / 'head-concurrency.jsonl').read_text().splitlines()]
    assert len(a) == len(b) == 13 and a[1:] == b[1:], engine
    for label,result in b[1:]:
        if label[-1] in ['threads','ractors'] and result != 'unavailable':
            assert all(value is True for value in result), (engine,label,result)
    print(engine, 'value digests equal; independent probes zero differences; base/head suites and concurrency pass')
print('PASS: all seven engine/backend configurations')
