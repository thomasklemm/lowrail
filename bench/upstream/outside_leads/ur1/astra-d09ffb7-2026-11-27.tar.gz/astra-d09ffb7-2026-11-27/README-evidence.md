# Astra d09ffb7 evidence

Reviewed one URI commit d09ffb7376d111123e5d217510c150c87c0cdd99 on
48cda77031e343d35213c36fe164b2a46ffbefa7, with c43954fa4d2a7605e18ecc8968c1aa188eae549a
as the previous-head control. See the adjacent tracked report for the verdict and boundaries.

`base/lib`, `head/lib`, `head/test`, and `previous/lib` are exact source snapshots. No URI repository was pushed.

Run with Bash and the pinned interpreters, adjusting the interpreter locations in these scripts to your machine:

    bash run.sh 2.5.9
    bash run.sh 4.0.10
    bash run.sh pure
    bash run.sh master
    bash run.sh master-zjit
    bash run.sh truffleruby-40.0.0
    bash run.sh jruby-10.1.3.0

`run.sh` calls `adversarial.rb` in separate processes for each revision/mode and the earlier independent
`probe.rb` for both public methods. `pure_cgi.rb` removes native CGI methods, exposing the shipped Ruby implementation.
`backend.sh` verifies implementation owners/source locations and standalone `uri/common` loading.

`suite.sh ENGINE` runs the new suite against each library. Dependencies were test-unit 3.6.8,
test-unit-ruby-core 1.0.7 and power_assert 3.1.0, installed in `test-gems`; install those gems there or adjust
GEM_HOME/GEM_PATH. RDoc's direct parser probe used 7.0.4.

`extract_asserts.rb head/test/uri/test_common.rb` generated `asserts.rb` with Prism.
`ruby mutants.rb` generates throwaway library copies. `mutation.sh ENGINE` executes the extracted assertions
individually, independently of the real full-suite run. Mutants run on 2.5.9, 4.0.10, pure CGI and TruffleRuby.
The no-b mutant crashes TruffleRuby at the GB18030 form assertion; its later assertions did not run.

Additional commands:

    ruby -Ibase/lib intermediates.rb
    ruby -Iprevious/lib intermediates.rb
    ruby -Ihead/lib intermediates.rb
    ruby -Ihead/lib load_hooks.rb wrapped_before
    ruby -Ihead/lib load_hooks.rb no_native
    ruby -Ihead/lib load_hooks.rb method_raises
    ruby -Ihead/lib load_hooks.rb respond_raises
    ruby rdoc.rb head/lib/uri/common.rb

The intermediate probe also ran against all three revisions on MRI 2.5, MRI 4, pure CGI, master, TruffleRuby and
JRuby. The additional load-hook and RDoc comparisons ran on MRI 4.0.10 against all three revisions.

JRuby's first broad value run was interrupted after prolonged recursive exception construction; a TRACE=1 rerun
was bounded with timeout 25. `results/jruby-initial-blocked` retains both attempts and a Java stack dump. The
minimized `jruby-error.rb` was run on base/head with timeout 15; each completed with exit 0 after rescuing the same
Java::JavaLang::StackOverflowError. Full separate base/head `adversarial.rb values` processes were then allowed to
finish: all 47,652 cases per method, none excluded, matching digests. Remaining modes, independent probes and
suites ran separately. This explains why JRuby's final directory has no combined run.sh status.txt.

`python3 verify.py` validates completed value digests, independent probes, suite outcomes, threads and fibers.
`python3 summarize.py` prints the object-hook differences and per-assertion mutant failures. Exception messages in
the adversarial JSONL are hex-encoded to preserve invalid encodings; decode with `[hex].pack('H*')` in Ruby.
Value outputs are deterministic result digests, not benchmark data. No timing/allocations/instructions are claimed.

Runtime builds:

* MRI master 0d399335b733776187e43a783e5f950c18ad881c: autogen.sh, configure with --enable-zjit --enable-yjit
  --disable-install-doc and a local prefix, make -j6, make install; base Ruby 4.0.10.
* MRI 2.5.9: ruby-build 2.5.9 PREFIX, MAKE_OPTS=-j6, bundled OpenSSL 1.1.1w; build/cache directories in orb-backup.
* MRI 4.0.10 and TruffleRuby 40.0.0: mise installations.
* JRuby 10.1.3.0: official jruby-bin-10.1.3.0.tar.gz, Temurin 21.0.13.1+2.

The initial mise combined install made no progress for 2.5/JRuby and was stopped; the direct installations above
recovered those cells. Build/install logs and exact revision receipts are included, not runtime binaries.
