require 'json'
require 'digest'
require ENV['PRELUDE'] if ENV['PRELUDE']
require 'cgi' if ENV['ORDER'] == 'cgi_first'
Object.autoload(:CGI, 'cgi') if ENV['ORDER'] == 'autoload'
require 'uri'
puts JSON.generate(['load', defined?(CGI), Object.autoload?(:CGI)])
require 'cgi'
METHODS = [:decode_www_form_component, :decode_uri_component]

def snap(s)
  [s.class.name, String.instance_method(:unpack).bind(s).call('H*')[0],
    String.instance_method(:encoding).bind(s).call.name,
    String.instance_method(:valid_encoding?).bind(s).call, s.frozen?, s.instance_variables.sort, s.singleton_methods.sort]
end

def outcome(method, s, enc = [])
  r = URI.send(method, s, *enc)
  ['ok', snap(r), r.equal?(s)]
rescue Exception => e
  message = e.message.sub(/\n\n.*\z/m, '').gsub(/0x[0-9a-f]+/, 'OBJECT')
  ['error', e.class.name, message.b.unpack('H*')[0]]
end

def emit(label, result)
  puts JSON.generate([label, result])
end

mode = ARGV.fetch(0)
case mode
when 'values'
  METHODS.each do |method|
    digest = Digest::SHA256.new
    count = 0
    skipped = 0
    check = lambda do |label, string, enc|
      warn [method,label,string.unpack('H*')[0],string.encoding.name,enc].inspect if ENV['TRACE']
      result = outcome(method, string, enc)
      result << snap(string)
      digest.update(JSON.generate([label, result]))
      count += 1
    end
    seeds = ['', 'a+b%00%ff%2B', '%', '%0', '%xz', '%%41', '%41%', "%41\0", '%2b%252b', "\xff".b, "a\xc2\x80%41".b]
    Encoding.list.each do |enc|
      (seeds + (0..255).map { |b| [b, 37, 52, 49, 43, 98].pack('C*') }).each_with_index do |bytes, index|
        begin
          s = bytes.dup.force_encoding(enc)
        rescue ArgumentError
          skipped += 1
          next
        end
        check.call([enc.name, index], s, [])
      end
    end
    targets = [[], [nil], [false], [0], [:UTF_8], ['UTF-8'], ['binary'], ['nope'], ["UTF-8\0"], [Encoding::UTF_16BE], [Encoding::UTF_7]]
    seeds.each_with_index do |s,i|
      targets.each_with_index { |e,j| check.call(['target',i,j], s.dup.freeze, e) }
    end
    rng = Random.new(81274)
    20000.times do |i|
      begin
        s = Array.new(rng.rand(0..48)) { rng.rand(256) }.pack('C*').force_encoding(Encoding.list.sample(random: rng))
      rescue ArgumentError
        skipped += 1
        next
      end
      check.call(['random', i], s, targets.sample(random: rng))
    end
    [0, 1, 32, 1048576, 8388608].each do |n|
      ['x' * n, '%41' + 'x' * n, 'x' * n + '%41', '%41' * (n / 3), 'x' * n + '%', 'x' * n + '+'].each_with_index do |s,i|
        check.call(['large',n,i], s.freeze, [])
      end
    end
    emit(method, [count, skipped, digest.hexdigest])
  end
when 'objects'
  METHODS.each do |method|
    [:b, :encoding, :instance_of?, :to_str, :gsub, :force_encoding, :tr].each do |hook|
      [false, true].each do |priv|
        s = 'a%41+b'.dup
        s.define_singleton_method(hook) { |*| raise "hook #{hook}" }
        s.singleton_class.send(:private, hook) if priv
        emit([method,'input',hook,priv], outcome(method,s))
      end
    end
    [:gsub, :tr, :encoding, :force_encoding, :to_str].each do |hook|
      [false, true].each do |priv|
        s = 'a%41+b'.dup
        intermediate = 'b%42+c'.b
        intermediate.define_singleton_method(hook) { |*| raise "intermediate #{hook}" }
        intermediate.singleton_class.send(:private, hook) if priv
        s.define_singleton_method(:b) { intermediate }
        emit([method,'intermediate',hook,priv], [outcome(method,s), snap(intermediate)])
      end
    end
    [:extended, :prepended, :subclass].each do |style|
      m = Module.new { def b; 'b%42+c'.b; end }
      s = case style
          when :extended then 'a%41+b'.dup.extend(m)
          when :prepended then 'a%41+b'.dup.tap { |s| s.singleton_class.prepend(m) }
          else Class.new(String) { include m }.new('a%41+b')
          end
      emit([method,style], outcome(method,s))
    end
    [false, true].each do |frozen|
      s = 'a%41+b'.dup
      mid = 'b%42+c'.b
      mid.freeze if frozen
      s.define_singleton_method(:b) { mid }
      emit([method,'frozen intermediate',frozen], [outcome(method,s),snap(mid)])
    end
    [BasicObject, Object].each do |klass|
      s = klass.new
      def s.to_str; 'a%41+b'; end
      def s.b; 'b%42+c'; end
      emit([method,'duck',klass.name], outcome(method,s))
    end
    events = []
    s = Class.new do
      define_method(:method_missing) { |name,*| events << name; name == :to_str ? 'a%41+b' : name == :b ? 'b%42+c' : super(name) }
      def respond_to_missing?(name,*); [:to_str,:b].include?(name); end
    end.new
    emit([method,'missing'],[outcome(method,s),events])
    ['UTF-8','bad',nil,123].each do |name|
      [false,true].each do |priv|
        calls = []
        e = Object.new
        e.define_singleton_method(:to_str) { calls << :to_str; name }
        e.singleton_class.send(:private,:to_str) if priv
        emit([method,'encoding',name,priv],[outcome(method,'a%ff',[e]),calls])
      end
    end
    [nil,123,:abc,[],{}].each { |s| emit([method,'nonstring',s],outcome(method,s)) }
  end
when 'concurrency'
  METHODS.each do |method|
    expected = method == :decode_uri_component ? '61ff2b62' : '61ff2062'
    workers = 8.times.map do
      Thread.new do
        1000.times.all? { URI.send(method,'a%ff+b').unpack('H*')[0] == expected }
      end
    end
    emit([method,'threads'],workers.map(&:value))
    if defined?(Ractor) && RUBY_ENGINE == 'ruby'
      workers = 4.times.map do
        Ractor.new(method,expected) do |meth,want|
          begin
            1000.times.all? { URI.send(meth,'a%ff+b').unpack('H*')[0] == want }
          rescue Exception => e
            [e.class.name,e.message]
          end
        end
      end
      emit([method,'ractors'],workers.map { |r| r.respond_to?(:value) ? r.value : r.take })
    else
      emit([method,'ractors'],'unavailable')
    end
    s = 'a%41+b'.dup
    e = Object.new
    e.define_singleton_method(:to_str) { Fiber.yield(:encoding); 'UTF-8' }
    f = Fiber.new { outcome(method,s,[e]) }
    emit([method,'fiber encoding pause'], f.resume)
    s.replace('%zz')
    emit([method,'fiber encoding resume'],[f.resume,snap(s)])
    s = 'a%41+b'.dup
    s.define_singleton_method(:b) { Fiber.yield(:b); super() }
    f = Fiber.new { outcome(method,s) }
    emit([method,'fiber b pause'], f.resume)
    s.replace('%zz')
    emit([method,'fiber b resume'],[f.resume,snap(s)])
  end
when 'overrides'
  METHODS.each do |method|
    name = method == :decode_uri_component ? :unescapeURIComponent : :unescape
    next emit([method,'cgi absent'],true) unless CGI.respond_to?(name)
    original = CGI.method(name)
    [false,true].each do |frozen|
      CGI.define_singleton_method(name) { |*| frozen ? 'intercepted'.freeze : 'intercepted' }
      emit([method,'CGI singleton',frozen],outcome(method,'a%41+b'))
    end
    CGI.define_singleton_method(name,original)
    hook = Module.new
    hook.define_method(name) { |*args| super(*args) + '!' }
    CGI.singleton_class.prepend(hook)
    emit([method,'CGI prepend'],outcome(method,'a%41+b'))
    hook.send(:remove_method,name)
    public_hook = Module.new
    public_hook.define_method(method) { |*args| super(*args) + '!' }
    URI.singleton_class.prepend(public_hook)
    emit([method,'URI public prepend'],outcome(method,'a%41+b'))
    public_hook.send(:remove_method,method)
  end
  hook = Module.new do
    private
    def _decode_uri_component(regexp, str, enc)
      super
    end
  end
  URI.singleton_class.prepend(hook)
  METHODS.each { |method| emit([method,'private helper old signature'],outcome(method,'a%41+b')) }
when 'load'
  METHODS.each { |method| emit([method,'value'],outcome(method,'a%41+b')) }
  load File.join(File.dirname(URI.method(:decode_www_form_component).source_location[0]),'common.rb')
  METHODS.each { |method| emit([method,'reload'],outcome(method,'a%41+b')) }
else
  abort mode
end
