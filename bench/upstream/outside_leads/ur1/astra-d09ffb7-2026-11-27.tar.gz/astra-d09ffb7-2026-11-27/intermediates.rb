require 'json'
require ENV['PRELUDE'] if ENV['PRELUDE']
require 'uri'
[:decode_www_form_component,:decode_uri_component].each do |method|
  [nil,1,:str].each do |middle|
    s = '%41'.dup
    s.define_singleton_method(:b) { middle }
    begin
      r = URI.send(method,s)
      p [method,middle,:ok,r]
    rescue Exception => e
      p [method,middle,:error,e.class.name,e.message.sub(/\n\n.*\z/m,'')]
    end
  end
  events = []
  middle = Object.new
  middle.define_singleton_method(:gsub) { |*| events << :gsub; 'from gsub' }
  middle.define_singleton_method(:to_str) { events << :to_str; 'b%42+c' }
  s = '%41'.dup
  s.define_singleton_method(:b) { middle }
  begin
    r = URI.send(method,s)
    p [method,:duck,:ok,r,events]
  rescue Exception => e
    p [method,:duck,:error,e.class.name,e.message.sub(/\n\n.*\z/m,''),events]
  end
  ['', 'plain', 'a+b', '%41', '%ff'].each do |text|
    s = text.dup
    s.taint if s.respond_to?(:taint)
    r = URI.send(method,s)
    p [method,:taint,text,r,r.respond_to?(:tainted?) && r.tainted?]
  end
end
