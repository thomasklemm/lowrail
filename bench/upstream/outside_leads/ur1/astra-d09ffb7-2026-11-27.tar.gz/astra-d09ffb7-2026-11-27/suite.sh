#!/usr/bin/env bash
set -u
here=$(cd "$(dirname "$0")" && pwd)
engine=$1
export PATH="$(mise where java@temurin-21)/bin:$PATH"
flags=()
case $engine in
  2.5.9) ruby=$here/ruby-2.5.9/bin/ruby ;;
  jruby-10.1.3.0) ruby=$here/jruby-10.1.3.0/bin/ruby ;;
  master) ruby=$here/master/bin/ruby ;;
  master-zjit) ruby=$here/master/bin/ruby; flags=(--zjit --zjit-call-threshold=1) ;;
  pure) ruby=$(mise where ruby@4.0.10)/bin/ruby; flags=(-r"$here/pure_cgi.rb") ;;
  *) ruby=$(mise where ruby@"$engine")/bin/ruby ;;
esac
export GEM_HOME=$here/test-gems GEM_PATH=$here/test-gems
for rev in base head; do
  "$ruby" "${flags[@]}" -I"$here/$rev/lib" -I"$here/head/test/lib" -rhelper -e 'Dir[ARGV[0]+"/test/uri/test_*.rb"].sort.each { |f| require f }' "$here/head" > "$here/results/$engine/$rev-suite.txt" 2>&1
  echo "$rev suite $?"
  grep -E '^[0-9]+ tests' "$here/results/$engine/$rev-suite.txt"
done
