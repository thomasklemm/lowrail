require 'fileutils'
here = __dir__
source = File.read("#{here}/head/lib/uri/common.rb")
mutants = {
  'head' => nil,
  'no_b' => ['yield(str.b)', 'yield(str)'],
  'no_force' => ['yield(str.b).force_encoding(enc)', 'yield(str.b)'],
  'in_place_fallback' => ['bytes.gsub(/%\\h\\h/, TBLDECWWWCOMP_)', 'bytes.gsub!(/%\\h\\h/, TBLDECWWWCOMP_)'],
  'upper_hex_fallback' => ['bytes.gsub(/%\\h\\h/, TBLDECWWWCOMP_)', 'bytes.gsub(/%[0-9A-F]{2}/, TBLDECWWWCOMP_)'],
  'word_hex_validation' => ['/%(?!\\h\\h)/', '/%(?!\\w\\w)/'],
  'native_form_preserves_plus' => ['CGI.unescape(bytes, Encoding::BINARY)', 'CGI.unescapeURIComponent(bytes, Encoding::BINARY)'],
  'native_uri_decodes_plus' => ['CGI.unescapeURIComponent(bytes, Encoding::BINARY)', 'CGI.unescape(bytes, Encoding::BINARY)'],
  'ruby_uri_decoder' => [' && !CGI.method(:unescapeURIComponent).source_location', ''],
  'return_nil_for_empty' => ['yield(str.b).force_encoding(enc)', 'return if str.empty?; yield(str.b).force_encoding(enc)']
}
mutants.each do |name, edit|
  dir = "#{here}/mutants/#{name}"
  FileUtils.mkdir_p(dir)
  FileUtils.cp_r("#{here}/head/lib",dir)
  text = source
  if edit
    raise "missing #{name}" unless source.include?(edit[0])
    text = source.sub(*edit)
  end
  File.write("#{dir}/lib/uri/common.rb",text)
end
