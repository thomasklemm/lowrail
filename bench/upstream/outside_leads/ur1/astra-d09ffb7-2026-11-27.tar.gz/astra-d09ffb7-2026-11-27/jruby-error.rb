require 'uri'
$stdout.sync = true
s = ['fea08fe95183172f802325b96335'].pack('H*').force_encoding('ISO-8859-14')
puts 'before decode'
begin
  p URI.decode_www_form_component(s, Encoding::UTF_16BE)
rescue Exception => e
  puts 'rescued'
  p e.class
  puts e.message.b.unpack('H*')[0]
end
puts 'finished'
