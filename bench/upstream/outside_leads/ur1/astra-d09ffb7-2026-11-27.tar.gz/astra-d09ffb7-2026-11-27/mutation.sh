#!/usr/bin/env bash
set -u
here=$(cd "$(dirname "$0")" && pwd)
engine=$1
if [ "$engine" = pure ]; then
  ruby=$(mise where ruby@4.0.10)/bin/ruby
  flags=(-r"$here/pure_cgi.rb")
elif [ "$engine" = 2.5.9 ]; then
  ruby=$here/ruby-2.5.9/bin/ruby
  flags=()
else
  ruby=$(mise where ruby@"$engine")/bin/ruby
  flags=()
fi
mkdir -p "$here/results/$engine/mutants"
for variant in "$here"/mutants/*; do
  name=${variant##*/}
  "$ruby" "${flags[@]}" -I"$variant/lib" "$here/eval_asserts.rb" > "$here/results/$engine/mutants/$name.jsonl" 2> "$here/results/$engine/mutants/$name.err"
  echo "$name $?"
done
