require 'uri'
require 'json'
load File.join(__dir__,'asserts.rb')
def assert_equal(expected, actual)
  raise "Expected #{expected.inspect}; got #{actual.inspect}" unless expected == actual
end
def assert_raise(klass)
  begin
    yield
  rescue Exception => e
    raise "Expected #{klass}; got #{e.class}: #{e.message}" unless e.is_a?(klass)
    return
  end
  raise "Expected #{klass}; nothing raised"
end
def assert_nothing_raised(*)
  yield
end
ASSERTS.each do |method,line,code|
  begin
    eval(code,binding,'assertions',line)
    puts JSON.generate([method,line,'pass'])
  rescue Exception => e
    puts JSON.generate([method,line,'fail',e.class.name,e.message.to_s])
  end
end
