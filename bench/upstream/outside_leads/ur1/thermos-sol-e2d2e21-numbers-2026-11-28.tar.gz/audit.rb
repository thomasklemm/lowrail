require "json"
require "digest"

repo = File.expand_path(ARGV.fetch(0))
prefix = File.join(repo, "bench/upstream/outside_leads/ur1/body")
body = File.read(File.join(__dir__, "UR1-f2365d60.md")).split(/^---\s*$/, 3).fetch(2)
names = ["hello", "form key", "form value", "cookie", "uri hello", "uri user"]
sides = %w[base candidate base2]
inputs = []
read = lambda do |path|
  inputs << path
  File.read(path)
end
check = ->(ok, label) { raise label unless ok }
close = lambda do |a, b|
  raise "different: #{a} != #{b}" unless (a - b).abs <= 1e-15 + [a.abs, b.abs].max * 1e-11
end
median = lambda do |xs|
  sorted = xs.sort
  (sorted[(sorted.size - 1) / 2] + sorted[sorted.size / 2]) / 2.0
end
interval = lambda do |rounds|
  random = Random.new(1)
  estimates = Array.new(5000) do
    sample = Array.new(rounds.size) { rounds.fetch(random.rand(rounds.size)) }.flatten
    median.call(sample)
  end.sort
  [estimates[124], estimates[4875]].map { |x| Math.exp(x) - 1 }
end
rate = lambda do |x|
  x >= 1_000_000 ? format("%.2fM i/s", x / 1_000_000.0) : format("%.1fk i/s", x / 1000.0)
end
body_rows = body.lines.filter_map do |line|
  match = line.match(/^\| (`decode_.+?) \| ([\d.Mk]+ i\/s) \| ([\d.Mk]+ i\/s) \|$/)
  match && match.captures
end
check.call(body_rows.size == 6, "body must have six rate rows")
wall_changes = []
window_count = 0

%w[4010 master].each do |version|
  dir = File.join(prefix, "UR1-d4ce0b0-#{version}-time")
  result = JSON.parse(read.call(File.join(dir, "results.json")))
  commands = read.call(File.join(dir, "commands.sh"))
  script = read.call(File.join(dir, "ur1_rework_body.rb"))
  check.call(result.fetch("sides").values.all? { |v| !v.fetch("dirty") }, "dirty tree")
  check.call(result.dig("sides", "base", "head") == "48cda77031e343d35213c36fe164b2a46ffbefa7", "wrong base")
  check.call(result.dig("sides", "candidate", "head") == "d4ce0b0376d0b1bbbf853c87ad0dd506ef6dc70c", "wrong head")
  check.call(result.dig("sides", "base", "ruby") == result.dig("sides", "candidate", "ruby"), "mixed Ruby pins")
  check.call(script.include?('COOKIE = "#{"A" * 200}--#{"b" * 40}%3D%3D"'), "changed cookie")
  check.call(("A" * 200 + "--" + "b" * 40 + "%3D%3D").bytesize == 248 && body.include?("248-byte"), "cookie size")
  benchmark_lines = commands.lines.select { |line| line.include?("--worker ") }
  check.call(benchmark_lines.all? { |line| result.fetch("heap").all? { |k, v| line.include?("#{k}=#{v}") } }, "heap drift")
  timed_lines = benchmark_lines.select { |line| line.match?(/--worker (wall |ips )/) }
  check.call(timed_lines.all? { |line| line.include?("taskset -c 1 ") }, "unpinned timer")
  wall_commands = timed_lines.select { |line| line.include?("--worker wall ") }
  flag = version == "4010" ? "--yjit" : "--zjit"
  check.call(wall_commands.size == 90 && wall_commands.all? { |line| line.include?(" #{flag} ") }, "wall mode drift")
  ips_commands = timed_lines.select { |line| line.include?("--worker ips ") }
  check.call(ips_commands.size == (version == "4010" ? 9 : 0) && ips_commands.none? { |line| line.match?(/--[yz]jit/) }, "IPS mode drift")
  calibration = read.call(File.join(dir, "raw/wall-calibrate.log")).scan(/^calibrate (.+)\t(\S+)$/).to_h
  check.call(calibration.keys == names, "missing calibration")
  names.each { |name| check.call((0.05 / Float(calibration.fetch(name))).round == result.fetch("wall").fetch(name).fetch("calls"), "calibration drift") }
  locks = %w[base candidate].map { |side| read.call(File.join(dir, side, "Gemfile.lock")) }
  check.call(locks.map { |text| text.sub(/  remote: \/home\/user\/w\/uri-.*\n/, "") }.uniq.size == 1, "bundle drift")

  if version == "4010"
    ips_rounds = names.to_h { |name| [name, sides.to_h { |side| [side, []] }] }
    1.upto(3) do |round|
      sides.each do |side|
        text = read.call(File.join(dir, "raw/ips-r#{round}-#{side}.log"))
        reports = text.scan(/^\s*(.+?)\s+(\d+(?:\.\d+)?)([kMB]?) \(.*\) i\/s/)
        check.call(reports.map(&:first) == names, "IPS case drift")
        reports.each do |name, number, unit|
          ips_rounds.fetch(name).fetch(side) << Float(number) * { "" => 1, "k" => 1000, "M" => 1_000_000, "B" => 1_000_000_000 }.fetch(unit)
        end
      end
    end
    names.each_with_index do |name, index|
      cell = result.fetch("ips").fetch(name)
      raw = ips_rounds.fetch(name)
      check.call(raw == cell.fetch("rounds"), "IPS raw/JSON drift")
      b1, after, b2 = sides.map { |side| raw.fetch(side).max }
      before = (b1 + b2) / 2.0
      change = after / before - 1
      aa = (b2 - b1).abs / before
      { "base1" => b1, "base2" => b2, "base" => before, "candidate" => after, "change" => change, "aa" => aa }.each { |k, v| close.call(v, cell.fetch(k)) }
      check.call(change > aa && cell.fetch("claim"), "IPS gain inside A/A")
      check.call(body_rows.fetch(index).drop(1) == [rate.call(before), rate.call(after)], "body rate mismatch")
      puts "IPS #{name}: #{b1} / #{after} / #{b2}; mean base #{before}; #{rate.call(before)} -> #{rate.call(after)}; gain #{change * 100}%; A/A #{aa * 100}%"
    end
  end

  jit_keys = version == "4010" ? %w[compiled_iseq_count compiled_block_count invalidation_count] : %w[compiled_iseq_count failed_iseq_count compiled_side_exit_count invalidation_time_ns]
  raw_rounds = names.to_h { |name| [name, []] }
  1.upto(30) do |round|
    records = sides.to_h do |side|
      text = read.call(File.join(dir, "raw/wall-r#{round}-#{side}.log"))
      samples = text.scan(/^wall (.+)\t(.+)$/).to_h.transform_values { |json| JSON.parse(json) }
      counters = text.scan(/^jit (.+)\t(.+)$/).to_h
      check.call(samples.keys == names && counters.keys == names, "wall case drift")
      samples.each do |name, windows|
        check.call(windows.keys.sort == %w[cpu wall] && windows.values.all? { |v| v.size == 30 && v.all?(&:positive?) }, "missing raw window")
        parsed = counters.fetch(name).scan(/(\w+)=(\d+)>(\d+)/).to_h { |key, a, b| [key, [Integer(a), Integer(b)]] }
        check.call(parsed.keys == jit_keys && parsed.values.all? { |a, b| a == 0 && b == 0 }, "non-flat/missing JIT counter")
        cell = result.fetch("wall").fetch(name)
        recorded = cell.fetch("jit").fetch("windows").find { |w| w.fetch("window") == "r#{round} #{side}" }
        check.call(recorded && parsed == recorded.fetch("counters"), "JIT raw/JSON drift")
        window_count += windows.fetch("cpu").size
      end
      [side, samples]
    end
    names.each { |name| raw_rounds.fetch(name) << sides.to_h { |side| [side, records.fetch(side).fetch(name)] } }
  end
  names.each do |name|
    cell = result.fetch("wall").fetch(name)
    rounds = raw_rounds.fetch(name)
    check.call(rounds == cell.fetch("rounds") && cell.fetch("windows") == 30 && cell.fetch("quantile") == 0.1, "raw wall/JSON drift")
    check.call(cell.fetch("jit").fetch("flat") && cell.fetch("jit").fetch("windows").size == 90, "bad flat summary")
    process_logs = rounds.map do |r|
      r.transform_values { |w| Math.log(w.fetch("cpu").sort.fetch(3) / cell.fetch("calls")) }
    end
    deltas = process_logs.map { |r| [r.fetch("candidate") - r.fetch("base"), r.fetch("candidate") - r.fetch("base2")] }
    controls = process_logs.map { |r| [r.fetch("base2") - r.fetch("base")] }
    stats = {
      "base" => Math.exp(median.call(process_logs.map { |r| (r.fetch("base") + r.fetch("base2")) / 2.0 })),
      "candidate" => Math.exp(median.call(process_logs.map { |r| r.fetch("candidate") })),
      "change" => Math.exp(median.call(deltas.flatten)) - 1,
      "aa" => Math.exp(median.call(controls.flatten)) - 1,
      "change_ci" => interval.call(deltas), "aa_ci" => interval.call(controls)
    }
    stats.each { |key, value| Array(value).zip(Array(cell.fetch(key))).each { |a, b| close.call(a, b) } }
    check.call(stats.fetch("aa_ci").first <= 0 && stats.fetch("aa_ci").last >= 0 && stats.fetch("change_ci").last < 0, "failed wall confidence gate")
    check.call(cell.fetch("aa_pass") && cell.fetch("claim"), "bad claim summary")
    wall_changes << -stats.fetch("change") * 100
    puts "#{version} wall #{name}: reduction #{-stats.fetch('change') * 100}%; change CI #{stats.fetch('change_ci').map { |n| n * 100 }}; A/A #{stats.fetch('aa') * 100}% #{stats.fetch('aa_ci').map { |n| n * 100 }}; all 2700 windows JIT-flat"
  end

  modes = version == "4010" ? %w[interp yjit] : %w[zjit]
  modes.each do |mode|
    logs = sides.to_h do |side|
      text = read.call(File.join(dir, "raw/objects-#{mode}-#{side}.log"))
      values = text.scan(/^objects (.+)\t([\d.]+)$/).to_h.transform_values { |n| Float(n) }
      check.call(values.keys == names, "objects case drift")
      [side, values]
    end
    check.call(logs.fetch("base") == logs.fetch("base2"), "objects A/A drift")
    check.call(logs.fetch("base").values.map(&:round) == [4, 7, 8, 7, 4, 6], "base object range")
    check.call(logs.fetch("candidate").values.map(&:round) == [3, 2, 2, 2, 3, 2], "candidate object range")
    puts "#{version} #{mode} objects: #{logs.fetch('base').values.inspect} -> #{logs.fetch('candidate').values.inspect}; exact A/A"
  end
end

check.call(body.include?("time per call drops by 23% to 80%") && wall_changes.min.floor == 23 && wall_changes.max.round == 80, "body timing range")
check.call(body.include?("Each call allocates 2 or 3 objects instead of 4 to 8."), "body objects sentence changed")
puts "Body range: #{wall_changes.min}% to #{wall_changes.max}%; 23% floors the minimum, 80% rounds the maximum"
puts "PASS: all 12 throughput cells, 12 wall point estimates and 24 bootstrap intervals, 54 allocation observations, #{window_count} timed JIT windows"
File.write(File.join(__dir__, "inputs.sha256"), inputs.uniq.sort.map { |path| "#{Digest::SHA256.file(path).hexdigest}  #{path.delete_prefix(repo + '/')}\n" }.join)
