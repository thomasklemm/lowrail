require 'json'
require 'digest'
require 'shellwords'

ROOT = File.expand_path('../../../..', __dir__)
DATA = File.join(ROOT, 'bench/upstream/outside_leads/ur1/body')
NAMES = ['hello', 'form key', 'form value', 'cookie', 'uri hello', 'uri user']
SIDES = ['base', 'candidate', 'base2']
INPUTS = {}
def read(path)
  text = File.read(path)
  INPUTS[path.delete_prefix(ROOT + '/')] = Digest::SHA256.hexdigest(text)
  text
end
def check(value, label)
  raise label unless value
end
def close(a, b)
  (a - b).abs < 1e-12
end
def median(values)
  sorted = values.sort
  mid = sorted.size / 2
  sorted.size.odd? ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2.0
end
def interval(rows)
  rng = Random.new(1)
  samples = 5000.times.map do
    selected = rows.size.times.flat_map { rows.fetch(rng.rand(rows.size)) }
    median(selected)
  end.sort
  [samples[124], samples[4875]].map { Math.exp(_1) - 1 }
end
def rate(value)
  value >= 1_000_000 ? format('%.2fM i/s', value / 1_000_000) : format('%.1fk i/s', value / 1000)
end

body = read(File.join(__dir__, 'queue.md')).split('---', 3)[2]
File.write(File.join(__dir__, 'body.md'), body)
puts "Body SHA256 #{Digest::SHA256.hexdigest(body)}"
body_cells = body.lines.grep(/^\| `decode_/).map { _1.split('|')[2..3].map(&:strip) }
check(body_cells.size == 6, 'body rows')
wall_changes = []
%w[4010 master].each do |version|
  dir = File.join(DATA, "UR1-d4ce0b0-#{version}-time")
  results = JSON.parse(read(File.join(dir, 'results.json')))
  check(results['sides']['base']['head'] == '48cda77031e343d35213c36fe164b2a46ffbefa7', 'base pin')
  check(results['sides']['candidate']['head'] == 'd4ce0b0376d0b1bbbf853c87ad0dd506ef6dc70c', 'candidate pin')
  check(results['sides'].values.none? { _1['dirty'] }, 'clean measured trees')
  check(results['sides']['base']['description'] == results['sides']['candidate']['description'], 'same Ruby')
  puts "#{version}: #{results['sides']['base']['description']}"
  read(File.join(dir, 'ur1_rework_body.rb'))
  commands = read(File.join(dir, 'commands.sh'))
  wall_commands = commands.lines.select { _1.include?('--worker wall ') }
  check(wall_commands.size == 90, '90 wall processes')
  flag = version == '4010' ? '--yjit' : '--zjit'
  check(wall_commands.all? { _1.include?(flag) && _1.include?('taskset -c 1') }, 'JIT/core flags')
  calibration = read(File.join(dir, 'raw', 'wall-calibrate.log')).lines.to_h do |line|
    name, time = line.delete_prefix('calibrate ').split("\t")
    [name, (0.05 / Float(time)).round]
  end
  check(calibration == results['wall'].transform_values { _1['calls'] }, 'calibrated counts')
  wall_commands.each do |line|
    args = Shellwords.split(line)
    check(JSON.parse(args[args.index('--worker') + 3]) == calibration, 'executed call counts')
  end
  %w[base candidate].each { |side| read(File.join(dir, side, 'Gemfile')); read(File.join(dir, side, 'Gemfile.lock')) }
  keys = version == '4010' ? %w[compiled_iseq_count compiled_block_count invalidation_count] :
    %w[compiled_iseq_count failed_iseq_count compiled_side_exit_count invalidation_time_ns]
  raw_rounds = Array.new(30) do |i|
    SIDES.to_h do |side|
      text = read(File.join(dir, 'raw', "wall-r#{i+1}-#{side}.log"))
      values = text.lines.grep(/^wall /).to_h do |line|
        name, json = line.delete_prefix('wall ').split("\t", 2)
        [name, JSON.parse(json)]
      end
      gates = text.lines.grep(/^jit /).to_h do |line|
        name, stats = line.delete_prefix('jit ').split("\t", 2)
        counters = stats.split.to_h { |field| k, pair = field.split('='); [k, pair.split('>').map { Integer(_1) }] }
        check(counters.keys == keys && counters.values.all? { _1 == [0, 0] }, "JIT moved/missing #{i} #{side} #{name}")
        [name, counters]
      end
      check(values.keys == NAMES && gates.keys == NAMES, 'six raw cases and gates')
      values.each_value { |v| check(v.keys.sort == %w[cpu wall] && v.values.all? { _1.size == 30 && _1.all?(&:positive?) }, '30 valid windows') }
      [side, values]
    end
  end
  NAMES.each do |name|
    cell = results['wall'].fetch(name)
    rows = raw_rounds.map { |round| round.transform_values { _1.fetch(name) } }
    check(rows == cell['rounds'], "raw/JSON mismatch #{name}")
    check(cell['windows'] == 30 && cell['quantile'] == 0.1, 'window metadata')
    estimates = rows.map { |r| r.transform_values { Math.log(_1['cpu'].sort[3] / cell['calls']) } }
    changes = estimates.map { |r| [r['candidate']-r['base'], r['candidate']-r['base2']] }
    controls = estimates.map { |r| [r['base2']-r['base']] }
    change = Math.exp(median(changes.flatten))-1
    aa = Math.exp(median(controls.flatten))-1
    change_ci, aa_ci = interval(changes), interval(controls)
    check(close(change, cell['change']) && close(aa, cell['aa']), 'point estimate')
    check(change_ci.zip(cell['change_ci']).all? { close(*_1) } && aa_ci.zip(cell['aa_ci']).all? { close(*_1) }, 'bootstrap interval')
    check(aa_ci[0] <= 0 && aa_ci[1] >= 0 && change_ci[1] < 0, 'A/A or effect gate')
    check(cell['jit']['flat'] && cell['jit']['windows'].size == 90 && cell['claim'], 'recorded claim')
    puts format('%s %-10s change %+.6f%% CI [%+.6f,%+.6f]; A/A %+.6f%% CI [%+.6f,%+.6f]', version, name, change*100, *change_ci.map { _1*100 }, aa*100, *aa_ci.map { _1*100 })
    wall_changes << change
  end
  modes = version == '4010' ? %w[interp yjit] : ['zjit']
  modes.each do |mode|
    values = SIDES.to_h do |side|
      text = read(File.join(dir, 'raw', "objects-#{mode}-#{side}.log"))
      [side, text.lines.to_h { |line| name, value = line.delete_prefix('objects ').split("\t"); [name, Float(value)] }]
    end
    check(values['base'] == values['base2'], 'objects A/A')
    check(values['base'].values == [3.999, 7.0, 8.0, 7.0, 4.0, 6.0], 'base objects')
    check(values['candidate'].values == [2.999, 2.0, 2.0, 2.0, 3.0, 2.0], 'candidate objects')
    puts "#{version}/#{mode} objects base #{values['base'].values.inspect}, candidate #{values['candidate'].values.inspect}; A/A identical"
  end
  next unless version == '4010'
  rates = SIDES.to_h do |side|
    rows = (1..3).map do |i|
      text = read(File.join(dir, 'raw', "ips-r#{i}-#{side}.log"))
      text.lines.grep(/\) i\/s/).to_h do |line|
        match = line.match(/^\s*(.+?)\s+([\d.]+)([kM]?) \(±/)
        [match[1], Float(match[2]) * {'k'=>1000, 'M'=>1_000_000, ''=>1}.fetch(match[3])]
      end
    end
    [side, NAMES.to_h { |name| [name, rows.map { _1.fetch(name) }] }]
  end
  NAMES.each_with_index do |name, i|
    cell = results['ips'][name]
    SIDES.each { |side| check(rates[side][name] == cell['rounds'][side], 'ips raw/JSON') }
    b1, c, b2 = SIDES.map { rates[_1][name].max }
    b = (b1 + b2)/2.0
    aa = (b1-b2).abs/b
    check([b, c] == [cell['base'], cell['candidate']], 'ips maxima')
    check(c/b-1 > aa, 'ips A/A')
    check([rate(b), rate(c)] == body_cells[i], "body cell #{name}")
    puts "ips #{name}: base maxima #{b1}/#{b2}, mean #{b}, candidate max #{c}; body #{body_cells[i].inspect}; A/A #{aa*100}%"
  end
end
check(body.include?('23% to 80%') && body.include?('2 or 3 objects instead of 4 to 8'), 'body claims')
check((-wall_changes.max*100).floor == 23 && (-wall_changes.min*100).round == 80, 'rounded range')
puts "Combined reduction range #{-wall_changes.max*100}% to #{-wall_changes.min*100}%"
File.write(File.join(__dir__, 'input-sha256.json'), JSON.pretty_generate(INPUTS) + "\n")
puts 'PASS: all 12 table cells, 12 wall cells, A/A intervals, 32,400 JIT-flat windows and object logs'
