require 'json'
require 'uri'

class PlainSub < String; end
class IdentityToS < String
  def to_s; self; end
end
class ReplacingToS < String
  def to_s; 'replacement'; end
end
class RaisingToS < String
  def to_s; raise 'to_s hook'; end
end

[String, PlainSub, IdentityToS, ReplacingToS, RaisingToS].each do |klass|
  ['', 'abc', 'a%41+b', "\x82\x33\xE7\x34".force_encoding('GB18030')].each do |text|
    [false, true].each do |frozen|
      input = klass.new(text)
      input.freeze if frozen
      result = begin
        value = URI.decode_www_form_component(input)
        [value.class.name, value.unpack1('H*'), value.encoding.name, value.frozen?]
      rescue Exception => error
        [error.class.name, error.message]
      end
      puts JSON.generate([klass.name, text.unpack1('H*'), frozen, result])
    end
  end
end
