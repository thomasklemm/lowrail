require 'json'
require 'uri'
require 'active_support'
require 'active_support/core_ext/string/output_safety'

puts JSON.generate([RUBY_DESCRIPTION, ActiveSupport.version.to_s, CGI.method(:unescape).source_location])
['', 'hello', '<script>alert(1)</script>', '%3Cscript%3E', 'hello+world'].each do |text|
  input = ActiveSupport::SafeBuffer.new(text)
  result = URI.decode_www_form_component(input)
  puts JSON.generate([text, result.class.name, result, result.html_safe?, ERB::Util.html_escape(result)])
end
