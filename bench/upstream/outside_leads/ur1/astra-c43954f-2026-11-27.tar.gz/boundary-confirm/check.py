import json
import math
import pathlib
import re

roots = pathlib.Path('bench/upstream/outside_leads/ur1/body')
labels = ['hello', 'form key', 'form value', 'cookie']
body_rows = [(4, 4486, 3, 3553), (7, 13101, 2, 4973), (8, 15320, 2, 4548), (7, 18059, 2, 9283)]
for run, modes in [('4010', ['interp', 'yjit']), ('master', ['interp', 'zjit'])]:
    root = roots / ('UR1-cecaed1-' + run)
    data = json.loads((root / 'results.json').read_text())
    assert data['sides']['base']['head'] == '48cda77031e343d35213c36fe164b2a46ffbefa7'
    assert data['sides']['candidate']['head'] == 'cecaed123f04e1704bccf4b1b3272c0b12e759c7'
    assert data['sides']['base']['description'] == data['sides']['candidate']['description']
    assert not any(side['dirty'] for side in data['sides'].values())
    for mode in modes:
        for i, label in enumerate(labels, 1):
            key = mode + ' ' + label
            for side, field in [('base', 'base1'), ('base2', 'base2'), ('candidate', 'candidate')]:
                prefix = root / 'raw' / ('ir-%s-%s-%s-%s' % (mode, i, label.replace(' ', '_'), side))
                totals = []
                for n in [0, data['n']]:
                    text = pathlib.Path(str(prefix) + '-n%s.callgrind' % n).read_text()
                    totals.append(int(re.search(r'^totals: (\d+)$', text, re.M)[1]))
                    if mode != 'interp':
                        log = pathlib.Path(str(prefix) + '-n%s.log' % n).read_text()
                        counters = re.findall(r'(\w+)=(\d+)>(\d+)', log)
                        assert len(counters) >= 3 and all(a == b for _, a, b in counters), log
                measured = (totals[1] - totals[0]) / data['n']
                assert math.isclose(measured, data['instructions'][key][field], abs_tol=1e-9)
                obj_text = (root / 'raw' / ('objects-%s-%s.log' % (mode, side))).read_text()
                objects = float(re.search(r'^objects ' + re.escape(label) + r'\t(.*)$', obj_text, re.M)[1])
                assert objects == data['objects'][key][field]
            for kind in ['instructions', 'objects']:
                row = data[kind][key]
                base = (row['base1'] + row['base2']) / 2
                aa = abs(row['base1'] - row['base2']) / base
                change = row['candidate'] / base - 1
                assert math.isclose(row['base'], base)
                assert math.isclose(row['aa'], aa)
                assert math.isclose(row['change'], change)
                assert abs(change) > aa and row['claim'] is True
            if run == '4010' and mode == 'interp':
                obs = data['objects'][key]
                ir = data['instructions'][key]
                assert tuple(round(x) for x in (obs['base'], ir['base'], obs['candidate'], ir['candidate'])) == body_rows[i - 1]
            print(run, key, 'PASS: raw objects, N-minus-zero instructions, A/A, claim and JIT counters')

body = pathlib.Path('bench/upstream/pr-queue/items/UR1.md').read_text().split('\n---\n', 2)[-1]
table = [line for line in body.splitlines() if line.startswith('| `') or line.startswith('| a 248')]
assert len(table) == 4
for row, expected in zip(table, body_rows):
    numbers = tuple(int(n.replace(',', '')) for n in re.findall(r'\d[\d,]*', '|'.join(row.split('|')[2:])))
    assert numbers == expected, (numbers, expected)
assert len('A' * 200 + '--' + 'b' * 40 + '%3D%3D') == 248
print('PASS: every body table value and cookie size; no fresh performance measurement')
