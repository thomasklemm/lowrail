`URI.decode_www_form_component` copies the string with `b` and then runs `gsub` with a regexp and a hash table, so every `+` and `%XX` is matched and looked up in Ruby. Rack decodes query strings and cookies with it ([Rack::QueryParser](https://github.com/rack/rack/blob/52941a02842fd956e3c5532147116354a0240149/lib/rack/query_parser.rb#L268) and [Rack::Utils.unescape](https://github.com/rack/rack/blob/52941a02842fd956e3c5532147116354a0240149/lib/rack/utils.rb#L59) in Rack 3.2.9), and Rails decodes query parameters and URL-encoded form fields with it ([ActionDispatch::QueryParser, Rails 8.1.4.1](https://github.com/rails/rails/blob/3f290b759c8e2ffe7c257951b1255740751355e4/actionpack/lib/action_dispatch/http/query_parser.rb#L46-L47)).

This replaces only the `gsub` with `CGI.unescape` from cgi/escape, which decodes `+` and `%XX` the same way in one pass in C. The check for an invalid `%`, the `b` copy and the final `force_encoding` stay, so the result has the same class, bytes and encoding as before.

| Objects and instructions per call, Ruby 4.0.10 | Before | After |
| --- | ---: | ---: |
| `"hello"` | 4 objects, 4,486 | 3 objects, 3,553 |
| `"article%5Btitle%5D"` | 7, 13,101 | 2, 4,973 |
| `"Hello+world+from+Rack"` | 8, 15,320 | 2, 4,548 |
| a 248-byte cookie value | 7, 18,059 | 2, 9,283 |