import json
import math
import pathlib
import re

root = pathlib.Path('bench/upstream/outside_leads/ur1/body/UR1-4010')
data = json.loads((root / 'results.json').read_text())
labels = ['hello', 'form key', 'form value', 'cookie']
for i, label in enumerate(labels, 1):
    key = 'interp ' + label
    for side, field in [('base', 'base1'), ('base2', 'base2'), ('candidate', 'candidate')]:
        prefix = root / 'raw' / ('ir-interp-%s-%s-%s' % (i, label.replace(' ', '_'), side))
        def total(n):
            text = pathlib.Path(str(prefix) + '-n%s.callgrind' % n).read_text()
            return int(re.search(r'^totals: (\d+)$', text, re.M)[1])
        measured = (total(data['n']) - total(0)) / data['n']
        assert math.isclose(measured, data['instructions'][key][field], abs_tol=1e-9)
        obj_text = (root / 'raw' / ('objects-interp-%s.log' % side)).read_text()
        objects = float(re.search(r'^objects ' + re.escape(label) + r'\t(.*)$', obj_text, re.M)[1])
        assert objects == data['objects'][key][field]
    for kind in ['instructions', 'objects']:
        row = data[kind][key]
        assert math.isclose(row['base'], (row['base1'] + row['base2']) / 2)
        assert row['claim'] is True
    print(label, 'raw counts and A/A aggregates agree with results.json')
assert data['sides']['base']['head'] == '48cda77031e343d35213c36fe164b2a46ffbefa7'
assert data['sides']['candidate']['head'] == 'a3b201f05b2efd737af193bc45ebd0534b3b6a5c'
print('Body table matches rounded results.json values; no benchmark rerun or new performance claim.')
