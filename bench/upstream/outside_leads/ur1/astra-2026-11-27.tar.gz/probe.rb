require 'json'
require 'digest'
if ENV['PURE']
  $LOADED_FEATURES << 'cgi/escape.so'
end
require 'uri'
require 'cgi/escape'

def snap(s)
  [s.class.name, String.instance_method(:unpack1).bind_call(s, 'H*'), String.instance_method(:encoding).bind_call(s).name,
    String.instance_method(:valid_encoding?).bind_call(s), s.frozen?, s.instance_variables.sort, s.singleton_methods.sort]
end

def outcome(s, enc = [Encoding::UTF_8])
  r = URI.decode_www_form_component(s, *enc)
  ['ok', snap(r), r.equal?(s)]
rescue Exception => e
  message = e.message.b.gsub(/0x[0-9a-f]+/, '0xOBJECT')
  ['error', e.class.name, message.ascii_only? ? message : ['hex', message.unpack1('H*')]]
end

def emit(label, result)
  puts JSON.generate([label, result])
end

mode = ARGV.fetch(0)
case mode
when 'values'
  rng = Random.new(81274)
  seeds = ['', 'a+b%00%ff%2B', '%', '%0', '%xz', '%%41', '%41%', "%41\0", '%2b%252b', "\xff".b, "a\xc2\x80%41".b]
  Encoding.list.each do |enc|
    seeds.each_with_index { |s,i| emit("encoding/#{enc.name}/#{i}", outcome(s.dup.force_encoding(enc))) }
    256.times do |b|
      emit("byte/#{enc.name}/#{b}", outcome([b, 37, 52, 49, 43, 98].pack('C*').force_encoding(enc)))
    end
  end
  targets = [[], [nil], [false], [0], [:UTF_8], ['UTF-8'], ['binary'], ['nope'], ["UTF-8\0"], [Encoding::UTF_16BE], [Encoding::UTF_7]]
  seeds.each_with_index do |s,i|
    targets.each_with_index { |e,j| emit("target/#{i}/#{j}", outcome(s, e)) }
  end
  20_000.times do |i|
    s = Array.new(rng.rand(0..48)) { rng.rand(256) }.pack('C*').force_encoding(Encoding.list.sample(random: rng))
    emit("random/#{i}", outcome(s))
  end
  [0, 1, 32, 1_048_576, 8_388_608].each do |n|
    ['x' * n, '%41' + 'x' * n, 'x' * n + '%41', '%41' * (n / 3), 'x' * n + '%', 'x' * n + '+'].each_with_index do |s,i|
      result = outcome(s.freeze)
      result[1][1] = [result[1][1].size, Digest::SHA256.hexdigest(result[1][1])] if result[0] == 'ok'
      result[2] = [result[2].size, Digest::SHA256.hexdigest(result[2])] if result[0] == 'error'
      result << s.frozen?
      emit("huge/#{n}/#{i}", result)
    end
  end
  emit('chilled', outcome(eval('"a%41+b"')))
when 'objects'
  [:b, :encoding, :instance_of?, :to_str, :gsub, :force_encoding, :tr].each do |method|
    [false, true].each do |private_method|
      s = +'a%41+b'
      s.define_singleton_method(method) { |*| raise "hook #{method}" }
      s.singleton_class.send(:private, method) if private_method
      emit("singleton/#{method}/#{private_method}", outcome(s))
    end
  end
  s = +'a%41+b'
  s.extend(Module.new { def b; 'extended'; end })
  emit('extended b', outcome(s))
  s = +'a%41+b'
  s.singleton_class.prepend(Module.new { def b; 'prepended'; end })
  emit('prepended b', outcome(s))
  s = +'a%41+b'
  def s.encoding; replace('%zz'); Encoding::UTF_8; end
  emit('encoding mutates after validation', outcome(s))
  emit('input after encoding mutation', snap(s))
  s = +'a%41+b'
  def s.b; 'frozen'.freeze; end
  emit('b returns frozen', outcome(s))
  klass = Class.new(String) { def b; 'subclass'; end }
  emit('subclass b', outcome(klass.new('a%41+b')))
  klass = Class.new(String) do
    def instance_of?(k); k == String; end
    def b; 'subclass'; end
  end
  emit('subclass spoofs instance_of', outcome(klass.new('a%41+b')))
  obj = BasicObject.new
  def obj.to_str; 'a%41+b'; end
  def obj.b; 'a%41+b'; end
  emit('BasicObject duck b', outcome(obj))
  obj = Object.new
  def obj.to_str; 'a%41+b'; end
  def obj.b; 'a%41+b'; end
  emit('Object duck b', outcome(obj))
  ['UTF-8', 'bad', nil, 123].each do |name|
    [false, true].each do |priv|
      calls = []
      obj = Object.new
      obj.define_singleton_method(:to_str) { calls << 'to_str'; name }
      obj.singleton_class.send(:private, :to_str) if priv
      emit("encoding duck/#{name}/#{priv}", [outcome('a%ff', [obj]), calls])
    end
  end
  obj = Object.new
  def obj.respond_to_missing?(m, *); m == :to_str || super; end
  def obj.method_missing(m, *); m == :to_str ? 'UTF-8' : super; end
  emit('encoding method_missing', outcome('a%ff', [obj]))
  s = +'a%41+b'
  e = Object.new
  e.define_singleton_method(:to_str) { s.replace('changed'); 'UTF-8' }
  emit('encoding conversion mutates input', outcome(s, [e]))
  emit('input after encoding conversion', snap(s))
when 'cgi_prepend'
  CGI.singleton_class.prepend(Module.new do
    def unescape(s, *args)
      'intercepted'
    end
  end)
  emit(mode, outcome('a%41+b'))
when 'cgi_singleton_frozen'
  def CGI.unescape(*); 'intercepted'.freeze; end
  emit(mode, outcome('a%41+b'))
when 'uri_prepend'
  URI.singleton_class.prepend(Module.new do
    def decode_www_form_component(s, *args)
      super + '!'
    end
  end)
  emit(mode, outcome('a%41+b'))
when 'uri_private_prepend'
  URI.singleton_class.prepend(Module.new do
    private
    def _decode_uri_component(*); 'intercepted'; end
  end)
  emit(mode, outcome('a%41+b'))
when 'threads'
  workers = 8.times.map do
    Thread.new do
      1000.times.all? { outcome('a%ff+b')[0,2] == ['ok', ['String', '61ff2062', 'UTF-8', false, false, [], []]] }
    end
  end
  emit(mode, workers.map(&:value))
when 'ractors'
  workers = 4.times.map do
    Ractor.new do
      begin
        1000.times.all? { URI.decode_www_form_component('a%ff+b').unpack1('H*') == '61ff2062' }
      rescue Exception => ractor_error
        [ractor_error.class.name, ractor_error.message]
      end
    end
  end
  emit(mode, workers.map(&:value))
when 'fiber'
  input = +'a%41+b'
  enc = Object.new
  enc.define_singleton_method(:to_str) { Fiber.yield(:suspended); 'UTF-8' }
  f = Fiber.new { outcome(input, [enc]) }
  emit('suspension', f.resume)
  input.replace('%zz')
  emit('after resume', f.resume)
when 'reload'
  load File.join(File.dirname(URI.method(:decode_www_form_component).source_location[0]), 'common.rb')
  emit(mode, outcome('a%41+b'))
else
  abort mode
end
