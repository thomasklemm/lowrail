`URI.decode_www_form_component` copies the string with `b` and then runs `gsub` with a regexp and a hash table, so every `+` and `%XX` is matched and looked up in Ruby. Rack decodes query strings and cookies with it ([Rack::QueryParser](https://github.com/rack/rack/blob/52941a02842fd956e3c5532147116354a0240149/lib/rack/query_parser.rb#L268) and [Rack::Utils.unescape](https://github.com/rack/rack/blob/52941a02842fd956e3c5532147116354a0240149/lib/rack/utils.rb#L59) in Rack 3.2.9), and Rails decodes query parameters and URL-encoded form fields with it ([ActionDispatch::QueryParser, Rails 8.1.4.1](https://github.com/rails/rails/blob/3f290b759c8e2ffe7c257951b1255740751355e4/actionpack/lib/action_dispatch/http/query_parser.rb#L46-L47)).

This replaces only the `gsub` with `CGI.unescape` from cgi/escape, which decodes `+` and `%XX` the same way in one pass in C. The check for an invalid `%`, the `b` copy and the final `force_encoding` stay, so the result has the same class, bytes and encoding as before. The one exception is JRuby 9.4, whose `String#b` keeps a String subclass: there, a subclass with nothing to decode comes back as that subclass.

| benchmark-ips, Ruby 4.0.10 | Before | After |
| --- | ---: | ---: |
| `"hello"` | 2.65M i/s | 3.72M i/s |
| `"article%5Btitle%5D"` | 816.4k i/s | 2.72M i/s |
| `"Hello+world+from+Rack"` | 685.7k i/s | 2.89M i/s |
| a 248-byte cookie value | 509.0k i/s | 1.11M i/s |

With YJIT, and with ZJIT on Ruby master, time per call drops by 25% to 80%. Each call allocates 2 or 3 objects instead of 4 to 8.