import json
import math
from pathlib import Path
import re
from statistics import median

root = Path('bench/upstream/outside_leads/ur1/body')
body = Path('bench/upstream/pr-queue/items/UR1.md').read_text().split('\n---\n')[-1]
names = ['hello', 'form key', 'form value', 'cookie']
rows = [line.split('|')[2:4] for line in body.splitlines() if line.startswith('| `') or line.startswith('| a 248')]
assert len(rows) == 4
reductions = []
jit_reports = 0

def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-15), (a, b)

def rate(x):
    return f'{x / 1e6:.2f}M i/s' if x >= 1e6 else f'{x / 1000:.1f}k i/s'

for pin in ['4010', 'master']:
    directory = root / f'UR1-cecaed1-{pin}-time'
    data = json.loads((directory / 'results.json').read_text())
    assert data['sides']['base']['head'] == '48cda77031e343d35213c36fe164b2a46ffbefa7'
    assert data['sides']['candidate']['head'] == 'cecaed123f04e1704bccf4b1b3272c0b12e759c7'
    assert data['sides']['base']['description'] == data['sides']['candidate']['description']
    assert not any(s['dirty'] for s in data['sides'].values())
    for name, cell in data['ips'].items():
        maxima = {}
        for side in ['base', 'base2', 'candidate']:
            values = []
            for n in range(1, 4):
                text = (directory / 'raw' / f'ips-r{n}-{side}.log').read_text()
                match = re.search(r'^\s*' + re.escape(name) + r'\s+([\d.]+)([kM]?) \(.*? i/s', text, re.M)
                values.append(float(match[1]) * {'': 1, 'k': 1000, 'M': 1e6}[match[2]])
            assert values == cell['rounds'][side]
            maxima[side] = max(values)
        base = (maxima['base'] + maxima['base2']) / 2
        aa = abs(maxima['base'] - maxima['base2']) / base
        change = maxima['candidate'] / base - 1
        close(base, cell['base'])
        close(aa, cell['aa'])
        close(change, cell['change'])
        assert cell['claim'] and change > aa
        assert [x.strip() for x in rows[names.index(name)]] == [rate(base), rate(maxima['candidate'])]
        print(f'ips {name}: body matches raw best-of-three, A/A {aa:.3%}, throughput +{change:.3%}')
    for name, cell in data['wall'].items():
        estimates = []
        assert len(cell['rounds']) == 30 and cell['windows'] == 30
        for n, saved in enumerate(cell['rounds'], 1):
            values = {}
            for side in ['base', 'base2', 'candidate']:
                text = (directory / 'raw' / f'wall-r{n}-{side}.log').read_text()
                raw = json.loads(re.search(r'^wall ' + re.escape(name) + r'\t(.*)$', text, re.M)[1])
                assert raw == saved[side]
                assert len(raw['cpu']) == len(raw['wall']) == 30
                values[side] = math.log(sorted(raw['cpu'])[3] / cell['calls'])
                line = re.search(r'^jit ' + re.escape(name) + r'\t(.*)$', text, re.M)[1]
                counters = re.findall(r'(\w+)=(\d+)>(\d+)', line)
                assert len(counters) >= 3 and all(a == b for _, a, b in counters)
                jit_reports += 1
            estimates.append(values)
        change = math.exp(median([r['candidate'] - r[s] for r in estimates for s in ['base', 'base2']])) - 1
        aa = math.exp(median([r['base2'] - r['base'] for r in estimates])) - 1
        close(change, cell['change'])
        close(aa, cell['aa'])
        assert cell['aa_ci'][0] <= 0 <= cell['aa_ci'][1]
        assert cell['change_ci'][1] < 0 and cell['claim'] and cell['aa_pass'] and cell['jit']['flat']
        reductions.append(-100 * change)
        print(f'{pin} {name}: raw 30-round reduction {-change:.3%}; stored A/A CI includes zero, change CI excludes zero')
    for file in (directory / 'raw').glob('objects-*.log'):
        expected = [3, 2, 2, 2] if 'candidate' in file.name else [4, 7, 8, 7]
        values = dict(re.findall(r'^objects (.+)\t(.+)$', file.read_text(), re.M))
        assert [round(float(values[n])) for n in names] == expected
assert round(min(reductions)) == 25 and round(max(reductions)) == 80
print(f'PASS: all body cells, object counts, 25%-80% rounded range; {jit_reports} raw JIT reports flat')
