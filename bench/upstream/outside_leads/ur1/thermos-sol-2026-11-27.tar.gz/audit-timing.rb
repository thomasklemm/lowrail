require "json"

def check_equal(actual, expected, label)
  raise "#{label}: #{actual.inspect} != #{expected.inspect}" unless (actual - expected).abs < 1e-12
end

def middle(values)
  sorted = values.sort
  sorted.size.odd? ? sorted[sorted.size / 2] : Math.sqrt(sorted[sorted.size / 2 - 1] * sorted[sorted.size / 2])
end

def interval(rounds)
  random = Random.new(1)
  estimates = 5000.times.map do
    middle(Array.new(rounds.size) { rounds[random.rand(rounds.size)] }.flatten)
  end.sort
  [estimates[124] - 1, estimates[4875] - 1]
end

ARGV.each do |directory|
  data = JSON.parse(File.read(File.join(directory, "results.json")))
  raise "wrong measured head" unless data.fetch("sides").fetch("candidate").fetch("head") == "cecaed123f04e1704bccf4b1b3272c0b12e759c7"
  raise "dirty measurement" if data.fetch("sides").values.any? { |side| side.fetch("dirty") }
  data.fetch("ips").each do |name, row|
    best = %w[base candidate base2].map do |side|
      rates = (1..3).map do |round|
        output = File.read(File.join(directory, "raw", "ips-r#{round}-#{side}.log")).split("Calculating").last
        value, unit = output.match(/^\s*#{Regexp.escape(name)}\s+([\d.]+)([kM]?)\s/).captures
        value.to_f * {"" => 1, "k" => 1000, "M" => 1000000}.fetch(unit)
      end
      raise "wrong ips raw rounds #{name}" unless rates == row.fetch("rounds").fetch(side)
      rates.max
    end
    mean = (best[0] + best[2]) / 2
    check_equal(mean, row.fetch("base"), "ips base #{name}")
    check_equal(best[1], row.fetch("candidate"), "ips candidate #{name}")
    check_equal(best[1] / mean - 1, row.fetch("change"), "ips change #{name}")
    check_equal((best[0] - best[2]).abs / mean, row.fetch("aa"), "ips A/A #{name}")
    raise "ips inside A/A" unless row.fetch("change").abs > row.fetch("aa") && row.fetch("claim")
    puts "#{File.basename(directory)} ips #{name}: raw best-of-three/mean-base +#{(row['change'] * 100).round(4)}%, A/A #{(row['aa'] * 100).round(4)}%"
  end

  raw = {}
  1.upto(30) do |round|
    %w[base candidate base2].each do |side|
      output = File.read(File.join(directory, "raw", "wall-r#{round}-#{side}.log"))
      output.scan(/^wall (.*?)\t(.*)$/) do |name, json|
        (raw[name] ||= Array.new(30) { {} })[round - 1][side] = JSON.parse(json)
      end
      required = directory.include?("master") ? %w[compiled_iseq_count failed_iseq_count compiled_side_exit_count invalidation_time_ns] : %w[compiled_iseq_count compiled_block_count invalidation_count]
      gates = output.scan(/^jit (.*?)\t(.*)$/)
      raise "missing JIT cases" unless gates.size == 4
      gates.each do |name, text|
        counters = text.scan(/(\w+)=(\d+)>(\d+)/)
        raise "missing JIT counters #{name}" unless counters.map(&:first).sort == required.sort
        raise "JIT changed #{name}" unless counters.all? { |_, before, after| before == after }
      end
    end
  end
  data.fetch("wall").each do |name, row|
    rounds = raw.fetch(name)
    raise "raw wall mismatch #{name}" unless rounds == row.fetch("rounds")
    raise "wrong wall windows" unless row.fetch("quantile") == 0.1 && row.fetch("windows") == 30
    per_process = rounds.map { |sides| sides.transform_values { |windows| windows.fetch("cpu").sort[3] / row.fetch("calls") } }
    ratios = per_process.map { |r| [r.fetch("candidate") / r.fetch("base"), r.fetch("candidate") / r.fetch("base2")] }
    controls = per_process.map { |r| [r.fetch("base2") / r.fetch("base")] }
    check_equal(middle(ratios.flatten) - 1, row.fetch("change"), "wall change #{name}")
    check_equal(middle(controls.flatten) - 1, row.fetch("aa"), "wall A/A #{name}")
    interval(ratios).zip(row.fetch("change_ci")).each { |a, b| check_equal(a, b, "wall change CI #{name}") }
    interval(controls).zip(row.fetch("aa_ci")).each { |a, b| check_equal(a, b, "wall A/A CI #{name}") }
    raise "wall claim fails #{name}" unless row.fetch("aa_ci").first <= 0 && row.fetch("aa_ci").last >= 0 && row.fetch("change_ci").last < 0 && row.fetch("claim")
    raise "wall gate fails #{name}" unless row.fetch("jit").fetch("flat") && row.fetch("jit").fetch("windows").size == 90
    puts "#{File.basename(directory)} wall #{name}: raw 30-round ratios/bootstrap verified, #{(row['change'] * 100).round(4)}%, A/A contains zero, change excludes zero, 90 JIT-flat processes"
  end
end
