require "uri"

URI.singleton_class.prepend(Module.new do
  def decode_www_form_component(str, enc = Encoding::UTF_8)
    raise ArgumentError, "invalid %-encoding (#{str})" if /%(?!\h\h)/.match?(str)
    CGI.unescape(str.b.to_s, Encoding::BINARY).force_encoding(enc)
  end
end)
