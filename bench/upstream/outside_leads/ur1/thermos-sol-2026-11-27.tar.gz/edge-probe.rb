require "uri"

calls = [
  ->(s, enc) { URI.send(:_decode_uri_component, /\+|%\h\h/, s, enc) },
  ->(s, enc) { URI.decode_www_form_component(s, enc) }
]
puts RUBY_DESCRIPTION

[:private_encoding_conversion, :missing_encoding_conversion, :frozen_binary_copy, :intermediate_gsub_hook].each do |kind|
  results = calls.map do |call|
    events = []
    input = "%41+%ff".dup
    enc = Encoding::UTF_8
    case kind
    when :private_encoding_conversion
      enc = Object.new
      enc.define_singleton_method(:to_str) { events << :to_str; "UTF-8" }
      enc.singleton_class.send(:private, :to_str)
    when :missing_encoding_conversion
      enc = Object.new
      enc.define_singleton_method(:respond_to_missing?) { |name, *| name == :to_str }
      enc.define_singleton_method(:method_missing) { |name, *| events << name; name == :to_str ? "UTF-8" : super(name) }
    when :frozen_binary_copy
      copy = input.b.freeze
      input.define_singleton_method(:b) { events << :b; copy }
    when :intermediate_gsub_hook
      copy = input.b
      copy.define_singleton_method(:gsub) { |*| events << :gsub; "custom" }
      input.define_singleton_method(:b) { events << :b; copy }
    end
    begin
      result = call.call(input, enc)
      [result.bytes, result.encoding.name, result.class.name, result.frozen?, events]
    rescue => error
      [error.class.name, error.message, events]
    end
  end
  puts "#{kind}: #{results.inspect}"
  raise "#{kind} differs" unless kind == :intermediate_gsub_hook || results.first == results.last
end
