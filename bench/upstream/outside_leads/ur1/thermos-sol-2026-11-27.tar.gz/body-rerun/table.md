Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `hello` | 4 | 2 | 4,486 | 4,084 | −9.0% |
| `form key` | 7 | 1 | 13,100 | 5,694 | −56.5% |
| `form value` | 8 | 1 | 15,379 | 5,266 | −65.8% |
| `cookie` | 7 | 1 | 18,050 | 10,155 | −43.7% |

Objects and Callgrind instructions per call, Ruby 4.0.10, YJIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `hello` | 4 | 2 | 3,506 | 2,785 | −20.6% |
| `form key` | 7 | 1 | 12,189 | 4,349 | −64.3% |
| `form value` | 8 | 1 | 14,467 | 3,921 | −72.9% |
| `cookie` | 7 | 1 | 17,138 | 8,810 | −48.6% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/ur1-review/body-rerun.
- JIT-flat: compiled_iseq_count, compiled_block_count, invalidation_count unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/ur1-review/base at 48cda77031
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/ur1-review/uri at a3b201f05b
- interp hello: instructions −9.0% with A/A 0.00% (base 4,486 / 4,486, candidate 4,084)
- interp form key: instructions −56.5% with A/A 0.00% (base 13,100 / 13,100, candidate 5,694)
- interp form value: instructions −65.8% with A/A 1.11% (base 15,464 / 15,293, candidate 5,266)
- interp cookie: instructions −43.7% with A/A 0.02% (base 18,048 / 18,052, candidate 10,155)
- yjit hello: instructions −20.6% with A/A 0.00% (base 3,506 / 3,506, candidate 2,785), JIT-flat in 6 windows
- yjit form key: instructions −64.3% with A/A 0.01% (base 12,189 / 12,190, candidate 4,349), JIT-flat in 6 windows
- yjit form value: instructions −72.9% with A/A 1.18% (base 14,382 / 14,553, candidate 3,921), JIT-flat in 6 windows
- yjit cookie: instructions −48.6% with A/A 0.00% (base 17,138 / 17,137, candidate 8,810), JIT-flat in 6 windows
