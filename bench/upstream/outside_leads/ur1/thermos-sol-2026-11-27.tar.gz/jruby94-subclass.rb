require "uri"

class Component < String
end

puts RUBY_DESCRIPTION
puts URI.method(:decode_www_form_component).source_location.inspect
["", "a", "+", "%41", "a%41"].each do |bytes|
  input = Component.new(bytes)
  result = URI.decode_www_form_component(input)
  p [bytes, input.b.class, result.class, result.bytes, result.encoding.name]
end
