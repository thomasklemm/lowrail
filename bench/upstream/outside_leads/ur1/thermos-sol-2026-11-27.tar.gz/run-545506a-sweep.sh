#!/usr/bin/env bash
set -euo pipefail
root=$(git rev-parse --show-toplevel)
dir="$root/.amp/in/orb-backup/ur1-review"
ruby="$HOME/.local/share/mise/installs/ruby/4.0.10/bin/ruby"
vg="$dir/valgrind/bin/valgrind"
mkdir -p "$dir/545506a-sweep-raw"
export RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000 RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000
unset RUBYOPT RUBY_YJIT_ENABLE
printf 'shape\tsize\tn\tbase\thead\tbase2\tchange_pct\taa_pct\n' > "$dir/545506a-sweep.tsv"
for size in 248 1048576 8388608; do
  shape=plain
  n=1
  values=()
  for side in base final-545506a base2; do
    tree=$side
    [[ $side != base2 ]] || tree=base
    totals=()
    for count in 0 "$n"; do
      stem="$dir/545506a-sweep-raw/$shape-$size-$side-$count"
      "$vg" --tool=callgrind --collect-atstart=no --toggle-collect=rb_ary_cycle --callgrind-out-file="$stem.callgrind" --log-file="$stem.valgrind.log" "$ruby" -I "$dir/$tree/lib" "$dir/sweep.rb" "$shape" "$size" "$count" > "$stem.log" 2>&1
      ! grep -q 'brk segment overflow' "$stem.valgrind.log"
      totals+=("$(awk '/^totals:/ { print $2 }' "$stem.callgrind")")
    done
    values+=("$(( (totals[1] - totals[0]) / n ))")
  done
  awk -v shape="$shape" -v size="$size" -v n="$n" -v a="${values[0]}" -v h="${values[1]}" -v b="${values[2]}" 'BEGIN {mean=(a+b)/2; printf "%s\t%d\t%d\t%d\t%d\t%d\t%.4f\t%.4f\n",shape,size,n,a,h,b,(h/mean-1)*100,sqrt((a-b)^2)/mean*100}' | tee -a "$dir/545506a-sweep.tsv"
done
