ARGV.each do |path|
  rows = {}
  File.foreach(path) do |line|
    m = /\A(.+?) (interp|yjit|zjit) (none\.rb|ur1_cgib\.rb) Ir\/op (\d+) objs\/op ([\d.]+) jit (\d+\/\d+) settle (\d+)\s*\z/.match(line)
    next unless m
    (rows[[m[1], m[2]]] ||= []) << [m[3], m[4].to_i, m[5].to_f, m[6]]
  end
  puts path
  rows.each do |key, values|
    bases = values.select { |row| row[0] == "none.rb" }
    head = values.select { |row| row[0] == "ur1_cgib.rb" }
    unless bases.size == 2 && head.size == 1
      puts "#{key.join(' ')}: incomplete comparison, no claim"
      next
    end
    mean = (bases[0][1] + bases[1][1]) / 2.0
    change = 100 * (head[0][1] / mean - 1)
    aa = 100 * (bases[0][1] - bases[1][1]).abs / mean
    raise "JIT counters moved" unless values.all? { |row| row[3] == "0/0" }
    puts "#{key.join(' ')}: #{format('%.6f', change)}% instructions, A/A #{format('%.6f', aa)}%, #{values.map { |row| row[2] }.inspect} objects; recorded JIT counters 0/0"
  end
end
