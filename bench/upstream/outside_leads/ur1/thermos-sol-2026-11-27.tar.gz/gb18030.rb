require "uri"
s = ["8233e734"].pack("H*").force_encoding("GB18030")
raise unless s.valid_encoding?
puts RUBY_DESCRIPTION
puts "input #{s.bytes.inspect} valid GB18030"
r = URI.decode_www_form_component(s)
raise unless r.bytes == [130, 51, 231, 52] && r.encoding == Encoding::UTF_8
puts "decoded #{r.bytes.inspect} #{r.encoding.name}"
