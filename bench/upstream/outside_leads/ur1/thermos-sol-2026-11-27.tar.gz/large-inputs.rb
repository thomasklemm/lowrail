require "uri"
require "digest"

puts RUBY_DESCRIPTION
[1 << 20, 8 << 20].each do |size|
  {
    "plain" => "a" * size,
    "early" => "%41" + "a" * (size - 3),
    "late" => "a" * (size - 3) + "%41",
    "percent" => "%41" * (size / 3),
    "plus" => "+" * size,
    "invalid-late" => "a" * (size - 1) + "%"
  }.each do |shape, input|
    outputs = [
      -> { URI.send(:_decode_uri_component, /\+|%\h\h/, input, Encoding::UTF_8) },
      -> { URI.decode_www_form_component(input) }
    ].map do |call|
      begin
        result = call.call
        [:ok, result.class.name, result.bytesize, result.encoding.name, Digest::SHA256.hexdigest(result)]
      rescue => error
        [:error, error.class.name, Digest::SHA256.hexdigest(error.message)]
      end
    end
    raise "#{shape} #{size}: #{outputs.inspect}" unless outputs.first == outputs.last
    puts "#{shape} #{input.bytesize} bytes equal #{outputs.first.inspect}"
  end
end
