require "uri"

shape, size, n = ARGV
size = Integer(size)
n = Integer(n)
s = case shape
when "plain" then "a" * size
when "early" then "%41" + "a" * [size - 3, 0].max
when "late" then "a" * [size - 3, 0].max + "%41"
when "percent" then "%41" * (size / 3)
when "plus" then "+" * size
else abort shape
end
5.times { URI.decode_www_form_component(s) }
GC.start
GC.disable
[s].cycle(n) { |v| URI.decode_www_form_component(v) }
puts "#{RUBY_DESCRIPTION}; #{URI.method(:decode_www_form_component).source_location.inspect}; #{shape} bytes=#{s.bytesize} n=#{n}"
