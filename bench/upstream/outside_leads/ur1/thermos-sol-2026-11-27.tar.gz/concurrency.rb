require "uri"
strings = ["%00%ff+a", "article%5Btitle%5D", "\xE3\x81\x82"].freeze
expected = strings.map { |s| URI.send(:_decode_uri_component, /\+|%\h\h/, s, Encoding::UTF_8) }
8.times.map {
  Thread.new { 1000.times { strings.each_with_index { |s, i| raise unless URI.decode_www_form_component(s) == expected[i] } } }
}.each(&:join)
puts "threads passed"
r = Ractor.new { URI.decode_www_form_component("%ff+a").bytes }
raise unless r.value == [255, 32, 97]
puts "Ractor passed"
