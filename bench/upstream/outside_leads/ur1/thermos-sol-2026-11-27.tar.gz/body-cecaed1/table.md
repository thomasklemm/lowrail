Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `hello` | 4 | 3 | 4,486 | 3,553 | −20.8% |
| `form key` | 7 | 2 | 13,099 | 4,974 | −62.0% |
| `form value` | 8 | 2 | 15,487 | 4,549 | −70.6% |
| `cookie` | 7 | 2 | 18,048 | 9,283 | −48.6% |

Objects and Callgrind instructions per call, Ruby 4.0.10, YJIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `hello` | 4 | 3 | 3,506 | 2,678 | −23.6% |
| `form key` | 7 | 2 | 12,202 | 4,052 | −66.8% |
| `form value` | 8 | 2 | 14,527 | 3,627 | −75.0% |
| `cookie` | 7 | 2 | 17,134 | 8,362 | −51.2% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/ur1-review/body-cecaed1.
- JIT-flat: compiled_iseq_count, compiled_block_count, invalidation_count unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/ur1-review/base at 48cda77031
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/ur1-review/cecaed1 at cecaed123f
- interp hello: instructions −20.8% with A/A 0.00% (base 4,486 / 4,486, candidate 3,553)
- interp form key: instructions −62.0% with A/A 0.02% (base 13,098 / 13,100, candidate 4,974)
- interp form value: instructions −70.6% with A/A 1.10% (base 15,572 / 15,401, candidate 4,549)
- interp cookie: instructions −48.6% with A/A 0.00% (base 18,048 / 18,048, candidate 9,283)
- yjit hello: instructions −23.6% with A/A 0.00% (base 3,506 / 3,506, candidate 2,678), JIT-flat in 6 windows
- yjit form key: instructions −66.8% with A/A 0.18% (base 12,212 / 12,191, candidate 4,052), JIT-flat in 6 windows
- yjit form value: instructions −75.0% with A/A 1.93% (base 14,387 / 14,667, candidate 3,627), JIT-flat in 6 windows
- yjit cookie: instructions −51.2% with A/A 0.00% (base 17,134 / 17,134, candidate 8,362), JIT-flat in 6 windows
