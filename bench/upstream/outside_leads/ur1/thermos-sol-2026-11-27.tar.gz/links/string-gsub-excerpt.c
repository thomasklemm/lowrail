str_gsub(int argc, VALUE *argv, VALUE str, int bang)
{
    VALUE pat, val = Qnil, repl, match0 = Qnil, dest, hash = Qnil, match = Qnil;
    long beg, beg0, end0;
    long offset, blen, slen, len, last;
    enum {STR, ITER, FAST_MAP, MAP} mode = STR;
    char *sp, *cp;
    int need_backref_str = -1;
    rb_encoding *str_enc;

    switch (argc) {
      case 1:
        RETURN_ENUMERATOR(str, argc, argv);
        mode = ITER;
        break;
      case 2:
        repl = argv[1];
        hash = rb_check_hash_type(argv[1]);
        if (NIL_P(hash)) {
            StringValue(repl);
        }
        else if (rb_hash_default_unredefined(hash) && !FL_TEST_RAW(hash, RHASH_PROC_DEFAULT)) {
            mode = FAST_MAP;
        }
        else {
            mode = MAP;
        }
        break;
      default:
        rb_error_arity(argc, 1, 2);
    }

    pat = get_pat_quoted(argv[0], 1);
    beg = rb_pat_search0(pat, str, 0, need_backref_str, &match);

    if (beg < 0) {
        if (bang) return Qnil;	/* no match, no substitution */
        return str_duplicate(rb_cString, str);
    }

    offset = 0;
    blen = RSTRING_LEN(str) + 30; /* len + margin */
    dest = rb_str_buf_new(blen);
    sp = RSTRING_PTR(str);
    slen = RSTRING_LEN(str);
    cp = sp;
    str_enc = STR_ENC_GET(str);
    rb_enc_associate(dest, str_enc);
    ENC_CODERANGE_SET(dest, rb_enc_asciicompat(str_enc) ? ENC_CODERANGE_7BIT : ENC_CODERANGE_VALID);

    do {
        struct re_registers *regs = RMATCH_REGS(match);
        if (RB_TYPE_P(pat, T_STRING)) {
            beg0 = beg;
            end0 = beg0 + RSTRING_LEN(pat);
            match0 = pat;
        }
        else {
            beg0 = BEG(0);
            end0 = END(0);
            if (mode == ITER) match0 = rb_reg_nth_match(0, match);
        }

        if (mode != STR) {
            if (mode == ITER) {
                val = rb_obj_as_string(rb_yield(match0));
            }
            else {
                struct RString fake_str = {RBASIC_INIT};
                VALUE key;
                if (mode == FAST_MAP) {
                    // It is safe to use a fake_str here because we established that it won't escape,
                    // as it's only used for `rb_hash_aref` and we checked the hash doesn't have a
                    // default proc.
                    key = setup_fake_str(&fake_str, sp + beg0, end0 - beg0, ENCODING_GET_INLINED(str));
                }
                else {
                    key = rb_str_subseq(str, beg0, end0 - beg0);
                }
                val = rb_hash_aref(hash, key);
                val = rb_obj_as_string(val);
            }
            str_mod_check(str, sp, slen);
            if (val == dest) { 	/* paranoid check [ruby-dev:24827] */
                rb_raise(rb_eRuntimeError, "block should not cheat");
            }
        }
        else if (need_backref_str) {
            val = rb_reg_regsub(repl, str, regs, RB_TYPE_P(pat, T_STRING) ? Qnil : pat);
            if (need_backref_str < 0) {
                need_backref_str = val != repl;
            }
        }
        else {
            val = repl;
        }

        len = beg0 - offset;	/* copy pre-match substr */
        if (len) {
            rb_enc_str_buf_cat(dest, cp, len, str_enc);
        }

        rb_str_buf_append(dest, val);

        last = offset;
        offset = end0;
        if (beg0 == end0) {
            /*
             * Always consume at least one character of the input string
             * in order to prevent infinite loops.
             */
            if (RSTRING_LEN(str) <= end0) break;
            len = rb_enc_fast_mbclen(RSTRING_PTR(str)+end0, RSTRING_END(str), str_enc);
            rb_enc_str_buf_cat(dest, RSTRING_PTR(str)+end0, len, str_enc);
            offset = end0 + len;
        }
        cp = RSTRING_PTR(str) + offset;
        if (offset > RSTRING_LEN(str)) break;

        // In FAST_MAP and STR mode the backref can't escape so we can re-use the MatchData safely.
        if (mode != FAST_MAP && mode != STR) {
            match = Qnil;
        }
        beg = rb_pat_search0(pat, str, offset, need_backref_str, &match);

        RB_GC_GUARD(match);
    } while (beg >= 0);

    if (RSTRING_LEN(str) > offset) {
        rb_enc_str_buf_cat(dest, cp, RSTRING_LEN(str) - offset, str_enc);
    }
    rb_pat_search0(pat, str, last, 1, &match);
    if (bang) {
        str_shared_replace(str, dest);
