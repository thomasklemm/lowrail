require "json"

path = File.join(__dir__, "probe-cecaed1-jruby94.txt")
pairs = File.read(path).scan(/^  base (.*)\n  head (.*)$/)
raise "missing retained differences" unless pairs.size == 1905
pairs.each do |base_text, head_text|
  base = eval(base_text)
  head = eval(head_text)
  raise "not a successful String result" unless base[0][0, 2] == [:ok, "String"] && head[0][0, 2] == [:ok, nil]
  head[0][1] = "String"
  raise "difference beyond class: #{base_text}\n#{head_text}" unless base == head
end
puts "All #{pairs.size} retained JRuby 9.4 differences are result class only; bytes, encoding, validity, frozen state, ownership, events and input mutation match."

ARGV.each do |directory|
  data = JSON.parse(File.read(File.join(directory, "results.json")))
  data.fetch("instructions").each do |name, row|
    mean = (row.fetch("base1") + row.fetch("base2")) / 2.0
    change = row.fetch("candidate") / mean - 1
    aa = (row.fetch("base1") - row.fetch("base2")).abs / mean
    raise "wrong change #{name}" unless (change - row.fetch("change")).abs < 1e-12
    raise "wrong A/A #{name}" unless (aa - row.fetch("aa")).abs < 1e-12
    raise "not outside A/A #{name}" unless change.abs > aa
  end
  puts "#{directory}: all instruction changes and A/A independently recomputed and outside A/A"
end
