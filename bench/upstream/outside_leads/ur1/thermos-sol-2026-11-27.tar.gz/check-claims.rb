require "json"

ARGV.each do |dir|
  j = JSON.parse(File.read(File.join(dir, "results.json")))
  j.fetch("instructions").each do |label, cell|
    mode, name = label.split(" ", 2)
    stem = "ir-#{mode}-#{%w[hello form_key form_value cookie].index(name.tr(' ', '_')) + 1}-#{name.tr(' ', '_')}"
    %w[base candidate base2].each do |side|
      totals = [0, j.fetch("n")].map do |n|
        File.read(File.join(dir, "raw", "#{stem}-#{side}-n#{n}.callgrind"))[/^totals: (\d+)/, 1].to_i
      end
      measured = (totals.last - totals.first).fdiv(j.fetch("n"))
      field = side == "base" ? "base1" : side
      raise "#{dir} #{label} #{field}: #{measured} != #{cell[field]}" unless (measured - cell.fetch(field)).abs < 0.000001
    end
    puts "#{dir}: #{label} raw N-minus-0 verified; change #{(cell['change'] * 100).round(3)}%, AA #{(cell['aa'] * 100).round(3)}%"
  end
end
