order = ARGV.fetch(0)
case order
when "cgi-first" then require "cgi"
when "escape-first" then require "cgi/escape"
when "autoload" then Object.autoload(:CGI, "cgi")
when "no-native" then require File.join(__dir__, "tests/no_c_decoder")
when "ruby-native" then require File.join(__dir__, "tests/ruby_decoder")
end
require "uri"
require "cgi" if order == "uri-first"
raise "www" unless URI.decode_www_form_component("a+%2b%FF").bytes == [97, 32, 43, 255]
raise "uri" unless URI.decode_uri_component("a+%2b%FF").bytes == [97, 43, 43, 255]
begin
  URI.decode_uri_component("a%")
  raise "missing error"
rescue ArgumentError => e
  raise "message" unless e.message == "invalid %-encoding (a%)"
end
native = CGI.respond_to?(:unescapeURIComponent) && !CGI.method(:unescapeURIComponent).source_location
[:decode_www_form_component, :decode_uri_component].each do |name|
  source = URI.method(name).source_location
  body = File.readlines(source.first)[source.last - 1, 3].join
  raise "selection #{name} #{source.inspect}" unless body.include?("CGI.") == !!native
end
sub = Class.new(String)
[:decode_www_form_component, :decode_uri_component].each do |name|
  ["", "a", "a+b", "a%41"].each do |input|
    result = URI.public_send(name, sub.new(input))
    raise "class #{name} #{input.inspect}" unless result.instance_of?(String)
  end
end
puts "#{RUBY_DESCRIPTION}; #{order}; native=#{native}; unescape=#{CGI.method(:unescape).source_location.inspect}; www=#{URI.method(:decode_www_form_component).source_location.inspect}; uri=#{URI.method(:decode_uri_component).source_location.inspect}; both selections and subclasses pass"
