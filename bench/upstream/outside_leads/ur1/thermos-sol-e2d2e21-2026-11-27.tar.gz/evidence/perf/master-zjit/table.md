Objects and Callgrind instructions per call, Ruby 4.1.0dev, ZJIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `hello` | 4 | 3 | 3,345 | 2,747 | −17.9% |
| `form key` | 7 | 2 | 11,898 | 4,315 | −63.7% |
| `form value` | 8 | 2 | 13,928 | 3,860 | −72.3% |
| `cookie` | 7 | 2 | 18,887 | 9,145 | −51.6% |
| `uri hello` | 4 | 3 | 3,345 | 2,747 | −17.9% |
| `uri user` | 6 | 2 | 8,916 | 3,739 | −58.1% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/ur1-d4-review/evidence/perf/master-zjit.
- JIT-flat: compiled_iseq_count, failed_iseq_count, compiled_side_exit_count, invalidation_time_ns unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- base: ruby 4.1.0dev (2026-11-27T16:40:23Z pinned-master 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/ur1-d4-review/base at 48cda77031
- candidate: ruby 4.1.0dev (2026-11-27T16:40:23Z pinned-master 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/ur1-d4-review/uri at d4ce0b0376
- zjit hello: instructions −17.9% with A/A 0.00% (base 3,345 / 3,345, candidate 2,747), JIT-flat in 6 windows
- zjit form key: instructions −63.7% with A/A 0.02% (base 11,897 / 11,899, candidate 4,315), JIT-flat in 6 windows
- zjit form value: instructions −72.3% with A/A 0.58% (base 13,969 / 13,888, candidate 3,860), JIT-flat in 6 windows
- zjit cookie: instructions −51.6% with A/A 0.29% (base 18,860 / 18,914, candidate 9,145), JIT-flat in 6 windows
- zjit uri hello: instructions −17.9% with A/A 0.00% (base 3,345 / 3,345, candidate 2,747), JIT-flat in 6 windows
- zjit uri user: instructions −58.1% with A/A 0.00% (base 8,916 / 8,916, candidate 3,739), JIT-flat in 6 windows
