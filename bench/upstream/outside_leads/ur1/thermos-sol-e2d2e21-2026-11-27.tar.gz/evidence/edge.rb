require "uri"
require "digest"
puts RUBY_DESCRIPTION
puts "CGI=#{CGI.const_defined?(:VERSION) ? CGI::VERSION : 'version not loaded'} unescape=#{CGI.method(:unescape).source_location.inspect} uri=#{CGI.respond_to?(:unescapeURIComponent) ? CGI.method(:unescapeURIComponent).source_location.inspect : 'absent'} URI=#{URI.method(:decode_uri_component).source_location.inspect}"
puts "CGI ancestors=#{CGI.singleton_class.ancestors.inspect}"
subclass = Class.new(String)
methods = [:decode_www_form_component, :decode_uri_component]
methods.each do |method|
  regex = method == :decode_uri_component ? /%\h\h/ : /\+|%\h\h/
  base = lambda do |str, enc = Encoding::UTF_8|
    raise ArgumentError, "invalid %-encoding (#{str})" if /%(?!\h\h)/.match?(str)
    str.b.gsub(regex, URI::TBLDECWWWCOMP_).force_encoding(enc)
  end
  head = URI.method(method)
  [12, 248, 16_384, 1_048_576, 8_388_608].each do |size|
    {"plain" => "a" * size, "early" => "%41" + "a" * (size - 3), "late" => "a" * (size - 3) + "%41", "plus" => "+" * size, "percent" => "%41" * (size / 3), "badlate" => "a" * (size - 1) + "%"}.each do |shape, input|
      values = [base, head].map do |call|
        begin
          r = call.call(input.freeze)
          [r.class, r.encoding, r.bytesize, Digest::SHA256.hexdigest(r), r.frozen?, r.equal?(input)]
        rescue => e
          [e.class, Digest::SHA256.hexdigest(e.message)]
        end
      end
      raise "large mismatch #{method} #{shape} #{size}: #{values.inspect}" unless values[0] == values[1]
    end
  end
  ["", "a", "+", "%41", "%ff"].each do |s|
    input = s.dup
    input.taint if RUBY_VERSION < "2.7"
    results = [base, head].map { |call| r = call.call(input); [r.respond_to?(:tainted?) && r.tainted?, r.encoding, r.bytes, r.class] }
    raise "taint mismatch #{results.inspect}" unless results[0] == results[1]
  end
  events = []
  enc = Object.new
  enc.define_singleton_method(:to_str) { events << :to_str; "UTF-8" }
  enc.singleton_class.send(:private, :to_str)
  results = [base, head].map { |call| r = call.call("%ff+", enc); [r.bytes, r.encoding] }
  raise "private conversion mismatch" unless results[0] == results[1] && events == [:to_str, :to_str]
  puts "#{method}: 30 large shape/size cases, taint and private conversion equal; subclass=#{head.call(subclass.new('a')).class == String ? 'String' : 'subclass'}"
end
threads = 8.times.map do |n|
  Thread.new do
    200.times do
      raise "www thread" unless URI.decode_www_form_component("%41+%00%ff").bytes == [65, 32, 0, 255]
      raise "uri thread" unless URI.decode_uri_component("%41+%00%ff").bytes == [65, 43, 0, 255]
    end
  end
end
threads.each(&:value)
puts "8 concurrent threads pass"
if defined?(Ractor) && RUBY_ENGINE == "ruby"
  worker = Ractor.new { [URI.decode_www_form_component("%41+"), URI.decode_uri_component("%41+")] }
  result = worker.respond_to?(:value) ? worker.value : worker.take
  raise "ractor" unless result == ["A ", "A+"]
  puts "Ractor pass"
end
