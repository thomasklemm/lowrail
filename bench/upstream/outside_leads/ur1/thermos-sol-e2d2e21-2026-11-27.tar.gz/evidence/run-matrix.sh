#!/usr/bin/env bash
set -euo pipefail
here=$(realpath "$(dirname "$0")/..")
export PATH="$(mise where java@temurin-21)/bin:$PATH"
v=$1
if [[ $v == master* ]]; then rb=$here/master/bin/ruby; else rb=$(mise where ruby@$v)/bin/ruby; fi
pre=()
if [[ $v == master-zjit ]]; then pre+=(--zjit); fi
if [[ ${2:-} == pure ]]; then pre+=(-r "$here/evidence/pure_cgi.rb"); v=$v-pure; fi
"$rb" -v > "$here/evidence/runtime/$v.txt"
for m in decode_www_form_component decode_uri_component; do
  METHOD=$m "$rb" "${pre[@]}" -I "$here/uri/lib" "$here/evidence/probe.rb" > "$here/evidence/diff/$m-$v.txt" 2>&1
done
"$rb" "${pre[@]}" -I "$here/uri/lib" "$here/evidence/edge.rb" > "$here/evidence/diff/edge-$v.txt" 2>&1
"$rb" "${pre[@]}" -I "$here/uri/lib" -I "$here/uri/test/lib" -rhelper -e 'Dir[ARGV.fetch(0) + "/uri/test_*.rb"].each { |f| require f }' "$here/uri/test" > "$here/evidence/tests/suite-$v.txt" 2>&1
for order in uri-first cgi-first escape-first autoload no-native ruby-native; do
  "$rb" "${pre[@]}" --disable-gems -I "$here/uri/lib" "$here/evidence/load-probe.rb" "$order" >> "$here/evidence/load/$v.txt" 2>&1
done
cat "$here/evidence/diff/"*"-$v.txt"
tail -9 "$here/evidence/tests/suite-$v.txt"
