        return str_duplicate(rb_cString, str);
    }
    if (bang) str_modify_keep_cr(str);

    offset = 0;
    blen = RSTRING_LEN(str) + 30; /* len + margin */
    dest = rb_str_buf_new(blen);
    sp = RSTRING_PTR(str);
    slen = RSTRING_LEN(str);
    cp = sp;
    str_enc = STR_ENC_GET(str);
    rb_enc_associate(dest, str_enc);
    ENC_CODERANGE_SET(dest, rb_enc_asciicompat(str_enc) ? ENC_CODERANGE_7BIT : ENC_CODERANGE_VALID);

    do {
        if (RB_TYPE_P(pat, T_STRING)) {
            beg0 = beg;
            end0 = beg0 + RSTRING_LEN(pat);
            match0 = pat;
        }
        else {
            beg0 = RMATCH_BEG(match, 0);
            end0 = RMATCH_END(match, 0);
            if (mode == ITER) match0 = rb_reg_nth_match(0, match);
        }

        if (mode != STR) {
            if (mode == ITER) {
                val = rb_obj_as_string(rb_yield(match0));
            }
            else {
                struct RString fake_str = {RBASIC_INIT};
                VALUE key;
                if (mode == FAST_MAP) {
                    // It is safe to use a fake_str here because we established that it won't escape,
                    // as it's only used for `rb_hash_aref` and we checked the hash doesn't have a
                    // default proc.
                    key = setup_fake_str(&fake_str, sp + beg0, end0 - beg0, ENCODING_GET_INLINED(str));
                }
                else {
                    key = rb_str_subseq(str, beg0, end0 - beg0);
                }
                val = rb_hash_aref(hash, key);
                val = rb_obj_as_string(val);
            }
            str_mod_check(str, sp, slen);
            if (val == dest) { 	/* paranoid check [ruby-dev:24827] */
                rb_raise(rb_eRuntimeError, "block should not cheat");
            }
        }
        else if (need_backref_str) {
            val = rb_reg_regsub_match(repl, str, match);
            if (need_backref_str < 0) {
                need_backref_str = val != repl;
