require "fileutils"
require "open3"
root = File.expand_path("..", __dir__)
tests = File.join(__dir__, "tests")
source = File.read(File.join(root, "uri/lib/uri/common.rb"))
mutants = {
  "head" => [],
  "base-new-tests" => :base,
  "uri-decodes-plus" => [["CGI.unescapeURIComponent(bytes, Encoding::ASCII_8BIT)", "CGI.unescape(bytes, Encoding::ASCII_8BIT)"]],
  "www-keeps-plus" => [["CGI.unescape(bytes, Encoding::ASCII_8BIT)", "CGI.unescapeURIComponent(bytes, Encoding::ASCII_8BIT)"]],
  "cgi-chooses-encoding" => [["yield(str.b).force_encoding(enc)", "yield(str.b, enc)"], ["{|bytes| CGI.unescape(bytes, Encoding::ASCII_8BIT) }", "{|bytes, e| CGI.unescape(bytes, e) }"]],
  "no-final-encoding" => [["yield(str.b).force_encoding(enc)", "yield(str.b)"]],
  "no-binary-copy" => [["yield(str.b)", "yield(str)"]],
  "accepts-bad-percent" => [["    raise ArgumentError, \"invalid %-encoding (\#{str})\" if /%(?!\\h\\h)/.match?(str)\n", ""]],
  "word-instead-of-hex" => [["/%(?!\\h\\h)/", "/%(?!\\w\\w)/"]],
  "fallback-bang" => [["bytes.gsub(/%\\h\\h/, TBLDECWWWCOMP_)", "bytes.gsub!(/%\\h\\h/, TBLDECWWWCOMP_)"]],
  "fallback-plus" => [["bytes.gsub(/%\\h\\h/, TBLDECWWWCOMP_)", "bytes.gsub(/\\+|%\\h\\h/, TBLDECWWWCOMP_)"]],
  "fallback-uppercase" => [["bytes.gsub(/%\\h\\h/, TBLDECWWWCOMP_)", "bytes.gsub(/%[0-9A-F]{2}/, TBLDECWWWCOMP_)"]],
  "www-fallback-bang" => [["bytes.gsub(/\\+|%\\h\\h/, TBLDECWWWCOMP_)", "bytes.gsub!(/\\+|%\\h\\h/, TBLDECWWWCOMP_)"]],
  "www-fallback-uppercase" => [["bytes.gsub(/\\+|%\\h\\h/, TBLDECWWWCOMP_)", "bytes.gsub(/\\+|%[0-9A-F]{2}/, TBLDECWWWCOMP_)"]],
  "www-fallback-keeps-plus" => [["bytes.gsub(/\\+|%\\h\\h/, TBLDECWWWCOMP_)", "bytes.gsub(/%\\h\\h/, TBLDECWWWCOMP_)"]],
  "ruby-decoder-selected" => [[" && !CGI.method(:unescapeURIComponent).source_location", ""]]
}
ruby = ARGV.fetch(0)
mode = ARGV.fetch(1, "native")
pre = mode == "fallback" ? ["-r", File.join(tests, "no_c_decoder.rb")] : []
mutants.each do |name, replacements|
  dir = File.join(root, "mutants-v2", name)
  unless File.exist?(dir)
    FileUtils.mkdir_p(dir)
    FileUtils.cp_r(File.join(root, "uri/lib"), dir)
    code = if replacements == :base
      IO.popen(["git", "-C", File.join(root, "uri"), "show", "48cda77031:lib/uri/common.rb"], &:read)
    else
      replacements.reduce(source) do |text, (from, to)|
        raise "missing #{from}" unless text.include?(from)
        text.sub(from) { to }
      end
    end
    File.write(File.join(dir, "lib/uri/common.rb"), code)
  end
  cmd = [ruby, *pre, "-I", File.join(dir, "lib"), File.join(tests, "eval_asserts.rb"), File.join(tests, "asserts.rb")]
  out, status = Open3.capture2e(*cmd)
  puts "#{name} | #{mode} | exit=#{status.exitstatus} | #{out.strip}"
  $stdout.flush
end
