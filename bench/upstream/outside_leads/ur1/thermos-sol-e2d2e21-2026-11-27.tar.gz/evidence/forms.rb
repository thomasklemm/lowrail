require "uri"
puts RUBY_DESCRIPTION
base = URI.method(:decode_www_form)
source = File.read(URI.method(:decode_www_form).source_location.first)
body = source[/  def self\.decode_www_form\(.*?^  end$/m]
raise "missing form source" unless body
body = body.sub("key.gsub!(/\\+|%\\h\\h/, TBLDECWWWCOMP_)", "key = CGI.unescape(key, Encoding::BINARY)")
body = body.sub("val.gsub!(/\\+|%\\h\\h/, TBLDECWWWCOMP_)", "val = CGI.unescape(val, Encoding::BINARY)")
URI.module_eval(body)
candidate = URI.method(:decode_www_form)
inputs = ["page=2&per=20&sort=name", "a=%&b=%zz&c=%FF", "article%5Btitle%5D=Hello+world", "a&b=&=c&&d=e"]
inputs.each do |input|
  results = [base, candidate].map { |call| call.call(input) }
  raise "form result differs" unless results[0] == results[1]
  counts = [base, candidate, base].map do |call|
    100.times { call.call(input) }
    GC.start
    GC.disable
    values = [1000, 2000].map do |n|
      before = GC.stat(:total_allocated_objects)
      n.times { call.call(input) }
      GC.stat(:total_allocated_objects) - before
    end
    GC.enable
    {windows: values, objects_per_call: (values[1] - values[0]) / 1000.0}
  end
  puts "#{input.inspect}: results=#{results[0].inspect}; base/CGI/base=#{counts.inspect}"
end
begin
  URI.decode_www_form_component("%")
  raise "component did not reject"
rescue ArgumentError
  puts "component rejects lone %, forms retain it"
end
