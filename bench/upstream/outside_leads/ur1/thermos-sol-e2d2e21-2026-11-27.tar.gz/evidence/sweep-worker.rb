require "uri"
method, shape, requested, calls = ARGV
size = Integer(requested)
input = case shape
when "plain" then "a" * size
when "early" then "%41" + "a" * (size - 3)
when "late" then "a" * (size - 3) + "%41"
when "plus" then "+" * size
when "percent" then "%41" * (size / 3)
end.freeze
call = -> { URI.public_send(method, input) }
[100, [3, 200_000 / [size, 1].max].max].min.times { call.call }
GC.start
GC.disable
[call].cycle(Integer(calls)) { |c| c.call }
