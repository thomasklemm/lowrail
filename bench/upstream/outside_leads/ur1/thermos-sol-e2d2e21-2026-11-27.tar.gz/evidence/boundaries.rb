require "uri"
puts RUBY_DESCRIPTION
subclass = Class.new(String)
[:decode_www_form_component, :decode_uri_component].each do |method|
  regex = method == :decode_uri_component ? /%\h\h/ : /\+|%\h\h/
  ["", "plain", "a+b", "%41", "<script>", "%3Cscript%3E"].each do |s|
    input = subclass.new(s)
    base = input.b.gsub(regex, URI::TBLDECWWWCOMP_).force_encoding(Encoding::UTF_8)
    head = URI.public_send(method, input)
    raise "bytes/encoding/frozen" unless [base.bytes, base.encoding, base.frozen?] == [head.bytes, head.encoding, head.frozen?]
    puts "#{method} #{s.inspect}: base=#{base.class == String ? 'String' : 'subclass'} head=#{head.class == String ? 'String' : 'subclass'}; bytes/encoding/frozen equal"
  end
end
