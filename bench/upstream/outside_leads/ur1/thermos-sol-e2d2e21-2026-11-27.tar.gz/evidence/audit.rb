require "json"
root = File.join(__dir__, "perf")
def close(a, b)
  raise "numeric mismatch #{a} != #{b}" unless (a - b).abs < 0.00001
end
if ARGV.include?("--complete")
  {"native" => 50, "pure" => 50, "native-tail" => 14, "pure-tail" => 14}.each do |name, count|
    rows = JSON.parse(File.read(File.join(root, name, "rows.json")))
    raise "incomplete #{name}" unless rows.size == count
  end
end
Dir[File.join(root, "*/rows.json")].sort.each do |path|
  dir = File.dirname(path)
  rows = JSON.parse(File.read(path))
  rows.each do |r|
    counts = %w[base uri base2].map do |side|
      totals = [0, r.fetch("calls")].map do |n|
        stem = File.join(dir, "#{r.fetch('method')}-#{r.fetch('size')}-#{r.fetch('shape')}-#{side}-#{n}")
        dump = File.read("#{stem}.callgrind")
        raise "multiple/missing totals" unless dump.scan(/^totals: /).size == 1
        log = File.read("#{stem}.valgrind")
        raise "bad Valgrind log" if log.match?(/brk segment overflow|Cannot map memory to grow brk segment|Process terminating/)
        Integer(dump[/^totals: (\d+)/, 1])
      end
      (totals[1] - totals[0]).fdiv(r.fetch("calls"))
    end
    counts.zip(r.fetch("counts")) { |a, b| close(a, b) }
    base = (counts[0] + counts[2]) / 2.0
    close((counts[1] / base - 1) * 100, r.fetch("change_pct"))
    close((counts[2] - counts[0]).abs / base * 100, r.fetch("aa_pct"))
  end
  puts "#{File.basename(dir)}: #{rows.size} rows independently reconstructed from raw dumps"
  rows.group_by { |r| r.fetch("method") }.each do |method, cases|
    puts "  #{method} worst=#{cases.max_by { |r| r.fetch('change_pct') }.inspect} max-AA=#{cases.map { |r| r.fetch('aa_pct') }.max}"
  end
end
path = File.join(root, "master-zjit/results.json")
if File.exist?(path)
  json = JSON.parse(File.read(path))
  json.fetch("instructions").each do |name, r|
    r.fetch("jit").fetch("windows").each do |w|
      raise "missing counters" unless w.fetch("counters").size == 4
      w.fetch("counters").each { |k, (a, b)| raise "#{name} #{k} moved" unless a && a == b }
    end
    raise "JIT gate not flat" unless r.fetch("jit").fetch("flat") && r.fetch("jit").fetch("windows").size == 6
    index = json.fetch("instructions").keys.index(name) + 1
    label = name.sub("zjit ", "")
    %w[base candidate base2].each do |side|
      totals = [0, json.fetch("n")].map do |n|
        stem = File.join(root, "master-zjit/raw/ir-zjit-#{index}-#{label.gsub(/\W+/, '_')}-#{side}-n#{n}")
        raw_counters = File.read("#{stem}.log").scan(/(\w+)=(\d+)>(\d+)/).to_h { |k, a, b| [k, [Integer(a), Integer(b)]] }
        window = r.fetch("jit").fetch("windows").find { |w| w.fetch("window") == "#{side} n#{n}" }
        raise "raw JIT counters differ" unless raw_counters == window.fetch("counters")
        log = File.read("#{stem}.valgrind.log")
        raise "bad JIT Valgrind log" if log.match?(/brk segment overflow|Cannot map memory to grow brk segment|Process terminating/)
        Integer(File.read("#{stem}.callgrind")[/^totals: (\d+)/, 1])
      end
      key = side == "base" ? "base1" : side
      close((totals[1] - totals[0]).fdiv(json.fetch("n")), r.fetch(key))
    end
    puts "#{name}: raw counts and all 6 JIT windows independently checked; change=#{r.fetch('change') * 100}% AA=#{r.fetch('aa') * 100}%"
  end
end
path = File.join(root, "pure-alternative/results.jsonl")
if File.exist?(path)
  rows = File.readlines(path).map { |line| JSON.parse(line) }
  raise "incomplete pure alternative" if ARGV.include?("--complete") && rows.size != 3
  rows.each do |row|
    size = row.fetch("size")
    n = size < 100 ? 100 : 1
    counts = 3.times.map do |index|
      totals = [0, n].map do |calls|
        stem = File.join(root, "pure-alternative/#{size}-#{index}-#{calls}")
        log = File.read("#{stem}.valgrind")
        raise "bad alternate Valgrind log" if log.match?(/brk segment overflow|Cannot map memory to grow brk segment|Process terminating/)
        dump = File.read("#{stem}.callgrind")
        raise "multiple/missing alternate totals" unless dump.scan(/^totals: /).size == 1
        Integer(dump[/^totals: (\d+)/, 1])
      end
      (totals[1] - totals[0]).fdiv(n)
    end
    counts.zip(row.fetch("counts")) { |a, b| close(a, b) }
    mean = (counts[0] + counts[2]) / 2.0
    close((counts[1] / mean - 1) * 100, row.fetch("change_pct"))
    close((counts[2] - counts[0]).abs / mean * 100, row.fetch("aa_pct"))
    puts "pure alternative #{size}: raw counts independently checked; change=#{row.fetch('change_pct')}% AA=#{row.fetch('aa_pct')}%"
  end
end
