require "json"
require "fileutils"
require "open3"
root = File.expand_path("..", __dir__)
out = File.join(__dir__, "perf", ARGV.fetch(0, "native"))
FileUtils.mkdir_p(out)
ruby = File.expand_path("~/.local/share/mise/installs/ruby/4.0.10/bin/ruby")
valgrind = File.join(root, "valgrind/bin/valgrind")
pure = ARGV[0].to_s.start_with?("pure")
tail = ARGV[0].to_s.end_with?("tail")
prelude = File.join(__dir__, "pure_cgi.rb")
env = {"RUBY_GC_HEAP_0_INIT_SLOTS" => "1000000", "RUBY_GC_HEAP_1_INIT_SLOTS" => "250000", "RUBY_GC_HEAP_2_INIT_SLOTS" => "100000", "RUBY_GC_HEAP_3_INIT_SLOTS" => "20000", "RUBY_GC_HEAP_4_INIT_SLOTS" => "10000", "RUBYOPT" => nil}
rows = []
commands = File.open(File.join(out, "commands.jsonl"), "w")
[:decode_www_form_component, :decode_uri_component].each do |method|
  sizes = tail ? [0, 8_388_608, 67_108_864] : [3, 12, 248, 16_384, 1_048_576]
  sizes.each do |size|
    shapes = tail ? (size.zero? ? %w[plain] : %w[plain early late]) : %w[plain early late plus percent]
    shapes.each do |shape|
      n = [100, [1, 65_536 / [size, 1].max].max].min
      counts = %w[base uri base2].map do |side|
        tree = side == "uri" ? "uri" : "base"
        totals = [0, n].map do |calls|
          stem = File.join(out, "#{method}-#{size}-#{shape}-#{side}-#{calls}")
          cmd = [valgrind, "--tool=callgrind", "--collect-atstart=no", "--toggle-collect=rb_ary_cycle", "--callgrind-out-file=#{stem}.callgrind", "--log-file=#{stem}.valgrind", ruby, *(pure ? ["-r", prelude] : []), "-I", File.join(root, tree, "lib"), File.join(__dir__, "sweep-worker.rb"), method.to_s, shape, size.to_s, calls.to_s]
          commands.puts JSON.generate(env: env, command: cmd)
          commands.flush
          ok = system(env, *cmd, out: "#{stem}.stdout", err: [:child, :out])
          raise "failed #{stem}" unless ok
          raise "brk overflow" if File.read("#{stem}.valgrind").match?(/brk segment overflow|Cannot map memory to grow brk segment/)
          Integer(File.read("#{stem}.callgrind")[/^totals: (\d+)/, 1])
        end
        (totals[1] - totals[0]).fdiv(n)
      end
      mean = (counts[0] + counts[2]) / 2.0
      row = {method: method, size: size, shape: shape, calls: n, counts: counts, change_pct: (counts[1] / mean - 1) * 100, aa_pct: (counts[2] - counts[0]).abs / mean * 100}
      rows << row
      File.write(File.join(out, "rows.json"), JSON.pretty_generate(rows))
      puts JSON.generate(row)
      $stdout.flush
    end
  end
end
