$LOAD_PATH.unshift(File.join(ENV.fetch("UPSTREAM_BENCH_TREE"), "lib"))
require "uri"
key = "article%5Btitle%5D"
value = "Hello+world+from+Rack"
cookie = "#{'A' * 200}--#{'b' * 40}%3D%3D"
user = "user%40example.com"
UpstreamBench.report("hello") { URI.decode_www_form_component("hello") }
UpstreamBench.report("form key") { URI.decode_www_form_component(key) }
UpstreamBench.report("form value") { URI.decode_www_form_component(value) }
UpstreamBench.report("cookie") { URI.decode_www_form_component(cookie) }
UpstreamBench.report("uri hello") { URI.decode_uri_component("hello") }
UpstreamBench.report("uri user") { URI.decode_uri_component(user) }
