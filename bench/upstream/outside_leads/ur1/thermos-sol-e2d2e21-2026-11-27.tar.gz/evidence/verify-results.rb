require "json"

versions = %w[2.5.9 4.0.10 master master-zjit 4.0.10-pure truffleruby-40.0.0 jruby-10.1.3.0 jruby-9.4.16.0 2.5.9-cgi-0.3.2 2.5.9-cgi-0.3.3]
versions.each do |version|
  suite = File.read(File.join(__dir__, "tests/suite-#{version}.txt"))
  raise "suite failed #{version}" unless suite.include?("94 tests,") && suite.include?("0 failures, 0 errors,")
  %w[decode_www_form_component decode_uri_component].each do |name|
    probe = File.read(File.join(__dir__, "diff/#{name}-#{version}.txt"))
    raise "probe failed #{name} #{version}" unless probe.include?("; 0 differences;")
  end
end
puts "10 runtime/CGI cohorts: both public-method probes and full suites pass"

records = Dir[File.join(__dir__, "tests/mutants-*.txt")].reject { |p| p.end_with?("-initial.txt") }.flat_map do |path|
  File.readlines(path).filter_map do |line|
    match = line.match(/^([^|]+) \| (\w+) \| exit=(\d+) \|\s*(.*)$/)
    next unless match
    name, mode, status, result = match.captures
    raise "process failed #{path} #{name}" unless status == "0"
    raise "control failed #{path} #{name}" if %w[head base-new-tests].include?(name) && !result.empty?
    [name, result]
  end
end
mutants = records.map(&:first).uniq - %w[head base-new-tests]
raise "missing mutants" unless mutants.size == 14
mutants.each do |name|
  raise "surviving mutant #{name}" unless records.any? { |n, result| n == name && !result.empty? }
end
puts "14 distinct faulty variants caught; base and exact-head controls pass in all 5 evaluator cohorts"

%w[native pure].each do |backend|
  paths = [backend, "#{backend}-tail"].map { |name| File.join(__dir__, "perf/#{name}/rows.json") }
  rows = paths.flat_map { |path| JSON.parse(File.read(path)) }
  raise "incomplete #{backend}" unless rows.size == 64
  rows.group_by { |r| r.fetch("method") }.each do |method, group|
    puts "#{backend} #{method}: worst #{JSON.generate(group.max_by { |r| r.fetch('change_pct') })}"
  end
  puts "#{backend}: max A/A #{rows.map { |r| r.fetch('aa_pct') }.max}%"
end
