#!/usr/bin/env bash
set -euo pipefail
root=/home/user/workspace/repo
here=$root/.amp/in/orb-backup/ur1-d09-review
export PATH="$(mise where java@temurin-21)/bin:$PATH"
v=$1
if [[ $v == master ]]; then rb=$here/master/bin/ruby; else rb=$(mise where ruby@$v)/bin/ruby; fi
pre=()
if [[ ${2:-} == pure ]]; then pre=(-r "$root/bench/upstream/outside_leads/ur1/pure_cgi.rb"); v=$v-pure; fi
"$rb" -v > "$here/evidence/runtime/$v.txt"
for m in decode_www_form_component decode_uri_component; do
  METHOD=$m "$rb" "${pre[@]}" -I "$here/uri/lib" "$root/bench/upstream/outside_leads/ur1/probe.rb" > "$here/evidence/diff/$m-$v.txt" 2>&1
done
"$rb" "${pre[@]}" -I "$here/uri/lib" "$here/evidence/edge.rb" > "$here/evidence/diff/edge-$v.txt" 2>&1
cat "$here/evidence/diff/"*"-$v.txt"
