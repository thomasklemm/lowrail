# Executed thermos-sol evidence

Scope: URI d09ffb7376d111123e5d217510c150c87c0cdd99, base 48cda77031e343d35213c36fe164b2a46ffbefa7. Original checkout: `/home/user/workspace/repo/.amp/in/orb-backup/ur1-d09-review/uri`; base is the sibling `base`. Both checkouts were clean. This archive excludes runtime binaries and fork clones.

`diff/` holds self-executed differential and edge results, not copies of the author's receipts. `probe.rb`, `diff.rb` and `pure_cgi.rb` are the existing retained harnesses copied here for retention. `run-matrix.sh` records the runtime/probe call shape. `edge.rb` independently adds large values, taint on Ruby 2.5, private conversion, threads and Ractors. Early attempts used the obsolete Ractor#take API; the final probe uses #value on current MRI, and the final logs replace those harness failures. Master was built from the pinned tarball; an initial generated version header picked up the enclosing Lowrail Git repository. The source was then given its own exact Git pin, its generated revision header rebuilt, and the master probes and suites rerun. The final runtime header/version is in `runtime/`.

`tests/` holds full-suite logs and mutation results. Mutation results list failing assertion lines, not suite counts. Blank output after `exit=0` means no assertion failed. The mutant dropping the native-only check fails the new subclass assertion on actual TruffleRuby. Dropping the binary copy reproduces its internal GB18030 crash. Inactive mutations are expected to survive on backends where their branch is not selected. `mutants.rb` generates disposable copies; its evaluator/assertions and CGI shims are copied in `tests/`.

`load/` records standalone/load-order tests and actual old-CGI gem installations. `load-probe.rb` checks the selected source branch as a review probe; upstream tests intentionally do not pin that implementation detail. CGI 0.3.2/0.3.3 were actually installed and executed. `review/cgi-source/` records the C/Java threshold source from tagged upstream CGI versions.

`perf/` holds the Callgrind sweep, with every executed command/environment in JSONL, every raw dump, stdout and Valgrind log, and aggregate rows. Each result is `(N-window minus zero-window) / N`, with base/candidate/base controls on one Ruby 4.0.10 pin. Collection toggles at `rb_ary_cycle`; input construction, warm-up and GC are outside collection. The fixed heap environment is in each command. Calls use the same `URI.public_send` wrapper on both sides; absolute counts include that wrapper. Tail rows include an empty input and 8/64 MiB plain/early/late inputs; 64 MiB exceeds the reported 54 MiB LLC. Percent-dense actual input length is 3 × floor(requested / 3). These are instruction counts, not time. `perf/master-zjit/` is a separate script/upstream-bench run with its own objects, A/A and JIT-flat checks.

`pure-alternative{,-sweep}.rb` separately compares the candidate's URI Ruby fallback with a hypothetical pure-CGI decoder block, using the same candidate helper and MRI 4.0.10. It tests the commit message's unqualified pure-Ruby performance assertion, not a proposed code change. Every command and raw dump is in `perf/pure-alternative/`; `results.jsonl` retains the gsub/CGI/gsub controls. `outputs.txt` independently checks each decoded value against `"A" * (requested_size / 3)`, with matching String class/UTF-8 encoding and unchanged input. This is instruction evidence, not elapsed time, and does not remove the TruffleRuby subclass reason to keep the actual fallback.

`audit.rb --complete` reconstructs every sweep and alternate comparison from its raw dumps, requires all 128 candidate/base sweep rows and all three alternate rows, and compares all 36 raw ZJIT window logs with the retained counters and counts. Its final output is `perf/audit.txt`.

`review/` also contains the exact patch/message/tree, Flog/RuboCop results, RDoc parse, executed form-decoder allocation comparison, caller source snapshots and the observed exact-head fork CI checks. `forms.rb` tests a hypothetical CGI replacement only to evaluate leaving decode_www_form unchanged; it does not alter the candidate checkout.

The scripts refer to their original workspace layout and pinned runtime paths. To rerun elsewhere, preserve that layout or replace the root/runtime paths. Typical commands:

```
bash evidence/run-matrix.sh 4.0.10
bash evidence/run-matrix.sh 4.0.10 pure
bash evidence/run-matrix.sh 2.5.9
bash evidence/run-matrix.sh master
bash evidence/run-matrix.sh jruby-10.1.3.0
bash evidence/run-matrix.sh truffleruby-40.0.0
ruby evidence/mutants.rb /path/to/ruby native
ruby evidence/mutants.rb /path/to/ruby fallback
ruby evidence/sweep.rb native
ruby evidence/sweep.rb pure
ruby evidence/sweep.rb native-tail
ruby evidence/sweep.rb pure-tail
ruby evidence/pure-alternative-sweep.rb
ruby evidence/audit.rb --complete
```

No URI push, upstream comment, queue edit or PR-body approval was made by this review.
