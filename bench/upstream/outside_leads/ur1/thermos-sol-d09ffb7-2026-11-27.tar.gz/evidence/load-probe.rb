order = ARGV.fetch(0)
case order
when "cgi-first" then require "cgi"
when "escape-first" then require "cgi/escape"
when "autoload" then Object.autoload(:CGI, "cgi")
when "no-native" then require File.expand_path("../../../../../bench/upstream/outside_leads/ur1/rework/tests/no_c_decoder", __dir__)
when "ruby-native" then require File.expand_path("../../../../../bench/upstream/outside_leads/ur1/rework/tests/ruby_decoder", __dir__)
end
require "uri"
require "cgi" if order == "uri-first"
raise "www" unless URI.decode_www_form_component("a+%2b%FF").bytes == [97, 32, 43, 255]
raise "uri" unless URI.decode_uri_component("a+%2b%FF").bytes == [97, 43, 43, 255]
begin
  URI.decode_uri_component("a%")
  raise "missing error"
rescue ArgumentError => e
  raise "message" unless e.message == "invalid %-encoding (a%)"
end
source = URI.method(:decode_uri_component).source_location
native = CGI.respond_to?(:unescapeURIComponent) && !CGI.method(:unescapeURIComponent).source_location
expected_line = native ? 444 : 448
raise "selection #{source.inspect} expected #{expected_line}" unless source.last == expected_line
puts "#{RUBY_DESCRIPTION}; #{order}; native=#{native}; unescape=#{CGI.method(:unescape).source_location.inspect}; uri=#{source.inspect}; pass"
