require "json"
require "fileutils"
root = File.expand_path("..", __dir__)
out = File.join(__dir__, "perf/pure-alternative")
FileUtils.mkdir_p(out)
env = {"RUBY_GC_HEAP_0_INIT_SLOTS" => "1000000", "RUBY_GC_HEAP_1_INIT_SLOTS" => "250000", "RUBY_GC_HEAP_2_INIT_SLOTS" => "100000", "RUBY_GC_HEAP_3_INIT_SLOTS" => "20000", "RUBY_GC_HEAP_4_INIT_SLOTS" => "10000", "RUBYOPT" => nil}
File.open(File.join(out, "commands.jsonl"), "w") do |commands|
  [12, 16_384, 1_048_576].each do |size|
    n = size < 100 ? 100 : 1
    counts = %w[gsub cgi gsub].each_with_index.map do |decoder, index|
      totals = [0, n].map do |calls|
        stem = File.join(out, "#{size}-#{index}-#{calls}")
        cmd = [File.join(root, "valgrind/bin/valgrind"), "--tool=callgrind", "--collect-atstart=no", "--toggle-collect=rb_ary_cycle", "--callgrind-out-file=#{stem}.callgrind", "--log-file=#{stem}.valgrind", File.expand_path("~/.local/share/mise/installs/ruby/4.0.10/bin/ruby"), "-r", File.join(__dir__, "pure_cgi.rb"), "-I", File.join(root, "uri/lib"), File.join(__dir__, "pure-alternative.rb"), "decode_uri_component", "percent", size.to_s, calls.to_s]
        child_env = env.merge("DECODER" => decoder)
        commands.puts JSON.generate(env: child_env, command: cmd)
        commands.flush
        abort "failed #{stem}" unless system(child_env, *cmd, out: "#{stem}.stdout", err: [:child, :out])
        Integer(File.read("#{stem}.callgrind")[/^totals: (\d+)/, 1])
      end
      (totals[1] - totals[0]).fdiv(n)
    end
    mean = (counts[0] + counts[2]) / 2.0
    puts JSON.generate(size: size, counts: counts, change_pct: (counts[1] / mean - 1) * 100, aa_pct: (counts[2] - counts[0]).abs / mean * 100)
    $stdout.flush
  end
end
