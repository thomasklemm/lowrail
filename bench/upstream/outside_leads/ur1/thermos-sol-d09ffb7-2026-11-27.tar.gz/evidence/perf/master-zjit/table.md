Objects and Callgrind instructions per call, Ruby 4.1.0dev, ZJIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `hello` | 4 | 3 | 3,324 | 2,727 | −18.0% |
| `form key` | 7 | 2 | 11,941 | 4,312 | −63.9% |
| `form value` | 8 | 2 | 13,883 | 3,856 | −72.2% |
| `cookie` | 7 | 2 | 18,925 | 9,144 | −51.7% |
| `uri hello` | 4 | 3 | 3,324 | 2,725 | −18.0% |
| `uri user` | 6 | 2 | 8,925 | 3,736 | −58.1% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/ur1-d09-review/evidence/perf/master-zjit.
- JIT-flat: compiled_iseq_count, failed_iseq_count, compiled_side_exit_count, invalidation_time_ns unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- base: ruby 4.1.0dev (2026-11-27T16:40:23Z pinned-master 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/ur1-d09-review/base at 48cda77031
- candidate: ruby 4.1.0dev (2026-11-27T16:40:23Z pinned-master 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/ur1-d09-review/uri at d09ffb7376
- zjit hello: instructions −18.0% with A/A 0.00% (base 3,324 / 3,324, candidate 2,727), JIT-flat in 6 windows
- zjit form key: instructions −63.9% with A/A 0.68% (base 11,900 / 11,981, candidate 4,312), JIT-flat in 6 windows
- zjit form value: instructions −72.2% with A/A 0.00% (base 13,883 / 13,883, candidate 3,856), JIT-flat in 6 windows
- zjit cookie: instructions −51.7% with A/A 0.00% (base 18,925 / 18,925, candidate 9,144), JIT-flat in 6 windows
- zjit uri hello: instructions −18.0% with A/A 0.00% (base 3,324 / 3,324, candidate 2,725), JIT-flat in 6 windows
- zjit uri user: instructions −58.1% with A/A 0.30% (base 8,939 / 8,912, candidate 3,736), JIT-flat in 6 windows
