require "uri"
if ENV.fetch("DECODER") == "cgi"
  def URI.decode_uri_component(str, enc = Encoding::UTF_8)
    _decode_uri_component(str, enc) { |bytes| CGI.unescapeURIComponent(bytes, Encoding::BINARY) }
  end
end
abort "CGI decoder is not Ruby" unless CGI.method(:unescapeURIComponent).source_location
load File.join(__dir__, "sweep-worker.rb")
