

# Decode URI components with cgi/escape

`URI.decode_www_form_component` and `URI.decode_uri_component` copy the string with `b` and then run `gsub` with a regexp and a Hash, which costs a match, a substring and a Hash lookup for every `+` and `%XX`. Rack decodes query strings and cookies with `decode_www_form_component` ([Rack::QueryParser](https://github.com/rack/rack/blob/52941a02842fd956e3c5532147116354a0240149/lib/rack/query_parser.rb#L268) and [Rack::Utils.unescape](https://github.com/rack/rack/blob/52941a02842fd956e3c5532147116354a0240149/lib/rack/utils.rb#L59) in Rack 3.2.9), and Rails decodes query parameters and URL-encoded form fields with it ([ActionDispatch::QueryParser, Rails 8.1.4.1](https://github.com/rails/rails/blob/3f290b759c8e2ffe7c257951b1255740751355e4/actionpack/lib/action_dispatch/http/query_parser.rb#L46-L47)).

The shared helper now yields the checked copy to `CGI.unescape` or `CGI.unescapeURIComponent`, which decode in one pass in C (in Java on JRuby). Results have the same class, bytes and encoding as before. Where cgi/escape has no native `unescapeURIComponent` (cgi before 0.3.3, TruffleRuby), both methods keep the `gsub`. uri now requires cgi/escape, which every supported Ruby ships.

| benchmark-ips, Ruby 4.0.10 | Before | After |
| --- | ---: | ---: |
| `decode_www_form_component("hello")` | 2.68M i/s | 3.50M i/s |
| `decode_www_form_component("article%5Btitle%5D")` | 869.5k i/s | 2.54M i/s |
| `decode_www_form_component("Hello+world+from+Rack")` | 720.2k i/s | 2.82M i/s |
| `decode_www_form_component` on a 248-byte cookie value | 489.0k i/s | 1.06M i/s |
| `decode_uri_component("hello")` | 2.73M i/s | 3.39M i/s |
| `decode_uri_component("user%40example.com")` | 1.13M i/s | 2.82M i/s |

With YJIT, and with ZJIT on Ruby master, time per call drops by 23% to 80%. Each call allocates 2 or 3 objects instead of 4 to 8.
