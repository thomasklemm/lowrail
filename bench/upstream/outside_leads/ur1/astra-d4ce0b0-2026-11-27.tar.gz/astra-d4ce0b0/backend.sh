#!/usr/bin/env bash
set -u
here=$(cd "$(dirname "$0")" && pwd)
export PATH="$(mise where java@temurin-21)/bin:$PATH"
for engine in 2.5.9 4.0.10 pure master truffleruby-40.0.0 jruby-10.1.3.0 jruby-9.4.16.0; do
  unset PRELUDE
  case $engine in
    2.5.9) ruby=$here/ruby-2.5.9/bin/ruby ;;
    jruby-10.1.3.0) ruby=$here/jruby-10.1.3.0/bin/ruby ;;
    jruby-9.4.16.0) ruby=$here/jruby-9.4.16.0/bin/ruby ;;
    master) ruby=$here/master/bin/ruby ;;
    pure) ruby=$(mise where ruby@4.0.10)/bin/ruby; export PRELUDE=$here/pure_cgi.rb ;;
    *) ruby=$(mise where ruby@"$engine")/bin/ruby ;;
  esac
  "$ruby" -I"$here/head/lib" "$here/backend.rb" > "$here/results/$engine/backend.txt" 2>&1
  "$ruby" ${PRELUDE:+-r"$PRELUDE"} -I"$here/head/lib" -e 'require "uri/common"; p [URI.decode_www_form_component("a%41+b"),URI.decode_uri_component("a%41+b")]' > "$here/results/$engine/standalone.txt" 2>&1
done
