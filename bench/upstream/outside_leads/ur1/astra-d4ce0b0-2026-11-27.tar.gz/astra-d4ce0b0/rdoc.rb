require 'rdoc/rdoc'
r = RDoc::RDoc.new
r.document(['--quiet','--dry-run','--op',File.join(__dir__,'rdoc-output'),ARGV.fetch(0)])
u = r.store.find_class_or_module('URI')
%w[decode_www_form_component decode_uri_component].each do |name|
  m = u.method_list.find { |m| m.name == name }
  p [RDoc::VERSION,m.name,m.document_self,m.comment.to_s]
end
