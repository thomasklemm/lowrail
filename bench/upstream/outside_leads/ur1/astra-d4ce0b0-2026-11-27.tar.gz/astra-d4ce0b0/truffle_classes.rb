require 'cgi/escape'
class S < String; end
['', 'a', 'a+b', 'a%41'].each do |text|
  input = S.new(text).b
  p [text, input.class, CGI.unescape(input, Encoding::ASCII_8BIT).class,
     CGI.unescapeURIComponent(input, Encoding::ASCII_8BIT).class]
end
