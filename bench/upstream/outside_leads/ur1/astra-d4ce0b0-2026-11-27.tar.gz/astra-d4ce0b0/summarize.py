import json
from pathlib import Path
root = Path(__file__).parent / 'results'
for engine in sorted(root.iterdir()):
    if not (engine / 'head-values.jsonl').exists():
        continue
    print('\nENGINE', engine.name)
    for mode in ['values', 'objects', 'concurrency', 'overrides', 'load-uri_first', 'load-cgi_first', 'load-autoload']:
        a_path, b_path = engine / f'base-{mode}.jsonl', engine / f'head-{mode}.jsonl'
        if not (a_path.exists() and b_path.exists()):
            print(mode, 'MISSING')
            continue
        a = [json.loads(line) for line in a_path.read_text().splitlines()]
        b = [json.loads(line) for line in b_path.read_text().splitlines()]
        assert len(a) == len(b), (engine, mode, len(a), len(b))
        differences = [(x, y) for x, y in zip(a, b) if x != y and x[0] != 'load']
        print(mode, len(a) - 1, 'cases;', len(differences), 'non-load differences')
        for x, y in differences:
            print(' ', x[0], '\n    base', x[1], '\n    head', y[1])
    for method in ['decode_www_form_component', 'decode_uri_component']:
        path = engine / f'head-independent-{method}.txt'
        print(path.read_text() if path.exists() else 'MISSING independent')
