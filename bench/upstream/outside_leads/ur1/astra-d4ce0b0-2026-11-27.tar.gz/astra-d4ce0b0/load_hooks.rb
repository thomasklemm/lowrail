require 'json'
require 'cgi/escape'
mode = ARGV.fetch(0)
if mode == 'no_native'
  CGI.singleton_class.send(:undef_method,:unescapeURIComponent) if CGI.respond_to?(:unescapeURIComponent)
elsif mode == 'wrapped_before'
  CGI.singleton_class.prepend(Module.new do
    def unescapeURIComponent(*args)
      super + '!'
    end
  end)
elsif mode == 'wrapped_both'
  CGI.singleton_class.prepend(Module.new do
    def unescapeURIComponent(*args)
      super
    end
    def unescape(*args)
      'intercepted'
    end
  end)
elsif mode == 'method_raises'
  def CGI.method(name)
    raise 'CGI.method called'
  end
elsif mode == 'respond_raises'
  def CGI.respond_to?(*args)
    raise 'CGI.respond_to? called'
  end
end
begin
  require 'uri'
  puts JSON.generate(['loaded',URI.decode_www_form_component('a%41+b'),URI.decode_uri_component('a%41+b')])
rescue Exception => e
  puts JSON.generate(['error',e.class.name,e.message])
end
