require ENV['PRELUDE'] if ENV['PRELUDE']
require 'uri'
require 'cgi'
puts RUBY_DESCRIPTION
p [:encoding_alias, Encoding::ASCII_8BIT.equal?(Encoding::BINARY)]
puts "CGI version #{CGI::VERSION}" if defined?(CGI::VERSION)
[:unescape,:unescapeURIComponent].each do |method|
  if CGI.respond_to?(method)
    p [method,CGI.method(method).owner.name,CGI.method(method).source_location]
  else
    p [method,:absent]
  end
end
[:decode_www_form_component,:decode_uri_component].each do |method|
  p [method,URI.method(method).source_location]
end
