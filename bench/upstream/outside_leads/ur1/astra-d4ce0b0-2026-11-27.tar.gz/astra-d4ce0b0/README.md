# Astra d4ce0b0 evidence

Base: 48cda77031e343d35213c36fe164b2a46ffbefa7.
Previous: d09ffb7376d111123e5d217510c150c87c0cdd99.
Head: d4ce0b0376d0b1bbbf853c87ad0dd506ef6dc70c.
Head tree: 3621b78834d9d699a0d8266887720d8ba6ffdfc8.
Body: UR1 after front matter at Lowrail e4f6b3e740c2e4c9f68c0044e810dec5cfcbf58b.

`base/`, `previous/` and `head/` contain source snapshots, not Git directories.
The head also contains its full tests. No runtime binaries or installed gems are archived.
The adjacent review is the verdict; this directory is the evidence and replay recipe.

## Full matrix

Install the exact Rubies in results/*/runtime.txt and backend.txt. The scripts expect MRI
2.5.9 under ruby-2.5.9/, master under master/, and the two JRubies under their named
directories. MRI 4.0.10, TruffleRuby 40.0.0 and Java Temurin 21 are found through mise.
Adjust these installation paths when replaying elsewhere, not the input corpus.
Master has ZJIT enabled; its ZJIT invocation uses --zjit-call-threshold=1.

test-gems/ held test-unit 3.6.8, test-unit-ruby-core 1.0.7 and power_assert 3.1.0.
Populate it with those gems before running suite.sh. pure_cgi.rb loads the shipped
Ruby backend instead of the native extension; backend.txt confirms its actual methods.

For each engine in 2.5.9 4.0.10 pure master master-zjit truffleruby-40.0.0
jruby-10.1.3.0 jruby-9.4.16.0, execute:

```sh
bash run.sh ENGINE
bash suite.sh ENGINE
```

Then execute `bash backend.sh`, `python3 verify.py` and `python3 summarize.py`.
run.sh invokes the actual base/head library in separate processes for value digests,
hooks, concurrency, overrides and load order. probe.rb is the earlier independent
harness with base inlined; it is run again on both revisions. Empty .err files mean
no stderr. Reload warnings are retained. Counts are correctness cases, not benchmarks.

## Supplemental probes

`truffle_classes.rb` runs directly with TruffleRuby; its first stdout and exact replay
are retained. `intermediates.rb` ran against base, previous and head with MRI 2.5.9;
its output includes taint. `load_hooks.rb` ran all five modes against all three library
snapshots with MRI 4.0.10; outputs are results/4.0.10/*-load-hook-*.jsonl.

`boundary-confirm/subclasses.rb` ran on JRuby 9.4.16.0 for each library snapshot:

```sh
jruby-9.4.16.0/bin/ruby -Ihead/lib boundary-confirm/subclasses.rb
```

For `safe_buffer.rb`, safe-gems/ held ActiveSupport 7.2.4 and dependencies listed in
safe-gems.txt. The successful invocation selected the JRuby default bigdecimal 3.1.4,
not the unrelated MRI native bigdecimal installed by the initial gem setup:

```sh
GEM_HOME="$PWD/safe-gems" GEM_PATH="$PWD/safe-gems:$PWD/jruby-9.4.16.0/lib/ruby/gems/shared" \
  jruby-9.4.16.0/bin/ruby -Ihead/lib -e \
  'gem "bigdecimal", "< 4"; load ARGV.fetch(0)' boundary-confirm/safe_buffer.rb
```

Repeat with base/lib and previous/lib. Earlier missing-securerandom errors are retained
as *-safe-buffer-setup.err; install securerandom 0.4.1 before the successful runs.

`rdoc.rb` ran under MRI 4.0.10 with RDoc 7.0.4 against each common.rb. Compare the two
JSON lines in results/4.0.10/{base,head}-rdoc.txt.

Generate mutants with `ruby delta_mutants.rb`. With GEM_HOME and GEM_PATH pointed at
test-gems/, run the actual test-unit test file on MRI 4.0.10 with mutants/no_b/lib,
and on TruffleRuby with mutants/no_native_guard/lib:

```sh
ruby -Imutants/no_b/lib -Ihead/test/lib -rhelper head/test/uri/test_common.rb \
  --name '/test_decode_(www_form|uri)_component/'
```

Expected failures are retained in results/4.0.10/mutant-no-b.txt and
results/truffleruby-40.0.0/mutant-native-guard.txt. These are intentional mutants,
not failures of head. Earlier per-assertion mutation evidence is in the d09ffb7 archive.

## Citation receipts

citations/*-gem.json: https://rubygems.org/api/v1/gems/{rack,rails}.json.
*-repository.json: GitHub API repos/rack/rack and repos/rails/rails.
*-tag.json: GitHub API commits/v3.2.9 and commits/v8.1.4.1, reduced to SHA and
committer/message metadata. *-main.json retains the fetched default-branch commit.
Sources are raw files at those exact SHAs: Rack lib/rack/{query_parser,utils}.rb;
Rails actionpack/lib/action_dispatch/http/{query_parser,param_builder,request}.rb.
The -main- sources use the SHAs in the corresponding -main.json.
CGI sources are ext/cgi/escape/escape.c at tags v0.3.2/v0.3.3 and
ext/java/org/jruby/ext/cgi/escape/CGIEscape.java at tags v0.4.0/v0.4.1.

The body table was awaiting a separate timing run. This archive contains no new
performance measurement and does not approve the old numerical claims.
