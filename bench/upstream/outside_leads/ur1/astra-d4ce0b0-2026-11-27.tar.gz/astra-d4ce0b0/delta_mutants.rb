require 'fileutils'
here = __dir__
source = File.read("#{here}/head/lib/uri/common.rb")
{
  'no_b' => ['yield(str.b)', 'yield(str)'],
  'no_native_guard' => [' && !CGI.method(:unescapeURIComponent).source_location', '']
}.each do |name, (from, to)|
  raise name unless source.include?(from)
  directory = "#{here}/mutants/#{name}"
  FileUtils.mkdir_p(directory)
  FileUtils.cp_r("#{here}/head/lib", directory)
  File.write("#{directory}/lib/uri/common.rb", source.sub(from, to))
end
