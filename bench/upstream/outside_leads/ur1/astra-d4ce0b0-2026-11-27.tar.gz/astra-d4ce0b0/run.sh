#!/usr/bin/env bash
set -u
here=$(cd "$(dirname "$0")" && pwd)
engine=$1
export PATH="$(mise where java@temurin-21)/bin:$PATH"
prelude=
flags=()
case $engine in
  2.5.9) ruby=$here/ruby-2.5.9/bin/ruby ;;
  jruby-10.1.3.0) ruby=$here/jruby-10.1.3.0/bin/ruby ;;
  jruby-9.4.16.0) ruby=$here/jruby-9.4.16.0/bin/ruby ;;
  master) ruby=$here/master/bin/ruby ;;
  master-zjit) ruby=$here/master/bin/ruby; flags=(--zjit --zjit-call-threshold=1) ;;
  pure) ruby=$(mise where ruby@4.0.10)/bin/ruby; prelude=$here/pure_cgi.rb ;;
  *) ruby=$(mise where ruby@$engine)/bin/ruby ;;
esac
export PRELUDE="$prelude"
[ -n "$prelude" ] || unset PRELUDE
out=$here/results/$engine
mkdir -p "$out"
"$ruby" "${flags[@]}" -v > "$out/runtime.txt" 2>&1
for rev in base head; do
  for mode in values objects concurrency overrides; do
    "$ruby" "${flags[@]}" -I"$here/$rev/lib" "$here/adversarial.rb" "$mode" > "$out/$rev-$mode.jsonl" 2> "$out/$rev-$mode.err"
    echo "$rev $mode $?" >> "$out/status.txt"
  done
  for order in uri_first cgi_first autoload; do
    ORDER=$order "$ruby" "${flags[@]}" -I"$here/$rev/lib" "$here/adversarial.rb" load > "$out/$rev-load-$order.jsonl" 2> "$out/$rev-load-$order.err"
    echo "$rev load-$order $?" >> "$out/status.txt"
  done
  for method in decode_www_form_component decode_uri_component; do
    METHOD=$method "$ruby" "${flags[@]}" ${prelude:+-r"$prelude"} -I"$here/$rev/lib" "$here/probe.rb" > "$out/$rev-independent-$method.txt" 2>&1
    echo "$rev independent-$method $?" >> "$out/status.txt"
  done
done
for file in "$out"/base-*.jsonl; do
  name=${file##*/base-}
  diff -u "$file" "$out/head-$name" > "$out/$name.diff" || true
done
cat "$out/status.txt"
