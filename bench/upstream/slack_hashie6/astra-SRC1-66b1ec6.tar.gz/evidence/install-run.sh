#!/usr/bin/env bash
set -uo pipefail
here=$(cd "$(dirname "$0")" && pwd)
rv=$1; shift
export PATH="$HOME/.local/share/mise/installs/ruby/$rv/bin:$PATH"
for v in "$@"; do
  for t in base slack; do
    tree=$(cd "$here/../$t" && pwd)
    cell="$here/bundles/$rv-$v-$t"
    mkdir -p "$cell"
    cp "$here/RuntimeGemfile" "$cell/Gemfile"
    export HASHIE=$v TREE=$tree BUNDLE_GEMFILE="$cell/Gemfile"
    bundle install --jobs 2 > "$cell/install.log" 2>&1
    installed=$?
    echo "$rv $v $t bundle exit=$installed"
    [ "$installed" = 0 ] || continue
    prefix="$here/out/$rv-$v-$t"
    ruby -v > "$prefix.version"
    bundle exec ruby -I"$tree/lib" "$here/adversarial.rb" > "$prefix.adversarial.jsonl" 2> "$prefix.adversarial.err"
    echo "$rv $v $t adversarial exit=$?"
    (cd "$tree"; bundle exec ruby -Ilib -Ispec -e 'require "rspec/autorun"; load "spec/slack/messages/message_spec.rb"') > "$prefix.spec.txt" 2>&1
    echo "$rv $v $t spec exit=$? $(grep -E 'examples?, .*failure' "$prefix.spec.txt" | tail -1)"
    if [[ $rv != 2.7* ]]; then
      bundle exec ruby -I"$tree/lib" "$here/message_diff.rb" > "$prefix.diff.txt" 2> "$prefix.diff.err"
      echo "$rv $v $t original diff exit=$?"
    fi
  done
done
