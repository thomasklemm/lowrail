# SRC1 second Astra pass

Head: 66b1ec68dd3996621d229d3f6d6e53406c37c586.
Base: 0f1757ebd856c2fea0ba168420fdaddecec8bf5c.
The scripts use sibling `slack` and `base` checkouts of these commits; base has
the unchanged new spec copied into spec/slack/messages/message_spec.rb.
source-checks.sh additionally uses a sibling hashie repository with release tags.

run.sh RUBY HASHIE... runs already-installed gems. install-run.sh RUBY HASHIE...
resolves RuntimeGemfile for that tree and version first. Versions and exit codes
are in run-*.txt, locks in bundles/, and raw stdout/stderr in out/. The runners
retain expected base failures without failing the overall shell process.
Use python3 compare.py to compare operation results separately from warnings.
message_diff.rb is the updated repository probe including quiet(:zip).
adversarial.rb, repros.rb and load-order.rb are the independent first-pass probes.

cold-ractor.txt uses gem 'hashie', VERSION; require 'slack-ruby-client'; then
Ractor.new { Slack::Messages::Message.new('size' => 7).to_hash }.take on Ruby
3.0.7 and Hashie 3.5.2/3.5.3/3.5.4, both trees. ractor-subclass.txt replaces
Message.new with Class.new(Message).new and checks the existing failure on both.
below-floor.txt requires each tree directly with gem 'hashie', '3.5.1', showing
why the changed gemspec needs the minimum (this direct load bypasses Bundler).

load-order.txt runs standalone, hashie-first, mash-first, logger-before,
logger-after and concurrent-require on both trees with Hashie 3.5.2 and 6.0.0.
full-3.4.7-* contain SuiteGemfile-based bundle exec rspec spec logs. As in the
first pass, these omit the three conditional release-tool examples, running 699.

facts.sh refreshes GitHub/RubyGems data, including the code comment's historical
issue URL. source-checks.sh archives the actual commit and tagged Hashie sources.
reviewed-item.md preserves the exact text reviewed. No benchmark was run.
