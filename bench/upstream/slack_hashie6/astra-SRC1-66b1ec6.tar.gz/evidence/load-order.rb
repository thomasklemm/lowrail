gem 'hashie', ENV.fetch('HASHIE')
require 'json'
begin
  case ARGV.fetch(0)
  when 'standalone'
    require 'slack/messages/message'
  when 'hashie-first'
    require 'hashie'
    require 'slack/messages/message'
  when 'mash-first'
    require 'hashie/mash'
    require 'slack/messages/message'
  when 'logger-before'
    require 'hashie'
    require 'logger'
    Hashie.logger = Logger.new(File::NULL)
    require 'slack-ruby-client'
  when 'logger-after'
    require 'slack-ruby-client'
    require 'logger'
    Hashie.logger = Logger.new(File::NULL)
  when 'concurrent-require'
    threads = 8.times.map { Thread.new { require 'slack-ruby-client' } }
    threads.each(&:value)
  end
  puts JSON.generate(result: Slack::Messages::Message.new('file' => {'size' => 7}).to_hash)
rescue Exception => e
  puts JSON.generate(error: e.class.name, message: e.message.lines.first.strip)
end
