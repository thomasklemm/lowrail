#!/usr/bin/env bash
set -eu
here=$(cd "$(dirname "$0")" && pwd)
slack="$here/../slack"
hashie="$here/../hashie"
git -C "$slack" show --format=fuller HEAD
git ls-remote https://github.com/slack-ruby/slack-ruby-client refs/heads/master
git ls-remote https://github.com/thomasklemm/slack-ruby-client refs/heads/thomasklemm/message-disable-warnings
git -C "$slack" show ffef2a8 -- lib/slack/messages/message.rb
git -C "$slack" show e5e4983 --stat
git -C "$slack" show HEAD:UPGRADING.md | head -70
cat "$slack/lib/slack/web/faraday/connection.rb"
git -C "$hashie" show 9f7c514 -- lib/hashie/mash.rb
git -C "$hashie" tag --contains 9f7c514
git -C "$hashie" show 9636f68 -- lib/hashie/mash.rb
for v in 3.5.1 3.5.2 3.5.3 5.2.0 6.0.0; do
  echo "===== Hashie $v ====="
  git -C "$hashie" show "v$v:lib/hashie/mash.rb" | grep -A12 -B2 'def self.disable_warnings\|def self.inherited\|def log_built_in_message\|def _log_built_in_message' || true
  git -C "$hashie" show "v$v:README.md" | grep -A18 -B3 disable_warnings || true
done
for name in hashie slack-ruby-client faraday-mashify; do
  jq '{full_name,stargazers_count,pushed_at,archived}' "$here/facts/$name-repo.json"
  jq '{name,downloads,version,version_created_at,dependencies}' "$here/facts/$name-gem.json"
done
echo 'Latest issue or PR numbers'
jq '.[0:5] | .[] | {number,title,state}' "$here/facts/slack-latest-issues.json"
echo 'Open PRs'
jq 'map({number,title})' "$here/facts/slack-open-prs.json"
echo 'Checks and workflows on exact head'
jq '.total_count' "$here/facts/check-runs.json" "$here/facts/actions.json"
