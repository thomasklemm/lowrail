gem 'hashie', ENV.fetch('HASHIE')
require 'json'
require 'stringio'
require 'logger'
require 'slack-ruby-client'
m = Slack::Messages::Message
io = StringIO.new
Hashie.logger = Logger.new(io)
begin
  result = case ARGV.fetch(0)
  when 'partial'
    klass = Class.new(m) { disable_warnings(:zip) }
    [klass.new('size' => 7).to_hash, io.string]
  when 'partial-error'
    klass = Class.new(m) { disable_warnings(:zip) }
    logger = Object.new
    def logger.warn(*); raise IOError, 'logger failed'; end
    Hashie.logger = logger
    klass.new('size' => 7).to_hash
  when 'frozen'
    Class.new(m).freeze.new('size' => 7).to_hash
  when 'ractor'
    m.new('size' => 0)
    r = Ractor.new { Slack::Messages::Message.new('size' => 7).to_hash }
    r.respond_to?(:value) ? r.value : r.take
  when 'impact-counterexample'
    [m.new('empty?' => true).to_hash, m.instance_methods.include?(:empty?), io.string]
  when 'body'
    [m.new('file' => {'size' => 1}).to_hash, io.string]
  when 'load'
    load File.join(ENV.fetch('TREE'), 'lib/slack/messages/message.rb')
    m.new('size' => 7).to_hash
  end
  puts JSON.generate(result: result)
rescue Exception => e
  puts JSON.generate(error: e.class.name, message: e.message, cause: e.cause && [e.cause.class.name, e.cause.message])
end
