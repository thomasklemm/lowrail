#!/usr/bin/env bash
set -uo pipefail
here=$(cd "$(dirname "$0")" && pwd)
rv=$1; shift
bin=$HOME/.local/share/mise/installs/ruby/$rv/bin
mkdir -p "$here/out"
for v in "$@"; do
  for t in base slack; do
    tree=$(cd "$here/../$t" && pwd)
    prefix="$here/out/$rv-$v-$t"
    export HASHIE=$v TREE=$tree
    "$bin/ruby" -v > "$prefix.version"
    "$bin/ruby" -I"$tree/lib" "$here/adversarial.rb" > "$prefix.adversarial.jsonl" 2> "$prefix.adversarial.err"
    echo "$rv $v $t adversarial exit=$?"
    (cd "$tree"; "$bin/ruby" -Ilib -Ispec -e 'gem "hashie", ENV.fetch("HASHIE"); require "rspec/autorun"; load "spec/slack/messages/message_spec.rb"') > "$prefix.spec.txt" 2>&1
    echo "$rv $v $t spec exit=$? $(grep -E 'examples?, .*failure' "$prefix.spec.txt" | tail -1)"
    if [[ $rv != 2.7* ]]; then
      "$bin/ruby" -I"$tree/lib" -e 'gem "hashie", ENV.fetch("HASHIE"); load ARGV[0]' "$here/message_diff.rb" > "$prefix.diff.txt" 2> "$prefix.diff.err"
      echo "$rv $v $t original diff exit=$?"
    fi
  done
done
