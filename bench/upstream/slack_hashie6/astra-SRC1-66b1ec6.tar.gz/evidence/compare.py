import glob, json, re
from pathlib import Path
root = Path(__file__).parent / 'out'
for base in sorted(root.glob('*-base.adversarial.jsonl')):
    head = Path(str(base).replace('-base.', '-slack.'))
    b = [json.loads(s) for s in base.read_text().splitlines()]
    h = [json.loads(s) for s in head.read_text().splitlines()]
    assert len(b) == len(h) and len(b) > 100
    print(base.name, 'rows', len(b))
    for x,y in zip(b,h):
        assert x['label'] == y['label']
        if x == y: continue
        different_logs = x.pop('warnings') != y.pop('warnings')
        if x != y:
            print('NONLOG', json.dumps(x), '=>', json.dumps(y))
        elif any(s in x['label'] for s in ['partial','quiet','web']):
            print('LOG ONLY', x['label'])
for base in sorted(root.glob('*-base.diff.txt')):
    head = Path(str(base).replace('-base.', '-slack.'))
    b = base.read_text().splitlines()
    h = head.read_text().splitlines()
    assert len(b) == len(h) and len(b) > 2000
    rows = [(x,y) for x,y in zip(b,h) if not x.startswith(('class','ractor'))]
    changed = [(x,y) for x,y in rows if x != y]
    nonlog = [(x,y) for x,y in changed if re.sub(r' \| warnings [0-9+]+$', '', x) != re.sub(r' \| warnings [0-9+]+$', '', y)]
    print(base.name, len(rows), 'rows', len(changed), 'changed', len(nonlog), 'nonlog')
