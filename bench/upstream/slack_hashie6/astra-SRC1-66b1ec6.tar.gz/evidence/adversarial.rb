require 'json'
require 'stringio'
gem 'hashie', ENV.fetch('HASHIE')
require 'hashie'
require 'logger'
require 'slack-ruby-client'
require 'webmock'
include WebMock::API
WebMock.enable!
WebMock.disable_net_connect!
M = Slack::Messages::Message
LOG = StringIO.new
Hashie.logger = Logger.new(LOG)

def norm(x)
  case x
  when Hash then [x.class.name, x.map { |k,v| [norm(k), norm(v)] }]
  when Array then [x.class.name, x.map { |v| norm(v) }]
  when String, Symbol, Numeric, NilClass, TrueClass, FalseClass then x
  else x.class.name
  end
end

def row(label)
  LOG.truncate(0); LOG.rewind
  begin
    result = norm(yield)
    error = nil
  rescue Exception => e
    result = nil
    error = [e.class.name, e.message.lines.first.to_s.strip.gsub(/0x[0-9a-f]+/, 'ADDRESS').gsub(/#<Class:ADDRESS>/, 'anonymous')]
  end
  puts JSON.generate(label: label, result: result, error: error, warnings: LOG.string.scan('conflicts with a built-in method').length)
end

class Plain < M; end
class Grandchild < Plain; end
class Own < M
  def channel; :own; end
end
class Dynamic < M
  def respond_to_missing?(name, private_too = false)
    name == :virtual || super
  end
  def method_missing(name, *args, &block)
    name == :virtual ? :dynamic : super
  end
end
module Convert
  def convert_value(value, *args)
    super
  end
end
class Prepended < M; prepend Convert; end

keys = ['size', :zip, 'class', 'default', 'log_built_in_message', '_log_built_in_message', 'channel', 'virtual', '', nil, 1]
[M, Plain, Grandchild, Own, Dynamic, Prepended].each do |klass|
  keys.each do |key|
    row("#{klass} new #{key.inspect}") do
      m = klass.new(key => [{'size' => 3, 'ok' => true}])
      [m, m[key], m.dup, m.to_hash, m.to_json]
    end
    row("#{klass} frozen #{key.inspect}") { m = klass.new.freeze; m[key] = 7 }
  end
end
row('public access to old helper key') { M.new('log_built_in_message' => 7).log_built_in_message }

class FancyHash < Hash
  def each_pair(&block); super(&block); end
  def to_hash; self; end
end
class FancyArray < Array
  def map(&block); super(&block); end
end
class FancyString < String
  def to_s; super; end
end
[FancyHash['size' => 7], FancyArray[{'size' => 8}], FancyString.new('x').freeze].each do |value|
  row("nested #{value.class}") do
    input = {'payload' => value}.freeze
    m = M.new(input)
    [m, m['payload'].equal?(value), input, m.dup, m.merge('size' => 3)]
  end
end
row('singleton key conversion') do
  key = Object.new
  calls = []
  key.define_singleton_method(:to_s) { calls << 'to_s'; 'size' }
  key.define_singleton_method(:to_sym) { calls << 'to_sym'; :size }
  [M.new(key => 3).values, calls]
end
row('mutating input each_pair') do
  input = {'size' => 3, 'ok' => true}
  def input.each_pair
    delete('ok')
    super { |k,v| yield k,v }
  end
  [M.new(input), input]
end
row('fiber in conversion') do
  key = Class.new(String) do
    def to_sym; Fiber.yield(:convert); super; end
  end.new('size')
  fiber = Fiber.new { M.new(key => 7).to_hash }
  results = []
  results << fiber.resume while fiber.alive?
  results
end
row('threads') do
  8.times.map { |i| Thread.new { 30.times.map { M.new('size' => i, 'nested' => {'zip' => i + 1}).to_hash } } }.map(&:value)
end

client = Slack::Web::Client.new(token: 'fixture', logger: Logger.new(StringIO.new))
[
  ['files.info', 200, {'ok' => true, 'file' => {'size' => 7, 'name' => 'a'}}],
  ['rtm.connect', 200, {'ok' => true, 'url' => 'wss://example.test/', 'self' => {'size' => 2}}],
  ['rtm.start', 200, {'ok' => true, 'users' => [{'size' => 3}]}],
  ['files.info', 200, {'ok' => false, 'error' => 'invalid_auth', 'size' => 9}],
  ['files.info', 500, {'error' => 'server_error', 'size' => 9}],
  ['files.info', 429, {'ok' => false, 'error' => 'ratelimited', 'size' => 9}],
  ['files.info', 200, 'invalid-json']
].each_with_index do |(endpoint, status, body), i|
  row("web #{i} #{endpoint} #{status}") do
    WebMock.reset!
    stub_request(:post, "https://slack.com/api/#{endpoint}").to_return(status: status, body: body.is_a?(String) ? body : JSON.generate(body), headers: {'Content-Type' => 'application/json', 'Retry-After' => '0'})
    begin
      client.public_send(endpoint.tr('.', '_'), endpoint == 'files.info' ? {file: 'F1'} : {})
    rescue StandardError => e
      [e.class.name, e.message, e.respond_to?(:response) && e.response && e.response.body]
    end
  end
end
row('realtime client availability') { Slack::RealTime::Client.new }

if M.respond_to?(:quiet)
  row('quiet(:zip) subclass') { M.quiet(:zip).new('size' => 7) }
end
unless M.method(:disable_warnings).arity == 0
  class Partial < M; disable_warnings(:zip); end
  row('partial subclass') { Partial.new('size' => 7) }
  row('partial subclass raising logger') do
    logger = Object.new
    def logger.warn(*); raise IOError, 'logger failed'; end
    Hashie.logger = logger
    begin
      Partial.new('size' => 7)
    ensure
      Hashie.logger = Logger.new(LOG)
    end
  end
end
row('raising logger') do
  logger = Object.new
  def logger.warn(*); raise IOError, 'logger failed'; end
  Hashie.logger = logger
  begin
    M.new('size' => 7)
  ensure
    Hashie.logger = Logger.new(LOG)
  end
end
row('reload message') do
  load File.join(ENV.fetch('TREE'), 'lib/slack/messages/message.rb')
  M.new('size' => 3)
end
row('standalone anonymous frozen class') { Class.new(M).freeze.new('size' => 7) }

if defined?(Ractor)
  [false, true].each do |conflict|
    row("ractor conflict #{conflict}") do
      r = Ractor.new(conflict) do |collision|
        begin
          Slack::Messages::Message.new(collision ? {'size' => 7} : {'ok' => true}).to_hash
        rescue StandardError => e
          [e.class.name, e.message]
        end
      end
      r.respond_to?(:value) ? r.value : r.take
    end
  end
end
