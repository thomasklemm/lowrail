# Astra SRC1 evidence

The reviewed head is dfbf7013bfaf7abf982a09ef29d732e6b452de71, with parent
0f1757ebd856c2fea0ba168420fdaddecec8bf5c. The scripts expect sibling directories
`base` and `slack` containing those trees. Copy the head's new
`spec/slack/messages/message_spec.rb` into the otherwise unchanged base checkout.
`source-checks.sh` additionally expects a sibling `hashie` clone with release tags.
The `reviewed-item.md` snapshot preserves the exact PR text reviewed.

`run.sh RUBY HASHIE...` uses gems already installed for that mise Ruby.
`install-run.sh RUBY HASHIE...` creates per-cell bundles using RuntimeGemfile, then
runs the independent probe, the exact new spec, and (Ruby >= 3.0) the original
message_diff.rb. Ruby binaries live under ~/.local/share/mise/installs/ruby/.
The runners do not treat expected base-spec failures as shell failures: inspect
the recorded exit statuses and raw outputs, not the runner's own exit status.

Executed matrix invocations are recorded in run-*.txt. An additional 3.0.7 run
with the literal requirement `>= 0` establishes actual unpinned resolution.
The 3.5.2 direct-load run deliberately bypasses the changed gemspec; the separate
bundled 3.5.2 run demonstrates that installation of the head is rejected.

Run `python3 compare.py` for the differential summary. Each adversarial JSON row
separates result, exception and warning count. Original probe output is compared
without warning counts; its Ractor/reflection rows remain in raw output.

Minimal probes use HASHIE=version and `ruby -I../TREE/lib repros.rb MODE`, with
TREE set to the absolute checkout path. Modes: body, partial, partial-error,
frozen, ractor, impact-counterexample, load. For the proposed correction, load
retain-legacy.rb after selecting Hashie and before repros.rb. That file is an
in-memory experiment, not an edit of the reviewed checkout. proposed-fix.txt
records the three regression examples and the Hashie 6 control.

load-order.rb accepts standalone, hashie-first, mash-first, logger-before,
logger-after or concurrent-require. load-order.txt contains both trees on
Hashie 3.5.3, 3.6.0, 4.1.0, 5.2.0 and 6.0.0.

The Ruby 3.4.7 full test runs use SuiteGemfile, which adds the repository's test
dependencies without its lint, benchmark or release-tool dependencies. Run
`bundle exec rspec spec` inside each tree with its recorded BUNDLE_GEMFILE.
This runs 699 examples, not the three conditional ruby-gem-release examples.

The first Ruby 4 spec attempt lacked the test dependency ostruct. Those logs
are retained in initial-4.0-ostruct-missing; RuntimeGemfile now includes ostruct,
and run-4.0.9-retry.txt plus out/ retain the corrected environment's results.
No upstream source or spec was patched to work around the test environment.

facts.sh saves public GitHub and RubyGems reads. source-checks.sh saves the
exact diff and release-source claims; source-checks.txt is its raw result.
The numbered issue checks 294 and 371 were fetched separately with
`gh api repos/slack-ruby/slack-ruby-client/issues/NUMBER`.
All response traffic in adversarial.rb is intercepted by WebMock, using real
Slack Web client middleware with synthetic JSON. No Slack API token or network
request is needed. No performance measurement was made.
