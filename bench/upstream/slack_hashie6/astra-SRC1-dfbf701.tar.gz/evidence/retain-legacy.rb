require 'slack-ruby-client'
class Slack::Messages::Message
  private
  def log_built_in_message(*); end
end
