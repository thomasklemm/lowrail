#!/usr/bin/env bash
set -eu
here=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$here/facts"
date -u > "$here/facts/checked-at.txt"
for pair in hashie/hashie slack-ruby/slack-ruby-client sue445/faraday-mashify; do
  name=${pair##*/}
  gh api "repos/$pair" > "$here/facts/$name-repo.json"
  curl -fsSL "https://rubygems.org/api/v1/gems/$name.json" > "$here/facts/$name-gem.json"
  curl -fsSL "https://rubygems.org/api/v1/versions/$name.json" > "$here/facts/$name-versions.json"
done
gh api repos/hashie/hashie/pulls/639 > "$here/facts/hashie-639.json"
gh api 'repos/hashie/hashie/pulls/639/files?per_page=100' > "$here/facts/hashie-639-files.json"
gh api repos/slack-ruby/slack-ruby-client/issues/132 > "$here/facts/slack-132.json"
gh api repos/slack-ruby/slack-ruby-client/issues/132/comments > "$here/facts/slack-132-comments.json"
gh api 'repos/slack-ruby/slack-ruby-client/issues?state=all&sort=created&direction=desc&per_page=100' > "$here/facts/slack-latest-issues.json"
gh api 'repos/slack-ruby/slack-ruby-client/pulls?state=open&per_page=100' > "$here/facts/slack-open-prs.json"
for query in 'hashie' 'log_built_in_message' 'disable_warnings' 'conflict warning'; do
  gh api -X GET search/issues -f q="repo:slack-ruby/slack-ruby-client $query" > "$here/facts/search-${query// /-}.json"
done
gh api repos/thomasklemm/slack-ruby-client/commits/dfbf7013bfaf7abf982a09ef29d732e6b452de71/check-runs > "$here/facts/check-runs.json"
gh api 'repos/thomasklemm/slack-ruby-client/actions/runs?head_sha=dfbf7013bfaf7abf982a09ef29d732e6b452de71' > "$here/facts/actions.json"
