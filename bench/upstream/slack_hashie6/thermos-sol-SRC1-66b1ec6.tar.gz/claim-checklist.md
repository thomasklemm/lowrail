# SRC1 second-pass claim audit

Exact head: 66b1ec68dd3996621d229d3f6d6e53406c37c586. Exact parent:
0f1757ebd856c2fea0ba168420fdaddecec8bf5c. The fetched diff and kept patch share
stable patch ID 0316aaca03fe2bb76ea98b40845d4f6bde45541d. Both Thermos rubrics
were applied in this thread, without delegation. The first pass and its archive
remain a separate historical review of dfbf701.

| Text | Direct check |
| --- | --- |
| Title fixes Hashie 6 key-conflict warnings for Message | Exact new spec and full project bundles on both trees; real Slack Web client response probes and real faraday-mashify mixed-array probe. Base warns, new head does not. |
| Body first sentence and literal nested file/size warning | `warning_text.rb out/SRC1-reviewed.md` on master/Hashie 6 prints `body warning matches: true`. `out/body-warning-text.txt` retains the literal comparison. |
| Silenced since issue 132, via private log_built_in_message | Fresh issue-132 API read and `git show ffef2a8`; first pass also checked the intervening method history. |
| Rename in Hashie PR 639, old hook no longer used in 6 | Fresh PR API, full renamed Mash diff, tag containment, new-spec failing stack on base. Only tag v6.0.0 contains the rename; the old name remains in v5.2.0. |
| Calls disable_warnings, Hashie's public setting | Exact head diff, tagged API source, documented Hashie README from the first pass, and executed calls. The method is publicly callable/documented although its source annotation says semipublic. |
| The setting exists from 3.5.2 | `floors.sh` loads release-tagged sources: head raises NameError on 3.5.1; Message and child are silent on 3.5.2 and 3.5.3. Hashie 3.5.2 CHANGELOG and issue-394 comments announce the feature in that release. |
| Gem specification previously unconstrained, now requires that version | Exact base/head gemspec diff and resolved full project Gemfiles. The syntax is >= 3.5.2, not an exact-version pin. |
| Override stays for Hashie before 6.0.0 | Exact Message source and tagged Hashie call sites; targeted Ractor/selective-logger probes check the compatibility behavior, not only the presence of the method. No new underscore-hook override exists. |
| New spec fails on master with 6 and passes with 5 | Independently executed exact spec and full suites. The negative failure is the forbidden size warning, not setup. Selecting only :zip in a scratch preload on Hashie 6 is a plausible mutation caught by the spec. |
| Commit subject and both paragraphs | Every factual clause maps to the warning, private rename, feature-introduction and retained-hook checks above. No runtime performance claim. |
| CHANGELOG line | New-spec result verifies the fix; gemspec verifies >= 3.5.2; contributor spelling matches commit author and existing changelog format. |
| Code comment: Hashie before 6 warns through the old method; issue 394 | Tagged Mash call/definition sources, plus opened https://github.com/intridea/hashie/issues/394. It redirects to hashie/hashie and includes the maintainer's original exact no-op workaround and the 3.5.2 release announcement. The version-boundary comment is useful because the method otherwise looks dead when reading Hashie 6. It is one line, not public-method documentation. |
| Impact release date, Ruby floor and reach | Fresh RubyGems versions/gem APIs retain Hashie 6.0.0's 2026-11-11 release and Ruby >= 3.0, and approximately 96M slack-ruby-client downloads. Full Gemfile resolution checks current supported MRI releases. The overbroad every-method-key claim was removed. |
| Prospective number 620 | Fresh latest-issues/PR API returns 619 as highest visible; no open PRs; GET issue 620 returns 404. It is still the apparent next number, not reserved or guaranteed. Recheck the allocated number on opening. |

There is no unchecked factual sentence in the submitted upstream text. The
body's final spec-status sentence is checked and true; optionally cut that test
narration under Lowrail's PR-description guidance. The second pass nevertheless
has a new demonstrated correctness finding: on Ruby 3.4.7/Hashie 3.5.3 and Ruby
4.0.9/Hashie 3.5.3–3.5.5, defining a Message subclass inside a non-main Ractor
succeeds on master but raises on the head. `ractor_subclass.sh` records both
trees and a scratch-only load-time Hashie 6+ gate that restores the result.
The original matrix did not exercise this public subclass-definition boundary.
It is not the first head's already-fixed direct-construction Ractor failure.
Verdict: changes. The floor 3.5.2 is valid for the unconditional API call, but
is no longer needed for API availability if that call is gated to Hashie 6+.

README/UPGRADING need no new selective-warning boundary for this shape: that
old behavior is retained. No new configuration API is added. The new Ractor
subclass boundary should be corrected before opening, or explicitly accepted
and disclosed; retaining the old hook alone does not preserve every pre-6
behavior. The changelog states the dependency minimum. The original warning
fix also did not add README instructions. CONTRIBUTING,
AGENTS, Gemfile, UPGRADING and Dangerfile are byte-identical to those read in
the first pass; lint and the changelog/TOC requirements were rechecked.
