#!/usr/bin/env bash
set -uo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
rv=$1; hv=${2:-latest}; mode=${3:-all}
export PATH="$HOME/.local/share/mise/installs/ruby/$rv/bin:$PATH"
if [ -x "$root/rubies/$rv/bin/ruby" ]; then export PATH="$root/rubies/$rv/bin:$PATH"; fi
if [ -x "$root/prebuilt/$rv/x64/bin/ruby" ]; then
  export PATH="/opt/hostedtoolcache/Ruby/$rv/x64/bin:$PATH"
  export LD_LIBRARY_PATH="$root/rubies/2.7.8/openssl/lib:${LD_LIBRARY_PATH:-}"
fi
cell="$root/env/$rv-$hv"
mkdir -p "$cell" "$root/out/$rv-$hv"
export BUNDLE_PATH="$root/gems/$rv" BUNDLE_APP_CONFIG="$cell/config"
for tree in base slack; do
  tree_root=$(realpath "$root/$tree")
  export BUNDLE_GEMFILE="$cell/$tree.Gemfile"
  printf "eval_gemfile '%s/Gemfile'\n" "$tree_root" > "$BUNDLE_GEMFILE"
  if [ "$hv" != latest ]; then printf "gem 'hashie', '= %s'\n" "$hv" >> "$BUNDLE_GEMFILE"; fi
  out="$root/out/$rv-$hv/$tree"
  (ruby -v; bundle --version; bundle install --jobs 3) > "$out-bundle.log" 2>&1
  status=$?
  echo "$rv $hv $tree bundle=$status"
  if [ "$status" != 0 ]; then tail -12 "$out-bundle.log"; continue; fi
  (
    cd "$tree_root" || exit
    bundle exec ruby -e 'require "hashie"; puts "Ruby #{RUBY_VERSION}, Hashie #{Hashie::VERSION}"' > "$out-versions.txt" 2>&1
    bundle exec rspec spec/slack/messages/message_spec.rb > "$out-spec.log" 2>&1
    echo "$rv $hv $tree spec=$? $(rg 'example.*,.*failure' "$out-spec.log" | tail -1)"
    bundle exec ruby -I lib "$root/scripts/extended.rb" > "$out-extended.jsonl" 2> "$out-extended.err"
    echo "$rv $hv $tree extended=$?"
    if [ "$mode" = all ]; then
      bundle exec rake spec > "$out-suite.log" 2>&1
      echo "$rv $hv $tree suite=$? $(rg 'examples.*,.*failure' "$out-suite.log" | tail -1)"
    fi
  )
done
