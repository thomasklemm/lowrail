require 'bundler/setup'
require 'hashie'

path = File.join(ENV.fetch('SLACK_TREE'), 'lib/slack/messages/message.rb')
source = File.read(path)
before = "      disable_warnings\n"
after = "      disable_warnings if Gem::Version.new(Hashie::VERSION) >= Gem::Version.new('6.0.0')\n"
raise 'unexpected source' unless source.scan(before).length == 1

eval(source.sub(before, after), TOPLEVEL_BINDING, path)
$LOADED_FEATURES << File.realpath(path)
