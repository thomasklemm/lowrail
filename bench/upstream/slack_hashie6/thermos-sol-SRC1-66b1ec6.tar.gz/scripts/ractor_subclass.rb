require 'slack-ruby-client'
require 'json'

puts "Ruby #{RUBY_VERSION}, Hashie #{Hashie::VERSION}"
begin
  ractor = Ractor.new do
    klass = Class.new(Slack::Messages::Message)
    klass.new('size' => 17).to_hash
  end
  result = ractor.respond_to?(:value) ? ractor.value : ractor.take
  puts JSON.generate(result: result)
rescue StandardError => error
  puts JSON.generate(error: error.class.name, message: error.message,
                     cause: error.cause && [error.cause.class.name, error.cause.message])
end
