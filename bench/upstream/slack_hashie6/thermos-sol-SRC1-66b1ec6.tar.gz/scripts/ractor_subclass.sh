#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
rv=$1; hv=$2
export PATH="$HOME/.local/share/mise/installs/ruby/$rv/bin:$PATH"
if [ -x "$root/prebuilt/$rv/x64/bin/ruby" ]; then
  export PATH="/opt/hostedtoolcache/Ruby/$rv/x64/bin:$PATH"
  export LD_LIBRARY_PATH="$root/rubies/2.7.8/openssl/lib:${LD_LIBRARY_PATH:-}"
fi
export BUNDLE_PATH="$root/gems/$rv" BUNDLE_APP_CONFIG="$root/env/$rv-$hv/config"
for tree in base slack; do
  export BUNDLE_GEMFILE="$root/env/$rv-$hv/$tree.Gemfile"
  tree_root=$(realpath "$root/$tree")
  echo "=== $tree ==="
  bundle exec ruby -I "$tree_root/lib" "$root/scripts/ractor_subclass.rb"
done
echo '=== head with load-time Hashie 6+ gate (scratch preload only) ==='
SLACK_TREE="$root/slack" bundle exec ruby -I "$root/slack/lib" -r "$root/scripts/version_gate.rb" "$root/scripts/ractor_subclass.rb"
