#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
rv=$1; hv=$2
export PATH="$HOME/.local/share/mise/installs/ruby/$rv/bin:$PATH"
if [ -x "$root/prebuilt/$rv/x64/bin/ruby" ]; then
  export PATH="/opt/hostedtoolcache/Ruby/$rv/x64/bin:$PATH"
  export LD_LIBRARY_PATH="$root/rubies/2.7.8/openssl/lib:${LD_LIBRARY_PATH:-}"
fi
export BUNDLE_PATH="$root/gems/$rv" BUNDLE_APP_CONFIG="$root/env/$rv-$hv/config"
export BUNDLE_GEMFILE="$root/env/$rv-$hv/slack.Gemfile" SLACK_TREE="$root/slack"
cd "$root/slack"
bundle exec ruby -I lib -r "$root/scripts/version_gate.rb" -S rspec spec/slack/messages/message_spec.rb
bundle exec ruby -I lib -r "$root/scripts/version_gate.rb" -S rake spec
if [ "$rv" != 2.7.8 ]; then
  for mode in body ractor frozen; do
    echo "=== $mode ==="
    RETAIN_LEGACY=0 bundle exec ruby -I lib -r "$root/scripts/version_gate.rb" "$root/scripts/late_cell.rb" "$mode"
  done
fi
