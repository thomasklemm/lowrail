#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
cd "$root"
run_cell() {
  bash scripts/run.sh "$1" "$2" all
  bash scripts/extras.sh "$1" "$2"
}
case $1 in
  hashie)
    for version in 3.5.2 3.5.3 3.5.4 3.5.5 3.5.6 3.5.7 3.6.0 4.0.0 4.1.0 5.0.0 5.1.0 5.2.0 6.0.0; do
      run_cell 4.0.9 "$version"
    done
    ;;
  rubies)
    for version in 2.7.8 3.0.7 3.1.7 3.2.9 3.3.10 3.4.7; do
      run_cell "$version" latest
    done
    run_cell 2.7.8 3.5.2
    for version in 3.5.2 3.5.3 3.5.4; do run_cell 3.0.7 "$version"; done
    ;;
esac
