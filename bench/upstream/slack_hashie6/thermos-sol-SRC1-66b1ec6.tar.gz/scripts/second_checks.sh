#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
cd "$root"
mkdir -p out/hashie-sources
for hv in 3.5.1 3.5.2 3.5.3 3.5.4 3.5.5 3.5.6 3.5.7 3.6.0 4.0.0 4.1.0 5.0.0 5.1.0 5.2.0 6.0.0; do
  git -C hashie show "v$hv:lib/hashie/mash.rb" > "out/hashie-sources/$hv.rb"
done
bash scripts/floors.sh > out/floors.txt 2>&1
for hv in 3.5.2 3.5.3 3.5.4; do
  bash scripts/late_cells.sh 3.0.7 "$hv" ractor > "out/late-ractor-3.0.7-$hv.txt" 2>&1
done
for hv in 3.5.2 3.5.3 3.5.4 3.5.5 3.5.6 3.5.7 3.6.0 4.0.0 4.1.0 5.0.0 5.1.0 5.2.0 6.0.0; do
  bash scripts/late_cells.sh 4.0.9 "$hv" frozen > "out/late-frozen-4.0.9-$hv.txt" 2>&1
done
for hv in 4.0.0 4.1.0 5.0.0 5.1.0 5.2.0 6.0.0; do
  bash scripts/late_cells.sh 4.0.9 "$hv" selective > "out/late-selective-4.0.9-$hv.txt" 2>&1
done
bash scripts/run.sh 3.4.7 3.6.0 short > out/probe-cell-3.4.7-3.6.0.txt 2>&1
bash scripts/late_cells.sh 3.4.7 3.6.0 ractor > out/late-ractor-3.4.7-3.6.0.txt 2>&1
bash scripts/late_cells.sh 4.0.9 3.6.0 ractor > out/late-ractor-4.0.9-3.6.0.txt 2>&1
bash scripts/late_cells.sh 4.0.9 6.0.0 body > out/late-body-4.0.9-6.0.0.txt 2>&1

export PATH="$HOME/.local/share/mise/installs/ruby/3.4.7/bin:$PATH"
export BUNDLE_PATH="$root/gems/3.4.7" BUNDLE_APP_CONFIG="$root/env/3.4.7-latest/config"
for tree in base slack; do
  export BUNDLE_GEMFILE="$root/env/3.4.7-latest/$tree.Gemfile"
  tree_root=$(realpath "$root/$tree")
  for script in middleware warnings impact; do
    bundle exec ruby -I "$tree_root/lib" "scripts/$script.rb" > "out/$tree-$script.txt" 2>&1
  done
  if [ "$tree" = base ]; then
    bundle exec ruby -I "$tree_root/lib" scripts/warning_text.rb out/SRC1-reviewed.md > out/body-warning-text.txt 2>&1
  fi
done
cd "$root/slack"
set +e
bundle exec ruby -r "$root/scripts/mutation.rb" -S rspec spec/slack/messages/message_spec.rb > "$root/out/spec-mutation.log" 2>&1
status=$?
set -e
echo "mutation exit=$status (expected 1)"
[ "$status" = 1 ]
