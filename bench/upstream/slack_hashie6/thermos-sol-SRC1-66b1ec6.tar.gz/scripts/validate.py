import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent.parent
out = root / 'out'
cells = []
suites = 0
for cell in sorted(out.iterdir()):
    if not (cell / 'slack-extended.jsonl').is_file():
        continue
    cells.append(cell.name)
    old = [json.loads(x) for x in (cell / 'base-extended.jsonl').read_text().splitlines()]
    new = [json.loads(x) for x in (cell / 'slack-extended.jsonl').read_text().splitlines()]
    assert len(old) == len(new) >= 195, cell
    versions = (cell / 'slack-versions.txt').read_text()
    hashie6 = 'Hashie 6.0.0' in versions
    for a, b in zip(old, new):
        if not hashie6:
            assert a == b, (cell.name, a['label'])
        a.pop('warnings', None)
        b.pop('warnings', None)
        assert a == b, (cell.name, a['label'])
    for tree in ('base', 'slack'):
        expected = int(tree == 'base' and hashie6)
        spec = (cell / f'{tree}-spec.log').read_text()
        assert re.search(rf'1 example, {expected} failure', spec), (cell.name, tree)
        if expected:
            assert '_log_built_in_message' in spec and 'received: 1 time' in spec
        suite = cell / f'{tree}-suite.log'
        if suite.is_file():
            assert re.search(rf'\d+ examples, {expected} failure', suite.read_text()), (cell.name, tree)
            suites += int(tree == 'slack')
    original = cell / 'base-original-diff.txt'
    if original.is_file():
        rows = lambda p: [x for x in p.read_text().splitlines() if not x.startswith(('class ', 'ractor'))]
        a = rows(original)
        b = rows(cell / 'slack-original-diff.txt')
        assert len(a) == len(b) >= 2880
        if not hashie6:
            assert a == b, cell.name
        strip = lambda lines: [re.sub(r' \| warnings [0-9+]+$', '', x) for x in lines]
        assert strip(a) == strip(b), cell.name
assert len(cells) == 25 and suites == 24, (cells, suites)

def results(name):
    return [json.loads(x) for x in (out / name).read_text().splitlines()
            if x.startswith(('{"result"', '{"error"'))]

for version in ('3.5.2', '3.5.3', '3.5.4'):
    assert results(f'late-ractor-3.0.7-{version}.txt') == [{'result': {'size': 17}}] * 3
for version in ('4.0.0', '4.1.0', '5.0.0', '5.1.0', '5.2.0'):
    assert results(f'late-selective-4.0.9-{version}.txt') == [{'result': {'zip': 11, 'size': 17}}] * 3
for item in results('late-selective-4.0.9-6.0.0.txt'):
    assert item['error'] == 'IOError' and item['message'] == 'logger failed'
for version in ('3.5.2', '3.5.3', '3.5.4', '3.5.5', '3.5.6', '3.5.7', '3.6.0', '4.0.0', '4.1.0', '5.0.0', '5.1.0', '5.2.0', '6.0.0'):
    a, b, shim = results(f'late-frozen-4.0.9-{version}.txt')
    assert b == shim == {'result': {'size': 17}}
    if version in ('3.5.2', '3.5.3', '3.5.4', '3.5.5'):
        assert a == b
    else:
        assert a['error'] == 'FrozenError'
for ruby in ('3.4.7', '4.0.9'):
    a, b, shim = results(f'late-ractor-{ruby}-3.6.0.txt')
    assert a['error'] == 'Ractor::RemoteError' and a['cause'][0] == 'Ractor::IsolationError'
    assert b == shim == {'result': {'size': 17}}
old = [json.loads(x) for x in (out / 'base-middleware.txt').read_text().splitlines()]
new = [json.loads(x) for x in (out / 'slack-middleware.txt').read_text().splitlines()]
assert len(old) == len(new) == 2
for a, b in zip(old, new):
    assert a.pop('warnings') == 2 and b.pop('warnings') == 0
    assert a == b
assert 'body warning matches: true' in (out / 'body-warning-text.txt').read_text()
assert '1 example, 1 failure' in (out / 'spec-mutation.log').read_text()
assert '_log_built_in_message' in (out / 'spec-mutation.log').read_text()
for ruby, version in (('3.4.7', '3.5.3'), ('4.0.9', '3.5.3'), ('4.0.9', '3.5.4'), ('4.0.9', '3.5.5')):
    a, b, gated = results(f'ractor-subclass-{ruby}-{version}.txt')
    assert a == gated == {'result': {'size': 17}}
    assert b['error'] == 'Ractor::RemoteError' and b['cause'][0] == 'Ractor::IsolationError'
for ruby, version in (('3.0.7', '3.5.2'), ('4.0.9', '3.5.2')):
    assert results(f'ractor-subclass-{ruby}-{version}.txt') == [{'result': {'size': 17}}] * 3
for ruby, version in (('2.7.8', '3.5.2'), ('3.0.7', '3.5.3'), ('3.4.7', '3.5.3'), ('4.0.9', '6.0.0')):
    log = (out / f'gate-check-{ruby}-{version}.txt').read_text()
    assert '1 example, 0 failures' in log and re.search(r'\d+ examples, 0 failures', log)
print('Validated 24 passing full head suites; 25 matching extended data comparisons; base/new-spec failure only with Hashie 6')
print('Validated corrected Ractor/selective-logger boundaries, frozen-class/Ractor improvements, real middleware values, warning text and mutation failure')
print('Confirmed new Ractor-subclass exception regression in 4 cells; load-time Hashie 6+ gate restores them, with 4 passing full scratch-variant suites')
