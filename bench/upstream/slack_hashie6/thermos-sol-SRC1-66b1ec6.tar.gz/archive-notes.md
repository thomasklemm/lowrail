# thermos-sol SRC1 second-pass evidence

Date: 2026-11-28. Thread: T-01a2221b-855f-7661-a87e-59f64efb922f.
Head: 66b1ec68dd3996621d229d3f6d6e53406c37c586.
Base: 0f1757ebd856c2fea0ba168420fdaddecec8bf5c.

This archive contains executed probes, raw results, resolved full-project
Gemfiles/lockfiles, source snapshots, and API claim checks. The prior review of
dfbf701 remains in thermos-sol-SRC1-dfbf701.tar.gz and was committed first.
The current head was reviewed directly in this thread using both rubrics.

Reproduction uses sibling base/ and slack/ checkouts at the pins above, with
only the unchanged new message spec copied into base/. Installed Rubies and
gems were reused from the first pass; their binaries/download checksums are
documented in that pass. They are not bundled here. Clones, installed tools,
Bundler configuration and compiler directories are omitted.

scripts/review_matrix.sh drives the full suites and extended probes. Ruby
4.0.9 runs every Hashie release from 3.5.2 through 6.0.0. Other MRI releases
run current full-Gemfile resolutions, with extra minimum/compatibility cells.
scripts/second_checks.sh covers isolated Ractor, frozen-class, selective
logger, real middleware, literal warning and spec-mutation cases.

Initially base/ was a symlink to the first pass's checkout. Ruby 2.7–3.1
then loaded Slack::VERSION through both the alias and physical path, breaking
four CLI assertions with duplicate-constant warnings. Those initial logs are
preserved under out/attempts/symlink-base/. All affected cells were rerun via
scripts/canonical_run.sh, which evaluates the physical tree's Gemfile. No
warning was suppressed, no suite assertion was changed, and no upstream file
was changed. The canonical rerun logs and final per-cell logs are authoritative.

out/attempts/ also retains an invalid Metrics/* invocation and a Flog attempt
whose isolated GEM_PATH omitted racc. Correct Metrics-department and Flog runs
are kept separately; neither failed invocation counts as a passing check.

Archived Gemfiles contain the original paths as provenance. Drivers regenerate
them for new physical checkouts. Use canonical_run.sh if a checkout is reached
through an alias; extras.sh runs after the cell's Gemfiles and bundle exist.
Ruby 2.7 cannot parse the original probe's endless definitions, so it runs the
compatible extended probe instead. No JRuby, Ruby master/ZJIT, performance,
live Slack request, hosted CI, fork push or upstream post is claimed.

The first Ruby 4 Ractor follow-up used the removed Ractor#take. The initial
harness-error log is preserved in out/attempts/ruby4-ractor-take.txt. The
corrected late_cell.rb chooses #value on Ruby 4 and #take on older Ruby; all
five direct-construction Ractor cells were rerun before validation.

A final adversarial probe defines the subclass inside the Ractor, rather than
only constructing a Message there. This adds a full Ruby 3.4.7/Hashie 3.5.3
cell (canonical_run.sh and extras.sh), taking the full-head-suite count to 24
and extended-comparison count to 25. It demonstrates a new exception on this
head with Ruby 3.4.7/Hashie 3.5.3 and Ruby 4.0.9/Hashie 3.5.3–3.5.5. This is
why the final second-pass verdict is changes, not the tentative nits verdict
considered before this probe. No passing suite was taken as Ractor coverage.

version_gate.rb evaluates a scratch-only source variant that calls the public
switch only on Hashie 6+, and marks that file as loaded before requiring the
complete gem. It never modifies either checkout. Four full-project variant
suites and the targeted subclass repros pass; existing Ractor failures on
other combinations remain failures. The first old-Ruby preload ran before
Bundler setup and could not require hashie; those attempts are retained under
out/attempts/preload-before-bundler/. The final preload explicitly requires
bundler/setup, and all affected attempts were rerun successfully.
