eval_gemfile '/home/user/workspace/repo/.amp/in/orb-backup/thermos-sol-SRC1-second/base/Gemfile'
gem 'hashie', '= 3.5.2'
