eval_gemfile '/home/user/workspace/repo/.amp/in/orb-backup/thermos-sol-SRC1-second/slack/Gemfile'
gem 'hashie', '= 4.1.0'
