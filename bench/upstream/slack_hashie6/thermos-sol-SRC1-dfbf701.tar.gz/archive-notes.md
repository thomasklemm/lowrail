# thermos-sol SRC1 evidence

Review date: 2026-11-28. Thread: T-01a2221b-855f-7661-a87e-59f64efb922f.

The reviewed repository is slack-ruby/slack-ruby-client, with base
0f1757ebd856c2fea0ba168420fdaddecec8bf5c and fork head
dfbf7013bfaf7abf982a09ef29d732e6b452de71. The verdict and findings are in the
adjacent Lowrail README; claim-checklist.md maps upstream text to checks.

This archive contains the executed scripts, raw outputs, source/API snapshots,
and resolved Gemfiles/lockfiles. It omits cloned repositories, installed gems,
Ruby toolchains, Bundler configuration, and compiler build directories. Logs
from unfinished source-build attempts are snapshots, not passing checks.

To reproduce, create sibling base/ and slack/ checkouts at the two pins, copy
only spec/slack/messages/message_spec.rb from slack/ to base/, and install the
Ruby versions named in the record. The drivers expect mise's Ruby installation
layout or the prebuilt toolcache layout established by scripts/prebuilt.sh.
The historical source builder uses scripts/source_ruby.sh; the completed older
Ruby checks instead used the prebuilt binaries and retained checksums. The
use-prebuilt marker prevents the earlier source-build driver from rerunning
tests when those unnecessary builds finish.

scripts/run.sh writes fresh Gemfiles pointing to those checkouts; archived
Gemfiles retain the original absolute paths as provenance. Run that driver
before extras.sh. Floors use a sibling hashie/ checkout with release tags.
scripts/message_diff.rb is an unmodified copy of the original candidate probe.
Full reruns contact public RubyGems/GitHub; the lockfiles record what resolved
for this review, not a promise that a future latest resolution is identical.
