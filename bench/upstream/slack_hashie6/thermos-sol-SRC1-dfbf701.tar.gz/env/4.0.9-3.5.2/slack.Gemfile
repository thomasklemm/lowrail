eval_gemfile '/home/user/workspace/repo/.amp/in/orb-backup/thermos-sol-SRC1/slack/Gemfile'
gem 'hashie', '= 3.5.2'
