eval_gemfile '/home/user/workspace/repo/.amp/in/orb-backup/thermos-sol-SRC1/base/Gemfile'
gem 'hashie', '= 4.0.0'
