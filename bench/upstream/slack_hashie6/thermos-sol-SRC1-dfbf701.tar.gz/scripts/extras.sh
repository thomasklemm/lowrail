#!/usr/bin/env bash
set -uo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
rv=$1; hv=$2
export PATH="$HOME/.local/share/mise/installs/ruby/$rv/bin:$PATH"
if [ -x "$root/rubies/$rv/bin/ruby" ]; then export PATH="$root/rubies/$rv/bin:$PATH"; fi
if [ -x "$root/prebuilt/$rv/x64/bin/ruby" ]; then
  export PATH="/opt/hostedtoolcache/Ruby/$rv/x64/bin:$PATH"
  export LD_LIBRARY_PATH="$root/rubies/2.7.8/openssl/lib:${LD_LIBRARY_PATH:-}"
fi
cell="$root/env/$rv-$hv"
export BUNDLE_PATH="$root/gems/$rv" BUNDLE_APP_CONFIG="$cell/config"
for tree in base slack; do
  export BUNDLE_GEMFILE="$cell/$tree.Gemfile"
  out="$root/out/$rv-$hv/$tree"
  (
    cd "$root/$tree" || exit
    bundle exec ruby -I lib "$root/scripts/extended.rb" > "$out-extended.jsonl" 2> "$out-extended.err"
    echo "$rv $hv $tree extended=$?"
    bundle exec ruby -I lib "$root/scripts/load_order.rb" > "$out-load-order.txt" 2>&1
    echo "$rv $hv $tree load-order=$?"
    if [ "$rv" != 2.7.8 ]; then
      bundle exec ruby -I lib "$root/scripts/message_diff.rb" > "$out-original-diff.txt" 2> "$out-original-diff.err"
      echo "$rv $hv $tree original-diff=$?"
    fi
  )
done
