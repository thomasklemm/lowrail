require 'slack-ruby-client'
require 'faraday/adapter/test'
require 'json'
require 'logger'
require 'stringio'
log = StringIO.new
Hashie.logger = Logger.new(log)
[
  [{ 'size' => 17 }, [{ 'count' => 23 }], nil, 'text', 31],
  { 'ok' => true, 'items' => [{ 'size' => 17 }, [{ 'count' => 23 }]] }
].each do |payload|
  stubs = Faraday::Adapter::Test::Stubs.new do |stub|
    stub.get('/test') { [200, { 'Content-Type' => 'application/json' }, JSON.generate(payload)] }
  end
  conn = Faraday.new do |c|
    c.response :mashify, mash_class: Slack::Messages::Message
    c.response :json
    c.adapter :test, stubs
  end
  log.truncate(0)
  log.rewind
  body = conn.get('https://example.invalid/test').body
  puts JSON.generate(payload: body, top_class: body.class.name,
                     first_class: body.is_a?(Array) ? body.first.class.name : body['items'].first.class.name,
                     warnings: log.string.scan('conflicts with a built-in method').size)
  stubs.verify_stubbed_calls
end
