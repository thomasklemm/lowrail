# frozen_string_literal: true
require 'hashie'
require 'json'
require 'logger'
require 'stringio'

class CaptureLogger
  attr_reader :warnings
  def initialize
    @warnings = []
  end
  def warn(message = nil)
    @warnings << (message || yield)
  end
end

class BeforeMash < Hashie::Mash; end
CAPTURE_LOGGER = CaptureLogger.new
Hashie.logger = CAPTURE_LOGGER
require 'slack-ruby-client'
require 'faraday/adapter/test'

class AfterMash < Hashie::Mash; end
class PlainMessage < Slack::Messages::Message; end
class OwnMessage < Slack::Messages::Message
  def channel
    :own
  end
end
class InputHash < Hash; end
class InputArray < Array; end
class InputString < String; end
class DuckHash
  def to_hash
    { 'size' => 7 }
  end
end

def snapshot(value)
  case value
  when Hash
    [value.class.name, value.map { |k, v| [snapshot(k), snapshot(v)] }]
  when Array
    [value.class.name, value.map { |v| snapshot(v) }]
  when String, Symbol, Numeric, TrueClass, FalseClass, NilClass
    [value.class.name, value.to_s]
  else
    [value.class.name, value.inspect.gsub(/0x[0-9a-f]+/, 'ADDRESS')]
  end
end

def probe(label)
  Hashie.logger.warnings.clear
  begin
    value = yield
    puts JSON.generate(label: label, value: snapshot(value), warnings: Hashie.logger.warnings)
  rescue StandardError => e
    puts JSON.generate(label: label, error: [e.class.name, e.message.gsub(/0x[0-9a-f]+/, 'ADDRESS')], warnings: Hashie.logger.warnings)
  end
end

payload = { 'ok' => true, 'file' => { 'size' => 17, 'name' => 'a' },
            'items' => [{ 'count' => 3, 'nested' => [{ 'zip' => 9 }] }] }
[Slack::Messages::Message, PlainMessage, OwnMessage].each do |klass|
  [payload, InputHash[payload], { 'values' => InputArray.new([{ 'size' => 19 }]) },
   { InputString.new('size') => 13 }, DuckHash.new, nil].each_with_index do |input, i|
    [:new, :dup, :clone, :marshal, :marshal_bytes, :frozen_dup, :default, :default_proc, :merge, :accessors].each do |op|
      probe("#{klass}:#{i}:#{op}") do
        m = klass.new(input)
        case op
        when :new then m
        when :dup
          copy = m.dup
          copy['other'] = { 'min' => 11 }
          copy['file']['name'] = 'changed' if copy['file']
          [m, copy]
        when :clone then m.clone
        when :marshal then Marshal.load(Marshal.dump(m))
        when :marshal_bytes then Marshal.dump(m).unpack1('H*')
        when :frozen_dup then [m.freeze.dup, m.clone.frozen?]
        when :default
          m.default = 'fallback'
          [m.dup['absent'], Marshal.load(Marshal.dump(m))['absent']]
        when :default_proc
          m.default_proc = proc { |_h, k| "missing:#{k}" }
          [m.dup['absent'], Marshal.dump(m)]
        when :merge then m.merge('size' => 23)
        when :accessors then m.with_accessors!
        end
      end
    end
  end
end

%w[object array null scalar error].each do |kind|
  probe("web:#{kind}") do
    body = case kind
           when 'object' then payload
           when 'array' then [payload, { 'size' => 31 }]
           when 'null' then nil
           when 'scalar' then 'hello'
           when 'error' then { 'ok' => false, 'error' => 'invalid_auth' }
           end
    stubs = Faraday::Adapter::Test::Stubs.new do |stub|
      stub.post('/api/auth.test') { [200, { 'Content-Type' => 'application/json' }, JSON.generate(body)] }
    end
    client = Slack::Web::Client.new(token: 'not-a-token', adapter: :test)
    client.send(:connection).builder.adapter(:test, stubs)
    result = client.auth_test
    stubs.verify_stubbed_calls
    result
  end
end

[BeforeMash, AfterMash, Hashie::Mash].each do |klass|
  probe("unrelated:#{klass}") { klass.new('size' => 29) }
end

if Hashie::Mash.method(:disable_warnings).arity != 0
  class SelectiveMessage < Slack::Messages::Message
    disable_warnings(:zip)
  end
  probe('selective:size') { SelectiveMessage.new('size' => 17) }
  probe('selective:zip') { SelectiveMessage.new('zip' => 19) }
  probe('quiet:size') { Slack::Messages::Message.quiet(:zip).new('size' => 17).to_hash }
end

probe('custom_logger:explicit') do
  Slack::Messages::Message.new(payload)
  raise 'logger was replaced' unless Hashie.logger.equal?(CAPTURE_LOGGER)
  Hashie.logger.warn('application warning')
  :done
end
probe('rtm_available') { [defined?(Slack::RealTime), Slack.const_defined?(:RealTime)] }

probe('singleton:frozen:conversion') do
  calls = []
  key = InputString.new('size')
  key.define_singleton_method(:to_sym) { calls << :to_sym; super() }
  key.define_singleton_method(:to_s) { calls << :to_s; super() }
  input = InputHash[key => { 'count' => 4 }.freeze]
  input.define_singleton_method(:each_pair) { |&block| calls << :each_pair; super(&block) }
  [Slack::Messages::Message.new(input.freeze), calls]
end
probe('prepend:writer') do
  mod = Module.new do
    def custom_writer(key, value, *rest)
      super(key, value, *rest)
    end
  end
  klass = Class.new(Slack::Messages::Message) { prepend mod }
  klass.new(payload).to_hash
end

probe('reload:existing_subclass') do
  load File.expand_path('slack/messages/message.rb', $LOAD_PATH.find { |p| File.file?(File.join(p, 'slack/messages/message.rb')) })
  PlainMessage.new(payload)
end

probe('mutation:fiber') do
  input = InputHash['start' => 1]
  input.define_singleton_method(:each_pair) do |&block|
    block.call('size', 41)
    Fiber.yield(:converted)
    block.call('count', self['changed'])
  end
  f = Fiber.new { Slack::Messages::Message.new(input) }
  first = f.resume
  input['changed'] = 53
  [first, f.resume]
end
probe('array:custom_map') do
  calls = []
  input = InputArray.new([{ 'size' => 47 }])
  input.define_singleton_method(:map) do |&block|
    calls << :map
    super(&block)
  end
  [Slack::Messages::Message.new('items' => input.freeze), calls]
end
