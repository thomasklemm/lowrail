#!/usr/bin/env bash
set -uo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
cd "$root" || exit
gh api repos/hashie/hashie/pulls/639 > out/hashie-639.json
gh api repos/slack-ruby/slack-ruby-client/issues/132 > out/slack-132.json
gh api 'repos/slack-ruby/slack-ruby-client/issues?state=all&sort=created&direction=desc&per_page=10' > out/latest-issues-prs.json
gh api 'repos/slack-ruby/slack-ruby-client/pulls?state=open&per_page=100' > out/open-prs.json
for word in hashie log_built_in_message disable_warnings 'key conflict'; do
  name=${word// /-}
  gh api --method GET search/issues -f "q=repo:slack-ruby/slack-ruby-client \"$word\"" -f per_page=100 > "out/search-$name.json"
done
curl -fsSL https://rubygems.org/api/v1/gems/slack-ruby-client.json > out/rubygems-slack.json
curl -fsSL https://rubygems.org/api/v1/gems/hashie.json > out/rubygems-hashie.json
curl -fsSL https://rubygems.org/api/v1/versions/hashie.json > out/rubygems-hashie-versions.json
git -C slack show ffef2a8 -- lib/slack/messages/message.rb CHANGELOG.md > out/slack-132-fix.txt
git -C hashie show 9f7c514 -- lib/hashie/mash.rb > out/hashie-639-diff.txt
git -C hashie tag --contains 9f7c514 > out/first-release-containing-rename.txt
git -C hashie tag --contains 9636f68 | sort -V > out/releases-inheriting-setting.txt
git -C slack show --format=fuller --no-patch HEAD > out/head.txt
git -C slack diff HEAD^ HEAD > out/exact-head.diff
