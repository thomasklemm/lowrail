#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
rv=$1; hv=$2; mode=$3
export PATH="$HOME/.local/share/mise/installs/ruby/$rv/bin:$PATH"
if [ -x "$root/prebuilt/$rv/x64/bin/ruby" ]; then
  export PATH="/opt/hostedtoolcache/Ruby/$rv/x64/bin:$PATH"
  export LD_LIBRARY_PATH="$root/rubies/2.7.8/openssl/lib:${LD_LIBRARY_PATH:-}"
fi
export BUNDLE_PATH="$root/gems/$rv" BUNDLE_APP_CONFIG="$root/env/$rv-$hv/config"
for tree in base slack; do
  export BUNDLE_GEMFILE="$root/env/$rv-$hv/$tree.Gemfile"
  echo "=== $tree $mode ==="
  RETAIN_LEGACY=0 bundle exec ruby -I "$root/$tree/lib" "$root/scripts/late_cell.rb" "$mode"
done
echo '=== head plus original legacy no-op (scratch preload only) ==='
RETAIN_LEGACY=1 bundle exec ruby -I "$root/slack/lib" "$root/scripts/late_cell.rb" "$mode"
