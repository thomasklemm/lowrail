#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
rv=$1
mkdir -p "$root/build-$rv" "$root/build-tmp" "$root/rubies"
export RUBY_CONFIGURE_OPTS=--disable-install-doc RUBY_BUILD_BUILD_PATH="$root/build-$rv" TMPDIR="$root/build-tmp" MAKE_OPTS=-j2
"$HOME/.cache/mise/ruby/ruby-build/bin/ruby-build" "$rv" "$root/rubies/$rv" > "$root/out/direct-ruby-$rv.log" 2>&1
if [ -f "$root/use-prebuilt" ]; then exit 0; fi
export PATH="$root/rubies/$rv/bin:$PATH"
gem install bundler -v 2.4.22 --no-document >> "$root/out/direct-ruby-$rv.log" 2>&1
bash "$root/scripts/run.sh" "$rv" latest all
bash "$root/scripts/extras.sh" "$rv" latest
