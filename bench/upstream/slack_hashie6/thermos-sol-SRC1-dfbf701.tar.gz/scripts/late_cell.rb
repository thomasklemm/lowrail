require 'slack-ruby-client'
require 'json'

puts "Ruby #{RUBY_VERSION}, Hashie #{Hashie::VERSION}, retain_legacy=#{ENV['RETAIN_LEGACY'] == '1'}"
if ENV['RETAIN_LEGACY'] == '1'
  Slack::Messages::Message.class_eval do
    private

    def log_built_in_message(*); end
  end
end

begin
  result = case ARGV.fetch(0)
           when 'body'
             Slack::Messages::Message.new('file' => { 'size' => 1 }).to_hash
           when 'ractor'
             Ractor.new { Slack::Messages::Message.new('size' => 17).to_hash }.take
           when 'frozen'
             Class.new(Slack::Messages::Message).freeze.new('size' => 17).to_hash
           when 'selective'
             logger = Object.new
             def logger.warn(*)
               raise IOError, 'logger failed'
             end
             Hashie.logger = logger
             Slack::Messages::Message.disable_warnings(:zip)
             Slack::Messages::Message.new('zip' => 11, 'size' => 17).to_hash
           end
  puts JSON.generate(result: result)
rescue StandardError => error
  puts JSON.generate(error: error.class.name, message: error.message,
                     cause: error.cause && [error.cause.class.name, error.cause.message],
                     trace: error.backtrace.first(5))
end
