#!/usr/bin/env bash
set -uo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.9/bin:$PATH"
for version in 3.5.1 3.5.2 3.5.3; do
  mkdir -p "$root/env/hashie-$version"
  git -C "$root/hashie" archive "v$version" | tar -xf - -C "$root/env/hashie-$version"
  for tree in base slack; do
    echo "hashie=$version tree=$tree"
    ruby -I "$root/env/hashie-$version/lib" "$root/scripts/floor.rb" "$root/$tree/lib/slack/messages/message.rb"
  done
done
