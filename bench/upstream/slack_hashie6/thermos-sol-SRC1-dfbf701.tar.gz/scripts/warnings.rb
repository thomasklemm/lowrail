require 'slack-ruby-client'
require 'logger'
require 'stringio'
log = StringIO.new
Hashie.logger = Logger.new(log)
if Hashie::Mash.method(:disable_warnings).arity != 0
  class Selective < Slack::Messages::Message
    disable_warnings(:zip)
  end
  [Selective, Slack::Messages::Message].each do |klass|
    klass.disable_warnings(:zip)
    log.truncate(0)
    log.rewind
    message = klass.new('zip' => 11, 'size' => 17)
    puts "#{klass}: zip=#{message['zip']} size=#{message['size']} warnings=#{log.string.scan('conflicts with a built-in method').size}"
    puts log.string.gsub(/^.*WARN -- : /, '')
  end
end
