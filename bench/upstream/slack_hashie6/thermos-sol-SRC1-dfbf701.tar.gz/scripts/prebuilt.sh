#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
rv=$1
url=$(jq -r --arg name "ruby-$rv-ubuntu-22.04.tar.gz" '.[] | select(.name==$name) | .browser_download_url' "$root/out/prebuilt-assets.json")
mkdir -p "$root/prebuilt/downloads" "$root/prebuilt/$rv"
if [ ! -f "$root/prebuilt/downloads/$rv.tar.gz" ]; then
  curl -fsSL "$url" -o "$root/prebuilt/downloads/$rv.tar.gz"
  tar -xzf "$root/prebuilt/downloads/$rv.tar.gz" -C "$root/prebuilt/$rv"
fi
sudo mkdir -p "/opt/hostedtoolcache/Ruby/$rv"
if [ ! -e "/opt/hostedtoolcache/Ruby/$rv/x64" ]; then
  sudo ln -s "$root/prebuilt/$rv/x64" "/opt/hostedtoolcache/Ruby/$rv/x64"
fi
export PATH="/opt/hostedtoolcache/Ruby/$rv/x64/bin:$PATH" LD_LIBRARY_PATH="$root/rubies/2.7.8/openssl/lib:${LD_LIBRARY_PATH:-}"
ruby -v
ruby -ropenssl -e 'puts OpenSSL::OPENSSL_VERSION'
gem install bundler -v 2.4.22 --no-document
bash "$root/scripts/run.sh" "$rv" latest all
bash "$root/scripts/extras.sh" "$rv" latest
