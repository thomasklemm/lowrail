require 'slack-ruby-client'
Slack::Messages::Message.disable_warnings(:zip)
