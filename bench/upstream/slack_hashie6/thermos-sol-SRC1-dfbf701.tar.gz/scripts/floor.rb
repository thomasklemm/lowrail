require 'hashie'
require 'logger'
require 'stringio'
Hashie::Mash
log = StringIO.new
Hashie.logger = Logger.new(log)
begin
  load ARGV.fetch(0)
  root = Slack::Messages::Message
  child = Class.new(root)
  root.new('size' => 17)
  puts "message warnings=#{log.string.scan('conflicts with a built-in method').size}"
  log.truncate(0)
  log.rewind
  child.new('size' => 17)
  puts "subclass warnings=#{log.string.scan('conflicts with a built-in method').size}"
rescue StandardError => e
  puts "#{e.class}: #{e.message.lines.first}"
end
