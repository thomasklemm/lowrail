require 'slack-ruby-client'
require 'logger'
require 'stringio'
log = StringIO.new
Hashie.logger = Logger.new(log)
%w[size empty?].each do |key|
  log.truncate(0)
  log.rewind
  message = Slack::Messages::Message.new(key => 17)
  owner = Hashie::Mash.instance_method(key).owner
  puts "key=#{key} method_owner=#{owner} stored=#{message[key]} warnings=#{log.string.scan('conflicts with a built-in method').size}"
end
