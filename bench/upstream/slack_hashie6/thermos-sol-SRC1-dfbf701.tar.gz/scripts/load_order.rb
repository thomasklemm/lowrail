require 'hashie'
require 'logger'
require 'stringio'
log = StringIO.new
Hashie.logger = Logger.new(log)
module Slack
  module Messages
    class Message < Hashie::Mash; end
  end
end
class EarlyMessage < Slack::Messages::Message; end
require 'slack-ruby-client'
class LateMessage < Slack::Messages::Message; end
[EarlyMessage, LateMessage].each do |klass|
  log.truncate(0)
  log.rewind
  value = klass.new('size' => 17)
  puts "#{klass}: value=#{value['size']}, warnings=#{log.string.scan('conflicts with a built-in method').size}"
end
