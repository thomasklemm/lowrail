require 'slack-ruby-client'
require 'logger'
require 'stringio'
log = StringIO.new
Hashie.logger = Logger.new(log)
Slack::Messages::Message.new('file' => { 'size' => 1 })
actual = log.string.split('WARN -- : ', 2).last.to_s.strip
expected = File.read(ARGV.fetch(0)).lines.find { |line| line.start_with?('# WARN -- : ') }.sub('# WARN -- : ', '').strip
puts "actual: #{actual}"
puts "body warning matches: #{actual == expected}"
abort 'warning mismatch' unless actual == expected
