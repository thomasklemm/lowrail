import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent.parent
for cell in sorted((root / 'out').iterdir()):
    base, head = cell / 'base-extended.jsonl', cell / 'slack-extended.jsonl'
    if not (base.is_file() and head.is_file()):
        continue
    b = [json.loads(x) for x in base.read_text().splitlines()]
    h = [json.loads(x) for x in head.read_text().splitlines()]
    if len(b) != len(h):
        print(f'{cell.name}: INCOMPLETE {len(b)}/{len(h)} rows')
        continue
    changes = []
    data_changes = []
    for old, new in zip(b, h):
        if old != new:
            changes.append(old['label'])
        old.pop('warnings', None)
        new.pop('warnings', None)
        if old != new:
            data_changes.append(old['label'])
    print(f'{cell.name}: rows={len(b)}/{len(h)} changed={len(changes)} non-warning={data_changes}')
    if len(changes) < 20:
        print('  changed labels:', changes)
    old_file, new_file = cell / 'base-original-diff.txt', cell / 'slack-original-diff.txt'
    if old_file.is_file() and new_file.is_file():
        old = [x for x in old_file.read_text().splitlines() if not x.startswith(('class ', 'ractor'))]
        new = [x for x in new_file.read_text().splitlines() if not x.startswith(('class ', 'ractor'))]
        changed = sum(a != b for a, b in zip(old, new))
        stripped_old = [re.sub(r' \| warnings [0-9+]+$', '', x) for x in old]
        stripped_new = [re.sub(r' \| warnings [0-9+]+$', '', x) for x in new]
        same = stripped_old == stripped_new
        print(f'  original rows={len(old)}/{len(new)} changed={changed} identical_without_warning_counts={same}')
