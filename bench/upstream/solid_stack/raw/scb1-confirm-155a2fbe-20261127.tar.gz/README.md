# SCB1 confirm pass, 2026-11-27

Head 155a2fbe9878ca820a593abf1cb22df646010d2e is a message-only amend of the prior reviewed head
ef534cc9414375d5c97339a4c05bb8f3c50fe81a. `commit-and-tree.log` records both tree IDs, parents and messages;
`git diff --exit-code OLD NEW` returned 0. No upstream source file changed.

From the Lowrail checkout, with the first review's pinned Ruby 4.0.10 and bundles, these ran sequentially for
each side and `DB=sqlite` / `DB=pg`, using the disposable local databases:

```sh
APP=$root/app BUNDLE_GEMFILE=$root/Gemfile.base ruby -rbundler/setup bench/upstream/solid_stack/sc1_differential.rb
APP=$root/app BUNDLE_GEMFILE=$root/Gemfile ruby -rbundler/setup bench/upstream/solid_stack/sc1_differential.rb
BUNDLE_GEMFILE=$root/Gemfile.base ruby -rbundler/setup $root/probe.rb
BUNDLE_GEMFILE=$root/Gemfile ruby -rbundler/setup $root/probe.rb
```

For each database both pairs of logs are byte-identical (ten original differential steps and eight state cases).
The original review archive contains the harness and bundles; the candidate bundle resolves the checkout now
detached at the new head. Earlier suites are carried forward by exact tree and parent equality, not claimed rerun.

The query-shape probe uses the original `bind_boundary.rb`, but disables benchmark registration; it measures no
performance and executes just one poll for each input:

```sh
BUNDLE_GEMFILE=$root/Gemfile ruby -rbundler/setup -e 'module UpstreamBench; def self.report(*); end; end; load ARGV.fetch(0)' $root/bind_boundary.rb
```

`bind-shape.log` again shows 999 binds at 998 channels and zero binds at 999 channels. The first direct invocation
without the benchmark registration stub stopped after the first shape with an uninitialized UpstreamBench error;
`bind-shape-attempt.log` retains it. It contributes no result.

`audit-existing-evidence.log` is another successful run of the retained `audit_numbers.py`; the original committed
SC1/SC1-zjit totals and the SC1-xxl raw timing and IPS reductions still match. No timing was rerun here, and the
required master ZJIT wall cohort was still absent from Lowrail when this confirm pass was recorded.
