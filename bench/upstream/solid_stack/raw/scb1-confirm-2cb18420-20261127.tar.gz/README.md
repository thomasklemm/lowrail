# SCB1 final confirm, 2026-11-27

Reviewed head 2cb1842043643d85ddee68aa48d02fd219305d56. `pins-and-messages.log` records its message and the
two preceding reviewed messages. All three have tree e737b3f89231ba7ebbc2d9fc1de4d00f10c1965d and parent
40dd29ffdc4ff76f27f0bbef1de1606fdd21cfee; `git diff --exit-code ef534cc HEAD` was empty in the fork checkout.
The checkout was clean and the remote branch head matched. The earlier correctness/maintainability review,
eight exactness items, version suites and PR 91/96 combinations carry forward, not claimed rerun here.

Fresh differential and state logs ran sequentially for each side on SQLite and PostgreSQL with Ruby 4.0.10:

```sh
DB=sqlite APP=$root/app BUNDLE_GEMFILE=$root/Gemfile.base ruby -rbundler/setup bench/upstream/solid_stack/sc1_differential.rb
DB=sqlite APP=$root/app BUNDLE_GEMFILE=$root/Gemfile ruby -rbundler/setup bench/upstream/solid_stack/sc1_differential.rb
DB=sqlite BUNDLE_GEMFILE=$root/Gemfile.base ruby -rbundler/setup $root/probe.rb
DB=sqlite BUNDLE_GEMFILE=$root/Gemfile ruby -rbundler/setup $root/probe.rb
```

Repeat those commands with `DB=pg`. `$root` is `.amp/in/orb-backup/scb1-review` in the reviewing orb, using the
harness and bundles retained in scb1-thermos-sol-20261127.tar.gz. Every pair compared byte-identical with `cmp`:
ten differential steps and eight state cases per database. The fresh `bind-shape.log` confirms 998 channels
use 999 binds, 999 channels use zero binds; the registration-disabled command is in the prior confirm archive.

`python3 audit_wall.py` runs from the Lowrail root, reading committed `body/SC1-zjit-wall`. It independently
reconstructs both timing summaries and A/A from all 90 raw process logs, compares the arrays with results.json,
checks all 30 balanced process orders, core pinning, Ruby/revision pins, third-party locks, benchmark source,
and every timed window's four summed absolute JIT deltas. Its independent 10,000-resample Python bootstrap
reaches the same interval verdicts as the Ruby runner; random generators differ, so intervals need not be
bit-identical. The raw cohort and commands are already committed; this archive does not duplicate them.
An initial audit-script assumption of core 0 was corrected after reading commands.sh: the entire cohort uses
core 1. No benchmark was rerun, discarded or selected because of that audit-harness correction.

The runner was T-01a21ee2-427f-70bf-a866-8436a4b8caa4. Reading the coordinator thread
T-01a21e77-af84-76fd-a951-068c857fafc8 in full for provenance returned the successful create_thread result
with orbSize a1.xxlarge (messages 440–441), and the runner's completion report (message 457: 16 cores, 31 GiB).
The raw run commit was ab220dd92e81b79f1530eb6466d979a8838fce92, the record update e8183fd4.

`prior-numbers-audit.log` is another run of the original archive's audit_numbers.py, checking all earlier body
cohorts and the retained adversarial measurements. No performance measurement was rerun in this confirm.
The final body has 109 prose words, two mechanism/safety paragraphs and one small benchmark-ips/instructions
table; ZJIT wall remains record-only. All original findings are closed; no must-fix remains.
