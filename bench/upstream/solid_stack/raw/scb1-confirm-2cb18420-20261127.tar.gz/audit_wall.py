import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import re
import statistics


repo = Path.cwd()
directory = repo / "bench/upstream/solid_stack/body/SC1-zjit-wall"
result = json.loads((directory / "results.json").read_text())
assert result["warmup"] == 2000
assert set(result["wall"]) == {"listener poll, idle", "listener poll, one message"}
assert {side["ruby"] for side in result["sides"].values()} == {"/home/user/w/ruby-master-inst/bin/ruby"}
assert all("0d399335b7" in side["description"] and side["zjit"] and not side["dirty"]
           for side in result["sides"].values())
assert result["sides"]["base"]["head"] == "40dd29ffdc4ff76f27f0bbef1de1606fdd21cfee"
assert result["sides"]["candidate"]["head"] == "155a2fbe9878ca820a593abf1cb22df646010d2e"
assert (directory / "sc1_body.rb").read_bytes() == (repo / "bench/upstream/solid_stack/sc1_body.rb").read_bytes()
locks = [(directory / side / "Gemfile.lock").read_text() for side in ("base", "candidate")]
assert locks[0].replace("/home/user/w/sc-base", "TREE") == locks[1].replace("/home/user/w/sc-cand", "TREE")

commands = (directory / "commands.sh").read_text().splitlines()
orders = []
cores = set()
for line in commands:
    match = re.search(r"raw/wall-r(\d+)-(base|candidate|base2)\.log 2>&1$", line)
    if match:
        orders.append((int(match[1]), match[2]))
        core = re.search(r"taskset -c (\d+) ", line)
        assert core and "ruby --zjit -rbundler/setup" in line
        cores.add(int(core[1]))
        assert " --worker wall " in line and "UPSTREAM_BENCH_WARMUP=2000 " in line
        assert "RUBY_GC_HEAP_0_INIT_SLOTS=1000000 " in line
        tree = "sc-cand" if match[2] == "candidate" else "sc-base"
        assert f"UPSTREAM_BENCH_TREE=/home/user/w/{tree} " in line
expected_orders = list(itertools.permutations(("base", "candidate", "base2")))
assert len(orders) == 90 and len(set(orders)) == 90
assert len(cores) == 1
assert set(directory.glob("raw/wall-r*-*.log")) == {
    directory / "raw" / f"wall-r{n}-{side}.log"
    for n in range(1, 31) for side in ("base", "candidate", "base2")
}
for n in range(1, 31):
    assert [side for round_n, side in orders if round_n == n] == list(expected_orders[(n - 1) % 6])
print("Pin, clean source revisions, matching third-party locks/script, --zjit and all 30 balanced process orders verified; CPU", cores)


def interval(rows):
    rng = random.Random(1007)
    estimates = sorted(statistics.median(value for _ in rows for value in rng.choice(rows))
                       for _ in range(10000))
    return [math.expm1(estimates[249]), math.expm1(estimates[9749])]


for label, cell in result["wall"].items():
    assert cell["windows"] == 30 and cell["quantile"] == 0.1 and len(cell["rounds"]) == 30
    logs = []
    for n in range(1, 31):
        process_values = {}
        for side in ("base", "candidate", "base2"):
            lines = (directory / "raw" / f"wall-r{n}-{side}.log").read_text().splitlines()
            times = [line.split("\t", 1)[1] for line in lines if line.startswith(f"wall {label}\t")]
            assert len(times) == 1
            windows = json.loads(times[0])
            assert windows == cell["rounds"][n - 1][side]
            assert set(windows) == {"cpu", "wall"}
            assert all(len(v) == 30 and all(math.isfinite(x) and x > 0 for x in v) for v in windows.values())
            process_values[side] = math.log(sorted(windows["cpu"])[3] / cell["calls"])
            jit_lines = [line.split("\t", 1)[1] for line in lines if line.startswith(f"jit {label}\t")]
            assert len(jit_lines) == 1
            counters = dict((key, (int(before), int(after)))
                            for key, before, after in re.findall(r"(\w+)=(\d+)>(\d+)", jit_lines[0]))
            assert set(counters) == {"compiled_iseq_count", "failed_iseq_count", "compiled_side_exit_count", "invalidation_time_ns"}
            assert all(before == after == 0 for before, after in counters.values())
        logs.append(process_values)
    med = statistics.median
    changes = [[r["candidate"] - r[side] for side in ("base", "base2")] for r in logs]
    aa = [[r["base2"] - r["base"]] for r in logs]
    calculated = {
        "base": math.exp(med((r["base"] + r["base2"]) / 2 for r in logs)),
        "candidate": math.exp(med(r["candidate"] for r in logs)),
        "change": math.expm1(med(x for row in changes for x in row)),
        "aa": math.expm1(med(x for row in aa for x in row)),
    }
    assert all(math.isclose(value, cell[key], rel_tol=1e-12, abs_tol=1e-15)
               for key, value in calculated.items())
    change_ci, aa_ci = interval(changes), interval(aa)
    assert change_ci[1] < 0 and aa_ci[0] < 0 < aa_ci[1]
    assert all(abs(a - b) < 0.002 for a, b in zip(change_ci, cell["change_ci"]))
    assert all(abs(a - b) < 0.002 for a, b in zip(aa_ci, cell["aa_ci"]))
    assert cell["aa_pass"] and cell["claim"] and cell["jit"]["flat"]
    assert len(cell["jit"]["windows"]) == 90 and not cell["jit"]["moved"]
    print(label, json.dumps(calculated, sort_keys=True))
    print("  independent 10,000-resample change CI:", change_ci, "A/A:", aa_ci)
    print("  all 90 processes: raw arrays match summary; four summed absolute JIT deltas zero in every timed window")

print("Worker source checked: timed clock is thread CPU; GC disabled per window; JIT deltas summed as absolute values")
print("Percentages are paired log-ratio medians, not the quotient of the two separately displayed time medians")
print("Raw results sha256:", hashlib.sha256((directory / "results.json").read_bytes()).hexdigest())
