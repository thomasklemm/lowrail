# frozen_string_literal: true
ENV["RAILS_ENV"] = "test"
require_relative "boot"

listener = new_listener
received = []
channel = Class.new(String) { def to_s = super }.new("cards").freeze
listener.add_subscriber(channel, ->(payload) { received << payload }, nil)
trace = []
token = ActiveSupport::Notifications.subscribe("sql.active_record") do |*, p|
  trace << [p[:name], p[:sql], !!p[:cached], p[:binds].size] unless p[:name] == "SCHEMA"
end
SolidCable::Message.broadcast("cards", "one")
trace.clear
one_poll(listener)
one_poll(listener)
raise received.inspect unless received == ["one"]
puts JSON.generate(case: "subclass frozen channel, fresh then idle", received: received, queries: trace)
ActiveSupport::Notifications.unsubscribe(token)

pool = SolidCable::Message.connection_pool
primary = ActiveRecord::Base.connection_pool
[false, true].each do |enabled|
  enabled ? pool.enable_query_cache! : pool.disable_query_cache!
  primary.enable_query_cache!
  before = [pool.query_cache_enabled, primary.query_cache_enabled]
  one_poll(listener)
  after = [pool.query_cache_enabled, primary.query_cache_enabled]
  raise [before, after].inspect unless before == after
  puts JSON.generate(case: "state restoration", before: before, after: after)
end

original = SolidCable::Message.method(:broadcastable)
error = Class.new(StandardError)
SolidCable::Message.define_singleton_method(:broadcastable) { |*| raise error, "poll failure" }
begin
  one_poll(listener)
rescue error => e
  raise unless e.message == "poll failure" && pool.query_cache_enabled && primary.query_cache_enabled
  puts JSON.generate(case: "exception restoration", message: e.message, cable: pool.query_cache_enabled, primary: primary.query_cache_enabled)
ensure
  SolidCable::Message.define_singleton_method(:broadcastable, original)
end

SolidCable::Record.connected_to(shard: :second) do
  other = SolidCable::Message.connection_pool
  other.enable_query_cache!
  l = new_listener
  l.add_subscriber("second", ->(p) { received << p }, nil)
  SolidCable::Message.broadcast("second", "shard two")
  one_poll(l)
  raise unless received.last == "shard two" && other.query_cache_enabled && pool.query_cache_enabled
  puts JSON.generate(case: "second shard", payload: received.last, restored: other.query_cache_enabled)
end

pool.disable_query_cache!
ready = Queue.new
release = Queue.new
worker = Thread.new do
  pool.enable_query_cache!
  ready << true
  release.pop
  raise unless pool.query_cache_enabled
  pool.disable_query_cache!
end
ready.pop
one_poll(listener)
release << true
worker.value
puts JSON.generate(case: "thread isolation", main: pool.query_cache_enabled)

SolidCable::Message.cache do
  SolidCable::Message.broadcast("cards", "nested")
  Rails.application.executor.wrap { one_poll(listener) }
  raise unless received.last == "nested" && pool.query_cache_enabled
end
puts JSON.generate(case: "nested executor", payload: received.last, restored: !pool.query_cache_enabled)

empty = new_listener
sql = []
token = ActiveSupport::Notifications.subscribe("sql.active_record") { |*, p| sql << p[:sql] unless p[:name] == "SCHEMA" }
one_poll(empty)
ActiveSupport::Notifications.unsubscribe(token)
raise sql.inspect unless sql.empty?
puts JSON.generate(case: "zero channels", queries: sql)
