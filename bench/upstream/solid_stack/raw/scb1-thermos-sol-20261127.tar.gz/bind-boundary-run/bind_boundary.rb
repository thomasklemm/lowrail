# frozen_string_literal: true
ENV["RAILS_ENV"] = "test"
require_relative "boot"
ENV.fetch("COUNTS", "998,999").split(",").map(&:to_i).each do |count|
  listener = new_listener
  count.times { |i| listener.send(:channels)[SolidCable::Message.channel_hash_for("stream-#{i}")] = 0 }
  sql_shape = []
  token = ActiveSupport::Notifications.subscribe("sql.active_record") do |*, payload|
    sql_shape << [payload[:sql].bytesize, payload[:binds].size] if payload[:name] == "SolidCable::Message Load"
  end
  one_poll(listener)
  ActiveSupport::Notifications.unsubscribe(token)
  warn "shape channels=#{count} sql_bytes,bind_count=#{sql_shape.inspect}"
  UpstreamBench.report("bind boundary #{count} channels") { one_poll(listener) }
end
