Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `listener poll, idle` | 234 | 231 | 1,698,544 | 1,451,480 | −14.5% |
| `listener poll, one message` | – | – | 2,747,607 | 2,500,930 | −9.0% |

Objects and Callgrind instructions per call, Ruby 4.0.10, YJIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `listener poll, idle` | 238 | 235 | 931,056 | 713,579 | not JIT-flat, no claim |
| `listener poll, one message` | – | – | 1,571,553 | 1,356,230 | −13.7% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/body-rerun-verified.
- JIT-flat: compiled_iseq_count, compiled_block_count, invalidation_count unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/solid_cable-base at 40dd29ffdc
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/solid_cable at ef534cc941
- interp listener poll, idle: instructions −14.5% with A/A 0.02% (base 1,698,733 / 1,698,355, candidate 1,451,480)
- interp listener poll, one message: objects differ between the two base runs (435, 435)
- interp listener poll, one message: instructions −9.0% with A/A 0.02% (base 2,747,324 / 2,747,890, candidate 2,500,930)
- yjit listener poll, idle: instructions −23.4% with A/A 0.17% (base 930,270 / 931,842, candidate 713,579): not JIT-flat (base n500 compiled_block_count +3, base2 n500 compiled_block_count +11), no claim
- yjit listener poll, one message: objects differ between the two base runs (442.9, 443)
- yjit listener poll, one message: instructions −13.7% with A/A 0.02% (base 1,571,428 / 1,571,678, candidate 1,356,230), JIT-flat in 6 windows
