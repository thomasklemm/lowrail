ENV["RAILS_ENV"] = "test"
ENV["SHARED_POOL"] = "1"
require_relative "boot"
pool = SolidCable::Message.connection_pool
raise unless pool.equal?(ActiveRecord::Base.connection_pool)
listener = new_listener
received = []
listener.add_subscriber("shared", ->(p) { received << p }, nil)
SolidCable::Message.broadcast("shared", "shared payload")
pool.enable_query_cache!
inside = nil
original = SolidCable::Message.method(:broadcastable)
SolidCable::Message.define_singleton_method(:broadcastable) do |*args|
  inside = ActiveRecord::Base.connection_pool.query_cache_enabled
  original.call(*args)
end
one_poll(listener)
raise unless received == ["shared payload"] && pool.query_cache_enabled
puts JSON.generate(shared_pool: true, primary_inside_poll: inside, restored: pool.query_cache_enabled, received: received)
