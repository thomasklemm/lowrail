Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `poll 0 channels cache_off=false` | 139 | 139 | 542,129 | 569,854 | +5.1% |
| `poll 1 channels cache_off=false` | 201 | 198 | 1,002,353 | 983,613 | −1.9% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/sweep-cache-on.
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/solid_cable-base at 40dd29ffdc
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/solid_cable at ef534cc941
- interp poll 0 channels cache_off=false: instructions +5.1% with A/A 0.04% (base 542,010 / 542,247, candidate 569,854)
- interp poll 1 channels cache_off=false: instructions −1.9% with A/A 0.02% (base 1,002,276 / 1,002,431, candidate 983,613)
