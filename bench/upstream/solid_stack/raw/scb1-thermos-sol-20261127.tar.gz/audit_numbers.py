import json
import math
import pathlib
import random
import re
import statistics

root = pathlib.Path(__file__).resolve().parent
repo = next(p for p in root.parents if (p / "script/upstream-bench").exists())


def total(path):
    return int(re.search(r"^totals: (\d+)", path.read_text(), re.M)[1])


for name in ("SC1", "SC1-zjit"):
    directory = repo / "bench/upstream/solid_stack/body" / name
    result = json.loads((directory / "results.json").read_text())
    for label, cell in result["instructions"].items():
        mode, operation = label.split(" ", 1)
        stem = re.sub(r"[^a-zA-Z0-9]+", "_", operation).strip("_")
        files = list((directory / "raw").glob(f"ir-{mode}-*-{stem}-base-n0.callgrind"))
        assert len(files) == 1, files
        prefix = files[0].name.removesuffix("base-n0.callgrind")
        values = {}
        for side in ("base", "candidate", "base2"):
            paths = [directory / "raw" / f"{prefix}{side}-n{n}.callgrind" for n in (0, result["n"])]
            values[side] = (total(paths[1]) - total(paths[0])) / result["n"]
            expected = cell[{"base": "base1", "base2": "base2", "candidate": "candidate"}[side]]
            assert abs(values[side] - expected) < 0.00001
        flat = True
        for log in (directory / "raw").glob(f"{prefix}*.log"):
            if log.name.endswith("valgrind.log"):
                continue
            for line in log.read_text().splitlines():
                if line.startswith("jit "):
                    flat &= all(a == b for a, b in re.findall(r"=(\d+)>(\d+)", line))
        assert flat == cell.get("jit", {}).get("flat", True)
        print(name, label, values, "JIT-flat", flat)

directory = repo / "bench/upstream/solid_stack/body/SC1-xxl"
result = json.loads((directory / "results.json").read_text())
label = "listener poll, idle"
cell = result["wall"][label]
logs = []
rounds = []
for n in range(1, 31):
    row = {}
    for side in ("base", "candidate", "base2"):
        text = (directory / "raw" / f"wall-r{n}-{side}.log").read_text()
        line = next(l for l in text.splitlines() if l.startswith("wall " + label + "\t"))
        windows = json.loads(line.split("\t", 1)[1])
        assert len(windows["cpu"]) == 30
        row[side] = math.log(sorted(windows["cpu"])[3] / cell["calls"])
        jit = next(l for l in text.splitlines() if l.startswith("jit " + label + "\t"))
        assert all(a == b for a, b in re.findall(r"=(\d+)>(\d+)", jit))
    rounds.append(row)

median = statistics.median
base = math.exp(median((r["base"] + r["base2"]) / 2 for r in rounds))
head = math.exp(median(r["candidate"] for r in rounds))
changes = [[r["candidate"] - r["base"], r["candidate"] - r["base2"]] for r in rounds]
aa = [[r["base2"] - r["base"]] for r in rounds]
for actual, expected in ((base, cell["base"]), (head, cell["candidate"]),
                         (math.expm1(median(x for r in changes for x in r)), cell["change"]),
                         (math.expm1(median(x for r in aa for x in r)), cell["aa"])):
    assert abs(actual - expected) < 0.000000001


def interval(rows):
    rng = random.Random(1)
    medians = sorted(median(x for _ in rows for x in rng.choice(rows)) for _ in range(5000))
    return [math.expm1(medians[124]), math.expm1(medians[4875])]


change_ci, aa_ci = interval(changes), interval(aa)
assert change_ci[1] < 0 and aa_ci[0] < 0 < aa_ci[1]
print("SC1-xxl idle seconds", base, head, "independent bootstrap", change_ci, "A/A", aa_ci, "90 flat processes")
rates = {}
for side in ("base", "candidate", "base2"):
    values = []
    for n in range(1, 6):
        text = (directory / "raw" / f"ips-r{n}-{side}.log").read_text()
        line = next(l for l in text.splitlines() if l.lstrip().startswith(label) and "i/s" in l)
        value, unit = re.search(r"idle\s+([\d.]+)([kM]?)", line).groups()
        values.append(float(value) * {"": 1, "k": 1000, "M": 1000000}[unit])
    rates[side] = max(values)
print("SC1-xxl best IPS", rates, "change", rates["candidate"] / ((rates["base"] + rates["base2"]) / 2) - 1)

for count in (998, 999, 65536):
    values = {}
    for side in ("base", "candidate", "base2"):
        paths = [root / "boundary-ir" / f"{side}-{count}-n{n}.callgrind" for n in (0, 2)]
        values[side] = (total(paths[1]) - total(paths[0])) / 2
    base = (values["base"] + values["base2"]) / 2
    print("boundary", count, values, "change", values["candidate"] / base - 1,
          "A/A", abs(values["base2"] - values["base"]) / base)

for directory in ("body-rerun-verified", "sweep-cache-on", "sweep-cache-off"):
    path = root / directory / "results.json"
    data = json.loads(path.read_text())
    for label, cell in data["instructions"].items():
        print(directory, label, {k: cell[k] for k in ("base", "candidate", "change", "aa", "claim")})
