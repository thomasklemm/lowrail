ENV["RAILS_ENV"] = "test"
require_relative "boot"
SolidCable::Record.connects_to(database: { writing: :cable, reading: :cable })
listener = new_listener
received = []
listener.add_subscriber("reader", ->(p) { received << p }, nil)
SolidCable::Message.broadcast("reader", "reader payload")
SolidCable::Record.connected_to(role: :reading) do
  pool = SolidCable::Message.connection_pool
  pool.enable_query_cache!
  one_poll(listener)
  raise unless received == ["reader payload"] && pool.query_cache_enabled
  puts JSON.generate(role: SolidCable::Record.current_role, restored: pool.query_cache_enabled, received: received)
end
