# frozen_string_literal: true
ENV["RAILS_ENV"] = "test"
require_relative "boot"

received = []
listener = new_listener
conversions = 0
duck = Object.new
duck.define_singleton_method(:to_s) { conversions += 1; "duck".freeze }
listener.add_channel(duck, nil)
listener.remove_channel(duck)
callback = ->(p) { received << p; listener.remove_subscriber("mutation", callback) }
listener.add_subscriber("mutation", callback, nil)
SolidCable::Message.broadcast("mutation", "one".b.freeze)
one_poll(listener)
one_poll(listener)
raise unless received == ["one"] && conversions == 2
puts JSON.generate(case: "duck singleton conversion and mutation in callback", received: received, conversions: conversions)

bad = Object.new
class << bad
  private
  def to_s = "private"
end
begin
  listener.add_subscriber(bad, ->(_) {}, nil)
rescue NoMethodError => e
  puts JSON.generate(case: "private conversion", error: e.class.name, method: e.name)
else
  raise "private conversion did not fail"
end

ActiveSupport::IsolatedExecutionState.isolation_level = :fiber
pool = SolidCable::Message.connection_pool
pool.enable_query_cache!
f = Fiber.new do
  l = new_listener
  l.add_subscriber("fiber", ->(_) { Fiber.yield(:callback) }, nil)
  SolidCable::Message.broadcast("fiber", "pause")
  pool.enable_query_cache!
  one_poll(l)
  raise unless pool.query_cache_enabled
  :restored
end
raise unless f.resume == :callback && pool.query_cache_enabled
raise unless f.resume == :restored && pool.query_cache_enabled
puts JSON.generate(case: "fiber isolation and suspended callback", restored: pool.query_cache_enabled)
