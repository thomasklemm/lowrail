# frozen_string_literal: true
ENV["RAILS_ENV"] = "test"
require_relative "boot"
ENV.fetch("COUNTS", "0,1").split(",").map(&:to_i).each do |count|
  listener = new_listener
  count.times { |i| listener.add_subscriber("stream-#{i}", ->(_) {}, nil) }
  one_poll(listener)
  UpstreamBench.report("poll #{count} channels cache_off=#{!!ENV['CACHE_OFF']}") { one_poll(listener) }
end
