Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `poll 1 channels cache_off=true` | 198 | 198 | 944,605 | 972,210 | +2.9% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/sweep-cache-off.
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/solid_cable-base at 40dd29ffdc
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/scb1-review/solid_cable at ef534cc941
- interp poll 1 channels cache_off=true: instructions +2.9% with A/A 0.06% (base 944,339 / 944,871, candidate 972,210)
