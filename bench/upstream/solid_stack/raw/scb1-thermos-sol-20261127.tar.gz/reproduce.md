# SCB1 thermos-sol evidence, 2026-11-27

Review thread: T-01a21eb4-4fce-7727-bded-abfba4ffb64e. Both Thermos rubrics were applied by the reviewer in this
thread, without delegated reviewers, as requested. No fork push or upstream post was made.

Pins: Ruby 4.0.10 a704b7cd95; solid_cable base 40dd29ffdc4ff76f27f0bbef1de1606fdd21cfee and head
ef534cc9414375d5c97339a4c05bb8f3c50fe81a; Rails main 2e299253f942ab94041cc6f210ac9d33884c210d;
Rails releases 7.2.4, 8.0.5.2 and 8.1.4.1. PostgreSQL 17 is a disposable local database. The review orb has
four CPUs; it did not produce wall-time claims.

The paths in the logs are the original orb paths. To replay, check out those pins as `solid_cable`,
`solid_cable-base`, and `rails-main` alongside these scripts, install Ruby 4.0.10 and the locked bundles, and
run from the Lowrail checkout with this evidence directory as `root`.

* `boot.rb` boots a small Rails application with separate primary/cable pools and two cable shards. No network
  service is needed for SQLite. `DB=pg` uses the local socket, role `user`, database `scb1_review`.
* The original `bench/upstream/solid_stack/sc1_differential.rb` ran with `APP=$root/app` and each side's
  `BUNDLE_GEMFILE` (`Gemfile` or `Gemfile.base`), for SQLite and PostgreSQL. Each output has ten JSON steps.
  `diff -u base-DB-original-differential.log candidate-DB-original-differential.log` is empty for each database.
* `ruby -rbundler/setup "$root/probe.rb"`, with each bundle and database, produced the eight state/delivery
  cases in `base-DB-probe.log` and `candidate-DB-probe.log`. Each pair is byte-identical.
* `extended_probe.rb` adds a singleton duck conversion, a private conversion error, subscriber removal from a
  callback, and a suspended callback under fiber-local isolation. Both `*-extended.log` files match.
* `reading_role.rb` exercises the reader pool; `role-base.log` and `role-candidate.log` match. `shared_pool.rb`
  intentionally observes the changed flag on a shared primary/cable pool: main true, head false during the
  poll, and restored true with the same payload afterwards. Those logs are intentionally not identical.
* Each released-version `Gemfile.VERSION` uses `RAILS_VERSION=VERSION`. The main bundle uses `Gemfile.main`.
  Head suites ran from `solid_cable` with `bin/rails db:setup` and `bin/test`; the base suite ran from
  `solid_cable-base`. Each head version has its own `suite-head-VERSION.log`. PostgreSQL suite URLs used only
  the disposable local socket and unique databases; the `*-pg-suite.log` files retain the results.
* The changes from `candidate.diff` applied unchanged to the open heads of PR 91
  (7995ad429d348c92cb9884c3e336a7d32161ab50) and PR 96 (f25ec2382aa01b60b36eeba7a8f8520aea7bb0e2).
  Their bundles are `Gemfile.pr91` and `Gemfile.pr96` with `PR=91` or `PR=96`. Both combinations ran the state
  probe and their full SQLite and PostgreSQL suites. PR metadata/diffs and suite logs are retained.
* `body-rerun-verified` repeats the original body script's interpreter and YJIT objects/instruction passes with
  the same fixed heaps, 500 warm-up calls and N=500, base/candidate/base2. The runner retains every command.
  Original committed SC1 and SC1-zjit totals were also independently recalculated as (N500 - N0) / 500;
  the raw JIT log counter pairs were checked for equality. Ruby master was not installed or rerun here.
* `sweep-cache-on` and `sweep-cache-off` use the same runner and fixed heaps, with base/candidate/base2. The
  latter has `CACHE_OFF=1 COUNTS=1`. `sweep.rb` tests empty and one-channel polls; the body tests 20 channels.
* `run_boundary.sh` runs the runner's instruction worker directly for 998, 999 and 65,536 channels, with the
  same fixed heaps, one warm-up poll and N=2 minus N=0, base/candidate/base2. `boundary-ir/commands.log` keeps
  expanded commands; `valgrind-manifest.json` identifies the tool. The large query is 1,401,475 bytes of SQL.
  Channels are seeded in the listener's map outside the measured window; only the real `listen` poll is measured.
* `metrics-identical-config.json` uses `metrics.yml` with thresholds zero to expose per-method metrics, not as
  a failing style gate. `omakase.log` uses the upstream configuration. Flog base/head outputs are retained.
* `audit_numbers.py` checks the committed SC1 and SC1-zjit raw totals and JIT counters and independently reduces
  the SC1-xxl idle timing logs (90 fresh processes) and best-of-five IPS. Python's bootstrap RNG differs from
  Ruby's, so its interval endpoints need not be identical; both intervals give the same verdict. `audit-numbers.log`
  retains the output. The script also summarizes the review's size and disabled-cache instruction sweeps.
* The body replay's YJIT idle instruction cohort is not JIT-flat (two base processes compiled 3 and 11 blocks).
  It is retained without retry and contributes no claimed result. Its YJIT message and interpreter cohorts pass.

Excluded runs: the first body attempt lacked the required Valgrind prefix and produced no result. The first
suite attempt omitted the gemspec's `msgpack` development dependency; the accepted reruns include it. An initial
large-input invocation of the full runner was stopped because its fixed 3,000-call GC-off allocation pass is
unsuitable for a 65,536-channel query. That incomplete run is retained as `bind-boundary-run` and is not evidence
for a claim; `boundary-ir` is the bounded replacement. No failed or non-flat result is promoted to a claim.
