#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.10/bin:$PATH"
export BUNDLE_GEMFILE="$root/Gemfile" RAILS_VERSION=8.1.4.1
exec 3>"$root/logs/combinations-commands.log"
export BASH_XTRACEFD=3
set -x
for side in cable-base cable cable-pr91-base cable-pr91 cable-pr96-base cable-pr96; do
  export CABLE="$side"
  bundle install > "$root/logs/bundle-$side-combo.log" 2>&1
  cp "$root/Gemfile.lock" "$root/logs/lock-$side-combo"
  for db in sqlite pg; do
    export DB="$db" SCB1_REVIEW_ROOT="$root/combo-app"
    ruby -rbundler/setup "$root/adversarial.rb" > "$root/logs/combo-$side-$db.log" 2>&1
    ruby -rbundler/setup "$root/prior/probe.rb" > "$root/logs/combo-state-$side-$db.log" 2>&1
    if [ "$db" = pg ]; then
      export DATABASE_URL="postgresql:///scb1_suite_${side//-/_}?host=/var/run/postgresql"
    else
      unset DATABASE_URL
    fi
    (cd "$root/$side"; bin/rails db:setup && bin/test) > "$root/logs/combo-suite-$side-$db.log" 2>&1
  done
  echo "$side passed"
done
for variant in cable cable-pr91 cable-pr96; do
  for db in sqlite pg; do
    for prefix in combo combo-state; do
      diff -u "$root/logs/$prefix-$variant-base-$db.log" "$root/logs/$prefix-$variant-$db.log"
    done
  done
done
