#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.10/bin:$PATH"
export BUNDLE_GEMFILE="$root/Gemfile" RAILS_VERSION=8.1.4.1
unset DATABASE_URL
exec 3>"$root/logs/clean-probe-commands.log"
export BASH_XTRACEFD=3
set -x
for side in cable-base cable cable-pr91-base cable-pr91 cable-pr96-base cable-pr96; do
  export CABLE="$side"
  bundle install > "$root/logs/bundle-$side-clean.log" 2>&1
  for db in sqlite pg; do
    export DB="$db" SCB1_REVIEW_ROOT="$root/clean-app"
    ruby -rbundler/setup "$root/adversarial.rb" > "$root/logs/clean-$side-$db.log" 2>&1
    ruby -rbundler/setup "$root/prior/probe.rb" > "$root/logs/clean-state-$side-$db.log" 2>&1
  done
done
for variant in cable cable-pr91 cable-pr96; do
  for db in sqlite pg; do
    for prefix in clean clean-state; do
      diff -u "$root/logs/$prefix-$variant-base-$db.log" "$root/logs/$prefix-$variant-$db.log"
    done
  done
done
echo 'All clean comparisons match'
