# frozen_string_literal: true
require "fileutils"
require "json"
require "rails"
require "active_record/railtie"
require "action_cable/engine"
require "solid_cable"

ROOT = ENV.fetch("SCB1_REVIEW_ROOT", File.expand_path(__dir__))
FileUtils.mkdir_p("#{ROOT}/app/config")
db_config = if ENV["DB"] == "pg"
  { "adapter" => "postgresql", "database" => "scb1_review", "host" => "/var/run/postgresql", "port" => 5432, "username" => "user", "pool" => 10 }
else
  { "adapter" => "sqlite3", "database" => "#{ROOT}/review.sqlite3", "pool" => 10, "timeout" => 5000 }
end
db_config["query_cache"] = false if ENV["CACHE_OFF"]
configs = { "primary" => db_config.merge("database" => "#{ROOT}/primary.sqlite3", "adapter" => "sqlite3").except("host", "port", "username"), "cable" => db_config }
configs["cable_two"] = db_config.merge("adapter" => "sqlite3", "database" => "#{ROOT}/two.sqlite3").except("host", "port", "username")
File.write("#{ROOT}/app/config/database.yml", { Rails.env => configs }.to_yaml)
class ReviewApp < Rails::Application
  config.root = "#{ROOT}/app"
  config.eager_load = false
  config.enable_reloading = true
  config.logger = ActiveSupport::Logger.new(IO::NULL)
  config.secret_key_base = "x" * 64
  config.action_cable.cable = { "adapter" => "solid_cable" }
  config.paths.add "config/database", with: "#{ROOT}/app/config/database.yml"
end
SolidCable.configure(polling_interval: "0.001.seconds", silence_polling: true, autotrim: false,
  connects_to: ENV["SHARED_POOL"] ? {} : { shards: { default: { writing: :cable }, second: { writing: :cable_two } } })
Rails.application.initialize!
ActiveRecord::Base.logger = ActiveSupport::Logger.new(IO::NULL)
ActiveRecord::Schema.verbose = false
[ActiveRecord::Base, SolidCable::Record].each do |record|
  record.connection_pool.with_connection do |connection|
    connection.create_table :solid_cable_messages, force: true do |t|
      t.binary :channel, null: false
      t.binary :payload, null: false
      t.datetime :created_at, null: false
      t.integer :channel_hash, null: false, limit: 8
      t.index :channel_hash
    end
  end
end
SolidCable::Record.connected_to(shard: :second) do
  SolidCable::Record.connection_pool.with_connection do |connection|
    connection.create_table :solid_cable_messages, force: true do |t|
      t.binary :channel, null: false
      t.binary :payload, null: false
      t.datetime :created_at, null: false
      t.integer :channel_hash, null: false, limit: 8
    end
  end
end unless ENV["SHARED_POOL"]

def new_listener
  server = ActionCable::Server::Base.new
  adapter = ActionCable::SubscriptionAdapter::SolidCable.new(server)
  listener = ActionCable::SubscriptionAdapter::SolidCable.const_get(:Listener).new(adapter, Concurrent::ImmediateExecutor.new)
  listener.shutdown
  def listener.interruptible = yield
  def listener.sleep(_) = throw(:polled)
  listener
end

def one_poll(listener)
  catch(:polled) { listener.listen }
end
