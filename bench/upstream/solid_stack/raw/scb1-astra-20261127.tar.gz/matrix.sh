#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.10/bin:$PATH"
export BUNDLE_GEMFILE="$root/Gemfile"
exec 3>"$root/logs/matrix-commands.log"
export BASH_XTRACEFD=3
set -x
for version in 7.2.4 8.0.5.2 8.1.4.1 main; do
  export RAILS_VERSION="$version"
  for side in cable-base cable; do
    export CABLE="$side"
    bundle install > "$root/logs/bundle-$version-$side.log" 2>&1
    cp "$root/Gemfile.lock" "$root/logs/lock-$version-$side"
    ruby -rbundler/setup "$root/adversarial.rb" > "$root/logs/adversarial-$version-$side.log" 2>&1
    for probe in probe extended_probe reading_role; do
      ruby -rbundler/setup "$root/prior/$probe.rb" > "$root/logs/$probe-$version-$side.log" 2>&1
    done
    SHARED_POOL=1 ruby -rbundler/setup "$root/adversarial.rb" > "$root/logs/shared-$version-$side.log" 2>&1
    (cd "$root/$side"; bin/rails db:setup && bin/test) > "$root/logs/suite-$version-$side.log" 2>&1
  done
  for probe in adversarial probe extended_probe reading_role shared; do
    diff -u "$root/logs/$probe-$version-cable-base.log" "$root/logs/$probe-$version-cable.log"
  done
  echo "$version passed"
done
