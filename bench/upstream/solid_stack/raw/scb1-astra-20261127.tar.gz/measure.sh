#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
repo=$(git -C "$root" rev-parse --show-toplevel)
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.10/bin:$PATH"
export SCB1_REVIEW_ROOT="$root/measure-app" COUNTS=0,1,20
export UPSTREAM_BENCH_WARMUP=50
export RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000
export RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000
mkdir -p "$root/ir"
exec 3>"$root/ir/commands.log"
export BASH_XTRACEFD=3
set -x
for side in base candidate base2; do
  export BUNDLE_GEMFILE="$root/prior/Gemfile.base"
  [ "$side" != candidate ] || export BUNDLE_GEMFILE="$root/prior/Gemfile"
  for count in 0 1 20; do
    for n in 0 100; do
      stem="$root/ir/$side-$count-n$n"
      "$root/valgrind/bin/valgrind" --tool=callgrind --collect-atstart=no --toggle-collect=rb_ary_cycle \
        --callgrind-out-file="$stem.callgrind" --log-file="$stem.valgrind.log" \
        ruby -rbundler/setup "$repo/script/upstream-bench" --worker ir "$root/prior/sweep.rb" \
        "poll $count channels cache_off=false" "$n" > "$stem.log" 2>&1
    done
  done
done
