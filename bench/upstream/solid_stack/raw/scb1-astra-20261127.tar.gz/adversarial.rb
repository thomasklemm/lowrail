ENV["RAILS_ENV"] = "test"
require_relative "boot"
require "timeout"

def check(label)
  result = yield
  puts JSON.generate(case: label, result: result)
end

l = new_listener
received = []
l.add_subscriber("cards", ->(p) { received << p }, nil)
pool = SolidCable::Message.connection_pool
errors = [ActiveRecord::ConnectionFailed, ActiveRecord::ConnectionTimeoutError,
  ActiveRecord::ConnectionNotEstablished, ActiveRecord::StatementTimeout, RuntimeError,
  ActionCable::SubscriptionAdapter::SolidCable::Listener::Stop]
probe = Module.new do
  def broadcastable(...)
    raise Thread.current[:poll_error], "injected" if Thread.current[:poll_error]
    super
  end
end
SolidCable::Message.singleton_class.prepend(probe)
errors.each do |error|
  check("restoration #{error.name}") do
    pool.enable_query_cache!
    Thread.current[:poll_error] = error
    caught = nil
    begin
      one_poll(l)
    rescue Exception => e
      caught = [e.class.name, e.message]
    ensure
      Thread.current[:poll_error] = nil
    end
    raise "state leak" unless pool.query_cache_enabled
    [caught, pool.query_cache_enabled]
  end
end

check("nested uncached/cache including dirties false") do
  states = []
  Rails.application.executor.wrap do
    SolidCable::Message.uncached(dirties: false) do
      one_poll(l)
      states << [pool.query_cache_enabled, pool.dirties_query_cache]
      SolidCable::Message.cache do
        one_poll(l)
        states << [pool.query_cache_enabled, pool.dirties_query_cache]
      end
      states << [pool.query_cache_enabled, pool.dirties_query_cache]
    end
  end
  raise states.inspect unless states == [[false, false], [true, true], [false, false]]
  states
end

check("connection disconnect then reconnect") do
  SolidCable::Message.broadcast("cards", "reconnect")
  pool.with_connection(&:disconnect!)
  one_poll(l)
  raise received.inspect unless received == ["reconnect"]
  received.dup
end

check("reload with existing listener") do
  old = SolidCable::Message
  Rails.application.reloader.reload!
  raise "did not reload" if old.equal?(SolidCable::Message)
  SolidCable::Message.broadcast("cards", "reloaded")
  one_poll(l)
  raise received.inspect unless received == ["reconnect", "reloaded"]
  [old.equal?(SolidCable::Message), received.dup]
end

check("Message prepend delegation and listener public override") do
  count = 0
  mod = Module.new do
    define_method(:broadcastable) { |*args| count += 1; super(*args) }
  end
  SolidCable::Message.singleton_class.prepend(mod)
  l.singleton_class.prepend(Module.new { def listen = super })
  SolidCable::Message.broadcast("cards", "prepend")
  one_poll(l)
  raise unless count == 1 && received.last == "prepend"
  [count, received.last]
end

check("real listener retry and normal Stop") do
  SolidCable.configuration.instance_variable_set(:@reconnect_attempts, [0, 0])
  failures = Queue.new
  deliveries = Queue.new
  failures << ActiveRecord::ConnectionFailed
  failures << ActiveRecord::ConnectionNotEstablished
  observed = []
  mod = Module.new do
    define_method(:broadcastable) do |*args|
      if Thread.current.name == "solid_cable_listener" && !failures.empty?
        error = failures.pop
        observed << error.name
        raise error, "retry injection"
      end
      super(*args)
    end
  end
  SolidCable::Message.singleton_class.prepend(mod)
  server = ActionCable::Server::Base.new
  adapter = ActionCable::SubscriptionAdapter::SolidCable.new(server)
  real = ActionCable::SubscriptionAdapter::SolidCable::Listener.new(adapter, Concurrent::ImmediateExecutor.new)
  begin
    real.add_subscriber("real", ->(p) { deliveries << p }, nil)
    SolidCable::Message.broadcast("real", "after retries")
    delivered = Timeout.timeout(10) { deliveries.pop }
    raise unless delivered == "after retries" && observed.size == 2
  ensure
    Timeout.timeout(10) { real.shutdown }
  end
  [observed, delivered, real.send(:thread).alive?]
end
