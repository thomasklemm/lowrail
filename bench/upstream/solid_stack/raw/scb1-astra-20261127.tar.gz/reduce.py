from pathlib import Path
import re
root = Path(__file__).resolve().parent
for count in (0, 1, 20):
    values = {}
    for side in ("base", "candidate", "base2"):
        totals = []
        for n in (0, 100):
            text = (root / "ir" / f"{side}-{count}-n{n}.callgrind").read_text()
            totals.append(int(re.search(r"^totals: (\d+)", text, re.M)[1]))
            log = (root / "ir" / f"{side}-{count}-n{n}.valgrind.log").read_text()
            assert "brk segment overflow" not in log
        values[side] = (totals[1] - totals[0]) / 100
    mean = (values["base"] + values["base2"]) / 2
    print(count, values, "base_mean", mean, "change_pct", 100 * (values["candidate"] / mean - 1),
          "aa_pct", 100 * abs(values["base"] - values["base2"]) / mean)
for version in ("7.2.4", "8.0.5.2", "8.1.4.1", "main"):
    locks = [(root / "logs" / f"lock-{version}-{side}").read_text() for side in ("cable-base", "cable")]
    assert locks[0].replace("remote: cable-base", "remote: cable") == locks[1]
    print(version, "identical third-party dependencies")
