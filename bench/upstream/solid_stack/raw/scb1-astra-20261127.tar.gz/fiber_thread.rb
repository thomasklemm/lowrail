ENV["RAILS_ENV"] = "test"
require_relative "boot"
ActiveSupport::IsolatedExecutionState.isolation_level = :thread
pool = SolidCable::Message.connection_pool
l = new_listener
l.add_subscriber("fiber", ->(_) { Fiber.yield(:paused) }, nil)
SolidCable::Message.broadcast("fiber", "payload")
pool.enable_query_cache!
f = Fiber.new { one_poll(l); :finished }
raise unless f.resume == :paused
inside = pool.query_cache_enabled
other_thread = Thread.new do
  pool.enable_query_cache!
  pool.query_cache_enabled
end.value
raise unless f.resume == :finished && pool.query_cache_enabled && other_thread
puts JSON.generate(isolation: "thread", same_thread_suspended: inside,
  other_thread: other_thread, restored: pool.query_cache_enabled)
