# SCB1 Astra adversarial review, 2026-11-27

Thread T-01a21f04-5bbf-7387-a46e-465a02dd0598. Exact target and Ruby pins: logs/exact-pins.txt.
No fork push or upstream post. All fresh runtime runs used Ruby 4.0.10, interpreter, Linux x86_64.

Recreate `cable` at 2cb1842043643d85ddee68aa48d02fd219305d56 and `cable-base` at
40dd29ffdc4ff76f27f0bbef1de1606fdd21cfee. `rails-main` is Rails
2e299253f942ab94041cc6f210ac9d33884c210d. PR worktrees are named cable-pr91[-base] and
cable-pr96[-base], at the heads in logs/pr91.json and logs/pr96.json; apply logs/patch.diff
only to the worktrees without `-base`. These are review-only local combinations.

`prior` holds the reused probes and measurement Gemfiles; its solid_cable / solid_cable-base
paths should symlink to ../cable and ../cable-base. Those two locks have identical dependencies.
The other retained locks in logs are the exact bundles used for the suites and matrix.

* `matrix.sh`: both sides, Rails 7.2.4 / 8.0.5.2 / 8.1.4.1 / main, SQLite suites and
  adversarial/state/fiber/reader/shared-pool probes. matrix-commands.log has the commands.
* `adversarial.rb`: runs the actual poll, not a replacement, and compares restored cache state,
  injected connection errors/timeouts/Stop, nesting, disconnect/reconnect, class reloading,
  Message and listener prepends, and real listener thread retries and shutdown.
* `combinations.sh`: SQLite and PostgreSQL suites on base/head and both sides of each open PR.
  PostgreSQL is a disposable local server with role user and database scb1_review plus
  scb1_suite_* databases. The script sets DATABASE_URL correctly for each suite. Because its
  URL remained set before some subsequent probes, those probes were repeated by `reprobe.sh`
  with DATABASE_URL explicitly unset; use clean-*.log for probe evidence. All comparisons match.
* `fiber_thread.rb`: under thread isolation, a suspended callback's sibling fiber sees the
  deliberately disabled flag on head. A different thread stays enabled; resumption restores
  enabled. The prior extended probe tests fiber isolation instead and is identical base/head.
* Original differential: run `bench/upstream/solid_stack/sc1_differential.rb` from Lowrail with
  APP and SCB1_REVIEW_ROOT set to this directory's differential-app, DB=sqlite or pg, and
  BUNDLE_GEMFILE=prior/Gemfile.base or prior/Gemfile. Each original-*.log has ten JSON steps;
  each database's pair is byte-identical.
* `measure.sh`: fixed heaps, pinned patched Valgrind (ir/valgrind.json), upstream-bench's
  instruction worker, 50 warm-up polls, (N100 minus N0)/100, base/head/base2, zero/one/20
  channels. `reduce.py` checks raw totals, overflow absence and matrix dependency parity.
  ir/commands.log holds every measurement command. No timing claim is made from this orb.
* `audit_numbers.py` and `audit_wall.py` were reused from the earlier committed review archives
  and executed here. The former needs the original thermos archive extracted into `prior`
  for its historical boundary/replay checks. It independently recalculates body instructions,
  benchmark-ips and the YJIT wall cohort. The latter checks all 90 master-ZJIT wall processes,
  commands, pins, locks and JIT gates. Their fresh outputs are logs/audit-*.log. Ruby master
  and the timing cohorts were audited, not rerun here.
* logs/reach.jsonl: GitHub `repos/rails/rails`, `repos/rails/solid_cable`, `repos/ruby/ruby`,
  RubyGems `api/v1/gems/{rails,activerecord,solid_cable}.json`. Current upstream main, open PRs
  and exact commit message/diff are retained alongside them. No customer data or credentials.

Source inspection covered Listener#listen, broadcast_messages and its sole caller, Message's
scope, connection configuration, the uncached public API, per-context disable/restore and the
released/main executor hooks. No new comments or production complexity beyond the block.
Detailed verdict, claim audit, exactness boundaries and exclusions are in the Lowrail census record.
