require 'json'

mode, tree, output = ARGV
tree = File.expand_path(tree)
files = Dir.glob(File.join(tree, 'lib/**/*.rb')).sort
objects = {}

case mode
when 'rdoc'
  gem 'rdoc', ENV.fetch('RDOC_VERSION')
  require 'rdoc/rdoc'
  rdoc = RDoc::RDoc.new
  rdoc.document(['--quiet', '--dry-run', '--op', File.join(__dir__, 'dump-output')] + files)
  rdoc.store.all_classes_and_modules.each do |context|
    (context.method_list + context.attributes).each do |method|
      key = context.full_name + (method.singleton ? '.' : '#') + method.name
      objects[key] = {
        'kind' => method.class.name,
        'visibility' => method.visibility.to_s,
        'params' => method.respond_to?(:params) ? method.params : nil,
        'call_seq' => method.respond_to?(:call_seq) ? method.call_seq : nil,
        'rw' => method.respond_to?(:rw) ? method.rw : nil,
        'docstring' => method.comment.to_s,
      }
    end
  end
  version = RDoc::VERSION
when 'yard'
  gem 'yard', '0.9.46'
  require 'yard'
  YARD::Registry.clear
  YARD.parse(files)
  YARD::Registry.all.each do |object|
    item = {'kind' => object.type.to_s, 'docstring' => object.docstring.to_s}
    if object.is_a?(YARD::CodeObjects::MethodObject)
      item['visibility'] = object.visibility.to_s
      item['scope'] = object.scope.to_s
      item['parameters'] = object.parameters
    end
    item['tags'] = object.tags.map { |tag| [tag.tag_name, tag.name, tag.text, tag.types] }
    objects[object.path] = item
  end
  version = YARD::VERSION
else
  abort 'mode must be rdoc or yard'
end

File.write(output, JSON.pretty_generate({'tool' => mode, 'version' => version, 'ruby' => RUBY_VERSION, 'objects' => objects.sort.to_h}) + "\n")
puts "#{mode} #{version} Ruby #{RUBY_VERSION}: #{objects.length} entries -> #{output}"
