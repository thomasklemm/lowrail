import json
from pathlib import Path

root = Path(__file__).parent / "confirm-logs-3ca13466"
summary = []
for tool in ["yard", "rdoc-8.1.0", "rdoc-7.0.4", "rdoc-7.2.0"]:
    trees = ["base", "confirm-fc894812", "confirm-3ca13466"]
    datasets = [json.loads((root / f"{tool}-{tree}.json").read_text())["objects"] for tree in trees]
    base, previous, current = datasets
    summary.append(tool)
    for label, old in [("base", base), ("previous", previous)]:
        changes = {
            key: {"before": old.get(key), "after": current.get(key)}
            for key in sorted(old.keys() | current.keys())
            if old.get(key) != current.get(key)
        }
        (root / f"{tool}-vs-{label}.json").write_text(json.dumps(changes, indent=2) + "\n")
        summary.append(f"  versus {label}: {list(changes)}")
    members = sorted(key for key in current if key.startswith("Rack::Utils.") and "multipart_" in key)
    expected_count = 6 if tool == "yard" else 4
    assert len(members) == expected_count, members
    assert all(base[key] == previous[key] == current[key] for key in members)
    for name in ["multipart_file_limit", "multipart_total_part_limit"]:
        if tool != "yard":
            assert current["Rack::Utils." + name]["rw"] == "RW"
    summary.append(f"  PASS all six logical accessors/aliases unchanged ({len(members)} records)")
    keys = ["Rack::Utils.unescape", "Rack::Utils#unescape"] if tool == "yard" else ["Rack::Utils#unescape"]
    for key in keys:
        item = current[key]
        if tool == "yard":
            assert item["docstring"] == base[key]["docstring"]
            assert item["parameters"] == base[key]["parameters"]
            assert item["visibility"] == base[key]["visibility"]
        else:
            assert item["docstring"].strip() == base[key]["docstring"].strip()
            assert item["call_seq"].strip() == "unescape(s, encoding = Encoding::UTF_8)"
            assert item["visibility"] == "public"
    summary.append("  PASS Utils unescape prose/signature/visibility restored (RDoc outer whitespace ignored; raw diffs retained)")

text = "\n".join(summary) + "\n"
(root / "documentation-summary.txt").write_text(text)
print(text, end="")
