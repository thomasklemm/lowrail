require 'json'

ARGV.each { |entry| require entry }

def snapshot
  {
    features: $LOADED_FEATURES.map { |f| f.sub(%r{.*/(?:base|confirm-e3d53cfd)/lib/}, '<rack>/') },
    constants: Rack.constants(false).sort_by(&:to_s).map { |name| [name, Rack.autoload?(name)] },
    utils_loaded: Rack.const_defined?(:Utils, false) && !Rack.autoload?(:Utils),
    parser_loaded: Rack.const_defined?(:QueryParser, false) && !Rack.autoload?(:QueryParser),
  }
end

before_use = snapshot
require 'rack/query_parser'
require 'rack/utils'
parser = Rack::QueryParser.make_default(8)
decoded = Rack::Utils.unescape('a%2Bb+c')
result = {
  entries: ARGV,
  before_use: before_use,
  after_use: snapshot,
  decode: [decoded, decoded.encoding.name],
  parsed: parser.parse_nested_query('x[a]=%2B+b&z=c'),
  visibility: [Rack::Utils.respond_to?(:unescape), Rack::Utils.private_method_defined?(:unescape), Rack::QueryParser.private_method_defined?(:unescape)],
}
puts JSON.generate(result)
