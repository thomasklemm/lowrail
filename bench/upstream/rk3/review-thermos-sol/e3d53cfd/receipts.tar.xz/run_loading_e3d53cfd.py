import copy
import json
from pathlib import Path
import subprocess

root = Path(__file__).parent
out = root / "review-logs-e3d53cfd"
rubies = {
    "2.7.3": "/opt/hostedtoolcache/Ruby/2.7.3/x64/bin/ruby",
    "4.0.9": "/home/user/.local/share/mise/installs/ruby/4.0.9/bin/ruby",
}
cases = [[entry] for entry in ["rack", "rack/query_parser", "rack/utils", "rack/request", "rack/mock_request"]]
cases += [[a, b] for a, b in [
    ("rack", "rack/query_parser"), ("rack/query_parser", "rack"),
    ("rack", "rack/utils"), ("rack/utils", "rack"),
    ("rack/query_parser", "rack/utils"), ("rack/utils", "rack/query_parser"),
    ("rack/request", "rack/mock_request"), ("rack/mock_request", "rack/request"),
]]
summaries = []
for version, ruby in rubies.items():
    for mode in ["clean", "util"]:
        preload = ["-rcgi/util"] if mode == "util" else []
        for index, entries in enumerate(cases):
            pair = []
            for tree in ["base", "confirm-e3d53cfd"]:
                command = [ruby, *preload, "-I", str(root / tree / "lib"), str(root / "loading_e3d53cfd.rb"), *entries]
                process = subprocess.run(command, check=True, capture_output=True, text=True)
                item = json.loads(process.stdout)
                (out / f"loading-{version}-{mode}-{index}-{tree}.json").write_text(json.dumps(item, indent=2) + "\n")
                assert item["decode"] == ["a+b c", "UTF-8"]
                assert item["parsed"] == {"x": {"a": "+ b"}, "z": "c"}
                assert item["visibility"] == [True, True, True]
                pair.append(item)
            normalized = copy.deepcopy(pair[1])
            for phase in ["before_use", "after_use"]:
                normalized[phase]["features"] = [f for f in normalized[phase]["features"] if f != "<rack>/rack/unescape.rb"]
                normalized[phase]["constants"] = [c for c in normalized[phase]["constants"] if c[0] != "Unescape"]
            assert pair[0] == normalized, (version, mode, entries, pair)
        summaries.append(f"PASS {version} {mode}: {len(cases)} base/head require scenarios, ordered features/constants/lazy loading and call results match except new helper")
        for index, entries in enumerate([["rack/unescape"], ["rack", "rack/unescape"], ["rack/unescape", "rack"]]):
            command = [ruby, *preload, "-I", str(root / "confirm-e3d53cfd/lib"), str(root / "loading_e3d53cfd.rb"), *entries]
            item = json.loads(subprocess.run(command, check=True, capture_output=True, text=True).stdout)
            assert not item["before_use"]["utils_loaded"]
            assert not item["before_use"]["parser_loaded"]
            assert ["Unescape", None] in item["before_use"]["constants"]
            (out / f"loading-helper-{version}-{mode}-{index}.json").write_text(json.dumps(item, indent=2) + "\n")
        summaries.append(f"PASS {version} {mode}: 3 standalone helper require orders leave both consumers unloaded")

text = "\n".join(summaries) + "\n"
(out / "loading-summary.txt").write_text(text)
print(text, end="")
