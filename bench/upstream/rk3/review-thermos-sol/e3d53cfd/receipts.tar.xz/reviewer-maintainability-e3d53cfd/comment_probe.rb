require 'rdoc'
require 'rdoc/parser/ruby'
require 'rdoc/options'
require 'rdoc/stats'

path = File.join(ARGV.fetch(0), 'lib/rack/utils.rb')
source = File.readlines(path)[16...88].join + "\n  end\nend\n"
variants = {
  unchanged_fragment: source,
  without_first_double_sharp: source.sub("    ##\n", ''),
  without_method_directive: source.sub("    # :method: unescape\n", ''),
  without_final_double_sharp: source.sub("    ##\n    class << self\n", "    class << self\n")
}
variants.each do |label, input|
  options = RDoc::Options.new
  store = RDoc::Store.new(options)
  top_level = store.add_file('fragment.rb')
  stats = RDoc::Stats.new(store, 1, 0)
  RDoc::Parser::Ruby.new(top_level, input, options, stats).scan
  utils = store.find_class_or_module('Rack::Utils')
  p label => {
    methods: utils.method_list.select { |m| m.name == 'unescape' }.map { |m| [m.name, m.singleton, m.visibility, m.call_seq, m.comment.to_s] },
    attributes: utils.attributes.map { |a| [a.name, a.singleton, a.comment.to_s] }
  }
end
