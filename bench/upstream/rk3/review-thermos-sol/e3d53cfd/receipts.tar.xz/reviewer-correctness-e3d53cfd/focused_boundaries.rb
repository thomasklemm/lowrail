require 'rack/utils'

def check(name)
  raise "FAIL: #{name}" unless yield
  puts "PASS: #{name}"
end

parser = Rack::QueryParser.make_default(32)
mixed = Class.new { include Rack::Utils }.new
check('private visibility') do
  !parser.respond_to?(:unescape) && parser.respond_to?(:unescape, true) &&
    !mixed.respond_to?(:unescape) && mixed.respond_to?(:unescape, true) &&
    Rack::Utils.respond_to?(:unescape)
end
check('module functions following named module_function remain exported') do
  [:clock_time, :parse_query, :parse_nested_query, :parse_cookies_header,
   :secure_compare, :valid_path?].all? do |name|
    Rack::Utils.respond_to?(name) && Rack::Utils.private_instance_methods.include?(name)
  end
end

subclass = Class.new(Rack::QueryParser) do
  private

  def unescape(s, encoding = Encoding::UTF_8)
    'sub:' + super
  end
end
check('subclass override and super') do
  subclass.make_default(32).parse_query('a=b%2Bc') == {'sub:a' => 'sub:b+c'}
end

layer = Module.new do
  private

  def unescape(s, encoding = Encoding::UTF_8)
    'layer:' + super
  end
end
included = Class.new(Rack::QueryParser) { include layer }
prepended = Class.new(Rack::QueryParser) { prepend layer }
check('subclass included/prepended overrides and super') do
  [included, prepended].all? do |klass|
    klass.make_default(32).parse_query('a=b%2Bc') == {'layer:a' => 'layer:b+c'}
  end
end

mixed_override = Class.new do
  include Rack::Utils
  prepend layer
end.new
check('mixed-in Utils prepend and super') do
  mixed_override.send(:parse_cookies_header, 'a=b%2Bc') == {'a' => 'layer:b+c'}
end

check('inherited URI constant remains available through const_get') do
  Rack::QueryParser.const_get(:URI).equal?(::URI)
end
check('query decoding still avoids eager Utils calls') do
  parser.parse_query('a=b%2Bc') == {'a' => 'b+c'}
end

original = Rack::Utils.method(:unescape)
Rack::Utils.module_eval do
  private

  def unescape(s, encoding = Encoding::UTF_8)
    'replacement:' + s
  end
end
check('Utils singleton retains module_function snapshot after instance redefinition') do
  Rack::Utils.unescape('a%2Bb') == 'a+b' &&
    mixed.send(:unescape, 'a%2Bb') == 'replacement:a%2Bb' &&
    original.call('a%2Bb') == 'a+b' &&
    parser.parse_query('a=b%2Bc') == {'a' => 'b+c'}
end

puts RUBY_DESCRIPTION
