require 'rack/utils'

module OtherHelpers
  private

  def unescape(s, encoding = Encoding::UTF_8)
    "other:" + super
  end
end

Rack::QueryParser.include OtherHelpers
p parser_after_include: Rack::QueryParser.make_default(32).parse_query('a=b')

class CustomParser < Rack::QueryParser
  private

  def unescape(s, encoding = Encoding::UTF_8)
    'custom:' + super
  end
end

class WithUtils < CustomParser
  include Rack::Utils
end

p mixed_in_cookies: WithUtils.make_default(32).send(:parse_cookies_header, 'token=a%2Bb')

if ENV['LOCAL_COPY_FIX']
  implementation = Rack::Unescape.instance_method(:unescape)
  Rack::QueryParser.send(:define_method, :unescape, implementation)
  Rack::QueryParser.send(:private, :unescape)
  Rack::Utils.send(:define_method, :unescape, implementation)
  Rack::Utils.send(:module_function, :unescape)
  p fixed_parser: Rack::QueryParser.make_default(32).parse_query('a=b')
  p fixed_cookies: WithUtils.make_default(32).send(:parse_cookies_header, 'token=a%2Bb')
end
