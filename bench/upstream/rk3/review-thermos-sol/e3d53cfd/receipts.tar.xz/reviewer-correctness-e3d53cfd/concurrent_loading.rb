require 'thread'
require 'timeout'

mode = ARGV.fetch(0)
require 'rack' if mode == 'autoload'

helper_entered = Queue.new
parser_entered = Queue.new
utils_entered = Queue.new
release_helper = Queue.new
helper_blocked = false

trace = TracePoint.new(:line) do |event|
  if event.path.end_with?('/rack/unescape.rb') && event.lineno == 6 && !helper_blocked
    helper_blocked = true
    helper_entered << true
    release_helper.pop
  elsif event.path.end_with?('/rack/query_parser.rb') && event.lineno == 4
    parser_entered << true
  elsif event.path.end_with?('/rack/utils.rb') && event.lineno == 12
    utils_entered << true
  end
end

Timeout.timeout(10) do
  trace.enable
  helper = Thread.new { require 'rack/unescape' }
  helper_entered.pop

  parser = Thread.new do
    require 'rack/query_parser' if mode == 'require'
    Rack::QueryParser.make_default(32).parse_query('a=b%2Bc')
  end
  parser_entered.pop

  utils = Thread.new do
    require 'rack/utils' if mode == 'require'
    Rack::Utils.unescape('a%2Bb')
  end
  utils_entered.pop

  release_helper << true
  helper.value
  raise 'incorrect parser result' unless parser.value == {'a' => 'b+c'}
  raise 'incorrect Utils result' unless utils.value == 'a+b'
  trace.disable
end

puts "PASS: #{mode}: held helper definition while QueryParser and Utils entered their requires; both completed"
puts RUBY_DESCRIPTION
