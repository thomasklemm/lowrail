require 'json'
require 'rack/utils'

module OtherDecoder
  private

  def unescape(value, encoding = Encoding::UTF_8)
    CGI.unescape(value, encoding)
  end
end

def capture
  {result: yield}
rescue => error
  {error: error.class.name, message: error.message}
end

parser = Rack::QueryParser.make_default(32)
puts JSON.generate(phase: 'unmodified', output: capture { parser.parse_query('a=%zz') })
Rack::QueryParser.include OtherDecoder
puts JSON.generate(phase: 'replacement-private-decoder', output: capture { parser.parse_query('a=%zz') })
puts JSON.generate(phase: 'Utils-singleton-snapshot', output: capture { Rack::Utils.unescape('%zz') })
