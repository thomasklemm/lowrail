import json
from pathlib import Path

root = Path(__file__).parent / "review-logs-e3d53cfd"
summary = []
for tool in ["yard", "rdoc-8.1.0", "rdoc-7.2.0"]:
    def load(tree):
        return json.loads((root / f"{tool}-{tree}.json").read_text())["objects"]

    base, previous, current = map(load, ["base", "confirm-3ca13466", "confirm-e3d53cfd"])
    summary.append(tool)
    for label, old in [("base", base), ("previous", previous)]:
        changes = {
            key: {"before": old.get(key), "after": current.get(key)}
            for key in sorted(old.keys() | current.keys())
            if old.get(key) != current.get(key)
        }
        (root / f"{tool}-vs-{label}.json").write_text(json.dumps(changes, indent=2) + "\n")
        summary.append(f"  versus {label}: {list(changes)}")
    utils = {key: value for key, value in current.items() if key.startswith(("Rack::Utils.", "Rack::Utils#"))}
    assert utils == {key: value for key, value in previous.items() if key.startswith(("Rack::Utils.", "Rack::Utils#"))}
    summary.append("  PASS every exported Utils method/attribute record unchanged from previous head")
    members = sorted(key for key in current if key.startswith("Rack::Utils.") and "multipart_" in key)
    assert len(members) == (6 if tool == "yard" else 4)
    assert all(base[key] == previous[key] == current[key] for key in members)
    summary.append("  PASS multipart attributes and aliases unchanged from parent")
    keys = ["Rack::Utils.unescape", "Rack::Utils#unescape"] if tool == "yard" else ["Rack::Utils#unescape"]
    for key in keys:
        item = current[key]
        if tool == "yard":
            assert item["docstring"] == base[key]["docstring"]
            assert item["parameters"] == base[key]["parameters"]
            assert item["visibility"] == base[key]["visibility"]
        else:
            assert item["docstring"].strip() == base[key]["docstring"].strip()
            assert item["call_seq"].strip() == "unescape(s, encoding = Encoding::UTF_8)"
            assert item["visibility"] == "public"
    summary.append("  PASS unescape signature/prose/visibility restored (RDoc outer whitespace ignored, raw diff kept)")

text = "\n".join(summary) + "\n"
(root / "documentation-summary.txt").write_text(text)
print(text, end="")
