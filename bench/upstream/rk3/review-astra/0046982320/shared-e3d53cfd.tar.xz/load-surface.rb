require 'json'

ENTRIES = ['rack', 'rack/query_parser', 'rack/utils', 'rack/request', 'rack/mock_request']
abort 'URI preloaded by harness' if defined?(URI)

def result
  yield
rescue Exception => error
  [error.class.name, error.message.sub(/\n\n.*\z/m, '').gsub(/0x\h+/, '0xADDRESS')]
end

def isolated(label)
  STDOUT.flush
  pid = fork do
    puts JSON.generate([label, result { yield }])
  end
  Process.wait(pid)
  abort "child failed: #{label}" unless $?.success?
end

def snapshot
  {
    'files' => $LOADED_FEATURES.map { |f| f.sub($LOAD_PATH.first, 'RACK_LIB') },
    'autoloads' => [:Utils, :QueryParser, :Unescape].map { |name| Rack.autoload?(name) },
    'defined' => [:Utils, :QueryParser].map { |name| Rack.const_defined?(name, false) }
  }
end

def ordinary_calls
  values = [Rack::Utils.unescape('a+b%2Bc'), Rack::Utils.escape('*~ +'),
            Rack::QueryParser.make_default(32).parse_query('a+b=c%2Bd')]
  raise "wrong results: #{values.inspect}" unless values == ['a b+c', '*%7E+%2B', {'a b' => 'c+d'}]
  values
end

if ARGV[0] == 'common' || ARGV[0] == 'six'
  entries = ENTRIES.dup
  entries << 'rack/unescape' if ARGV[0] == 'six'
  entries.permutation.each do |order|
    isolated(order) do
      steps = order.map do |entry|
        require entry
        [entry, snapshot]
      end
      [steps, ordinary_calls]
    end
  end
  exit
end

isolated('standalone unescape') do
  require 'rack/unescape'
  before = snapshot
  raise 'eager Utils or QueryParser' if Rack.const_defined?(:Utils, false) || Rack.const_defined?(:QueryParser, false)
  object = Class.new { include Rack::Unescape }.new
  decoded = object.send(:unescape, 'a+b%2Bc')
  malformed = result { object.send(:unescape, '%') }
  require 'rack'
  after = snapshot
  [before, decoded, malformed, object.respond_to?(:unescape), after]
end

isolated('rack alone') do
  require 'rack'
  [snapshot, result { Rack::Unescape }]
end

['integer', 'class', 'module', 'frozen module'].each do |kind|
  isolated("constant collision #{kind}") do
    rack = Module.new
    Object.const_set(:Rack, rack)
    value = case kind
            when 'integer' then 17
            when 'class' then Class.new
            when 'module' then Module.new { def unescape(*); 'prior'; end }
            when 'frozen module' then Module.new.freeze
            end
    rack.const_set(:Unescape, value)
    require 'rack/utils'
    ordinary_calls
  end
end

isolated('preexisting module callback') do
  Object.const_set(:Rack, Module.new)
  Rack.const_set(:Unescape, Module.new)
  Rack::Unescape.instance_variable_set(:@included, [])
  Rack::Unescape.singleton_class.class_eval do
    def included(base)
      @included << base.name
    end
  end
  require 'rack/utils'
  [ordinary_calls, Rack::Unescape.instance_variable_get(:@included)]
end

isolated('reopen before consumers') do
  require 'rack/unescape'
  Rack::Unescape.module_eval { private; def unescape(*); 'before'; end }
  require 'rack/utils'
  [Rack::Utils.unescape('x'), Rack::Utils.default_query_parser.send(:unescape, 'x'),
   Object.new.extend(Rack::Utils).send(:unescape, 'x')]
end

isolated('reopen after consumers') do
  require 'rack/utils'
  Rack::Unescape.module_eval { private; def unescape(*); 'after'; end }
  [Rack::Utils.unescape('x'), Rack::Utils.default_query_parser.send(:unescape, 'x'),
   Object.new.extend(Rack::Utils).send(:unescape, 'x')]
end

isolated('concurrent requires') do
  threads = ['rack/query_parser', 'rack/utils', 'rack/request', 'rack/unescape'].map do |entry|
    Thread.new { require entry }
  end
  threads.each(&:value)
  ordinary_calls
end

if defined?(Ractor)
  isolated('standalone helper in ractor') do
    require 'rack/unescape'
    worker = Ractor.new do
      object = Class.new { include Rack::Unescape }.new
      [object.send(:unescape, 'a+b%2Bc'), Rack.autoload?(:Utils), Rack.const_defined?(:QueryParser, false)]
    end
    worker.respond_to?(:value) ? worker.value : worker.take
  end
end
