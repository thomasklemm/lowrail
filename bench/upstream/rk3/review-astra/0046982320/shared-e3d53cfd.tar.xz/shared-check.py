import collections
import copy
import hashlib
import json
import pathlib
import re
import subprocess

root = pathlib.Path(__file__).parent
out = root / 'shared-results'
versions = ['2.7.3', '3.0.7', '3.1.7', '3.2.9', '3.3.9', '3.4.6', '4.0.9']

def rows(path):
    return list(map(json.loads, path.read_text().splitlines()))

def normalize(value):
    if isinstance(value, list):
        if len(value) == 5 and value[0] == 'String':
            if bytes(value[1]) == b'Rack::QueryParser::Unescape':
                value = copy.deepcopy(value)
                value[1] = list(b'Rack::Unescape')
            return value
        return [normalize(v) for v in value if not (
            isinstance(v, list) and len(v) == 5 and v[0] == 'String'
            and bytes(v[1]) == b'RACK_LIB/rack/unescape.rb')]
    return value

hashes = {}
for version in versions:
    old = dict(rows(root / 'results' / f'rack-{version}-adversarial.jsonl'))
    new = dict(rows(out / f'{version}-adversarial.jsonl'))
    assert {k: normalize(v) for k, v in old.items()} == {k: normalize(v) for k, v in new.items()}
    print(version, 'independent probes: only owner name and added file changed from 0046982320')
    if version != '2.7.3':
        assert new['ractor'] == old['ractor'] and new['ractor'][0] == 'ok'
    source = root / 'results' / f'rack-{version}-clean-replay.txt'
    target = out / f'{version}-replay.txt'
    before = source.read_text().splitlines()
    after = target.read_text().splitlines()
    base = (root / 'results' / f'base-{version}-clean-replay.txt').read_text().splitlines()
    assert len(before) == len(after) == len(base) == 204073
    for label, control in [('0046982320', before), ('e26338b40a', base)]:
        counts = collections.Counter()
        for a, b in zip(control, after):
            if a == b:
                continue
            if re.sub('0x[0-9a-f]+', '0xADDRESS', a) == re.sub('0x[0-9a-f]+', '0xADDRESS', b):
                counts['object address noise'] += 1
            elif version == '3.1.7' and 'BasicObject' in a and 'NoMethodError' in a:
                assert a.split('\\n\\n')[0] == b.split('\\n\\n')[0]
                counts['error_highlight source excerpt'] += 1
            elif label == 'e26338b40a' and a.startswith('probe QueryParser parameters'):
                assert a.replace('string', 's') == b
                counts['parameter name'] += 1
            elif label == 'e26338b40a' and ':err' in a:
                assert re.sub(r', "(?:BINARY|ASCII-8BIT)"\]$', ', "UTF-8"]', a) == b
                counts['message encoding'] += 1
            else:
                raise AssertionError((version, label, a, b))
        print(version, label, 'to e3d53cfd replay:', dict(counts))
    diff = subprocess.run(['diff', '-u', str(source), str(target)], capture_output=True)
    assert diff.returncode == 1
    (out / f'{version}-replay.diff').write_bytes(diff.stdout)
    hashes[version] = {'source': str(source.relative_to(root)), 'target': target.name,
                       'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                       'target_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
    special = dict(rows(out / f'{version}-special.jsonl'))
    assert special['constant collision integer'][0] == special['constant collision class'][0] == 'TypeError'
    assert special['constant collision frozen module'][0] == 'FrozenError'
    expected = ['a b+c', '*%7E+%2B', {'a b': 'c+d'}]
    assert special['constant collision module'] == special['concurrent requires'] == expected
    assert special['preexisting module callback'] == [expected, ['Rack::QueryParser', 'Rack::Utils']]
    assert special['reopen before consumers'] == ['before'] * 3
    assert special['reopen after consumers'] == ['x', 'after', 'after']
    if version != '2.7.3':
        assert special['standalone helper in ractor'] == ['a b+c', None, False]
    print(version, 'constant/reopening/thread/standalone helper scenarios verified')

for version in ['2.7.3', '4.0.9']:
    old, new = [rows(out / f'{tree}-{version}-common.jsonl') for tree in ['base', 'shared']]
    assert len(old) == len(new) == 120
    for row in new:
        for entry, state in row[1][0]:
            state['files'] = [f for f in state['files'] if f != 'RACK_LIB/rack/unescape.rb']
    assert old == new
    six = rows(out / f'shared-{version}-six.jsonl')
    assert len(six) == 720
    for order, data in six:
        assert data[1] == expected, order
        previous = {'autoloads': [None, None, None], 'defined': [False, False]}
        for entry, state in data[0]:
            if entry == 'rack/unescape':
                assert state['autoloads'] == previous['autoloads'] and state['defined'] == previous['defined'], order
            previous = state
    base_special = dict(rows(out / f'base-{version}-special.jsonl'))
    for kind in ['integer', 'class', 'module', 'frozen module']:
        assert base_special[f'constant collision {kind}'] == expected
    print(version, '120 common orders equal step-by-step except new file; 720 orders pass without eager consumers')

def doc(path):
    text = path.read_text()
    return json.loads(text[text.index('{'):])

for engine in ['yard', 'rdoc-7.0.4', 'rdoc-7.2.0', 'rdoc-8.1.0']:
    version = '0.9.46' if engine == 'yard' else engine.split('-', 1)[1]
    a = doc(root / 'confirm-results' / f'confirmed-{engine}.json')
    b = doc(out / f'docs-{engine.split("-")[0]}-{version}.json')
    changed = [k for k in sorted(a.keys() | b.keys()) if a.get(k) != b.get(k)]
    if engine == 'yard':
        assert changed == ['Rack::QueryParser::Unescape', 'Rack::QueryParser::Unescape#unescape', 'Rack::Unescape', 'Rack::Unescape#unescape']
        for key in ['Rack::Utils.unescape', 'Rack::Utils#unescape']:
            assert a[key] == b[key]
    else:
        assert changed == []
    print(engine, 'documentation changes versus 3ca13466:', changed)

(out / 'replay-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
