require 'json'
engine, version, lib = ARGV
if engine == 'yard'
  gem 'yard', version
  require 'yard'
  YARD.parse(File.join(lib, '**/*.rb'))
  records = YARD::Registry.all.map do |object|
    data = {'kind' => object.type, 'doc' => object.docstring.to_s}
    data['parameters'] = object.parameters if object.respond_to?(:parameters)
    data['visibility'] = object.visibility if object.respond_to?(:visibility)
    [object.path, data]
  end.to_h
else
  gem 'rdoc', version
  require 'rdoc/rdoc'
  doc = RDoc::RDoc.new
  doc.document(['--quiet', '--dry-run', lib])
  records = {}
  doc.store.all_classes_and_modules.each do |mod|
    comment = mod.comment
    records[mod.full_name] = {'kind' => mod.type, 'doc' => comment.respond_to?(:text) ? comment.text : comment.to_s, 'document_self' => mod.document_self}
    mod.method_list.each do |method|
      path = mod.full_name + (method.singleton ? '.' : '#') + method.name
      comment = method.comment
      records[path] = {'kind' => 'method', 'doc' => comment.respond_to?(:text) ? comment.text : comment.to_s, 'parameters' => method.params,
                      'call_seq' => method.call_seq, 'visibility' => method.visibility, 'document_self' => method.document_self}
    end
  end
end
puts JSON.pretty_generate(records.sort.to_h)
