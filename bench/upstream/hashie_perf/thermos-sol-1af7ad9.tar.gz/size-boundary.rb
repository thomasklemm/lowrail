# frozen_string_literal: true

require 'hashie'
require 'digest'

[0, 16, 1_048_576].each do |length|
  stem = 'x' * length
  { absent: stem, early: "?#{stem}x", late: "#{stem}?" }.each do |position, text|
    [text.to_sym, text.dup, text.dup.freeze].each do |name|
      parts = Hashie::Mash.new.send(:_method_name_and_suffix, name)
      result = parts.map { |part| part && [part.bytesize, part.frozen?, part.encoding.name, Digest::SHA256.hexdigest(part)] }
      puts [length, position, name.class, name.frozen?, result].inspect
    end
  end
end
