# frozen_string_literal: true

require 'hashie'
require 'logger'
require 'stringio'

log = StringIO.new
Hashie.logger = Logger.new(log)
Hashie.logger.formatter = ->(_severity, _time, _prog, message) { "#{message}\n" }

INITIALIZATIONS = []

class InitializedMash < Hashie::Mash
  def initialize(*args, &block)
    INITIALIZATIONS << object_id
    super
  end
end

original = InitializedMash.new(key: 'value')
INITIALIZATIONS.clear
log.truncate(0)
log.rewind
copy = original.dup
puts "dup initialization count: #{INITIALIZATIONS.length}"
puts "dup warning count: #{log.string.lines.count}"

class OverridingMash < Hashie::Mash
  include Hashie::Extensions::MethodAccessWithOverride
end

copy = OverridingMash.new(size: :stored_value).dup
puts "dup conflicting reader: #{copy.size.inspect}"

class RestMash < Hashie::Mash
  def method_missing(method_name, *args, &block)
    super
  end
end

args = [1, 2, 3]
mash = RestMash.new
puts "reader extra arguments: #{mash.MISSING(*args).inspect}"
puts "writer extra arguments: #{mash.send(:NAME=, *args).inspect}; stored #{mash.NAME.inspect}"

class FixedArity
  def method_missing(_name, first = nil, &block)
    first
  end
end

class AnonymousRest
  def method_missing(_name, first = nil, *, &block)
    first
  end
end

[FixedArity, AnonymousRest].each do |klass|
  begin
    puts "#{klass}: #{klass.new.missing(*args).inspect}"
  rescue ArgumentError => error
    puts "#{klass}: #{error.class}: #{error.message}"
  end
end
