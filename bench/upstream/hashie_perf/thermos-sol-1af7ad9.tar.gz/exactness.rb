# frozen_string_literal: true

require 'hashie'
require 'json'
require 'logger'
require 'stringio'

if ENV['HM2_FIX'] == '1'
  class Hashie::Mash
    private

    def _method_name_and_suffix(method_name)
      name = method_name.is_a?(Symbol) ? method_name.name : method_name.to_s
      if name.end_with?(*ALLOWED_SUFFIXES)
        [name[0..-2], name[-1]]
      else
        [method_name.is_a?(Symbol) ? method_name.to_s : name, nil]
      end
    end
  end
end

TRACE = []
ROOT_FIBER = Fiber.current
LOG = StringIO.new
Hashie.logger = Logger.new(LOG)
Hashie.logger.formatter = ->(_severity, _time, _prog, message) { "#{message}\n" }

class NameString < String
  def to_s
    TRACE << :string_to_s
    super
  end
end

class DuckName
  def initialize(text, frozen_result = false)
    @text = text
    @frozen_result = frozen_result
  end

  def to_s
    TRACE << :duck_to_s
    @frozen_result ? @text.dup.freeze : @text.dup
  end
end

class PrivateName < DuckName
  private :to_s
end

class SubHash < Hash
  def each(&block)
    TRACE << :hash_each
    super
  end

  def to_hash
    TRACE << :to_hash
    self
  end
end

class SubArray < Array
  def to_ary
    TRACE << :to_ary
    self
  end

  def to_a
    TRACE << :to_a
    super
  end
end

def snapshot(value)
  case value
  when Hash
    ['hash', value.frozen?, value.map { |key, item| [snapshot(key), snapshot(item)] }]
  when Array
    ['array', value.frozen?, value.map { |item| snapshot(item) }]
  when String
    [value.class.name, value, value.frozen?, value.encoding.name]
  when Symbol, Numeric, TrueClass, FalseClass, NilClass
    [value.class.name, value.inspect]
  else
    [value.class.name]
  end
end

def outcome
  snapshot(yield)
rescue StandardError => error
  ['error', error.class.name, error.message.gsub(/0x\h+/, 'ADDRESS')]
end

variants = {
  'Mash' => -> { Class.new(Hashie::Mash) },
  'DefineAccessors' => -> { Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::DefineAccessors } },
  'StrictKeyAccess' => -> { Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::StrictKeyAccess } },
  'KeepOriginalKeys' => -> { Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::KeepOriginalKeys } },
  'SymbolizeKeys' => -> { Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::SymbolizeKeys } },
  'prepended_dispatch' => -> do
    Class.new(Hashie::Mash).tap do |klass|
      klass.prepend(Module.new do
        def method_missing(name, *args, &block)
          TRACE << :prepended_dispatch
          super
        end

        def respond_to_missing?(name, include_private = false)
          TRACE << :prepended_respond
          super
        end
      end)
    end
  end,
  'singleton_dispatch' => -> { Class.new(Hashie::Mash) },
  'extend_accessors' => -> { Class.new(Hashie::Mash) }
}

[:StrictKeyAccess, :DefineAccessors].each do |extension|
  [false, true].each do |transform_first|
    ['read', 'mutate', 'fiber'].each do |transform|
      variants["#{extension}/TransformKeys/#{transform_first}/#{transform}"] = lambda do
        Class.new(Hashie::Mash).tap do |klass|
          modules = [Hashie::Extensions::Mash::TransformKeys, Hashie::Extensions::Mash.const_get(extension)]
          modules.reverse! unless transform_first
          modules.each { |mod| klass.include(mod) }
          klass.transform_keys_with do |name|
            TRACE << [:transform, name.frozen?] if transform != 'read'
            Fiber.yield(:transforming) if transform == 'fiber' && Fiber.current != ROOT_FIBER
            if transform == 'read'
              name.downcase
            else
              name.downcase!
              name
            end
          end
        end
      end
    end
  end
end

names = ['', 'NAME', 'NAME?', 'NAME!', 'NAME_', 'NAME=', 'missing', 'private?', 'ÜNÏCODE', '名前=', 'a??', '?', '=', 'x' * 8192 + '?']
forms = {
  'symbol' => ->(text) { text.to_sym },
  'string' => ->(text) { text.dup },
  'frozen_string' => ->(text) { text.dup.freeze },
  'subclass' => ->(text) { NameString.new(text) },
  'frozen_subclass' => ->(text) { NameString.new(text).freeze },
  'singleton_to_s' => ->(text) { text.dup.tap { |name| name.define_singleton_method(:to_s) { TRACE << :singleton_to_s; super() } } },
  'frozen_conversion' => ->(text) { DuckName.new(text, true) },
  'conversion' => ->(text) { DuckName.new(text) },
  'private_conversion' => ->(text) { PrivateName.new(text) }
}

variants.each do |label, factory|
  [false, true].each do |freeze_mash|
    names.each_with_index do |text, name_index|
      forms.each do |form, make_name|
        TRACE.clear
        LOG.truncate(0)
        LOG.rewind
        klass = factory.call
        mash = klass.new
        if label == 'extend_accessors'
          mash.extend(Hashie::Extensions::Mash::DefineAccessors)
        elsif label == 'singleton_dispatch'
          mash.singleton_class.prepend(Module.new do
            def method_missing(name, *args, &block)
              TRACE << :singleton_dispatch
              super
            end
          end)
          mash.define_singleton_method(:secret) { :private_value }
          mash.singleton_class.send(:private, :secret)
        end
        unless label.include?('/mutate') || label.include?('/fiber')
          mash[NameString.new('frozen_key').freeze] = SubHash['inside' => 3].freeze
          mash[:items] = SubArray[1, { 'nested' => true }].freeze
          mash[:NAME] = false if name_index.even?
        end
        mash.freeze if freeze_mash
        name = make_name.call(text)
        args = text.end_with?('=') ? [:first] : []
        results = 2.times.map do
          outcome do
            if label.include?('/fiber')
              fiber = Fiber.new { mash.send(:method_missing, name, *args) }
              result = fiber.resume
              while fiber.alive?
                TRACE << result
                result = fiber.resume
              end
              result
            else
              mash.send(:method_missing, name, *args) { |value| TRACE << [:block, snapshot(value)] }
            end
          end
        end
        response = outcome { [mash.respond_to?(name), mash.respond_to?(name, true)] }
        # Callback traces record the newly frozen input without making it the result assertion.
        trace = TRACE.map { |entry| entry.is_a?(Array) && entry.first == :transform ? entry.first : entry }
        puts JSON.generate([label, freeze_mash, name_index, form, results, response, snapshot(mash), snapshot(name), trace, LOG.string.gsub(/0x\h+/, 'ADDRESS')])
      end
    end
  end
end
