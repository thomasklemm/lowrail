# frozen_string_literal: true

require 'hashie'

accessors = Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::DefineAccessors }
mash = accessors.new
mash.default_proc = proc { |hash, key| hash[key.upcase!] = 7 }
begin
  puts "default proc: #{mash.missing.inspect}"
rescue StandardError => error
  puts "default proc: #{error.class}: #{error.message}"
end

[:StrictKeyAccess, :DefineAccessors].each do |extension|
  klass = Class.new(Hashie::Mash) do
    include Hashie::Extensions::Mash::TransformKeys
    include Hashie::Extensions::Mash.const_get(extension)
    transform_keys_with { |name| name.downcase!; name }
  end
  begin
    puts "mutating transformer/#{extension}: #{klass.new.MISSING.inspect}"
  rescue StandardError => error
    puts "mutating transformer/#{extension}: #{error.class}: #{error.message}"
  end
end

klass = Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::StrictKeyAccess }
name = String.new('MISSING')
calls = 0
name.define_singleton_method(:to_s) do
  calls += 1
  ['lookup', 'expected', 'changed'].fetch(calls - 1, 'changed')
end
begin
  klass.new.method_missing(name)
rescue StandardError => error
  puts "String conversion: #{error.class}: #{error.message}; calls=#{calls}"
end
