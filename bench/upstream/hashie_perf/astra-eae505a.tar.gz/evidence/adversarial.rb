# frozen_string_literal: true
require 'hashie'
require 'json'
require 'logger'
Hashie.logger = Logger.new(nil)

def capture
  value = yield
  [value, value.frozen?]
rescue StandardError => e
  [e.class.name, e.message.gsub(/0x[0-9a-f]+/, 'ADDRESS').gsub(%r{/[^ ]*/lib/}, 'lib/')]
end

module ForwardMissing
  def method_missing(name, *args, &block)
    super(name, *args, &block)
  end
end

class StringName < String
  attr_reader :calls
  def to_s
    (@calls ||= []) << 'to_s'
    super
  end
end

class DuckName
  attr_reader :calls
  def initialize
    @calls = []
  end
  def to_s
    @calls << 'to_s'
    'fresh='
  end
end

extensions = Hashie::Extensions::Mash.constants.sort.filter_map do |name|
  mod = Hashie::Extensions::Mash.const_get(name)
  [name, mod] if mod.is_a?(Module)
end
factories = [['Mash', -> { Class.new(Hashie::Mash) }]]
extensions.each do |name, mod|
  factories << [name, -> { Class.new(Hashie::Mash) { include mod } }]
end
factories << ['MethodAccessWithOverride', -> { Class.new(Hashie::Mash) { include Hashie::Extensions::MethodAccessWithOverride } }]
%i[StrictKeyAccess KeepOriginalKeys SymbolizeKeys].each do |name|
  mod = Hashie::Extensions::Mash.const_get(name)
  factories << ["DefineAccessors+#{name}", -> { Class.new(Hashie::Mash) { include mod; include Hashie::Extensions::Mash::DefineAccessors } }]
end

names = ['', 'fresh', 'fresh?', 'fresh!', 'fresh_', 'fresh=', 'ready?', 'ready?=', '名前?', 'é_', "a\x00?", "\xFF?".b, '?', '=', '[]', 'private?', 'send=', 'default=', 'existing'].flat_map { |s| [s, s.dup.freeze, s.to_sym, StringName.new(s)] }
names += [nil, 42, true, DuckName.new]
factories.each do |label, factory|
  [false, true].each do |prepend|
    [false, true].each do |freeze_mash|
      names.each_with_index do |name, index|
        klass = factory.call
        klass.prepend(ForwardMissing) if prepend
        klass.class_eval { def method_missing(name, *args, &block); super; end } unless prepend
        klass.required_keys(:existing) if label == :RequiredKeys
        mash = klass.new('existing'.freeze => 'payload'.dup, :symbol_key => 3)
        mash.regular_writer('ready?'.freeze, false)
        mash.freeze if freeze_mash
        results = 2.times.map { capture { mash.__send__(:method_missing, name, 'value', 2, a: 3) { |v| v } } }
        response = capture { mash.respond_to?(name) }
        keys = mash.keys.map { |k| [k.inspect, k.class.name, k.frozen?] }
        puts [label, prepend, freeze_mash, index, results, response, keys].inspect.gsub(/0x[0-9a-f]+/, 'ADDRESS')
      end
    end
  end
end

puts 'BOUNDARIES'
[:plain, :plain?, 'plain', 'plain?'].each do |name|
  puts [name.inspect, capture { key, = Hashie::Mash.new.send(:_method_name_and_suffix, name); key << 'x' }].inspect
end
name = String.new('fresh=')
def name.is_a?(klass)
  raise 'is_a? intercepted'
end
keeping = Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::KeepOriginalKeys }.new
puts ['direct String with singleton is_a?', capture { keeping.send(:method_missing, name, 7) }].inspect
puts ['duck conversion calls', capture { obj = DuckName.new; Hashie::Mash.new.send(:method_missing, obj, 7); obj.calls }].inspect
