# frozen_string_literal: true
require 'hashie'
require 'logger'
Hashie.logger = Logger.new(nil)
plain = Hashie::Mash.new('exact?' => 'stored')
strict_class = Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::StrictKeyAccess }
strict = strict_class.new
UpstreamBench.report('stored suffix') { plain.exact? }
UpstreamBench.report('ordinary missing suffix') { plain.other? }
UpstreamBench.report('strict missing suffix') { strict.other? }
