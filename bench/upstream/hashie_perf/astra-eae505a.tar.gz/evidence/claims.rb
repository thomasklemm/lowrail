# frozen_string_literal: true
require 'hashie'
require 'json'
require 'objspace'
require 'logger'
require 'stringio'
Hashie.logger = Logger.new(nil)
src = JSON.parse(File.read(ARGV.fetch(0)))
src_without_conflicts = Marshal.load(Marshal.dump(src))
src_without_conflicts['licenses'].each { |entry| entry['license_key'] = entry.delete('key') }

def allocations
  2000.times { yield }
  GC.start
  GC.disable
  results = [1000, 2000].map do |n|
    objects = GC.stat(:total_allocated_objects)
    strings = ObjectSpace.count_objects[:T_STRING]
    n.times { yield }
    [GC.stat(:total_allocated_objects) - objects, ObjectSpace.count_objects[:T_STRING] - strings]
  end
  GC.enable
  results.last.zip(results.first).map { |a, b| (a - b) / 1000.0 }
end

puts RUBY_DESCRIPTION
puts "new objects/strings #{allocations { Hashie::Mash.new(src) }.inspect}"
puts "without key conflict objects/strings #{allocations { Hashie::Mash.new(src_without_conflicts) }.inspect}"
class Forwarder
  def method_missing(name, ...) = 1
end
puts "forwarder extra args #{Forwarder.new.foo(1, 2, x: 3)}"
stream = StringIO.new
Hashie.logger = Logger.new(stream)
Hashie.logger.formatter = ->(_, _, _, msg) { msg + "\n" }
mash = Hashie::Mash.new(src)
stream.truncate(0)
stream.rewind
mash.dup
puts "dup warning count #{stream.string.lines.size}"
