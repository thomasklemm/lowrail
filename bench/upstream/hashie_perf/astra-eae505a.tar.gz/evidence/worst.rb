# frozen_string_literal: true
require 'hashie'
require 'logger'
Hashie.logger = Logger.new(nil)
ENV.fetch('SIZES', '1,16,1048576').split(',').map(&:to_i).each do |size|
  ['a' * size, '?' + 'a' * (size - 1), 'a' * (size - 1) + '?'].uniq.each_with_index do |text, placement|
    [text.to_sym, text.freeze].each do |name|
      mash = Hashie::Mash.new
      UpstreamBench.report("#{size}-#{placement}-#{name.class}") { mash.send(:method_missing, name) }
    end
  end
end
