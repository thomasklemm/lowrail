# frozen_string_literal: true
require 'json'
dir = __dir__
names = %w[1-1-Symbol 1-1-String 16-0-Symbol 16-0-String 1048576-2-Symbol 1048576-2-String]
rows = names.map do |name|
  counts = %w[base base2 hashie revised].to_h do |run|
    values = [0, 100].map do |n|
      prefix = "#{dir}/ir-#{name}-#{run}-#{n}"
      raise "brk overflow #{prefix}" if File.read("#{prefix}.valgrind").match?(/brk segment overflow|Cannot map memory to grow brk segment/)
      Integer(File.read("#{prefix}.callgrind").scan(/^totals: (\d+)/).last.fetch(0))
    end
    [run, (values[1] - values[0]) / 100.0]
  end
  mean = (counts['base'] + counts['base2']) / 2
  counts.merge('case' => name, 'aa_percent' => (counts['base2'] / counts['base'] - 1) * 100,
               'old_change_percent' => (counts['hashie'] / mean - 1) * 100,
               'revised_change_percent' => (counts['revised'] / mean - 1) * 100)
end
puts JSON.pretty_generate(rows)
