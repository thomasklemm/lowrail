# frozen_string_literal: true
require 'hashie'
require 'logger'
Hashie.logger = Logger.new(nil)
class AccessorMash < Hashie::Mash
  include Hashie::Extensions::Mash::DefineAccessors
end
2.times do |i|
  mash = AccessorMash.new
  mash.default_proc = proc { |hash, key| hash[key.upcase!] = 7 }
  begin
    puts [i, mash.missing, mash.to_hash].inspect
  rescue StandardError => e
    puts [i, e.class, e.message].inspect
  end
end
