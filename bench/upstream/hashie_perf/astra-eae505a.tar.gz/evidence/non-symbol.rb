# frozen_string_literal: true
require 'hashie'
class CountingName < String
  attr_reader :conversions
  def to_s
    @conversions = (@conversions || 0) + 1
    raise 'second conversion' if @conversions > 1
    super
  end
end
klass = Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::KeepOriginalKeys }
name = CountingName.new('missing')
begin
  puts [klass.new.send(:method_missing, name), name.conversions].inspect
rescue StandardError => e
  puts [e.class, e.message, name.conversions].inspect
end
