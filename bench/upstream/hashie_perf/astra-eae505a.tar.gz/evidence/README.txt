HM2 Astra review, 2026-11-27
Thread T-01a21ea6-c103-7055-b928-054d2f8d8df1
Base 9e313f308f3270995c2c978e92f0f216b861861b
Original d1f403e0774a7ad509ae06477407dbc2836491fd (hashie directory)
Revised eae505a846f162e743b65261a7cda01d32e84f85 (revised directory)
fix-prototype is the reviewer's alternative repair, not the published revised head.
dup-prototype is master plus probes/c2-dup-copy.patch already kept in Lowrail.

Rubies: mise Ruby 4.0.9 for the original 8,528-line differential;
mise Ruby 4.0.10 a704b7cd95 for all new counts, targeted suites and adversarial probes.
Only interpreter Callgrind, no new wall measurements. No Ruby-master execution here.

Execution from the Lowrail root:
  bash .amp/in/orb-backup/hm2-astra/evidence/measure.sh
  bash .amp/in/orb-backup/hm2-astra/evidence/revised-measure.sh
  ruby .amp/in/orb-backup/hm2-astra/evidence/summarize.rb
Those scripts use script/upstream-bench workers (snapshot included), two master runs,
N=100 minus N=0, GC off for instruction windows, and the heap variables in the scripts.
Pinned tool built with script/bench-valgrind; valgrind.json is its manifest.
The preceding system-Valgrind run was rejected for brk overflow; retained separately.
No measured output was discarded to select a favorable result.

For each checkout: ruby -I CHECKOUT/lib evidence/adversarial.rb
For each checkout: ruby -I CHECKOUT/lib evidence/default-proc.rb
For each checkout: ruby -I CHECKOUT/lib evidence/non-symbol.rb
For each checkout: ruby -I CHECKOUT/lib c1_diff-current.rb
The c1 outputs normalize only Logger's W, [timestamp PID] prefix to WARN:.
The adversarial probe normalizes object addresses and checkout path prefixes in errors.
Run specs from each checkout:
  ruby -Ilib -S rspec spec/hashie/mash_spec.rb spec/hashie/extensions/mash spec/hashie/extensions/method_access_spec.rb --format progress
Run metrics from Lowrail root:
  flog -a CHECKOUT/lib/hashie/mash.rb
  rubocop --config evidence/metrics.yml --only Metrics --format json CHECKOUT/lib/hashie/mash.rb
Zero metric thresholds expose counts; they are not production lint settings.

suffix-alloc-aa.log is probes/alloc_probe.rb on base, original head, base, each interpreter
then YJIT; it includes Hashie::Mash.new in the new-key benchmark unlike Duel.
claims-* is an independent fixture-with/without-conflicts count, repeated base, plus
argument-forwarding and duplicate-warning checks. dup-claims.log uses the dup prototype.

External data fetched with gh api repos/{hashie/hashie,sferik/duel-ruby,ruby/ruby},
gh api repos/ruby/ruby/releases/latest, and RubyGems v1 gems/{hashie,duel}.json and
versions/hashie.json. Also opened Hashie comment 7226612359 and pull 656 via gh api.
Raw Duel runs remain in bench/upstream/hashie_perf/duel/logs.tar.gz (not duplicated).
