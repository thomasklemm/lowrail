# frozen_string_literal: true

require 'hashie'
class ForwardedMash < Hashie::Mash
  def method_missing(name, *args, &block); super; end
end
class DotsMash < Hashie::Mash
  def method_missing(...); super; end
end
EMPTY = [].freeze
mash = Hashie::Mash.new(name: 47)
forwarded = ForwardedMash.new(name: 47)
dots = DotsMash.new(name: 47)
def count(call)
  10_000.times { call.call }
  GC.start
  GC.disable
  GC.stat(:total_allocated_objects)
  before = GC.stat(:total_allocated_objects)
  10_000.times { call.call }
  value = (GC.stat(:total_allocated_objects) - before) / 10_000.0
  GC.enable
  value
end
puts RUBY_DESCRIPTION
{
  'direct read' => -> { mash.name },
  'empty splat read' => -> { mash.name(*EMPTY) },
  'super named rest read' => -> { forwarded.name },
  'super dots read' => -> { dots.name },
  'read with one' => -> { mash.name(13) },
  'setter' => -> { mash.name = 47 }
}.each { |name, call| puts "#{name}: #{count(call)}" }
