# frozen_string_literal: true

require 'json'
root = File.expand_path(__dir__)
Dir[File.join(root, 'evidence', '*-base.jsonl')].sort.each do |base|
  head = base.sub(/-base\.jsonl\z/, '-head.jsonl')
  next unless File.exist?(head)
  differences = 0
  count = 0
  first = []
  File.open(head) do |right|
    File.foreach(base) do |left|
      other = right.gets
      count += 1
      normalize = ->(s) { s&.gsub(%r{#{Regexp.escape(root)}/(?:base|head)/lib/}, 'CHECKOUT/lib/').gsub(/0x[0-9a-f]+/, '0xADDR') }
      next if normalize.call(left) == normalize.call(other)
      differences += 1
      first << [JSON.parse(left)[0, 7], other && JSON.parse(other)[0, 7]] if first.length < 3
    end
    abort "extra head rows in #{head}" if right.gets
  end
  puts "#{File.basename(base, '-base.jsonl')}: #{count} rows; #{differences} semantic differences; #{first.inspect}"
end
