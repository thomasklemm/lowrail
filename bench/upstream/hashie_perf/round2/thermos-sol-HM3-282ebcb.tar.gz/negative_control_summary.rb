require 'json'

root = File.expand_path(__dir__)
base = File.open(File.join(root, 'evidence/4.0.10-interp-base.jsonl'))
rows = 0
differences = 0
File.foreach(File.join(root, 'evidence/fixed-arity-control.jsonl')) do |line|
  expected = JSON.parse(base.gets)
  actual = JSON.parse(line)
  rows += 1
  differences += 1 if expected != actual
end
puts "Fixed-arity negative control: #{differences} changed rows among #{rows} completed rows."
puts 'The control then raises ArgumentError in the first unrescued fiber scenario; it did not complete that scenario.'
