require 'json'

results_path, raw_dir = ARGV
data = JSON.parse(File.read(results_path))
logs = {}
checks = 0
data.fetch('wall').each do |name, measurement|
  measurement.fetch('rounds').each_with_index do |round, i|
    round.each do |side, windows|
      path = File.join(raw_dir, "wall-r#{i + 1}-#{side}.log")
      parsed = logs[path] ||= File.readlines(path).filter_map do |line|
        match = line.chomp.match(/\A(wall|jit) (.+)\t(.*)\z/)
        [match[1..2], match[3]] if match
      end.to_h
      raise "window mismatch: #{name}, #{path}" unless JSON.parse(parsed.fetch(['wall', name])) == windows
      counters = parsed.fetch(['jit', name]).split.to_h do |part|
        key, values = part.split('=')
        [key, values.split('>').map { |v| Integer(v) }]
      end
      expected = measurement.fetch('jit').fetch('windows').find { |w| w.fetch('window') == "r#{i + 1} #{side}" }
      raise "JIT mismatch: #{name}, #{path}" unless counters == expected.fetch('counters')
      checks += 1
    end
  end
  puts "#{name}: #{measurement.values_at('change', 'change_ci', 'aa', 'aa_ci', 'aa_pass', 'claim').inspect}"
end
puts "#{checks} case/process window arrays and JIT summaries match the archived raw logs"
