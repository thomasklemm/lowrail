# HM3 thermos-sol review commands

Reviewed base: 9e313f308f3270995c2c978e92f0f216b861861b.
Reviewed head: 282ebcbb8248ae3ef379bc7254ad69fd0422d7b4.
Reviewer orb: T-01a21f08-d041-7016-b829-aa1e0ed68eaf, 2026-11-27.
Both Thermos rubrics were applied directly in this thread, without delegation, as requested.

The worktrees and Ruby build are not in this archive. Scripts were run from
`.amp/in/orb-backup/thermos-sol-HM3`; recreate `base`, `head`, and `reverted`
worktrees at the pins above to rerun them. The `reverted` worktree is head with
`restore-named-rest.patch` applied. Review findings and claim audit are in the
adjacent Lowrail round2 README; this file records how the evidence was made.

## Independent compatibility probe

`bash run_diff.sh` runs `public_diff.rb` separately against each library on
3.0.7; 3.1.7, 3.2.10, 3.3.10, 3.4.7 and 4.0.10 (interpreter/YJIT);
master 0d399335b733776187e43a783e5f950c18ad881c (interpreter/YJIT/ZJIT).
The installed release Rubies are under `~/.local/share/mise/installs/ruby`.
Master was built locally with YJIT and ZJIT; its pin and build output are kept.

`ruby compare.rb` compares the raw JSON lines, normalizing only checkout paths
and object addresses. It also compares `edge_diff.rb` outputs (54 cases per
release, and master/ZJIT). Separate fresh Ruby processes checked loading
`hashie/mash` before `hashie`; those outputs are `load-order-*`.

`ruby -I base/lib keyword_repro.rb` and `ruby -I head/lib keyword_repro.rb`,
with the corresponding version/JIT switches, produce `keyword-repro-all.txt`.
The same command against `reverted/lib` produces `reverted-repro.txt`.

`ruby -I TREE/lib allocations.rb` was run base/head/base on all 14
configurations. `allocations-all.txt` is the complete output. This uses
GC.stat total_allocated_objects, not elapsed time; direct read has one equal
instrumentation allocation per process (0.0001 per iteration).

`ruby -I head/lib -r ./fixed_arity.rb public_diff.rb` is a deliberately wrong
negative control: it raises after 197600 completed rows at the first fiber
case. `negative_control_summary.rb` counts that completed prefix only. The
two changed examples separately run with and without that control; their
outputs are `added-specs.txt` and `added-specs-control.txt`.

## Suites and metrics

On Ruby 4.0.10, `bundle exec rake spec` in base, head and reverted;
`bundle exec rake docs:examples` and `bundle exec rake rubocop` in head;
`bundle exec rake rubocop` in reverted. Outputs have descriptive file names.

`flog -ad TREE/lib/hashie/mash.rb` on base/head, flog 4.10.0.
`rubocop --config metrics.yml --format json TREE/lib/hashie/mash.rb` on
base/head, RuboCop 1.91.0. Limits of zero expose the numbers; metric-only
offenses are expected and are not the project's lint result.

## Timing and historical data audit

The new diagnostic cohort was run with Ruby 4.0.10 driving:

    ruby script/upstream-bench --out "$R/evidence/worst-master-zjit" \
      --base "$R/base" --candidate "$R/head" \
      --ruby "$R/ruby-master/bin/ruby" --modes '' --wall 30 \
      --wall-mode zjit --wall-windows 5 --wall-ms 10 --warmup 10000 \
      --core 4 "$R/perf_body.rb"

`worst-master-zjit/commands.sh` contains every generated worker command,
with raw process outputs and results.json next to it. This is an 8-CPU orb,
not the required a1.xxlarge publication host: these numbers diagnose worst
call shapes, not approved upstream timing claims. `screen-master-zjit.txt`
is a noisy exploratory screen, not a claimed cohort.

`historical-wall-audit.txt` checks the existing four-case cohort's arrays
against all 90 extracted worker logs (360 case/process arrays), including
both A/A and change intervals and JIT-flat flags. Those original logs were
extracted under `historical-wall/raw`. The original run was also on 8 CPUs.
`audit_wall.rb RESULTS_JSON RAW_DIR` repeats the array and JIT-summary checks
for both cohorts. Wall-worker `0>0` lines summarize zero absolute counter
deltas across measured windows, not a claim that the VM compiled no code.

## Claim-source audit

`git show --format=fuller HEAD`, base..head diff, lib/spec/benchmarks/.duel.rb
tree hashes for base/head and Duel workflow commits; `gh api` for run
46067769275, the workflow tree/config and Duel implementation, and reply
issuecomment-7227673119. API responses and extracted Duel logs are kept.
The hashes in `duel-blobs.txt` are in that four-path order.

Calibration-8 A/A/negative-control logs are copied from the existing
hashie_duel archive. They are distinct from HM3's actual Duel run.

Ruby's anonymous-rest optimization commit is
43683e1e9d8f7f6ed3fb4a48598190a0993f8f66; git merge-base verified it is
an ancestor of tag v4.0.0 (the first lookup used the wrong underscore tag
spelling, returned 404, and was corrected). The master VM argument setup
excerpt and optimization diff are retained, not inferred from timings.

After the independent audit, the fork PR 27 discussion/reviews were read
and an upstream candidate PR was searched for. No feedback findings were
imported. There were no upstream writes, fork pushes or PR openings.
