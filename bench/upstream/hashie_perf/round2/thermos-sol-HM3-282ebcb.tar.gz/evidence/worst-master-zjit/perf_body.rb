# frozen_string_literal: true

$LOAD_PATH.unshift File.join(ENV.fetch('UPSTREAM_BENCH_TREE'), 'lib')
require 'hashie'
Hashie.logger = Object.new.tap { |o| o.define_singleton_method(:warn) { |_| } }
mash = Hashie::Mash.new(name: 'Ada', active: false, nested: {id: 19})
ary = [1, 2, 3, 4, 5].freeze
empty = [].freeze
UpstreamBench.report('read zero') { mash.name }
UpstreamBench.report('read empty splat') { mash.name(*empty) }
UpstreamBench.report('read nil') { mash.name(nil) }
UpstreamBench.report('read one') { mash.name(1) }
UpstreamBench.report('read two') { mash.name(1, 2) }
UpstreamBench.report('read five') { mash.name(1, 2, 3, 4, 5) }
UpstreamBench.report('read splat five') { mash.name(*ary) }
UpstreamBench.report('read keyword') { mash.name(a: 1) }
UpstreamBench.report('predicate one') { mash.active?(1) }
UpstreamBench.report('setter one') { mash.name = 'Grace' }
UpstreamBench.report('setter two') { mash.public_send(:name=, 'Grace', 29) }
class SuperMash < Hashie::Mash
  def method_missing(name, *args, &block); super; end
end
subclass = SuperMash.new(name: 'Ada')
UpstreamBench.report('super read zero') { subclass.name }
UpstreamBench.report('super read one') { subclass.name(1) }
class DotsSuperMash < Hashie::Mash
  def method_missing(...); super; end
end
dots = DotsSuperMash.new(name: 'Ada')
UpstreamBench.report('dots super read zero') { dots.name }
