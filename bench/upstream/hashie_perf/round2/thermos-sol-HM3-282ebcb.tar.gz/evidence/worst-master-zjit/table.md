Time per call, Ruby 4.1.0dev, ZJIT, 30 rounds of fresh processes on one core

| | Before | After | Change |
| --- | ---: | ---: | ---: |
| `read zero` | 0.13 µs | 0.12 µs | −7.3% |
| `read empty splat` | 0.15 µs | 0.16 µs | +5.9% |
| `read nil` | 0.14 µs | 0.15 µs | +5.8% |
| `read one` | 0.14 µs | 0.15 µs | +5.8% |
| `read two` | 0.14 µs | 0.15 µs | +5.8% |
| `read five` | 0.15 µs | 0.16 µs | +4.8% |
| `read splat five` | 0.16 µs | 0.17 µs | +5.3% |
| `read keyword` | 0.19 µs | 0.20 µs | +5.4% |
| `predicate one` | 0.31 µs | 0.32 µs | +3.3% |
| `setter one` | 0.59 µs | 0.60 µs | +1.7% |
| `setter two` | 0.61 µs | 0.62 µs | +2.0% |
| `super read zero` | 0.21 µs | 0.22 µs | +2.7% |
| `super read one` | 0.22 µs | 0.23 µs | +4.1% |
| `dots super read zero` | 0.27 µs | 0.26 µs | −4.2% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/thermos-sol-HM3/evidence/worst-master-zjit.
- JIT-flat: compiled_iseq_count, failed_iseq_count, compiled_side_exit_count, invalidation_time_ns unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- Wall: thread CPU time with GC off per window, the 10th-percentile window per process; change = median of every round's candidate / base and candidate / base2, A/A = median of base2 / base, 95% bootstrap intervals resampling rounds
- base: ruby 4.1.0dev (2026-11-27T16:40:23Z HEAD 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/thermos-sol-HM3/base at 9e313f308f
- candidate: ruby 4.1.0dev (2026-11-27T16:40:23Z HEAD 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/thermos-sol-HM3/head at 282ebcbb82
- wall read zero: −7.3% [−7.8%, −7.1%] with A/A +0.0% [−0.4%, +0.4%] (71415 calls × 5 windows per process), JIT-flat in 90 processes
- wall read empty splat: +5.9% [+5.6%, +6.2%] with A/A +0.1% [−0.5%, +0.5%] (64940 calls × 5 windows per process), JIT-flat in 90 processes
- wall read nil: +5.8% [+5.5%, +6.3%] with A/A +0.2% [−0.2%, +0.8%] (64464 calls × 5 windows per process), JIT-flat in 90 processes
- wall read one: +5.8% [+5.5%, +6.2%] with A/A +0.1% [−0.2%, +0.7%] (67671 calls × 5 windows per process), JIT-flat in 90 processes
- wall read two: +5.8% [+5.3%, +6.3%] with A/A +0.1% [−0.2%, +0.6%] (69339 calls × 5 windows per process), JIT-flat in 90 processes
- wall read five: +4.8% [+4.1%, +5.3%] with A/A +0.2% [−0.5%, +1.0%] (64168 calls × 5 windows per process), JIT-flat in 90 processes
- wall read splat five: +5.3% [+4.6%, +6.1%] with A/A +0.3% [−0.4%, +1.7%] (62299 calls × 5 windows per process), JIT-flat in 90 processes
- wall read keyword: +5.4% [+5.0%, +6.1%] with A/A +0.0% [−0.6%, +0.5%] (50573 calls × 5 windows per process), JIT-flat in 90 processes
- wall predicate one: +3.3% [+2.8%, +3.7%] with A/A +0.1% [−0.4%, +0.7%] (30767 calls × 5 windows per process), JIT-flat in 90 processes
- wall setter one: +1.7% [+1.1%, +2.0%] with A/A −0.0% [−0.3%, +0.5%] (16505 calls × 5 windows per process), JIT-flat in 90 processes
- wall setter two: +2.0% [+1.5%, +2.2%] with A/A +0.4% [−0.2%, +2.0%] (15718 calls × 5 windows per process), JIT-flat in 90 processes
- wall super read zero: +2.7% [+2.3%, +3.0%] with A/A +0.3% [−0.4%, +1.2%] (45643 calls × 5 windows per process), JIT-flat in 90 processes
- wall super read one: +4.1% [+3.6%, +4.6%] with A/A +0.2% [−0.2%, +0.9%] (44469 calls × 5 windows per process), JIT-flat in 90 processes
- wall dots super read zero: −4.2% [−4.8%, −3.8%] with A/A +0.6% [−0.2%, +1.2%] (35268 calls × 5 windows per process), JIT-flat in 90 processes
