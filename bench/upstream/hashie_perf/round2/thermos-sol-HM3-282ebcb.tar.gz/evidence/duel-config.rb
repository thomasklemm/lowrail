# frozen_string_literal: true

module Duel
  # What Duel knows about a project. Most of it follows from conventions,
  # so most projects need no configuration at all:
  #
  # - benchmarks are in files named *_duel.rb in duel/ (see
  #   Duel::DSL#duel)
  # - the library is the gem the project's .gemspec names, required from
  #   each version's lib/ (so benchmarks needn't require it)
  # - a project with ext/ is built with `bundle exec rake compile` when
  #   a baseline is checked out
  # - a change is compared with where it left the branch origin/HEAD
  #   points to (origin/main, say), when lib/ or ext/ changed, or what
  #   decides how they're measured (see #watch)
  # - releases are tagged v*
  #
  # .duel.rb, at the root, changes what doesn't fit:
  #
  #   Duel.configure do |c|
  #     c.benchmarks = "perf/**/*_duel.rb"
  #     c.build = "make"
  #     c.use :redis                        # a plugin: see #use
  #     c.metric MyMetric                   # see Duel::Metric
  #   end
  #
  # The file is the candidate's, and every worker loads it too: the
  # baseline's worker runs the candidate's benchmarks and plugins against
  # the baseline's code.
  class Config
    # Where the project is (and its config file).
    attr_reader :root

    # Where Duel keeps what it keeps for the project, tmp/duel: the lock
    # that keeps two runs from sharing it (see Lock), what prepare blocks
    # build once (Resource#cached), in cache/, and the baseline's checkout
    # where it can't go next to the repository (see Baseline#checkout), in
    # base/. A run removes the lock when it ends, and what that leaves
    # empty. `duel clean` removes the rest.
    def state = File.join(root, "tmp", "duel")

    # Where what a resource builds once is kept (see Resource#cached):
    # tmp/duel/cache.
    # @api private
    def cache = File.join(state, "cache")

    # A glob, from the root, of the files defining benchmarks, or a list
    # of them:
    #
    #   c.benchmarks = %w[perf/**/*_duel.rb test/perf/**/*_duel.rb]
    attr_reader :benchmarks

    def benchmarks=(globs)
      @benchmarks = Config.given(:benchmarks, globs, "a glob, or a list of them") { Config.strings?(globs) }
    end

    # A path, from the root, of the code whose changes a comparison is
    # about, or a list of them: when none of them changed since the
    # baseline, nor what decides how it's measured (the benchmarks'
    # directory, the configuration's file, and with each version on its
    # own Ruby, the version files at the root), there's nothing to
    # compare.
    attr_reader :watch

    def watch=(paths)
      @watch = Config.given(:watch, paths, "a path, or a list of them") { Config.strings?(paths, empty: true) }
    end

    # How each version loads: the library to require from it, as
    # `require` takes it (with its lib/ first on the load path), nil for
    # none (benchmarks require what they need), or a lambda that loads the
    # version from the root of its tree, which it's given, instead (see
    # #load_into):
    #
    #   c.library = "my_gem"
    #   c.library = ->(root) { require File.join(root, "config", "boot") }
    def library=(library)
      @library = Config.given(:library, library, "a library's name, a lambda (->(root) { ... }), or nil") do
        library.nil? || library.instance_of?(String) || library.is_a?(Proc)
      end
    end

    # A shell command that builds a checked-out tree, run in it, or nil
    # for none.
    def build=(command)
      @build = Config.given(:build, command, "a shell command, or nil") { command.nil? || command.instance_of?(String) }
    end

    # The branch a comparison defaults to (nil: the one origin/HEAD names).
    attr_reader :main_branch

    def main_branch=(branch)
      @main_branch = Config.given(:main_branch, branch, "a branch (origin/main, say), or nil") { branch.nil? || branch.instance_of?(String) }
    end

    # The glob release tags match (for `--base last-release`), or a list
    # of them, any of which a tag may match (a gem that renamed its tags,
    # say):
    #
    #   c.release_tags = %w[v* my_gem-v*]
    attr_reader :release_tags

    def release_tags=(globs)
      @release_tags = Config.given(:release_tags, globs, "a glob, or a list of them") { Config.strings?(globs) }
    end

    # The Ruby each version runs on (`duel --ruby` overrides it). It's nil
    # for the runner's own, or :version_file for the one the version's own
    # version file names (.ruby-version, .tool-versions or mise.toml, in
    # its tree or above), installed with rbenv, chruby, mise or asdf (see
    # Rubies). It can also be a path to a Ruby for both, or a block given
    # the version's tree, returning the path to its Ruby.
    #
    #   c.ruby = :version_file
    #   c.ruby = ->(root) { File.join(Dir.home, ".rubies", File.read(File.join(root, ".ruby-version")).strip, "bin", "ruby") }
    attr_reader :ruby

    def ruby=(ruby)
      @ruby = Config.given(:ruby, ruby, "a Ruby's path, :version_file, a lambda (->(root) { ... }), or nil") do
        ruby.nil? || ruby == :version_file || ruby.instance_of?(String) || ruby.is_a?(Proc)
      end
    end

    # When the workflow that `duel init` writes comments on a pull request
    # with the report:
    #
    # - :always, on every run
    # - :results, when a run passed or failed, but not with nothing
    #   compared
    # - :failures (the default), only when a run failed or couldn't
    #   compare
    # - :never
    #
    # It never edits a comment: each is a new one, so the pull request
    # keeps them all. Once it has commented, a run that it wouldn't
    # comment on still does, but :never's, when its status differs from
    # the last comment's, so the last comment is never stale: after a
    # failure, the first run that passes says so. A regression that
    # #accept_label accepts counts as a run that passed. Duel tells the
    # workflow which to do (see CLI.comment).
    #
    #   c.comment = :results
    attr_reader :comment

    # The values #comment takes.
    COMMENTS = %i[always results failures never].freeze #: Array[comment]

    def comment=(mode)
      @comment = Config.one_of(:comment, mode, COMMENTS)
    end

    # Which runs a regression fails:
    #
    # - :every_run (the default)
    # - :pull_requests, only a pull request's (or a merge queue's), and a
    #   run outside GitHub Actions. On GitHub Actions, a regression in
    #   any other run (a push, the schedule, run by hand) passes, with a
    #   warning, and the workflow that `duel init` writes comments on a
    #   pushed commit with the report, as #comment says, which notifies
    #   its author.
    #
    # A run that couldn't compare fails either way.
    #
    #   c.fail_on = :pull_requests
    attr_reader :fail_on

    # The values #fail_on takes.
    FAIL_ON = %i[every_run pull_requests].freeze #: Array[fail_on]

    def fail_on=(runs)
      @fail_on = Config.one_of(:fail_on, runs, FAIL_ON)
    end

    # The settings of a run that .duel.rb can set too, as the options of
    # their names do (--limit, --confidence, --jobs, --processes,
    # --timeout, --time-limit, --warm), and their variables (DUEL_LIMIT,
    # say): for a run given neither, as in CI, where the workflow runs Duel
    # with none. Each is nil, by default, for Duel's own default. For
    # each, what it takes, and whether a value is that: a number, as a
    # Float, but a number of jobs or processes, a whole one.
    # @api private
    RUN_SETTINGS = {
      limit: ["a ratio of 1 or more", ->(value) { value >= 1 }],
      confidence: ["a level above 0 and below 1", ->(value) { value.positive? && value < 1 }],
      jobs: ["a whole number, 1 or more", ->(value) { value.is_a?(Integer) && value.positive? }],
      processes: ["a whole number, 1 or more", ->(value) { value.is_a?(Integer) && value.positive? }],
      timeout: ["seconds, more than 0", ->(value) { value.positive? }],
      time_limit: ["seconds, more than 0", ->(value) { value.positive? }],
      warm: ["seconds, 0 or more", ->(value) { value >= 0 }]
    }.freeze #: Hash[Symbol, [String, ^(Numeric) -> bool]]

    # The ratio above which a timing is slower (--limit), for every
    # measure without a limit of its own (see #measure): 1.02 by default.
    #
    #   c.limit = 1.05
    attr_reader :limit

    def limit=(ratio)
      @limit = Config.setting(:limit, ratio)
    end

    # The confidence of every interval Duel judges with (--confidence):
    # 0.99 by default. A higher one fails less code that isn't slower, and
    # takes more samples, and workers, to fail what is: judging by process
    # (see Lane.by_process?) takes 5 workers of each version at 0.99, and
    # 7 at 0.999.
    #
    #   c.confidence = 0.995
    attr_reader :confidence

    def confidence=(level)
      @confidence = Config.setting(:confidence, level)
    end

    # The benchmarks measured at once (--jobs): by default, one for every
    # CPUS_PER_LANE CPUs, as many as fit in memory. One set is
    # that many, however much memory there is.
    #
    #   c.jobs = 2
    attr_reader :jobs

    def jobs=(count)
      @jobs = Config.setting(:jobs, count)
    end

    # The worker processes of each version (--processes): 12 by default (8
    # on JRuby and TruffleRuby), as many as fit in memory. One set is that
    # many, however much memory there is.
    #
    #   c.processes = 6
    attr_reader :processes

    def processes=(count)
      @processes = Config.setting(:processes, count)
    end

    # The most seconds a worker may take to load, or to answer a request,
    # before it's taken for hung (--timeout): 60 by default, 300 on JRuby
    # and TruffleRuby.
    #
    #   c.timeout = 120
    attr_reader :timeout

    def timeout=(seconds)
      @timeout = Config.setting(:timeout, seconds)
    end

    # The most seconds a run measures for, before it fails what it hasn't
    # measured, or what looks worse (--time-limit): 7200 by default.
    #
    #   c.time_limit = 3600
    attr_reader :time_limit

    def time_limit=(seconds)
      @time_limit = Config.setting(:time_limit, seconds)
    end

    # The seconds each benchmark warms up for, before it's measured
    # (--warm), or nil (the default) for until it's steady, for up to a
    # minute on JRuby and TruffleRuby, ten seconds with YJIT or ZJIT on,
    # and none otherwise.
    #
    #   c.warm = 10
    attr_reader :warm

    def warm=(seconds)
      @warm = Config.setting(:warm, seconds)
    end

    # +value+, set as the setting +name+d, if the block says it's one it
    # takes. One that isn't fails, saying to +give+ one that is, before
    # anything runs.
    # @api private
    def self.given(name, value, give)
      raise Error, "c.#{name} = #{value.inspect}: give #{give}" unless yield

      value
    end

    # Whether +value+ is a String, or a list of them (+empty+, or not).
    # @api private
    def self.strings?(value, empty: false)
      value.instance_of?(String) || (value.instance_of?(Array) && (empty || !value.empty?) && value.all? { |each| each.instance_of?(String) })
    end

    # +value+, set as the setting +name+d, if it's one of +values+, the
    # ones that takes. One that isn't fails, saying which to give.
    # @api private
    def self.one_of(name, value, values)
      raise Error, "c.#{name} = #{value.inspect}: give #{values.map(&:inspect).join(", ")}" unless values.include?(value)

      value
    end

    # +value+, set as the RUN_SETTINGS +name+d, as that takes it (a Float,
    # or an Integer), or nil. One that's neither fails, saying what to
    # give.
    # @api private
    def self.setting(name, value)
      return if value.nil?

      problem = problem(name, value)
      raise Error, "c.#{name} = #{value.inspect}: give #{problem}, or nil" if problem

      WHOLE.include?(name) ? value : Float(value)
    end

    # The RUN_SETTINGS that are whole numbers: the rest are Floats.
    # @api private
    WHOLE = %i[jobs processes].freeze

    # What to give instead of +value+ for the RUN_SETTINGS +name+d, or
    # nil if it's one that takes.
    # @api private
    def self.problem(name, value)
      what, valid = RUN_SETTINGS.fetch(name)
      what unless value.is_a?(Numeric) && valid.call(value)
    end

    # The RUN_SETTINGS .duel.rb set, by name.
    # @api private
    def run_settings = RUN_SETTINGS.to_h { |name| [name, public_send(name)] }.compact

    # The name of a label that accepts a regression in a pull request:
    # "duel: accept" by default, or nil for none. On GitHub Actions, the
    # workflow that `duel init` writes passes Duel the pull request's
    # labels (DUEL_LABELS), and with this one, a regression passes, with a
    # warning, and the report says it was accepted. For a push, it's the
    # labels of the pull request that merged it, so where #push_base is
    # :last_passed, the push is marked passed too. The labels are read
    # when the workflow runs, so the comment workflow runs the Duel job
    # again when the label is added or taken off. On a schedule, the
    # workflow compares with the last commit since the last release that
    # merged a pull request with the label (see Baseline#last_release).
    #
    #   c.accept_label = "duel: accept"
    attr_reader :accept_label

    def accept_label=(label)
      raise Error, "c.accept_label = #{label.inspect}: give a label's name, or nil" unless label.nil? || label.instance_of?(String)

      @accept_label = label
    end

    # What the workflow that `duel init` writes compares a push with:
    #
    # - :before (the default), the commit before the push
    # - :last_passed, the last commit Duel passed, which the workflow
    #   marks with a branch, duel/passed/main for main (see
    #   Baseline#passed_branch),
    #   when a push passes, or has nothing to compare. Slowdowns too
    #   small for any one push to fail then add up until they fail one,
    #   and a push the workflow didn't compare (its run cancelled, say)
    #   is compared with the next. After a regression, every push is
    #   compared with the commit before it, until one is no slower, or
    #   the branch is moved to accept the regression. Without the branch,
    #   or where HEAD doesn't have its commit (after a force push, say),
    #   a push is compared with the commit before it.
    #
    #   c.push_base = :last_passed
    attr_reader :push_base

    # The values #push_base takes.
    PUSH_BASES = %i[before last_passed].freeze #: Array[push_base]

    def push_base=(base)
      @push_base = Config.one_of(:push_base, base, PUSH_BASES)
    end

    # The metrics #metric added, in order (classes: a Duel::Metric
    # subclass, or running totals' Snapshot), for a plugin's tests to
    # look at (their .measures and .settings).
    attr_reader :metrics

    # What #prepare (by scope), #in_worker, the hooks (#setup, say: by
    # name) and #measure were given.
    # @api private
    attr_reader :prepares, :in_workers, :hooks, :measures

    # The memory that what the plugins used start for each worker takes at
    # most, as they say (see Duel.plugin), in bytes: 0 where none says.
    # @api private
    attr_reader :worker_memory

    # A configuration of the conventions, for the project at +root+ (a
    # plugin's tests make one to use it in).
    def initialize(root = Dir.pwd)
      @root = root
      @benchmarks = "duel/**/*_duel.rb"
      @watch = %w[lib ext]
      @library = :conventional
      @build = :conventional
      @release_tags = "v*"
      @comment = :failures
      @fail_on = :every_run
      @push_base = :before
      @accept_label = "duel: accept"
      @prepares = SCOPES.to_h { |scope| [scope, []] }
      @metrics = []
      @in_workers = []
      @hooks = HOOKS.to_h { |hook| [hook, []] }
      @used = {}
      @worker_memory = 0
      @measures = Hash.new do |all, name|
        all[name] = {} #: Hash[Symbol, untyped]
      end
    end

    # What #prepare prepares: each version, or each worker.
    # @api private
    SCOPES = %i[version worker].freeze

    # The library: the gem the project's only .gemspec names (see
    # #gem_library), unless set.
    def library
      case (given = @library)
      when :conventional then gem_library
      else given
      end
    end

    # The gem the project's only .gemspec names (its name's dashes are
    # directories: my-gem is my/gem), or nil.
    # @api private
    def gem_library
      specs = Dir[File.join(root, "*.gemspec")]
      return unless specs.size == 1

      name = File.basename(specs.first, ".gemspec")
      File.exist?(File.join(root, "lib", "#{name}.rb")) ? name : name.tr("-", "/")
    end

    # The build command: `bundle exec rake compile` for a project with
    # ext/ and a Rakefile, unless set.
    def build
      given = @build
      return given unless given == :conventional

      "bundle exec rake compile" if Dir.exist?(File.join(root, "ext")) && File.exist?(File.join(root, "Rakefile"))
    end

    # Loads the version at +version_root+: with a lambda for the library,
    # as that does, and otherwise, its lib/ goes first on the load path,
    # and the library is required from it. Under `bundle exec`, Bundler
    # has already loaded the candidate's gemspec, which may have required
    # files of the candidate's (its version, say): for another version
    # they're forgotten, and constants they defined are redefined quietly.
    # @api private
    def load_into(version_root)
      loaded = library
      return loaded.call(version_root) if loaded.is_a?(Proc)

      $LOAD_PATH.unshift(File.join(version_root, "lib"))
      return unless loaded
      return require(loaded) if File.expand_path(version_root) == File.expand_path(root)

      candidate_lib = File.join(File.expand_path(root), "lib", "")
      $LOADED_FEATURES.reject! { |feature| feature.start_with?(candidate_lib) }
      QuietRedefinition.during { require loaded }
    end

    # Uses a plugin, by its name: requires it (duel/+name+, the plugin's
    # gem's file: duel-redis's duel/redis, say), gives files of
    # benchmarks its DSL methods, if it has any, and configures Duel for
    # it, with +options+ (see Duel.plugin). Returns what that returned
    # (the plugin's own connection to its server, say).
    #
    #   c.use :redis
    #   c.use :rails, database: :postgresql
    #
    # A plugin is configured once, the first time it's used: using it
    # again (as a plugin that needs another uses it) returns what that
    # did. Options given again must be the first's, and others fail, as
    # they would be ignored.
    def use(name, **options)
      used = @used[name]
      return used.again(name, options) if used

      begin
        require "duel/#{name}"
      rescue LoadError => e
        raise unless e.path == "duel/#{name}"

        raise Error, "c.use #{name.inspect}: no duel/#{name} to require: add the duel-#{name} gem to the Gemfile"
      end
      plugin = Duel.plugins.fetch(name) { raise Error, "c.use #{name.inspect}: duel/#{name} registers no plugin #{name.inspect} (Duel.plugin)" }
      DSL.add(plugin::DSL) if plugin.const_defined?(:DSL, false)
      used = @used[name] = Used.new(options)
      used.value = plugin.configure(self, **options)
      @worker_memory += plugin.worker_memory if plugin.respond_to?(:worker_memory)
      used.value
    end

    # The most workers whose resources can run at once, as the plugins
    # used say (see Duel.plugin), counting each version's: the fewest any
    # says, or nil where none does. Asked as the run fits its workers (see
    # Runner#fit), not as .duel.rb loads, which each worker does too.
    # @api private
    def worker_limit
      @used.each_key.filter_map do |name|
        plugin = Duel.plugins.fetch(name)
        limited = plugin #: Module & Duel::_Plugin & Duel::_WorkerLimit
        limited.worker_limit if plugin.respond_to?(:worker_limit)
      end.min
    end

    # The plugins used (see #use), by name, in the order they were first
    # used.
    def plugins = @used.keys

    # A plugin as #use configured it: with +options+, returning +value+.
    # @api private
    class Used
      attr_accessor :value

      def initialize(options)
        @options = options
      end

      # What using it again returns: #value, unless +given+ (options)
      # has any but the first's, which fails.
      def again(name, given)
        ignored = given.reject { |option, value| @options.key?(option) && @options.fetch(option) == value }
        return @value if ignored.empty?

        raise Error, "c.use #{name.inspect}: used already, without #{ignored.map { |option, value| "#{option}: #{value.inspect}" }.join(", ")}: " \
          "give a plugin's options the first time it's used"
      end
    end

    # Prepares each version, or each worker (+scope+: :version or
    # :worker), by the block, given a Duel::Resource for it: a directory
    # of its own, and help running commands and starting servers there,
    # stopped when it's done with. The block returns the environment
    # variables it gets: a worker's, under its version's.
    #
    # A version's (named "base" or "head", its #root the version's tree
    # and its #ruby the Ruby it runs on) is prepared once for a run, in
    # the runner, before any of its workers start: installing its bundle,
    # say. Its environment is its workers' (and its process benchmarks').
    #
    #   c.prepare(:version) do |v|
    #     v.cached("bundle-#{Digest::SHA256.file(File.join(v.root, "Gemfile.lock"))}") { |_| v.run("bundle", "install", chdir: v.root) }
    #     {"BUNDLE_GEMFILE" => File.join(v.root, "Gemfile")}
    #   end
    #
    # A worker's (named "base-1", say) is prepared by the runner as
    # the worker starts: a server of its own, say.
    #
    #   c.prepare(:worker) do |w|
    #     socket = w.path("redis.sock")
    #     w.spawn("redis-server", "--port", "0", "--unixsocket", socket)
    #     w.wait_until { File.socket?(socket) }
    #     {"REDIS_URL" => "unix://#{socket}"}
    #   end
    def prepare(scope, &block)
      blocks = @prepares.fetch(scope) { raise ArgumentError, "prepare(:version) or prepare(:worker), not prepare(#{scope.inspect})" }
      raise ArgumentError, "prepare(#{scope.inspect}): give a block" unless block

      blocks << block
    end

    # Adds a metric to every benchmark: a Duel::Metric subclass, or
    # running totals that the block reads (see Duel::Snapshot), one by
    # name or several by their settings:
    #
    #   c.metric("sql_queries") { queries }
    #   c.metric("redis_cpu" => {kind: :timed, unit: "µs"}, "redis_commands" => {kind: :counted}) do
    #     {"redis_cpu" => usec, "redis_commands" => calls}
    #   end
    #
    # Returns the metric: running totals' takes what explains a sample
    # (see Snapshot.details), given each stretch's readings, with the
    # context the block read with them (+[totals, context]+).
    #
    #   c.metric("sql_queries") { [queries, statements] }.details { |stretches, sample| ... }
    def metric(metric = nil, **settings, &read)
      made = case metric
      when String then Snapshot.define({metric => settings}, read)
      when Hash, nil then Snapshot.define(metric || settings, read) # (several, without braces, are keywords)
      else metric
      end
      @metrics << made
      made
    end

    # Runs the block in each worker, once its version and the benchmarks
    # have loaded and before its metrics are made: for what only a worker
    # does (loading its data, say: .duel.rb itself is loaded by the runner
    # too). It gets the worker's Stops: what it gives at_stop runs when
    # the worker ends. Returns an InWorker, whose #value is what the block
    # returned, in that worker: a connection, say.
    #
    #   redis = c.in_worker { |w| Redis.new.tap { |r| w.at_stop { r.close } } }
    #   c.metric("redis_commands") { redis.value.info["total_commands_processed"] }
    def in_worker(&block)
      made = InWorker.new
      @in_workers << lambda do |worker|
        made.made(block.call(worker))
        worker.at_stop { made.forget }
      end
      made
    end

    # The hooks (see Duel::HOOKS), for every benchmark, run in each worker
    # before its file's and its own: setup once before a benchmark's
    # samples, and teardown after them (last first), and before_sample
    # before every sample (the warm-up's too), not measured.
    # around_iteration runs around each iteration, given it to run, and
    # after_iterations after each sample's iterations (inside each
    # iteration, with around_iteration), measured with them: to do the
    # work they left to be done later (jobs they queued, say), which is
    # theirs. Unlike a file's, they run where they were written (not in
    # the benchmark's context: they're a plugin's, say).
    def setup(&block) = add_hook(:setup, block)

    def teardown(&block) = add_hook(:teardown, block)

    def before_sample(&block) = add_hook(:before_sample, block)

    def around_iteration(&block) = add_hook(:around_iteration, block)

    def after_iterations(&block) = add_hook(:after_iterations, block)

    # Changes a measure's settings, by its name: any metric's, a plugin's
    # or Duel's own (`c.measure("cpu", limit: 1.05)`). `skip: true` leaves
    # it out.
    def measure(name, **settings)
      Metric.check(name, settings)
      @measures[name].merge!(settings)
    end

    # Whether a measure is skipped (see #measure): for a plugin's metric,
    # to set up nothing for it.
    def skip?(name) = @measures.key?(name) && @measures.fetch(name).fetch(:skip, false)

    # The files that define benchmarks, in order.
    # @api private
    def benchmark_files = Config.list(benchmarks).flat_map { |glob| Dir[File.join(root, glob)] }.uniq

    # A setting that takes one or a list (c.benchmarks, c.watch,
    # c.release_tags), as a list.
    # @api private
    def self.list(given) = given.instance_of?(String) ? [given] : given

    private

    def add_hook(name, block) = @hooks.fetch(name) << Duel.hook(name, block)
  end

  # Silences warnings about redefined constants, while loading a version
  # over files of another's (see Config#load_into).
  # @api private
  module QuietRedefinition
    REDEFINITION = /already initialized constant|previous definition of/

    # Silences them in this thread (what's silenced, while it is: see
    # #warn) during the block.
    def self.during
      Thread.current[:duel_quiet] = REDEFINITION
      yield
    ensure
      Thread.current[:duel_quiet] = nil
    end

    def warn(message, ...)
      return if Thread.current[:duel_quiet]&.match?(message)

      super
    end
  end
  Warning.singleton_class.prepend(QuietRedefinition)
end
