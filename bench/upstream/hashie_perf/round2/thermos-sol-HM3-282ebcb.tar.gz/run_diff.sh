#!/usr/bin/env bash
set -euo pipefail
root=$(pwd)/.amp/in/orb-backup/thermos-sol-HM3
logger=$(find /home/user/.local/share/mise/installs/ruby/4.0.10/lib/ruby/gems -type d -path '*/gems/logger-*/lib' | head -1)
for version in 3.0.7 3.1.7 3.2.10 3.3.10 3.4.7 4.0.10 master; do
  rb=/home/user/.local/share/mise/installs/ruby/$version/bin/ruby
  [[ $version == master ]] && rb=$root/ruby-master/bin/ruby
  [[ -x $rb ]] || continue
  for mode in interp yjit zjit; do
    flags=()
    [[ $mode != interp ]] && flags=(--$mode)
    if [[ $mode != interp ]]; then
      "$rb" "${flags[@]}" -e "exit(defined?(RubyVM::${mode^^}) && RubyVM::${mode^^}.enabled? ? 0 : 1)" >/dev/null 2>&1 || continue
    fi
    for side in base head; do
      "$rb" "${flags[@]}" -I"$root/$side/lib" -I"$logger" "$root/public_diff.rb" > "$root/evidence/$version-$mode-$side.jsonl" 2> "$root/evidence/$version-$mode-$side.stderr"
    done
    diff -u "$root/evidence/$version-$mode-base.jsonl" "$root/evidence/$version-$mode-head.jsonl" > "$root/evidence/$version-$mode.diff" || true
    printf '%s %s: ' "$version" "$mode"
    wc -l "$root/evidence/$version-$mode.diff"
    cat "$root/evidence/$version-$mode-head.stderr"
  done
done
