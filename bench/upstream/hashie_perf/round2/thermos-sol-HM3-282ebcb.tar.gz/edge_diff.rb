# frozen_string_literal: true

require 'hashie'
require 'json'
Hashie.logger = Object.new.tap { |o| o.define_singleton_method(:warn) { |_| } }

def attempt
  yield
rescue StandardError => error
  [error.class.name, error.message.lines.first.to_s.gsub(/0x[0-9a-f]+/, '0xADDR').strip]
end

[false, true].each do |frozen|
  [:plain, :singleton, :prepend, :extended].each do |style|
    [[], [nil], [false], [13, 47], [{a: 13}], [Hash.ruby2_keywords_hash({a: 13})]].each do |args|
      events = []
      mash = Hashie::Mash.new(item: 37)
      case style
      when :singleton
        mash.define_singleton_method(:method_missing) do |name, *values, **kw, &block|
          events << [:singleton, name, values, kw, block.nil?]
          super(name, *values, **kw, &block)
        end
      when :prepend
        mod = Module.new do
          define_method(:method_missing) do |name, *values, **kw, &block|
            events << [:prepended, name, values, kw, block.nil?]
            super(name, *values, **kw, &block)
          end
        end
        mash.singleton_class.prepend(mod)
      when :extended
        mash.extend(Hashie::Extensions::Mash::StrictKeyAccess)
      end
      leaf = Object.new
      leaf.define_singleton_method(:to_hash) { events << :leaf_to_hash; {a: 19} }
      leaf.define_singleton_method(:to_a) { events << :leaf_to_a; [19, 43] }
      leaf.freeze
      mash.freeze if frozen
      results = %i[item absent item? item! item_ item=].map do |name|
        [name, attempt { mash.public_send(name, *args) { |x| events << [:yield, x]; :ignored } }]
      end
      results << attempt { mash.public_send(:leaf=, leaf); mash[:leaf].equal?(leaf) }
      results << attempt { mash.method_missing }
      results << attempt { Hashie::Mash.instance_method(:method_missing).bind(mash).call(:item, *args) }
      puts JSON.generate([frozen, style, args, results, mash, events])
    end
  end
end

[:public, :private, :mutates, :raises].each do |kind|
  events = []
  mash = Hashie::Mash.new(item: 19)
  name = String.new('item=')
  name.define_singleton_method(:to_s) do
    events << :name_to_s
    mash[:other] = 23 if kind == :mutates
    raise 'conversion' if kind == :raises
    super()
  end
  name.singleton_class.send(:private, :to_s) if kind == :private
  result = attempt { mash.method_missing(name, false, 43) }
  puts JSON.generate([kind, result, mash, events])
end

[:hashie_first, :mash_first].each do |order|
  puts JSON.generate([order, attempt {
    require 'hashie/mash'
    klass = Class.new(Hashie::Mash) do
      include Hashie::Extensions::Mash::StrictKeyAccess
      include Hashie::Extensions::Mash::KeepOriginalKeys
    end
    o = klass.new(item: 47)
    [o.item(13, 29), o.public_send(:item=, false, 71), o.item]
  }])
end

method = Hashie::Mash.instance_method(:method_missing)
STDERR.puts JSON.generate(arity: method.arity, parameters: method.parameters, owner: method.owner.name)
