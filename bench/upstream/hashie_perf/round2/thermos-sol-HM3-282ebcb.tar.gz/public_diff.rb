# frozen_string_literal: true

require 'hashie'
require 'json'
require 'delegate'

EVENTS = []
Hashie.logger = Object.new.tap { |o| o.define_singleton_method(:warn) { |s| EVENTS << [:warning, s] } }

class Marker
  def to_s; EVENTS << :to_s; 'marker'; end
  def to_hash; EVENTS << :to_hash; { 'converted' => 37 }; end
  def to_ary; EVENTS << :to_ary; [19, 43]; end
  def to_a; EVENTS << :to_a; [23, 41]; end
end

class PrivateMarker < Marker
  private :to_hash, :to_ary, :to_a
end

class LoudString < String
  def to_s; EVENTS << :string_to_s; super; end
  def to_sym; EVENTS << :string_to_sym; super; end
end

class LoudArray < Array
  def to_a; EVENTS << :array_to_a; super; end
  def each(&block); EVENTS << :array_each; super; end
  def map(&block); EVENTS << :array_map; super; end
end

class LoudHash < Hash
  def to_hash; EVENTS << :hash_to_hash; super; end
  def each(&block); EVENTS << :hash_each; super; end
end

class BareSuper < Hashie::Mash
  def method_missing(name, *args, &block)
    EVENTS << [:before, name, args, block.nil?]
    super
  end
end

class ExplicitSuper < Hashie::Mash
  def method_missing(name, *args, &block); super(name, *args, &block); end
end

class KeywordSuper < Hashie::Mash
  def method_missing(name, *args, **kw, &block); super(name, *args, **kw, &block); end
end

class LegacySuper < Hashie::Mash
  ruby2_keywords def method_missing(name, *args, &block)
    EVENTS << [:keywords, args.last.is_a?(Hash) && Hash.ruby2_keywords_hash?(args.last)]
    super
  end
end

class ForwardSuper < Hashie::Mash
  def method_missing(...); super; end
end

class OptionalSuper < Hashie::Mash
  def method_missing(name, value = :default, *args, &block); super; end
end

module BeforeMash
  def method_missing(name, *args, **kw, &block)
    EVENTS << [:prepend, name, args, kw]
    super
  end
end
class PrependedMash < Hashie::Mash; prepend BeforeMash; end

class ObservedMash < Hashie::Mash
  def assign_property(name, value)
    EVENTS << [:assign, name, value, value.equal?($first), value.is_a?(Hash) && Hash.ruby2_keywords_hash?(value)]
    super
  end
  def [](name, &block)
    EVENTS << [:brackets, name, block.nil?]
    super
  end
end

CLASSES = [Hashie::Mash, BareSuper, ExplicitSuper, KeywordSuper, LegacySuper, ForwardSuper, OptionalSuper, PrependedMash, ObservedMash]
%i[KeepOriginalKeys PermissiveRespondTo SafeAssignment SymbolizeKeys DefineAccessors StrictKeyAccess RequiredKeys TransformKeys UnderscoreKeys].each do |ext|
  klass = Class.new(Hashie::Mash) { include Hashie::Extensions::Mash.const_get(ext) }
  Object.const_set("With#{ext}", klass)
  CLASSES << klass
end
class WithBlocks < Hashie::Mash; include Hashie::Extensions::BlockAccess; end
CLASSES << WithBlocks

def snap(v, depth = 0)
  return ['depth'] if depth > 6
  case v
  when Hash
    [v.class.name, v.frozen?, v.map { |k, x| [snap(k, depth + 1), snap(x, depth + 1)] }]
  when Array
    [v.class.name, v.frozen?, v.map { |x| snap(x, depth + 1) }]
  when String
    [v.class.name, v.frozen?, String.new(v)]
  when Symbol, Numeric, NilClass, TrueClass, FalseClass
    [v.class.name, v]
  else
    [v.class.name, v.frozen?]
  end
end

SHAPES = {
  none: '', nil: 'nil', false: 'false', one: '71', several: '71, 29, :tail',
  array: '($first = LoudArray[13, 47])', hash: "($first = LoudHash['nested', [13, 47]])", empty_hash: '($first = {})',
  frozen_hash: '($first = {a: 13}.freeze)', string: "($first = LoudString.new('value').freeze)", duck: '($first = Marker.new)',
  private_duck: '($first = PrivateMarker.new)', mash: '($first = Hashie::Mash.new(a: 17))',
  keyword: 'a: 13, b: 47', mixed: 'false, a: 13', empty_kw: '**{}', hash_kw: '**LoudHash[a: 13]',
  splat_empty: '*[]', splat_one: '*[nil]', splat_several: '*LoudArray[71, 29]',
  splat_duck: '*Marker.new', splat_private: '*PrivateMarker.new',
  double_duck: '**Marker.new', double_private: '**PrivateMarker.new',
  marked: 'Hash.ruby2_keywords_hash({a: 13})', tail_kw: '71, 29, a: 13'
}.freeze

row_count = 0
CLASSES.each do |klass|
  [false, true].each do |frozen|
    [false, true].each do |seed|
      %w[item absent item? absent? item! absent! item_ absent_ item= absent=].each do |name|
        SHAPES.each do |shape, expression|
          [:dispatch, :direct, :bound, :string, :delegator].each do |style|
            [false, true].each do |blocked|
              EVENTS.clear
              initial = seed ? {item: 37, nested: {leaf: 11}} : {}
              initial['item?'] = false if seed && klass != WithSafeAssignment
              mash = klass.new(initial)
              mash.default_proc = ->(h, k) { EVENTS << [:default, k]; k == 'absent' ? 59 : nil }
              mash.freeze if frozen
              $first = :not_supplied
              events_before = EVENTS.length
              target = style == :delegator ? SimpleDelegator.new(mash) : mash
              prefix = case style
              when :dispatch, :delegator then 'target.public_send(name.to_sym'
              when :direct then 'mash.method_missing(name.to_sym'
              when :string then 'mash.public_send(name'
              when :bound then 'mash.method(name.to_sym).call('
              end
              code = if style == :bound
                "#{prefix}#{expression})"
              else
                "#{prefix}#{expression.empty? ? '' : ', '}#{expression})"
              end
              code += ' { |child| EVENTS << [:block, child]; :block_result }' if blocked
              begin
                result = eval(code, binding)
                outcome = ['ok', snap(result), result.equal?($first)]
              rescue StandardError => error
                outcome = ['error', error.class.name, error.message.lines.first.to_s.gsub(/0x[0-9a-f]+/, '0xADDR').strip]
              end
              puts JSON.generate([klass.name, frozen, seed, name, shape, style, blocked, outcome, snap(mash), snap(EVENTS[events_before..-1])])
              row_count += 1
            end
          end
        end
      end
    end
  end
end

class FiberMash < Hashie::Mash
  def key?(name)
    Fiber.yield(:key_boundary) if Fiber.current != $root_fiber
    super
  end
end
$root_fiber = Fiber.current
[false, true].each do |freeze_after|
  mash = FiberMash.new(item: 13)
  fiber = Fiber.new { mash.item(71, 29) { |v| EVENTS << [:fiber_block, v] } }
  sequence = [fiber.resume]
  mash[:item] = 47
  mash.freeze if freeze_after
  sequence << fiber.resume while fiber.alive?
  puts JSON.generate(['fiber', freeze_after, snap(sequence), snap(mash)])
  row_count += 1
end
STDERR.puts "#{RUBY_DESCRIPTION}: #{row_count} public rows"
