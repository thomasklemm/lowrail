# frozen_string_literal: true

require 'hashie'
require 'delegate'

def receive(*positional, **keywords)
  [positional, keywords]
end

mash = Hashie::Mash.new
proxy = SimpleDelegator.new(mash)
value = proxy.public_send(:item=, a: 13)
p receive(*[value])

class HookMash < Hashie::Mash
  def assign_property(name, value)
    receive(*[value])
  end
end
p SimpleDelegator.new(HookMash.new).public_send(:item=, a: 13)

class LegacyKeywordMash < Hashie::Mash
  ruby2_keywords def method_missing(name, *args, &block)
    super
  end
end
value = LegacyKeywordMash.new.public_send(:item=, a: 13)
p receive(*[value])
