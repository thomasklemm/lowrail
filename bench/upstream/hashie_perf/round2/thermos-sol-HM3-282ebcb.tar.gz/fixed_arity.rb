# frozen_string_literal: true

require 'hashie'
method = Hashie::Mash.instance_method(:method_missing)
Hashie::Mash.define_method(:method_missing) do |name, value = nil, &block|
  method.bind(self).call(name, value, &block)
end
