# Astra HM5 exact-head review

Reviewed in T-01a21f3c-2ef1-726e-be84-05ebf5389576, without delegation or upstream writes.
Candidate: 6b6f67b39c4f839154209f4d94ceadb416f82ddb.
Parent: 277e88e6ccc317497e6c20fb8b9e35abebc0fe19.
The full verdict and findings are appended to Lowrail's round2/README.md.

## Reproduce the layout

Run from Lowrail's root. Extract this directory as `.amp/in/orb-backup/astra-HM5`.
Clone https://github.com/thomasklemm/hashie into `.amp/in/orb-backup/hashie`, detach at the
candidate, and add a detached worktree `.amp/in/orb-backup/hashie-base` at the parent.
The fork branch was checked with `git ls-remote`; `sources/verified-heads.txt` also records
the full head, parent and equality of the Duel merge tree and reviewed candidate tree.
No reviewed runtime code, commit message or CHANGELOG was edited.

## Rubies and checks

`mise install ruby@3.0.7 ruby@3.1.7 ruby@3.2.10 ruby@3.3.10 ruby@3.4.7 ruby@4.0.10`
installed the release pins. Installation output is in `outputs/ruby-install.log`.
Master was cloned at 0d399335b733776187e43a783e5f950c18ad881c under
`.amp/in/orb-backup/ruby-master`, then built with Ruby 4.0.10 on PATH:

```
./autogen.sh
./configure --prefix=/home/user/workspace/repo/.amp/in/orb-backup/ruby-master-install --enable-yjit --enable-zjit --disable-install-doc
make -j2
make install
```

`bash .amp/in/orb-backup/astra-HM5/run-probes.sh` runs each side in separate processes,
on one Ruby pin per comparison. Optional arguments select cells. The `*-version.txt` files
record actual runtime descriptions. `original` is Lowrail's unchanged
`bench/upstream/hashie_perf/round2/probes/to_hash_diff.rb`; the other scripts are kept here.
`edges.rb` exercises deterministic thread/fiber synchronization only when the receiver's
`to_hash` actually belongs to Hashie::Hash. Dash, Trash and IndifferentAccess use different
implementations, so do not assert that those unrelated methods yield at this callback.
The edge probe's earlier draft waited on a callback those methods never invoke; it was
stopped and corrected before the retained complete runs. This was a harness defect,
not a candidate hang or library difference.

The broad probe records graph identity, container frozenness, String encoding/bytes,
Hash keyword flags, identity-comparison mode, default-proc presence, user conversion events,
results, receiver state and exceptions. Object addresses in JSON's default object strings
are normalized; independent graph IDs retain aliasing. Exception output records class and
the first message line, excluding Ruby's source excerpt/caret and checkout-path backtraces.
`python3 .amp/in/orb-backup/astra-HM5/analyze.py` summarizes retained output.

`control.rb` intentionally drops conversion options, loaded with `-r` before
`adversarial.rb`, on 4.0.10/head. This negative control must differ from the normal output.
`minimal.rb`, `repros.rb` and `key-callback.rb` are standalone reproductions; run each with
`ruby -I .amp/in/orb-backup/hashie-base/lib SCRIPT` and then the candidate's `lib`.
`bash .amp/in/orb-backup/astra-HM5/load-order.sh` exercises four fresh-process require orders.

With Ruby 4.0.10 on PATH, ran `bundle install` in head, copied the resolved ignored lock
to base, and ran `bundle check` there. In each checkout: `bundle exec rake spec`.
On head also: `bundle exec rake rubocop` and `bundle exec rake docs:examples`.
The corresponding complete logs and exact lock are retained. These checks load each local
checkout, not an installed Hashie gem. Metrics were run with `flog -a lib/hashie/hash.rb`
and `rubocop --config <archive>/metrics.yml --only Metrics --format json lib/hashie/hash.rb`
for each side; zero thresholds intentionally expose scores, not project lint failures.

## Claims and sources

`reach.sh` fetches live RubyGems gem/version metadata, repository metadata and current
heads. The actual OmniAuth 2.4.2 gem and unpacked source are retained. Its released
auth_hash.rb was fetched at 2045f32693592360488c833b1505658dceddcd03 and compared byte-for-byte
with the gem; `sources/omniauth-tag*.json` resolves the annotated release tag. The current
gemspec was fetched independently. `sources/HM5-reviewed.md` is the exact reviewed PR text.

Used read-only `gh api` for fork PR 33, Actions run 46077588957, upstream master,
all-state issues, open PRs and number 662. Extracted the two original logs and run JSON
from Lowrail's `round2/duel/logs.tar.gz`; checked both actual CPU/allocations rows and totals,
the Ruby version lines, and checkout merge parents. Fetched the merge commit
a52a15e2b6dddaeae2626e561cb82ed8893a9898 and compared full trees with the reviewed head.
The source diff, gemspec, benchmark, fixture-loader, Duel config and API responses are kept.

## Measurements and limitations

`worst.rb` is a bounded 31-case search, not a universal worst-case proof. It includes
empty, scalar, Array and Hashie::Array inputs, copying readers, sizes 1/10/100, options,
and the actual Duel nested fixture and JSON. Dash/IndifferentAccess are unaffected controls.
`screen.sh` uses five base/head/base rounds on CPU 1; `screen.rb` uses GC-off CPU-time windows.
Its estimates select confirmation cases only, and have no significance/JIT-flat claim.
The confirmation uses Lowrail's `script/upstream-bench --wall 30`, retaining all generated
commands, A/A controls, per-window counters and outputs. See its `table.md` and `results.json`.
`bash .amp/in/orb-backup/astra-HM5/confirm.sh` measures the single-scalar Hash and empty
copying-reader subclass selected by screening, plus a scalar Mash control. It uses distinct
call sites, 30 rounds, five 10-ms windows per process, and 10,000 warmup calls. Neither
screened slowdown repeats in those isolated JIT-flat confirmations. This does not certify
the broad screen's mixed-profile call site: the screen is deliberately not a speed claim.
`confirm-yjit` and `confirm-zjit` each retain 90 processes and passing repeated-base controls.

The orb has **two CPUs**, not the required a1.xxlarge publication host. All new timings
are diagnostic, not approved for an upstream body. No measurement was delegated because
the request confined this review to this thread. The body audit verifies what the retained
exact-head Duel run reported; it does not substitute this orb's timing for that run.

Independent allocation checks used `UPSTREAM_BENCH_TREE=<side> ruby script/upstream-bench
--worker objects <archive>/worst.rb`, base/head/base on 4.0.10. The actual Duel fixture is
10 objects on all three. Copying readers can save allocations; “unchanged” in the body is
supported for its named benchmark, not a universal allocation guarantee for arbitrary overrides.
The first empty case has a common 0.001 startup residual; symbolization's fractional count is
also identical in both base controls and head, so neither is represented as a new saving.
