import collections
import glob
import json
import pathlib
import statistics

root = pathlib.Path(__file__).parent
for path in sorted((root / 'outputs').glob('*-adversarial-base.jsonl')):
    other = pathlib.Path(str(path).replace('-base.jsonl', '-head.jsonl'))
    if not other.exists():
        continue
    a = [json.loads(line) for line in path.read_text().splitlines()]
    b = [json.loads(line) for line in other.read_text().splitlines()]
    errors = collections.Counter(row[-1][1] for row in a if row[-1][0] == 'error')
    print(path.name, len(a), len(b), 'differing rows', sum(x != y for x, y in zip(a, b)), 'base errors', dict(errors))
for path in sorted((root / 'outputs').glob('*edges*base.jsonl')):
    other = pathlib.Path(str(path).replace('-base.jsonl', '-head.jsonl').replace('-hashie-head', '-hashie'))
    if not other.exists():
        continue
    a = [json.loads(line) for line in path.read_text().splitlines()]
    b = [json.loads(line) for line in other.read_text().splitlines()]
    changed = [(x, y) for x, y in zip(a, b) if x != y]
    print(path.name, len(a), len(b), 'differing rows', len(changed), collections.Counter(x[0] for x, y in changed))
for mode in ('interp', 'yjit', 'zjit'):
    ratios = collections.defaultdict(list)
    aa = collections.defaultdict(list)
    times = collections.defaultdict(list)
    for round_ in range(1, 6):
        files = [root / f'outputs/screen-{mode}-{round_}-{side}.jsonl' for side in ('base', 'head', 'base2')]
        if not all(p.exists() for p in files):
            continue
        a, h, b = [dict(json.loads(line) for line in p.read_text().splitlines()) for p in files]
        for name in a:
            x, y, z = [statistics.median(d[name]) for d in (a, h, b)]
            ratios[name].extend([y / x, y / z])
            aa[name].append(z / x)
            times[name].append(y)
    if ratios:
        print('SCREEN', mode, '(diagnostic only, no confidence intervals)')
        for name in sorted(ratios, key=lambda n: statistics.median(ratios[n]), reverse=True):
            print(name, 'head/base', statistics.median(ratios[name]), 'AA', statistics.median(aa[name]), 'head ns', statistics.median(times[name]) * 1e9)
