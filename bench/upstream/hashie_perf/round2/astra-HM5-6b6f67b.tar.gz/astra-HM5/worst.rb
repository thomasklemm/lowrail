# frozen_string_literal: true
$LOAD_PATH.unshift(File.join(ENV.fetch('UPSTREAM_BENCH_TREE'), 'lib'))
require 'hashie'
require 'json'
require 'logger'
Hashie.logger = Logger.new(nil)

class PerfDash < Hashie::Dash
  property :x
end
class PerfIA < Hashie::Hash
  include Hashie::Extensions::MergeInitializer
  include Hashie::Extensions::IndifferentAccess
end
class PerfCopy < Hashie::Hash
  def [](key); super.dup; end
end
classes = [Hashie::Hash, Hashie::Mash, PerfDash, PerfIA, PerfCopy]
classes.each do |klass|
  { empty: nil, scalar: 13, array: Hashie::Array[13, 29], plain_array: [13, 29], empty_array: Hashie::Array.new }.each do |label, value|
    h = klass.new
    h[:x] = value unless label == :empty
    UpstreamBench.report("#{klass} #{label}") { h.to_hash }
  end
end
[1, 10, 100].each do |n|
  h = Hashie::Mash.new((1..n).to_h { |i| ["key#{i}", i] })
  UpstreamBench.report("Mash #{n} keys") { h.to_hash }
end
fixture = JSON.parse(File.read(File.join(ENV.fetch('UPSTREAM_BENCH_TREE'), 'benchmarks/fixtures/repository.json')))
mash = Hashie::Mash.new(fixture)
UpstreamBench.report('Duel nested fixture') { mash.to_hash }
UpstreamBench.report('Duel nested JSON') { mash.to_json }
UpstreamBench.report('Duel nested symbolize') { mash.to_hash(symbolize_keys: true) }
