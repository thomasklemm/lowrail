# frozen_string_literal: true
require 'hashie'
Hashie::Hash.prepend(Module.new do
  def to_hash(_options = {})
    super()
  end
end)
