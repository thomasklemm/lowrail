# frozen_string_literal: true
require 'hashie'
h = Hashie::Hash.new
v = Object.new
v.define_singleton_method(:is_a?) { |type| h[:x] = 29; super(type) }
v.define_singleton_method(:to_hash) { { old: 13 } }
h[:x] = v
p h.to_hash
