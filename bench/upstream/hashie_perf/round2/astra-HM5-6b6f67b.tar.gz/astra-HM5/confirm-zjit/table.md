Time per call, Ruby 4.1.0dev, ZJIT, 30 rounds of fresh processes on one core

| | Before | After | Change |
| --- | ---: | ---: | ---: |
| `Hashie::Hash one scalar` | 0.21 µs | 0.19 µs | −6.2% |
| `copying-reader subclass empty` | 0.07 µs | 0.07 µs | within noise |
| `Mash one scalar control` | 0.29 µs | 0.26 µs | −10.0% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/astra-HM5/confirm-zjit.
- JIT-flat: compiled_iseq_count, failed_iseq_count, compiled_side_exit_count, invalidation_time_ns unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- Wall: thread CPU time with GC off per window, the 10th-percentile window per process; change = median of every round's candidate / base and candidate / base2, A/A = median of base2 / base, 95% bootstrap intervals resampling rounds
- base: ruby 4.1.0dev (2026-11-27T16:40:23Z master 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/hashie-base at 277e88e6cc
- candidate: ruby 4.1.0dev (2026-11-27T16:40:23Z master 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/hashie at 6b6f67b39c
- wall Hashie::Hash one scalar: −6.2% [−6.7%, −5.8%] with A/A −0.2% [−1.3%, +0.4%] (48142 calls × 5 windows per process), JIT-flat in 90 processes
- wall copying-reader subclass empty: +0.3% [−0.4%, +0.8%] with A/A −0.1% [−1.0%, +1.3%] (194376 calls × 5 windows per process), JIT-flat in 90 processes: interval includes 0, no claim
- wall Mash one scalar control: −10.0% [−10.4%, −9.8%] with A/A −0.5% [−1.2%, +0.1%] (35855 calls × 5 windows per process), JIT-flat in 90 processes
