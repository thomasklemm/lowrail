#!/usr/bin/env bash
set -euo pipefail
ruby="$HOME/.local/share/mise/installs/ruby/4.0.10/bin/ruby"
for side in base head; do
  lib="$PWD/.amp/in/orb-backup/hashie/lib"
  [[ $side == base ]] && lib="$PWD/.amp/in/orb-backup/hashie-base/lib"
  for requires in 'hashie,json' 'json,hashie' 'hashie/hash' 'hashie/mash,json'; do
    "$ruby" -I "$lib" -e 'ARGV.shift.split(",").each { |f| require f }; begin; h=Hashie::Hash[x: 13]; p [h.to_hash, h.to_json]; rescue StandardError=>e; p [e.class.name,e.message.lines.first.strip]; end' "$requires"
  done > ".amp/in/orb-backup/astra-HM5/outputs/load-order-$side.txt" 2>&1
done
