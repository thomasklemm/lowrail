# frozen_string_literal: true
require 'hashie'
require 'json'
require 'logger'
$stdout.sync = true
Hashie.logger = Logger.new(nil)
class EdgeDash < Hashie::Dash
  property :x
end
class EdgeTrash < Hashie::Trash
  property :x
end
class EdgeIA < Hashie::Hash
  include Hashie::Extensions::MergeInitializer
  include Hashie::Extensions::IndifferentAccess
end
[Hashie::Hash, Hashie::Mash, EdgeDash, EdgeTrash, EdgeIA].each do |klass|
  [:to_hash, :to_json].each do |method|
    [false, true].each do |frozen|
      [:replace, :delete, :freeze, :array, :fiber, :thread, :prepend, :private].each do |action|
        next if frozen && [:fiber, :thread].include?(action)
        h = klass.new
        next if [:fiber, :thread].include?(action) && h.method(:to_hash).owner != Hashie::Hash
        events = []
        value = action == :array ? Hashie::Array[13] : Object.new
        h[:x] = value
        value = h[:x]
        ready = Queue.new
        resume = Queue.new
        tested = false
        hook = proc do |type|
          if type == Hashie::Array && !tested
            tested = true
            events << :test
            case action
            when :delete then h.delete(h.keys.first)
            when :freeze then h.freeze
            when :fiber then Fiber.yield(:pause)
            when :thread then ready << :pause; resume.pop
            else h[:x] = 29
            end
          end
          super(type)
        end
        if action == :prepend
          value.singleton_class.prepend(Module.new { define_method(:is_a?, hook) })
        else
          value.define_singleton_method(:is_a?, hook)
          value.singleton_class.send(:private, :is_a?) if action == :private
        end
        value.define_singleton_method(:to_hash) { { old: 13 } }
        h.freeze if frozen
        begin
          call = -> { h.public_send(method) }
          if action == :fiber
            f = Fiber.new { call.call }
            first = f.resume
            h[:x] = 29
            result = f.resume
          elsif action == :thread
            t = Thread.new { call.call }
            t.report_on_exception = false
            ready.pop
            h[:x] = 29
            resume << :go
            result = t.value
          else
            result = call.call
          end
          result = result.inspect.gsub(/0x[0-9a-f]+/, 'ADDR')
        rescue StandardError => e
          result = [e.class.name, e.message.lines.first.strip.gsub(/0x[0-9a-f]+/, 'ADDR')]
        ensure
          if defined?(t) && t&.alive?
            resume << :go
            t.join rescue nil
          end
        end
        puts JSON.generate([klass.name, method, frozen, action, result, events])
      end
    end
  end
end
