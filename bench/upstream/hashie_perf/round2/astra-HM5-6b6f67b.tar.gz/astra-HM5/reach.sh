#!/usr/bin/env bash
set -euo pipefail
out=$(dirname "$0")/sources
for pair in omniauth:omniauth/omniauth hashie:hashie/hashie duel:sferik/duel-ruby; do
  gem=${pair%%:*}; repo=${pair#*:}
  curl -fsSL "https://rubygems.org/api/v1/gems/$gem.json" > "$out/$gem-gem.json"
  curl -fsSL "https://rubygems.org/api/v1/versions/$gem.json" > "$out/$gem-versions.json"
  gh api "repos/$repo" > "$out/$gem-repo.json"
  gh api "repos/$repo/commits/HEAD" > "$out/$gem-head.json"
done
gh api repos/ruby/ruby > "$out/ruby-repo.json"
curl -fsSL https://rubygems.org/downloads/omniauth-2.4.2.gem -o "$out/omniauth-2.4.2.gem"
