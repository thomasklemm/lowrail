# frozen_string_literal: true
require 'hashie'
h = Hashie::Hash.new
key = Object.new
calls = 0
key.define_singleton_method(:hash) do
  calls += 1
  h.clear if calls == 3
  7
end
h[key] = Hashie::Array[13]
begin
  p h.to_hash.values
rescue StandardError => e
  puts "#{e.class}: #{e.message.lines.first}"
end
