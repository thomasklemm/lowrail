#!/usr/bin/env bash
set -euo pipefail
root=$(pwd)
for mode in yjit zjit; do
  ruby="$HOME/.local/share/mise/installs/ruby/4.0.10/bin/ruby"
  [[ $mode == zjit ]] && ruby="$root/.amp/in/orb-backup/ruby-master-install/bin/ruby"
  "$ruby" script/upstream-bench --base "$root/.amp/in/orb-backup/hashie-base" --candidate "$root/.amp/in/orb-backup/hashie" --gems '' --ruby "$ruby" --modes '' --wall 30 --wall-mode "$mode" --wall-windows 5 --wall-ms 10 --warmup 10000 --core 1 --out "$root/.amp/in/orb-backup/astra-HM5/confirm-$mode" "$root/.amp/in/orb-backup/astra-HM5/confirm.rb"
done
