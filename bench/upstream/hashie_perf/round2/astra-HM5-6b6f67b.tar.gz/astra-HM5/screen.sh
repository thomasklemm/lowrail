#!/usr/bin/env bash
set -euo pipefail
root=$(pwd)
out="$root/.amp/in/orb-backup/astra-HM5/outputs"
for mode in interp yjit zjit; do
  ruby="$HOME/.local/share/mise/installs/ruby/4.0.10/bin/ruby"
  flags=()
  [[ $mode == yjit ]] && flags=(--yjit)
  if [[ $mode == zjit ]]; then
    ruby="$root/.amp/in/orb-backup/ruby-master-install/bin/ruby"
    flags=(--zjit)
  fi
  for round in 1 2 3 4 5; do
    sides=(base head base2)
    [[ $((round % 2)) == 0 ]] && sides=(head base2 base)
    for side in "${sides[@]}"; do
      tree="$root/.amp/in/orb-backup/hashie-base"
      [[ $side == head ]] && tree="$root/.amp/in/orb-backup/hashie"
      env UPSTREAM_BENCH_TREE="$tree" taskset -c 1 "$ruby" "${flags[@]}" "$root/.amp/in/orb-backup/astra-HM5/screen.rb" > "$out/screen-$mode-$round-$side.jsonl"
    done
  done
done
