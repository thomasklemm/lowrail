Time per call, Ruby 4.0.10, YJIT, 30 rounds of fresh processes on one core

| | Before | After | Change |
| --- | ---: | ---: | ---: |
| `Hashie::Hash one scalar` | 0.21 µs | 0.20 µs | −5.7% |
| `copying-reader subclass empty` | 0.08 µs | 0.08 µs | −0.6% |
| `Mash one scalar control` | 0.29 µs | 0.25 µs | −13.2% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/astra-HM5/confirm-yjit.
- JIT-flat: compiled_iseq_count, compiled_block_count, invalidation_count unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- Wall: thread CPU time with GC off per window, the 10th-percentile window per process; change = median of every round's candidate / base and candidate / base2, A/A = median of base2 / base, 95% bootstrap intervals resampling rounds
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/hashie-base at 277e88e6cc
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/hashie at 6b6f67b39c
- wall Hashie::Hash one scalar: −5.7% [−6.1%, −4.8%] with A/A +0.4% [−0.5%, +1.4%] (52797 calls × 5 windows per process), JIT-flat in 90 processes
- wall copying-reader subclass empty: −0.6% [−1.6%, −0.0%] with A/A +0.4% [−1.1%, +2.2%] (160628 calls × 5 windows per process), JIT-flat in 90 processes
- wall Mash one scalar control: −13.2% [−13.6%, −12.7%] with A/A −0.3% [−0.9%, +1.0%] (34428 calls × 5 windows per process), JIT-flat in 90 processes
