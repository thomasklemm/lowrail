# frozen_string_literal: true
$LOAD_PATH.unshift(File.join(ENV.fetch('UPSTREAM_BENCH_TREE'), 'lib'))
require 'hashie'
class CopyingEmpty < Hashie::Hash
  def [](key); super.dup; end
end
h = Hashie::Hash[x: 13]
empty = CopyingEmpty.new
m = Hashie::Mash.new(x: 13)
UpstreamBench.report('Hashie::Hash one scalar') { h.to_hash }
UpstreamBench.report('copying-reader subclass empty') { empty.to_hash }
UpstreamBench.report('Mash one scalar control') { m.to_hash }
