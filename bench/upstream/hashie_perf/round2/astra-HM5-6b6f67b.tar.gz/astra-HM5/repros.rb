# frozen_string_literal: true
require 'hashie'
require 'json'

# A documented public conversion can call user code between the two reads.
h = Hashie::Hash.new
old = Object.new
def old.is_a?(type)
  @owner[:x] = 29 if type == Hashie::Array
  super
end
old.instance_variable_set(:@owner, h)
def old.to_hash; { old: 13 }; end
h[:x] = old
p ['value callback replaces entry', h.to_hash, h[:x]]

class CopyingHash < Hashie::Hash
  def [](key); super.dup; end
end
value = Class.new do
  def is_a?(type); @tested = true if type == Hashie::Array; super; end
  def to_hash; { tested: !!@tested }; end
end.new
h = CopyingHash[x: value]
p ['copied value state', h.to_hash]

# A real fiber boundary, using a public value method, not a private Hashie hook.
h = Hashie::Hash.new
value = Object.new
def value.is_a?(type); Fiber.yield(:read) if type == Hashie::Array; super; end
def value.to_hash; { old: 13 }; end
h[:x] = value
f = Fiber.new { h.to_hash }
p ['fiber paused', f.resume]
h[:x] = 29
p ['fiber resumed after replacement', f.resume]

# Default procs can be reached by a key present when iteration starts.
h = Hashie::Hash.new { |_hash, _key| 29 }
value = Object.new
value.define_singleton_method(:is_a?) { |type| h.delete(:x) if type == Hashie::Array; super(type) }
def value.to_hash; { old: 13 }; end
h[:x] = value
p ['deleted entry uses default', h.to_hash]
