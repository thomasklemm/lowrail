require 'cgi/escape'
require 'omniauth/key_store'
require 'omniauth/strategy/class_methods'
require 'omniauth/strategy/fetchers'
require 'omniauth/strategy/hosts'
require 'omniauth/strategy/paths'
require 'omniauth/strategy/sign_ins'
require 'omniauth/strategy/test_mode'

module OmniAuth
  class NoSessionError < StandardError; end

  # The Strategy is the base unit of OmniAuth's ability to
  # wrangle multiple providers. Each strategy provided by
  # OmniAuth includes this mixin to gain the default functionality
  # necessary to be compatible with the OmniAuth library.
  module Strategy # rubocop:disable Metrics/ModuleLength
    include Fetchers
    include Hosts
    include Paths
    include SignIns
    include TestMode

    def self.included(base)
      OmniAuth.strategies << base

      base.extend ClassMethods
      base.option :setup, false
      base.option :skip_info, false
      base.option :origin_param, 'origin'
    end

    attr_reader :app, :env, :options, :response

    # Initializes the strategy by passing in the Rack endpoint,
    # the unique URL segment name for this strategy, and any
    # additional arguments. An `options` hash is automatically
    # created from the last argument if it is a hash.
    #
    # @param app [Rack application] The application on which this middleware is applied.
    #
    # @overload new(app, options = {})
    #   If nothing but a hash is supplied, initialized with the supplied options
    #   overriding the strategy's default options via a deep merge.
    # @overload new(app, *args, options = {})
    #   If the strategy has supplied custom arguments that it accepts, they may
    #   will be passed through and set to the appropriate values.
    #
    # @yield [Options] Yields options to block for further configuration.
    def initialize(app, *args)
      @app = app
      @env = nil
      @options = self.class.default_options.dup

      options.deep_merge!(args.pop) if args.last.is_a?(Hash)
      options[:name] ||= self.class.to_s.split('::').last.downcase

      self.class.args.each do |arg|
        break if args.empty?

        options[arg] = args.shift
      end

      # Make sure that all of the args have been dealt with, otherwise error out.
      raise(ArgumentError.new("Received wrong number of arguments. #{args}")) unless args.empty?

      yield options if block_given?
    end

    def inspect
      "#<#{self.class}>"
    end

    # Direct access to the OmniAuth logger, automatically prefixed
    # with this strategy's name.
    #
    # @example
    #   log :warn, "This is a warning."
    def log(level, message)
      OmniAuth.logger.public_send(level, "(#{name}) #{message}")
    end

    # Duplicates this instance and runs #call! on it. A request that can't be
    # the strategy's goes straight to the app instead, skipping the copy.
    # @param [Hash] The Rack environment.
    def call(env)
      return @app.call(env) if passthrough?(env)

      dup.call!(env)
    end

    # The logic for dispatching any additional actions that need
    # to be taken. For instance, calling the request phase if
    # the request path is recognized.
    #
    # @param env [Hash] The Rack environment.
    def call!(env)
      unless env['rack.session']
        error = NoSessionError.new('You must provide a session to use OmniAuth.')
        raise(error)
      end

      @env = env

      warn_if_using_get_on_request_path

      env['omniauth.strategy'] = self if on_auth_path?

      return mock_call!(env) if OmniAuth.config.test_mode

      phase_call || @app.call(env)
    end

    # Runs the phase that matches the current request, or returns nil
    # if the request isn't for this strategy.
    def phase_call
      if options_call?
        options_call
      elsif request_call?
        request_call
      elsif on_callback_path?
        callback_call
      elsif respond_to?(:other_phase)
        other_phase
      end
    rescue StandardError => e
      handle_phase_error(e)
    end

    # True for an OPTIONS request to the request or callback path.
    def options_call?
      on_auth_path? && options_request?
    end

    # True for a request to the request path with an allowed method.
    def request_call?
      on_request_path? && OmniAuth.config.allowed_request_methods.include?(request.request_method.downcase.to_sym)
    end

    def warn_if_using_get_on_request_path
      return unless on_request_path?
      return unless OmniAuth.config.allowed_request_methods.include?(:get)
      return if OmniAuth.config.silence_get_warning

      log :warn, <<-WARN
  You are using GET as an allowed request method for OmniAuth. This may leave
  you open to CSRF attacks. As of v2.0.0, OmniAuth by default allows only POST
  to its own routes. You should review the following resources to guide your
  mitigation:
  https://github.com/omniauth/omniauth/wiki/Resolving-CVE-2015-9284
  https://github.com/omniauth/omniauth/issues/960
  https://nvd.nist.gov/vuln/detail/CVE-2015-9284
  https://github.com/omniauth/omniauth/pull/809

  You can ignore this warning by setting:
  OmniAuth.config.silence_get_warning = true
      WARN
    end

    # Responds to an OPTIONS request.
    def options_call
      run_hook(:before_options_phase)
      verbs = OmniAuth.config.allowed_request_methods.collect(&:upcase).join(', ')
      [200, {'Allow' => verbs}, []]
    end

    # Performs the steps necessary to run the request phase of a strategy.
    def request_call
      setup_phase
      log :debug, 'Request phase initiated.'
      warn_if_using_request_host
      return invalid_host! unless allowed_host?

      run_hook(:request_validation_phase)
      session['omniauth.params'] = omniauth_params
      run_hook(:before_request_phase)
      request_response.tap { run_hook(:after_request_phase) }
    rescue OmniAuth::AuthenticityError => e
      fail!(:authenticity_error, e)
    end

    # Renders the login form (from a Rack endpoint or the app itself) if
    # one is configured, or else runs the strategy's request phase.
    def request_response
      if options.form.respond_to?(:call)
        log :debug, 'Rendering form from supplied Rack endpoint.'
        options.form.call(env)
      elsif options.form
        log :debug, 'Rendering form from underlying application.'
        call_app!
      else
        store_origin if options.origin_param
        request_phase
      end
    end

    # The authenticity token never goes into omniauth.params, so the app
    # can't leak it by echoing the params back.
    AUTHENTICITY_PARAM = 'authenticity_token'.freeze

    # The params the app sent to the request phase, from both the query
    # string and the form, which the callback phase hands back as
    # env['omniauth.params'].
    def omniauth_params
      request.params.reject { |key, _| key.eql?(AUTHENTICITY_PARAM) }
    end

    # Remembers where the user came from (the origin param, or else the
    # referer) so the callback phase can send them back there.
    def store_origin
      origin = request.params[options.origin_param]
      if origin
        # A present origin param is what the app asked for, so never silently
        # fall back to the referer when it's rejected; just store nothing. It
        # must be a String: an array (origin[]=...) would pass the scheme check
        # through its to_s and still land in the session.
        session['omniauth.origin'] = origin if origin.is_a?(String) && safe_origin?(origin)
      elsif (referer = referer_origin)
        session['omniauth.origin'] = referer
      end
    end

    # Performs the steps necessary to run the callback phase of a strategy.
    def callback_call
      setup_phase
      log :debug, 'Callback phase initiated.'
      return invalid_host! unless allowed_host?

      sign_in = recall_sign_in
      origin = sign_in['origin']
      env['omniauth.origin'] = (origin unless origin.eql?(''))
      env['omniauth.params'] = sign_in['params'] || {}
      run_hook(:before_callback_phase)
      callback_phase
    end

    def options_request?
      request.request_method.eql?('OPTIONS')
    end

    # The setup phase looks for the `:setup` option to exist and,
    # if it is, will call either the Rack endpoint supplied to the
    # `:setup` option or it will call out to the setup path of the
    # underlying application. This will default to `/auth/:provider/setup`.
    def setup_phase
      setup = options[:setup]
      if setup.respond_to?(:call)
        log :debug, 'Setup endpoint detected, running now.'
        setup.call(env)
      elsif setup
        log :debug, 'Calling through to underlying application for setup.'
        setup_env = env.merge('PATH_INFO' => setup_path, 'REQUEST_METHOD' => 'GET')
        call_app!(setup_env)
      end
    end

    # @abstract This method is called when the user is on the request path. You should
    # perform any information gathering you need to be able to authenticate
    # the user in this phase.
    def request_phase
      raise(NotImplementedError)
    end

    def callback_phase
      env['omniauth.auth'] = auth_hash
      call_app!
    end

    def call_app!(app_env = env)
      @app.call(app_env)
    rescue StandardError
      app_env['omniauth.error.app'] = true
      raise
    end

    def session
      env['rack.session']
    end

    def request
      @request ||= Rack::Request.new(env)
    end

    def name
      options.fetch(:name)
    end

    def redirect(uri)
      uri = ascii_compatible_uri(uri)
      r = Rack::Response.new
      r['content-type'] = 'text/html'

      # A disallowed scheme (javascript:, data:, ...) never reaches the inline
      # script; it falls through to the 302, where a Location header is inert.
      if options[:iframe] && allowed_redirect_uri?(uri)
        r.write("<script type='text/javascript' charset='utf-8'>top.location.href = '#{escape_javascript(uri)}';</script>")
      else
        r.write("Redirecting to #{CGI.escapeHTML(uri.to_s)}...")
        r.redirect(uri)
      end

      r.finish
    end

    def user_info
      {}
    end

    def fail!(message_key, exception = nil)
      env['omniauth.error'] = exception
      env['omniauth.error.type'] = message_key.to_sym
      env['omniauth.error.strategy'] = self

      if exception
        log :error, "Authentication failure! #{message_key}: #{exception.class}, #{exception.message}"
      else
        log :error, "Authentication failure! #{message_key} encountered."
      end

      OmniAuth.config.on_failure.call(env)
    end

    class Options < OmniAuth::KeyStore; end

  protected

    # Characters that could end the single-quoted string literal or the
    # <script> element the :iframe redirect writes the URI into.
    JAVASCRIPT_UNSAFE = /[\x00-\x1f"&'<>\\\u2028\u2029]/.freeze
    private_constant :JAVASCRIPT_UNSAFE

    # Rewrites each unsafe character as a \uXXXX escape, which the browser
    # decodes back to that character inside the string literal. Binary strings
    # (which Rack hands back for query strings and the like) are read as UTF-8
    # so multibyte characters survive, any other encoding is transcoded so a
    # non-UTF-8 charset isn't misread, and only invalid bytes are replaced.
    # A valid UTF-8 string goes straight through without being copied.
    def escape_javascript(value)
      string = value.to_s
      string = string.dup.force_encoding(Encoding::UTF_8) if string.encoding.equal?(Encoding::BINARY)
      string = string.encode(Encoding::UTF_8, :invalid => :replace, :undef => :replace) unless string.encoding.equal?(Encoding::UTF_8)
      string = string.scrub unless string.valid_encoding?
      string.gsub(JAVASCRIPT_UNSAFE) { |char| format('\\u%04x', char.ord) }
    end

    # Tab/newline/CR anywhere, or a leading control byte or space, which a
    # browser strips before it reads the scheme.
    NEEDS_NORMALIZING = /[\t\r\n]|\A[\x00-\x20]/.freeze
    private_constant :NEEDS_NORMALIZING

    # Schemes a browser runs as script when it follows the URL. Escaping can't
    # neutralize one (none of its characters are unsafe), so such a URI must
    # never reach the inline :iframe script or be persisted as an origin.
    DANGEROUS_SCHEME = /\A(?:javascript|vbscript|data):/i.freeze
    private_constant :DANGEROUS_SCHEME

    ANY_SCHEME = /\A[a-z][a-z0-9+.-]*:/i.freeze
    private_constant :ANY_SCHEME

    WEB_SCHEME = /\Ahttps?:/i.freeze
    private_constant :WEB_SCHEME

    # The URI as a browser reads its scheme: tab/newline/CR dropped anywhere
    # and leading control bytes and spaces trimmed, so a split or padded scheme
    # can't slip past the checks. A URI with none of those is returned as-is,
    # so the common case allocates nothing. Invalid bytes are scrubbed first,
    # since matching a regexp against them raises ArgumentError.
    def normalize_redirect_uri(uri)
      uri = uri.to_s
      uri = uri.scrub unless uri.valid_encoding?
      return uri unless uri.match?(NEEDS_NORMALIZING)

      uri.gsub(/[\t\r\n]/, '').sub(/\A[\x00-\x20]+/, '')
    end

    # Safe to write into the inline :iframe script: a relative/protocol-relative
    # path or an http(s) URL. A javascript:/data:/vbscript: URI is excluded here
    # because escaping leaves it able to run in the application's origin.
    def allowed_redirect_uri?(uri)
      uri = normalize_redirect_uri(uri)
      !uri.match?(ANY_SCHEME) || uri.match?(WEB_SCHEME)
    end

    # Safe to persist as an origin: anything but a scheme that runs as script.
    # Unlike the iframe check this keeps non-web deep links such as myapp://,
    # which mobile sign-in relies on, while still refusing a URI that a later
    # redirect to omniauth.origin could execute.
    def safe_origin?(uri)
      !normalize_redirect_uri(uri).match?(DANGEROUS_SCHEME)
    end

    # The referer to fall back on as the origin, unless it is the request path
    # itself or has a scheme that runs as script. It's scrubbed before any
    # matching, which would otherwise raise on invalid bytes.
    def referer_origin
      referer = env['HTTP_REFERER']
      return unless referer

      referer = referer.scrub unless referer.valid_encoding?
      referer if !referer.end_with?(request_path) && safe_origin?(referer)
    end

    # A URI in an encoding that isn't ASCII-compatible, such as UTF-16, can't
    # be matched against the scheme checks or written into the UTF-8 response,
    # so it's transcoded to UTF-8 first. Anything else is returned as-is.
    def ascii_compatible_uri(uri)
      return uri unless uri.is_a?(String) && !uri.encoding.ascii_compatible?

      uri.encode(Encoding::UTF_8, :invalid => :replace, :undef => :replace)
    end

    # Re-raises errors from the downstream app; reports anything else
    # raised during a phase as an authentication failure.
    def handle_phase_error(error)
      raise error if env.delete('omniauth.error.app')

      fail!(error.message, error)
    end

    # Calls the named OmniAuth.config hook (such as :before_request_phase)
    # with the Rack env. A hook set to nil or false is skipped.
    def run_hook(name)
      hook = OmniAuth.config.public_send(name)
      return unless hook # not hook&.call: a hook can be set to false

      hook.call(env)
    end

    def initialize_copy(*args)
      super
      @options = @options.dup
    end

    # True when #call! would only hand env to the app: there's a session, the
    # path alone decides, and env isn't on the strategy's paths. The
    # strategy's own path methods check, on a copy that shares its options.
    def passthrough?(env)
      return false unless env['rack.session'] && dispatch_by_path?
      return false if path_probe(env).on_auth_path?

      true
    end

    # True when OmniAuth's own dispatch runs, with no test mode or
    # other_phase, and no path lambdas, which would otherwise run twice on
    # the strategy's own paths.
    def dispatch_by_path?
      self.class.default_dispatch? && !OmniAuth.config.test_mode && !respond_to?(:other_phase) &&
        !options[:request_path].respond_to?(:call) && !options[:callback_path].respond_to?(:call)
    end

    # A copy like #dup makes, but sharing this instance's options, so the
    # path methods can memoize on it instead of on this shared instance.
    def path_probe(env)
      probe = self.class.allocate
      instance_variables.each { |ivar| probe.instance_variable_set(ivar, instance_variable_get(ivar)) }
      probe.instance_variable_set(:@env, env)
      probe
    end
  end
end
