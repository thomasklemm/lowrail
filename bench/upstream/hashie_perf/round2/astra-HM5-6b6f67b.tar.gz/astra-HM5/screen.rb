# frozen_string_literal: true
require 'json'
module UpstreamBench
  CASES = {}
  def self.report(name, &block); CASES[name] = block; end
end
load File.join(__dir__, 'worst.rb')
UpstreamBench::CASES.each do |name, call|
  10_000.times { call.call }
  samples = 5.times.map do
    GC.start
    GC.disable
    start = Process.clock_gettime(Process::CLOCK_THREAD_CPUTIME_ID)
    10_000.times { call.call }
    elapsed = Process.clock_gettime(Process::CLOCK_THREAD_CPUTIME_ID) - start
    GC.enable
    elapsed / 10_000
  end
  puts JSON.generate([name, samples])
end
