# frozen_string_literal: true
require 'hashie'
require 'json'
require 'stringio'
require 'logger'
$LOAD_PATH.unshift(File.expand_path('sources/omniauth-2.4.2/lib', __dir__))
require 'omniauth/auth_hash'
Hashie.logger = Logger.new(StringIO.new)
$events = []

class Zero
  def to_hash; $events << 'zero'; { a: 13 }.freeze; end
end
class One
  def to_hash(options); $events << ['one', options.dup]; { b: 29 }; end
end
class Optional
  def to_hash(options = {}); $events << ['optional', options.dup]; { c: 31 }; end
end
class Two
  def to_hash(a, b); { a: a, b: b }; end
end
class Keywords
  def to_hash(**opts); opts; end
end
class Missing
  def respond_to_missing?(name, priv = false); name == :to_hash || super; end
  def method_missing(name, *args); return { mm: args } if name == :to_hash; super; end
end
class PrivateConversion
  private
  def to_hash; { hidden: 13 }; end
end
class ClaimPrivate < PrivateConversion
  def respond_to_missing?(name, priv = false); name == :to_hash || super; end
end
class TaggedArray < Hashie::Array
  def each
    $events << 'array each'
    super
  end
end
class PlainArray < Array; end
class PlainHash < Hash; end
class KwHash < Hash; end
class MyString < String; end
class H < Hashie::Hash; end
class M < Hashie::Mash; end
class D < Hashie::Dash
  property :x
  property :y
end
class T < Hashie::Trash
  property :x, from: :input
  property :y
end
class IA < Hashie::Hash
  include Hashie::Extensions::MergeInitializer
  include Hashie::Extensions::IndifferentAccess
end
class Copying < Hashie::Hash
  def [](key); value = super; value.dup; end
end
class Forward < Hashie::Mash
  def [](key); super; end
end
module Reader
  def [](key); super; end
end
class Prepended < Hashie::Mash
  prepend Reader
end
class PrivateReader < Hashie::Hash
  private
  def [](key); super; end
end

classes = [Hashie::Hash, H, Hashie::Mash, M, D, T, IA, Copying, Forward, Prepended,
           PrivateReader, Hashie::Clash, Hashie::Rash, OmniAuth::AuthHash, OmniAuth::AuthHash::InfoHash]
%i[StrictKeyAccess KeepOriginalKeys SymbolizeKeys DefineAccessors SafeAssignment PermissiveRespondTo].each do |ext|
  k = Class.new(Hashie::Mash) { include Hashie::Extensions::Mash.const_get(ext) }
  Object.const_set("Ext#{ext}", k)
  classes << k
end
k = Class.new(Hashie::Mash) { include Hashie::Extensions::MethodAccessWithOverride }
Object.const_set('ExtOverride', k)
classes << k

def values
  h = Hash.ruby2_keywords_hash({ a: 13 })
  [nil, false, 13, 'abc'.freeze, MyString.new('abc'), Zero.new, One.new, Optional.new,
   Two.new, Keywords.new, Missing.new, PrivateConversion.new, ClaimPrivate.new,
   [One.new, { a: 13 }], Hashie::Array[Zero.new, Hashie::Hash[a: 13]],
   TaggedArray[One.new, { b: 29 }].freeze, PlainArray[13, 29], PlainHash[a: 13],
   h, Hashie::Mash.new(a: [13, 29]), Hashie::Hash[a: 13].freeze,
   D.new(x: 13, y: 29), T.new(input: 13, y: 29),
   Hashie::Array[Hashie::Array[Hashie::Hash[a: 13]]], Hashie::Array.new]
end

def snapshot(x, seen = {})
  return [x.class.name, x] if x.nil? || x == true || x == false || x.is_a?(Numeric) || x.is_a?(Symbol)
  id = x.__id__
  return ['ref', seen[id]] if seen.key?(id)
  seen[id] = seen.size
  meta = [seen[id], x.class.name, x.frozen?]
  case x
  when Hash
    meta + [Hash.ruby2_keywords_hash?(x), x.compare_by_identity?, x.default_proc != nil,
            x.map { |k, v| [snapshot(k, seen), snapshot(v, seen)] }]
  when Array
    meta + [x.map { |v| snapshot(v, seen) }]
  when String
    meta + [x.encoding.name, x.valid_encoding?, x.bytes]
  else
    meta + [x.instance_variables.sort.map { |v| [v, snapshot(x.instance_variable_get(v), seen)] }]
  end
end

options = [{}, { stringify_keys: true }, { symbolize_keys: true }, { stringify_keys: true, symbolize_keys: true }, { stringify_keys: false, symbolize_keys: nil }]
classes.each do |klass|
  values.size.times do |index|
    options.each_with_index do |opts, oi|
      [false, true].each do |frozen|
        %i[none proc identity].each do |mode|
          [:to_hash, :to_json].each do |method|
            source = values[index]
            $events = []
            begin
              input = { x: source, y: 29 }
              hash = if klass == Hashie::Rash || klass == Hashie::Clash
                klass.new(input)
              else
                klass.new.tap { |h| input.each { |k, v| h[k] = v } }
              end
              if mode == :proc && hash.respond_to?(:default_proc=)
                hash.default_proc = proc { |_, key| $events << ['default', key]; 73 }
              elsif mode == :identity && hash.respond_to?(:compare_by_identity)
                hash.compare_by_identity
              end
              hash.freeze if frozen
              result = method == :to_json ? hash.to_json : hash.to_hash(opts)
              result = result.gsub(/0x[0-9a-f]+/, 'ADDR') if method == :to_json
              seen = {}
              output = [snapshot(result, seen), snapshot(source, seen), snapshot(hash, seen), $events]
            rescue Exception => e
              output = ['error', e.class.name, e.message.lines.first.strip.gsub(/0x[0-9a-f]+/, 'ADDR'), $events]
            end
            puts JSON.generate([klass.name, index, oi, frozen, mode, method, output])
          end
        end
      end
    end
  end
end
