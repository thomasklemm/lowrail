#!/usr/bin/env bash
set -euo pipefail
root=$(pwd)
dir="$root/.amp/in/orb-backup/astra-HM5"
cells=("$@")
[[ ${#cells[@]} == 0 ]] && cells=(3.0.7 3.1.7 3.2.10 3.3.10 3.4.7 4.0.10 4.0.10-yjit master-zjit)
for cell in "${cells[@]}"; do
  flags=()
  version=${cell%-yjit}; version=${version%-zjit}
  ruby="$HOME/.local/share/mise/installs/ruby/$version/bin/ruby"
  [[ $cell == *-yjit ]] && flags=(--yjit)
  [[ $cell == *-zjit ]] && flags=(--zjit)
  [[ $version == master ]] && ruby="$root/.amp/in/orb-backup/ruby-master-install/bin/ruby"
  [[ -x $ruby ]] || { echo "unavailable $cell"; continue; }
  "$ruby" "${flags[@]}" -v > "$dir/outputs/$cell-version.txt"
  for side in base head; do
    lib="$root/.amp/in/orb-backup/hashie/lib"
    [[ $side == base ]] && lib="$root/.amp/in/orb-backup/hashie-base/lib"
    for probe in repros adversarial original edges; do
      file="$dir/$probe.rb"
      [[ $probe == original ]] && file="$root/bench/upstream/hashie_perf/round2/probes/to_hash_diff.rb"
      "$ruby" "${flags[@]}" -I "$lib" "$file" > "$dir/outputs/$cell-$probe-$side.jsonl" 2> "$dir/outputs/$cell-$probe-$side.err"
    done
  done
  for probe in repros adversarial original edges; do
    diff -u "$dir/outputs/$cell-$probe-base.jsonl" "$dir/outputs/$cell-$probe-head.jsonl" > "$dir/outputs/$cell-$probe.diff" || test $? = 1
  done
  echo "completed $cell"
done
