#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "$(dirname "$0")")
repo=$(realpath "$root/../../../..")
for version in "$@"; do
  ruby="$root/rubies/$version/bin/ruby"
  for mode in interp yjit zjit; do
    flags=()
    case "$mode" in
      yjit) "$ruby" --yjit -e 'exit defined?(RubyVM::YJIT) && RubyVM::YJIT.enabled? ? 0 : 1' >/dev/null 2>&1 || continue; flags=(--yjit);;
      zjit) "$ruby" --zjit -e 'exit defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled? ? 0 : 1' >/dev/null 2>&1 || continue; flags=(--zjit);;
    esac
    for side in base head; do
      lib="$root/../hashie/lib"
      test "$side" != base || lib="$root/../hashie-base/lib"
      for probe in repros public_diff; do
        "$ruby" "${flags[@]}" -I"$lib" "$root/$probe.rb" > "$root/evidence/$probe-$version-$mode-$side.jsonl" 2> "$root/evidence/$probe-$version-$mode-$side.stderr"
      done
      if [[ "$version" == 4.0.10 || "$version" == master ]]; then
        "$ruby" "${flags[@]}" -I"$lib" "$repo/bench/upstream/hashie_perf/round2/probes/quiet_diff.rb" > "$root/evidence/original-$version-$mode-$side.txt" 2> "$root/evidence/original-$version-$mode-$side.stderr"
      fi
    done
    echo "completed $version $mode"
  done
done
