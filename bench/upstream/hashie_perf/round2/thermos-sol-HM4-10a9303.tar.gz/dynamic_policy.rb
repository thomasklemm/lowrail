require 'hashie'
require 'logger'
require 'stringio'
require 'json'

log = StringIO.new
Hashie.logger = Logger.new(log)

class BudgetPolicy < Hashie::Mash
  def self.disable_warnings?(_key = nil)
    @queries = @queries.to_i + 1
    (@queries % 3).zero?
  end
end

value = BudgetPolicy.new(name: 0, size: 7)
puts JSON.generate(value: value.to_h, warnings: log.string.scan(/You are setting a key/).size)

class MissingMaterializer < Hashie::Mash
  disable_warnings

  def respond_to_missing?(key, *rest)
    regular_writer('checked', true) if key == :name
    super
  end
end

puts JSON.generate(value: MissingMaterializer.new(name: 7).to_h)
