# frozen_string_literal: true

require 'hashie'
require 'logger'
require 'stringio'
require 'json'

LOG = StringIO.new
Hashie.logger = Logger.new(LOG)

def run(label)
  LOG.truncate(0)
  LOG.rewind
  value = yield
  puts JSON.generate(label: label, value: value, warnings: LOG.string.scan(/You are setting a key/).size)
rescue Exception => error
  puts JSON.generate(label: label, error: error.class.name, message: error.message.gsub(/0x[0-9a-f]+/, 'X'), warnings: LOG.string.scan(/You are setting a key/).size)
end

class ListPolicy < Hashie::Mash
  def self.disabled_warnings
    [:size]
  end
end

run('overridden list query') { ListPolicy.disable_warnings?(:size) }
run('overridden list write') { ListPolicy.new(size: 7).to_h }

class QuietRactorMash < Hashie::Mash
  disable_warnings
end
QuietRactorMash.new(name: 0)
run('quiet Ractor new key') do
  worker = Ractor.new do
    begin
      QuietRactorMash.new(name: 7).to_h
    rescue Exception => error
      [error.class.name, error.message]
    end
  end
  worker.respond_to?(:value) ? worker.value : worker.take
end

class FilterPolicy < Hashie::Mash
  def self.disable_warnings?(key = nil)
    return super if key.nil? || key == :size

    raise KeyError, "policy has no entry for #{key}"
  end
end
run('extra policy call on noncollision') { FilterPolicy.new(name: 7).to_h }

class MaterializingMash < Hashie::Mash
  disable_warnings

  def respond_to?(key, *rest)
    regular_writer('checked', true) if key == :name
    super
  end
end
run('skipped public respond_to? side effect') { MaterializingMash.new(name: 7).to_h }

class FrozenPolicy < Hashie::Mash; end
FrozenPolicy.freeze
run('frozen class noncollision') { FrozenPolicy.new(name: 7).to_h }
run('frozen class collision') { FrozenPolicy.new(size: 7).to_h }
run('frozen class query') { FrozenPolicy.disable_warnings? }

class OverridingQuietMash < Hashie::Mash
  disable_warnings
  include Hashie::Extensions::MethodAccessWithOverride
end
run('MethodAccessWithOverride respond_to?') do
  OverridingQuietMash.new('respond_to?' => 1, 'name' => 2).to_h
end

class HookPolicy < Hashie::Mash
  def self.disabled_warnings
    @policy ||= [:size]
  end
end
run('lazy overridden list') { HookPolicy.new(size: 7).to_h }

class InheritedListPolicy < ListPolicy; end
run('inherited overridden list query') { InheritedListPolicy.disable_warnings?(:size) }
run('inherited overridden list write') { InheritedListPolicy.new(size: 7).to_h }
