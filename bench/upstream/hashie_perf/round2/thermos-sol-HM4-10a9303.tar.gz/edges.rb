# frozen_string_literal: true

require 'hashie'
require 'logger'
require 'stringio'
require 'json'
Hashie.logger = Logger.new(nil)

class CountingMash < Hashie::Mash
  attr_reader :queries, :missing_queries

  def respond_to?(key, *rest)
    (@queries ||= []) << key
    super
  end

  def respond_to_missing?(key, *rest)
    (@missing_queries ||= []) << key
    super
  end
end
[:size, :unseen, 7, nil].each do |key|
  mash = CountingMash.new
  mash[key] = 1
  puts JSON.generate(['claim every write / unset key', key, mash.queries, mash.missing_queries, mash.to_h])
end

class PlainRactor < Hashie::Mash; end
class AllRactor < Hashie::Mash
  disable_warnings
end
class SomeRactor < Hashie::Mash
  disable_warnings(:size)
end
class PrimedRactor < Hashie::Mash
  disabled_warnings
end
class FrozenRactor < Hashie::Mash; end
FrozenRactor.freeze
[PlainRactor, AllRactor, SomeRactor, PrimedRactor, FrozenRactor].each { |klass| klass.new(name: 1) }
[PlainRactor, AllRactor, SomeRactor, PrimedRactor, FrozenRactor].each do |klass|
  worker = Ractor.new(klass) do |type|
    begin
      type.new(name: 2).to_h
    rescue Exception => error
      [error.class.name, error.message]
    end
  end
  puts JSON.generate(['Ractor class', klass.name, worker.respond_to?(:value) ? worker.value : worker.take])
end

class PolicyProbe < Hashie::Mash
  def self.disabled_warnings
    Thread.current[:list] || []
  end
end
Thread.current[:list] = [:size]
puts JSON.generate(['thread-local list query', PolicyProbe.disable_warnings?(:size)])

class MutatingKey
  def initialize(klass)
    @klass = klass
  end

  def to_sym
    @klass.disable_warnings(:size)
    :size
  end

  def to_s
    'size'
  end
end
type = Class.new(Hashie::Mash)
puts JSON.generate(['configure during conversion', type.new(MutatingKey.new(type) => 3).to_h])

[:false, :nil, :list, :empty, :true].each do |variant|
  klass = Class.new(Hashie::Mash)
  case variant
  when :false then klass.instance_variable_set(:@disable_warnings, false)
  when :nil then klass.instance_variable_set(:@disabled_warnings, nil)
  when :list then klass.instance_variable_set(:@disabled_warnings, [:size])
  when :empty then klass.instance_variable_set(:@disabled_warnings, [])
  when :true then klass.instance_variable_set(:@disable_warnings, true)
  end
  values = [nil, :size, :name, 'size'].map { |key| klass.disable_warnings?(key) }
  puts JSON.generate(['direct ivars query', variant, values])
end

[:inherit, :prepend, :extend].each do |mode|
  mod = Module.new do
    def disabled_warnings
      [:size]
    end
  end
  klass = Class.new(Hashie::Mash)
  case mode
  when :prepend then klass.singleton_class.prepend(mod)
  when :extend then klass.extend(mod)
  when :inherit
    klass.extend(mod)
    klass = Class.new(klass)
  end
  puts JSON.generate(['list mixin query', mode, klass.disable_warnings?(:size)])
end

frozen = Class.new(Hashie::Mash) { disable_warnings }.new.freeze
begin
  frozen[:name] = 3
rescue StandardError => error
  puts JSON.generate(['frozen receiver', error.class.name, frozen.to_h])
end
