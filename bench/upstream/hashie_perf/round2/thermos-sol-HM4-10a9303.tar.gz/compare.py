import collections
import glob
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
for filename in sorted(glob.glob(str(root / 'evidence/*-base.jsonl'))):
    base = pathlib.Path(filename)
    head = pathlib.Path(filename.replace('-base.jsonl', '-head.jsonl'))
    if not head.exists():
        continue
    a = [json.loads(line) for line in base.read_text().splitlines()]
    b = [json.loads(line) for line in head.read_text().splitlines()]
    assert len(a) == len(b)
    differences = [(old, new) for old, new in zip(a, b) if old != new]
    print(base.name, len(a), 'rows;', len(differences), 'differences')
    groups = collections.Counter((old[0], tuple(i for i, (x, y) in enumerate(zip(old, new)) if x != y)) for old, new in differences) if a and isinstance(a[0], list) else None
    if groups:
        print(dict(groups))
    with base.with_name(base.name.replace('-base.jsonl', '-diff.jsonl')).open('w') as output:
        for pair in differences:
            output.write(json.dumps(pair) + '\n')
for base in sorted((root / 'evidence').glob('original-*-base.txt')):
    head = base.with_name(base.name.replace('-base.txt', '-head.txt'))
    if not head.exists():
        continue
    a, b = base.read_text().splitlines(), head.read_text().splitlines()
    assert len(a) == len(b)
    differences = [(old, new) for old, new in zip(a, b) if old != new]
    print(base.name, len(a), 'rows;', len(differences), 'differences; non-accepted', sum(not x.startswith('accepted') for x, _ in differences))
