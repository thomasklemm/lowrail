import json
import os
import pathlib
import random
import statistics
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
ruby = root / 'rubies' / sys.argv[1] / 'bin/ruby'
mode = sys.argv[2]
mode_tag = mode + ('-primed' if os.getenv('PRIME_LIST') == '1' else '')
flags = [] if mode == 'interp' else ['--' + mode]
for order in ['plain', 'mixed']:
    rounds = []
    for repeat in range(6):
        sides = ['base', 'head', 'base2']
        random.Random(repeat).shuffle(sides)
        row = {}
        for side in sides:
            lib = root.parent / ('hashie' if side == 'head' else 'hashie-base') / 'lib'
            command = ['taskset', '-c', str(min(os.sched_getaffinity(0))), str(ruby), *flags, '-I' + str(lib), str(root / 'perf.rb'), order]
            output = subprocess.check_output(command, text=True)
            (root / 'evidence' / f'perf-{sys.argv[1]}-{mode_tag}-{order}-{repeat}-{side}.json').write_text(output)
            row[side] = json.loads(output)['samples']
        rounds.append(row)
    print(sys.argv[1], mode_tag, order)
    results = []
    for name in rounds[0]['base']:
        estimates = [{side: sorted(row[side][name])[1] for side in ['base', 'head', 'base2']} for row in rounds]
        change = statistics.median([item['head'] / item[side] - 1 for item in estimates for side in ['base', 'base2']])
        aa = statistics.median([item['base2'] / item['base'] - 1 for item in estimates])
        results.append((change, name, aa))
    for change, name, aa in sorted(results, reverse=True):
        print(f'{name:22} {change * 100:+.2f}% A/A {aa * 100:+.2f}%')
