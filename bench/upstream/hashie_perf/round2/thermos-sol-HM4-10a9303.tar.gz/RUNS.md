# HM4 thermos-sol execution record

Review date requested: 2026-11-27. Thread T-01a21f5c-5173-76cc-aa9a-676d6e5f0c2d.
Model GPT-6.1 Sol xhigh; both rubrics applied in the same thread, no delegation.
Lowrail initially ef4bb88df2a53259aba9b6749ecc3b5b71781597, descendant of required 6c86087f.
Hashie head 10a93033975136664d7b7231986663e9c7689d91, direct parent/base
277e88e6ccc317497e6c20fb8b9e35abebc0fe19. Neither checkout edited.

The outer tar.gz contains scripts, source snapshots and API responses. Extract
raw-evidence.tar.xz to obtain every raw output, including preliminary/noisy ones.
Ruby builds and installed gems are not archived. setup-rubies.sh records downloads;
build logs and ruby-*.txt record versions and master pin. Paths in scripts reflect
the original .amp/in/orb-backup/HM4-review location; restore there or adjust paths.

## Runtime commands

`bash setup-rubies.sh` downloaded the pinned releases and built 3.0.7 and master.
3.0.7 was built without OpenSSL; no TLS test is claimed. Master supports YJIT/ZJIT.
`bash run-matrix.sh 3.0.7 3.1.7 3.2.10 3.3.10 3.4.7 4.0.10 master` was run in batches.
It runs repros.rb/public_diff.rb against each checkout in interpreter and every
available YJIT/ZJIT mode, plus the existing quiet_diff.rb on 4.0.10/master.
`edges.rb` was run against both checkouts on every release and master/ZJIT:

    rubies/V/bin/ruby [--yjit|--zjit] -I../hashie[-base]/lib edges.rb

The independent public_diff.rb originally left anonymous-class addresses in
exception text. Final corrected, normalized interpreter snapshots for releases
are public-final-V-{base,head}.jsonl; master snapshots public_diff-master-* were
run after correction. Earlier files retain normalization noise, not new defects.
`python3 compare.py > evidence/comparison.txt` compares and retains all differences.
All original quiet_diff comparisons have 66,999 lines/21 differences, 18 substantive.

`dynamic_policy.rb` was run on master interpreter and ZJIT with both libraries.
It demonstrates changed warnings for a Boolean-returning stateful public predicate
and changed stored state through respond_to_missing?, not only hook counts.

## Timing commands and limitations

Orb: 2 online CPUs, 3,931 MiB total RAM (`getconf _NPROCESSORS_ONLN`, `free -m`).
Not a1.xxlarge. All new timings are diagnostic only, not upstream body evidence.

    python3 -u perf.py 4.0.10 yjit
    python3 -u perf.py master zjit
    python3 -u perf.py 4.0.10 interp
    PRIME_LIST=1 python3 -u perf.py master zjit

Each keeps six randomized base/head/base2 rounds, thirteen operations in separate
plain-only/mixed processes, seven GC-off thread-CPU windows, core pinned. Analysis
uses the second-fastest of seven windows/process, median relative head/base and
head/base2, and median base2/base. No bootstrap or JIT-flat gate is asserted here.
The first YJIT screen overlapped builds; unaffected-empty control drift makes it
unusable. It is retained and was not rerun until green. The other two are independent
runtime questions, not replacements for the rejected YJIT run. Every sample is kept.
Unprimed sweeps' worst changed mixed point estimates: interpreter overwrite-question +4.29% (A/A
+0.19%); master ZJIT questions20 +2.67% (A/A -0.46%). These do not refute archived
older-master +9.108% nested-fixture timing. No a1.xxlarge confirmation was run.
After the independent audit, origin/main contained a concurrent Astra review
identifying the inspected-empty-list state. The final PRIME_LIST sweep checks that
separate caller state directly: Hashie::Mash.disabled_warnings is called once
before constructing anything. The list remains empty and no warning was disabled.
No prior output is overwritten; these samples use the zjit-primed file tag.
Largest primed mixed point estimate: new question key +10.70%, A/A +0.36%.
Plain-only primed: flat20 +7.26%, A/A -0.69%; repository +6.10%, A/A -0.22%.

## Existing raw-evidence audit

    rubies/4.0.10/bin/ruby audit_raw.rb > evidence/raw-recomputed.txt
    python3 audit_files.py > evidence/archive-crosscheck.txt

audit_raw.rb loads Lowrail's actual wall_cell estimator and recomputes round arrays,
confidence intervals, A/A and JIT-flat decisions from every HM4 results.json. The
Python script checks all wall samples against raw worker logs, exact-head Callgrind
totals and every printed Duel CPU row against the raw archived Duel logs. Both
completed; stderr files empty. It did not rerun Callgrind or GitHub-hosted Duel.

Read out/profile-stackprof-4.0.10-{interp,yjit}.txt and out/zjit-mixed-order.txt,
and the refused-form patches. The latter statistics are earlier forms, not a new
causal experiment on the exact head. Their numerical records were recomputed.

## Suite and maintainability commands

Installed tools into scratch gems directory, GEM_HOME/GEM_PATH set to it and
PATH prefixed with rubies/4.0.10/bin. In each hashie checkout:

    ruby -Ilib -S rspec spec/hashie/mash_spec.rb spec/hashie/extensions/mash
    ruby -Ilib -S rspec
    ruby -Ilib -S rspec spec/release_preparation_spec.rb
    ruby -Ilib -S rubocop
    ruby -Ilib -S rubocop --config ../HM4-review/metrics.yml --format json lib/hashie/mash.rb lib/hashie/extensions/key_conflict_warning.rb
    ruby -Ilib -S flog -a lib/hashie/mash.rb lib/hashie/extensions/key_conflict_warning.rb

Final targeted base/head commands and results are retained in validation.sh and
evidence/validation-*.log. Full head 1,076/3; same three release-preparation failures
reproduced on base (subprocess Bundler cannot find guard). RuboCop 156 files has
the same two existing RSpec/EmptyLineAfterSharedInclusion offenses on both sides.
On head, executable docs ran through rake docs:examples, 359/0. No all-green claim.
RuboCop 1.93.0, rubocop-rspec 3.11.0, flog 4.10.0. Metrics raw JSON and flog text kept.

## Public fact checks

Read-only GitHub CLI API requests, responses preserved at top level/sources:

    gh api repos/thomasklemm/hashie/actions/runs/46079366956
    gh api repos/thomasklemm/hashie/pulls/36
    gh api 'repos/hashie/hashie/issues?state=all&per_page=1&sort=created&direction=desc'
    gh api 'repos/hashie/hashie/pulls?state=open&per_page=100'
    gh api repos/hashie/hashie/issues/662
    gh api repos/hashie/hashie/issues/663

Latest issue 661, both 662/663 404, open PR list empty; thus next number 662 at check.
Also searched warning-related issues/commits and Ractor issues; snapshots are in
sources/upstream. No upstream PR exists for this candidate to read a review of.
Fork PR 36 is closed; its exact head and base agree with retained Duel logs.

For omniauth, elasticsearch-model, zendesk_api, restforce, chef-zero, and hashie:
fetched https://rubygems.org/api/v1/gems/NAME.json and corresponding GitHub repo
metadata with gh api; downloaded each latest gem from rubygems.org and inspected
gemspec requirements and Mash subclasses. API JSONs include download counts,
latest release dates, repo stars/archived flags. Current-branch and release-tag
responses and source files are preserved. The two body permalink raw blobs were
downloaded and compared to the latest gem sources; KeyStore line 8/HashWrapper
line 29 match, AuthHash inherits KeyStore. Default branches retain these callers.
Release constraints permit hashie 6 for the first three consumers and exclude it
for restforce/chef-zero. Lifetime downloads do not measure actual hashie-6 use.

## Disposition

Changes: R1 Ractor writes now fail; R2 semipublic list policies now warn. Detailed
minimal reproductions, intended/accepted boundaries, text findings, reach table,
performance judgment and both rubric conclusions are in the appended round2
README section. No candidate fixes applied, no fork push/PR/upstream comment.
