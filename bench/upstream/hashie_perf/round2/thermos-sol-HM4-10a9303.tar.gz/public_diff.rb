# frozen_string_literal: true

require 'hashie'
require 'logger'
require 'stringio'
require 'json'

LOG = StringIO.new
Hashie.logger = Logger.new(LOG)
H_EACH = Hash.instance_method(:each_pair)
H_DEFAULT = Hash.instance_method(:default)
H_PROC = Hash.instance_method(:default_proc)

def snapshot(value)
  case value
  when Hash
    [value.class.name || 'anon', value.frozen?, Hash.ruby2_keywords_hash?(value), H_DEFAULT.bind_call(value), !!H_PROC.bind_call(value), H_EACH.bind_call(value).map { |k, v| [snapshot(k), snapshot(v)] }]
  when Array
    [value.class.name, value.frozen?, value.map { |v| snapshot(v) }]
  when String
    [value.class.name, value.to_s, value.encoding.name, value.frozen?]
  else
    [value.class.name, value.inspect.gsub(/0x[0-9a-f]+/, 'X')]
  end
end

def sub(parent = Hashie::Mash, &block)
  Class.new(parent, &block)
end

plain = sub
quiet = sub { disable_warnings }
some = sub { disable_warnings(:size, :zip) }
classes = {
  'Mash' => Hashie::Mash,
  'plain' => plain,
  'quiet' => quiet,
  'some' => some,
  'String list' => sub { disable_warnings('size') },
  'twice' => sub { disable_warnings(:size); disable_warnings(:zip) },
  'narrowed' => sub { disable_warnings; disable_warnings(:size) },
  'widened' => sub { disable_warnings(:size); disable_warnings },
  'inherit all' => sub(quiet),
  'inherit some' => sub(some),
  'child narrows' => sub(quiet) { disable_warnings(:size) },
  'direct list' => sub { disabled_warnings << :size },
  'direct flag' => sub { @disable_warnings = true },
  'direct ivars' => sub { @disable_warnings = false; @disabled_warnings = [:size] },
  'list override' => sub { def self.disabled_warnings; [:size]; end },
  'predicate override' => sub { def self.disable_warnings?(key = nil); key == :size; end },
  'private predicate override' => sub { def self.disable_warnings?(key = nil); key == :size; end; private_class_method :disable_warnings? },
  'public respond override' => sub { disable_warnings; def respond_to?(*args); super; end },
  'missing override' => sub { disable_warnings; def respond_to_missing?(*args); super; end },
  'private collision super' => sub { disable_warnings; private; def _log_collision?(key); super; end },
  'frozen plain' => sub.freeze,
  'frozen quiet' => sub { disable_warnings }.freeze,
  'frozen some' => sub { disable_warnings(:size) }.freeze,
  'quiet macro' => Hashie::Mash.quiet,
  'quiet macro some' => Hashie::Mash.quiet(:size)
}
[:PermissiveRespondTo, :DefineAccessors, :StrictKeyAccess, :SafeAssignment, :KeepOriginalKeys, :SymbolizeKeys].each do |extension|
  mod = Hashie::Extensions::Mash.const_get(extension)
  { 'all' => [], 'some' => [:size], 'none' => nil }.each do |setting, keys|
    classes["#{extension} #{setting}"] = sub do
      include mod
      disable_warnings(*keys) if keys
    end
  end
end
classes['MethodAccessWithOverride all'] = sub { disable_warnings; include Hashie::Extensions::MethodAccessWithOverride }
classes['MethodAccessWithOverride some'] = sub { disable_warnings(:size); include Hashie::Extensions::MethodAccessWithOverride }

class HashValue < Hash; end
class ArrayValue < Array; end
class StringKey < String; end
class DuckKey
  def to_sym; :size; end
  def to_s; 'size'; end
end

keys = ['size', :size, :name, 'other', :zip, 'name?', 'name!', 'name_', 'name=', 'respond_to?', :class, :default, :method_missing, nil, 7, StringKey.new('size'), DuckKey.new]
values = [Hash.ruby2_keywords_hash({x: 7}), HashValue[x: 8], ArrayValue.new([1, {x: 9}]), 'value'.freeze]
operations = {
  'write' => ->(m, k, v) { m[k] = v },
  'setter' => ->(m, k, v) { m.public_send("#{k}=", v) },
  'new' => ->(m, k, v) { m.class.new(k => v) },
  'update' => ->(m, k, v) { m.update(k => v) },
  'merge' => ->(m, k, v) { m.merge(k => v) { |_key, old, new| [old, new] } },
  'replace' => ->(m, k, v) { m.replace(k => v) },
  'dup' => ->(m, k, v) { m[k] = v; m.dup },
  'shallow' => ->(m, k, v) { m.shallow_update(k => v) }
}
classes.each do |label, klass|
  keys.each_with_index do |key, ki|
    operations.each do |operation, block|
      [false, true].each do |frozen|
        LOG.truncate(0)
        LOG.rewind
        mash = nil
        result = nil
        error = nil
        begin
          mash = klass.new('existing' => 1) { |_h, _k| :fallback }
          mash.freeze if frozen
          result = block.call(mash, key, values[ki % values.size])
        rescue Exception => exception
          error = [exception.class.name, exception.message.gsub(/0x[0-9a-f]+/, 'X').gsub(/#<Class:X>/, 'anon')]
        end
        warnings = LOG.string.lines.grep(/You are setting a key/).map { |line| line.split('built-in method ', 2).last.split(' ', 2).first.gsub(/0x[0-9a-f]+/, 'X') }
        puts JSON.generate([label, ki, operation, frozen, error, snapshot(result), snapshot(mash), warnings])
      end
    end
  end
end

late = sub
instance = late.new('before' => 1)
late.disable_warnings(:size)
LOG.truncate(0)
LOG.rewind
instance[:size] = 4
puts JSON.generate(['late configuration', snapshot(instance), LOG.string.empty?])

thread_class = sub { disable_warnings(:size) }
results = 4.times.map do |n|
  Thread.new do
    20.times.map { |i| thread_class.new(size: n + i, name: n).to_h }
  end
end.map(&:value)
puts JSON.generate(['threads configured before use', results])
