#!/usr/bin/env bash
set -uo pipefail
root=$(realpath "$(dirname "$0")")
export GEM_HOME="$root/gems" GEM_PATH="$root/gems"
export PATH="$root/rubies/4.0.10/bin:$root/gems/bin:$PATH"
for side in base head; do
  path="$root/../hashie"
  test "$side" != base || path="$root/../hashie-base"
  (
    cd "$path" || exit 1
    ruby -Ilib -S rspec spec/hashie/mash_spec.rb spec/hashie/extensions/mash
  ) > "$root/evidence/validation-$side.log" 2>&1
  printf '%s status=%s\n' "$side" "$?"
  tail -4 "$root/evidence/validation-$side.log"
done
