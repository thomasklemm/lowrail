require 'hashie'

class QuietWorkerMash < Hashie::Mash
  disable_warnings
end

QuietWorkerMash.new(name: 0)
worker = Ractor.new { QuietWorkerMash.new(name: 7).to_h }
begin
  p(worker.respond_to?(:value) ? worker.value : worker.take)
rescue Exception => error
  p [error.class.name, error.cause.class.name]
end
