# frozen_string_literal: true

require 'json'
root = File.expand_path('../../../..', __dir__)
source = File.read(File.join(root, 'script/upstream-bench'))
eval(source[source.index('WALL_QUANTILE = 0.1')...source.index('def ci(c)')], TOPLEVEL_BINDING)
paths = Dir[File.join(root, 'bench/upstream/hashie_perf/round2/{body/HM4,body/HM4-module-f41c3b2,wall/HM4-*}/results.json')]
paths.each do |path|
  data = JSON.parse(File.read(path))
  puts "FILE #{path.delete_prefix(root + '/')}"
  data.fetch('instructions', {}).each do |name, cell|
    change = cell['candidate'] / ((cell['base1'] + cell['base2']) / 2.0) - 1
    raise "instruction mismatch #{name}" unless (change - cell['change']).abs < 1e-12
    puts "instructions #{name}: #{(change * 100).round(3)}%, A/A #{(cell['aa'] * 100).round(3)}%"
  end
  data.fetch('wall', {}).each do |name, cell|
    recomputed = wall_cell(cell.fetch('rounds'), cell.fetch('calls'))
    recomputed[:claim] = false if cell['jit'] && !cell['jit']['flat']
    %i[base candidate change change_ci aa aa_ci aa_pass claim].each do |field|
      raise "wall mismatch #{name} #{field}" unless recomputed[field] == cell[field.to_s]
    end
    puts "wall #{name}: #{(cell['change'] * 100).round(3)}% #{cell['change_ci'].map { |x| (x * 100).round(3) }} A/A #{(cell['aa'] * 100).round(3)}% #{cell['aa_ci'].map { |x| (x * 100).round(3) }} rounds=#{cell['rounds'].size} claim=#{cell['claim']} flat=#{cell.dig('jit', 'flat')}"
  end
end
