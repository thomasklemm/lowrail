import json
import pathlib
import re
import tarfile

root = pathlib.Path(__file__).resolve().parents[4]
round2 = root / 'bench/upstream/hashie_perf/round2'
paths = [round2 / 'body/HM4', round2 / 'body/HM4-module-f41c3b2', *sorted((round2 / 'wall').glob('HM4-*'))]
for path in paths:
    result = json.loads((path / 'results.json').read_text())
    with tarfile.open(path / 'raw.tar.gz') as archive:
        for label, cell in result.get('wall', {}).items():
            for index, row in enumerate(cell['rounds'], 1):
                for side, samples in row.items():
                    text = archive.extractfile(f'raw/wall-r{index}-{side}.log').read().decode()
                    recorded = dict(line[5:].split('\t', 1) for line in text.splitlines() if line.startswith('wall '))
                    assert samples == json.loads(recorded[label]), (path, label, index, side)
    print(path.relative_to(root), 'all wall samples match raw worker logs')

for topic in ['HM4', 'HM4-module-f41c3b2']:
    with tarfile.open(round2 / f'body/{topic}/raw.tar.gz') as archive:
        data = json.loads((round2 / f'body/{topic}/results.json').read_text())
        cases = list(data['wall'])
        for label, cell in data['instructions'].items():
            mode, name = label.split(' ', 1)
            index = cases.index(name) + 1
            for side in ['base', 'candidate', 'base2']:
                files = [m.name for m in archive.getmembers() if m.name.startswith(f'raw/ir-{mode}-{index}-') and m.name.endswith(f'-{side}-n0.callgrind')]
                assert len(files) == 1
                zero = archive.extractfile(files[0]).read().decode()
                nfile = files[0].replace('-n0.callgrind', f'-n{data["n"]}.callgrind')
                run = archive.extractfile(nfile).read().decode()
                total = lambda content: int(re.search(r'^totals: (\d+)', content, re.M)[1])
                instructions = (total(run) - total(zero)) / data['n']
                field = 'base1' if side == 'base' else side
                assert instructions == cell[field], (label, side, instructions, cell[field])
        print(archive.name, 'all instruction deltas match raw Callgrind files')

with tarfile.open(round2 / 'duel/logs.tar.gz') as archive:
    for mode in ['yjit', 'zjit']:
        log = archive.extractfile(f'./46079366956-{mode}___Duel__{mode}_.log').read().decode()
        summary = (round2 / f'duel/46079366956-{mode}.summary.txt').read_text()
        for line in summary.splitlines():
            if line.startswith('  ') and ' cpu ' in line:
                assert line in log, (mode, line)
        assert '10a93033975136664d7b7231986663e9c7689d91' in log
        assert '277e88e6ccc317497e6c20fb8b9e35abebc0fe19' in log
        assert '28 benchmarks' in log and '0 regressed' in log
        print('Duel', mode, 'all printed CPU rows and exact head/base match raw log')
    for run in ['46071221821', '46077591328', '46077594232', '46068675920']:
        for mode in ['yjit', 'zjit']:
            log = archive.extractfile(f'./{run}-{mode}___Duel__{mode}_.log').read().decode()
            summary = (round2 / f'duel/{run}-{mode}.summary.txt').read_text()
            for line in summary.splitlines():
                if line.startswith('  ') and ' cpu ' in line:
                    assert line in log, (run, mode, line)
            print('Duel', run, mode, 'all printed CPU rows match raw log')
