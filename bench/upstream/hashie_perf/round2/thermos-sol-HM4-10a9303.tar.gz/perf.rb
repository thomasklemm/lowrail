# frozen_string_literal: true

require 'hashie'
require 'logger'
require 'json'
Hashie.logger = Logger.new(nil)
Hashie::Mash.disabled_warnings if ENV['PRIME_LIST'] == '1'
class QuietPerfMash < Hashie::Mash
  disable_warnings
end
fixture = JSON.parse(File.read(File.expand_path('../../../../bench/upstream/hashie_perf/round2/fixtures/github-org-repos.json', __dir__))).first
order = ARGV.fetch(0)
3000.times { QuietPerfMash.new(fixture) } if order == 'mixed'
plain = Hashie::Mash.new('existing' => 1, 'ready?' => true)
cases = {
  'empty' => -> { Hashie::Mash.new },
  'symbol absent' => -> { Hashie::Mash.new(name: 1) },
  'string absent' => -> { Hashie::Mash.new('name' => 1) },
  'question key' => -> { Hashie::Mash.new('ready?' => true) },
  'bang key' => -> { Hashie::Mash.new('ready!' => 1) },
  'underscore key' => -> { Hashie::Mash.new('ready_' => 1) },
  'equals key' => -> { Hashie::Mash.new('ready=' => 1) },
  'integer key' => -> { Hashie::Mash.new(7 => 1) },
  'overwrite' => -> { plain['existing'] = 1 },
  'overwrite question' => -> { plain['ready?'] = true }
}
flat = (1..20).to_h { |n| ["field#{n}", n] }
questions = (1..20).to_h { |n| ["field#{n}?", n] }
cases['flat20'] = -> { Hashie::Mash.new(flat) }
cases['questions20'] = -> { Hashie::Mash.new(questions) }
cases['repository'] = -> { Hashie::Mash.new(fixture) }
cases.each_value { |call| 4000.times { call.call } }
result = {}
cases.each do |label, call|
  n = label == 'repository' ? 200 : 4000
  samples = 7.times.map do
    GC.start
    GC.disable
    start = Process.clock_gettime(Process::CLOCK_THREAD_CPUTIME_ID)
    n.times { call.call }
    elapsed = Process.clock_gettime(Process::CLOCK_THREAD_CPUTIME_ID) - start
    GC.enable
    elapsed / n
  end
  result[label] = samples
end
puts JSON.generate(ruby: RUBY_DESCRIPTION, order: order, samples: result)
