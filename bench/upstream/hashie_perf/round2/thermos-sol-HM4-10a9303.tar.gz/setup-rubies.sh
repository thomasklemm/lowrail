#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "$(dirname "$0")")
mkdir -p "$root"/{rubies,builds,evidence,sources}
for version in 3.1.7 3.2.10 3.3.10 3.4.7 4.0.10; do
  prefix="$root/rubies/$version"
  curl -fLsS "https://github.com/ruby/ruby-builder/releases/download/ruby-$version/ruby-$version-ubuntu-22.04-x64.tar.gz" -o "$root/builds/prebuilt-$version.tar.gz"
  mkdir -p "$prefix"
  tar xzf "$root/builds/prebuilt-$version.tar.gz" --strip-components=1 -C "$prefix"
  sudo mkdir -p "/opt/hostedtoolcache/Ruby/$version"
  sudo ln -sfn "$prefix" "/opt/hostedtoolcache/Ruby/$version/x64"
  "$prefix/bin/ruby" -e 'puts RUBY_DESCRIPTION; require "json"; require "logger"' | tee "$root/evidence/ruby-$version.txt"
done
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.9/bin:$HOME/.cargo/bin:$PATH"
version=3.0.7
curl -fLsS "https://cache.ruby-lang.org/pub/ruby/3.0/ruby-$version.tar.xz" -o "$root/builds/ruby-$version.tar.xz"
tar xJf "$root/builds/ruby-$version.tar.xz" -C "$root/builds"
(
  cd "$root/builds/ruby-$version"
  ./configure --prefix="$root/rubies/$version" --disable-install-doc --with-out-ext=openssl --disable-yjit
  make -j2
  make install
) > "$root/evidence/build-$version.log" 2>&1
"$root/rubies/$version/bin/ruby" -v | tee "$root/evidence/ruby-$version.txt"
git clone --quiet --depth 1 https://github.com/ruby/ruby.git "$root/builds/ruby-master"
git -C "$root/builds/ruby-master" rev-parse HEAD > "$root/evidence/ruby-master-pin.txt"
(
  cd "$root/builds/ruby-master"
  ./autogen.sh
  ./configure --prefix="$root/rubies/master" --disable-install-doc --enable-yjit --enable-zjit --with-out-ext=openssl
  make -j2
  make install
) > "$root/evidence/build-master.log" 2>&1
"$root/rubies/master/bin/ruby" --zjit -v | tee "$root/evidence/ruby-master.txt"
