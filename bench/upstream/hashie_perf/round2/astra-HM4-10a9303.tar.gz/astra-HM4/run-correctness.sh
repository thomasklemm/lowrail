#!/usr/bin/env bash
set -eu
root=/home/user/workspace/repo
out=$root/.amp/in/orb-backup/astra-HM4
versions=("$@")
for version in "${versions[@]}"; do
  ruby="$HOME/.local/share/mise/installs/ruby/$version/bin/ruby"
  flags=()
  case "$version" in
    4.0.10-yjit) ruby="$HOME/.local/share/mise/installs/ruby/4.0.10/bin/ruby"; flags=(--yjit);;
    4.0.10-zjit) ruby="$HOME/.local/share/mise/installs/ruby/4.0.10/bin/ruby"; flags=(--zjit);;
    master-zjit) ruby="$root/.amp/in/orb-backup/ruby-master/bin/ruby"; flags=(--zjit);;
  esac
  "$ruby" "${flags[@]}" -v > "$out/version-$version.txt"
  for side in base head; do
    tree="$root/.amp/in/orb-backup/hashie"
    [ "$side" = base ] && tree="$tree-base"
    "$ruby" "${flags[@]}" -I "$tree/lib" "$out/adversarial.rb" > "$out/adversarial-$side-$version.jsonl" 2> "$out/adversarial-$side-$version.err"
    for touch in untouched touch; do
      "$ruby" "${flags[@]}" -I "$tree/lib" "$out/ractors.rb" "$touch" > "$out/ractors-$side-$touch-$version.jsonl" 2> "$out/ractors-$side-$touch-$version.err"
    done
    "$ruby" "${flags[@]}" -I "$tree/lib" "$root/bench/upstream/hashie_perf/round2/probes/quiet_diff.rb" > "$out/quiet-$side-$version.txt" 2> "$out/quiet-$side-$version.err"
  done
  diff -u "$out/adversarial-base-$version.jsonl" "$out/adversarial-head-$version.jsonl" > "$out/adversarial-$version.diff" || test "$?" = 1
  diff -u "$out/quiet-base-$version.txt" "$out/quiet-head-$version.txt" > "$out/quiet-$version.diff" || test "$?" = 1
  echo "$version complete"
done
