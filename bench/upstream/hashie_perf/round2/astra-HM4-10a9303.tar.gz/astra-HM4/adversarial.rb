require 'hashie'
require 'logger'
require 'stringio'
require 'json'

LOG = StringIO.new
Hashie.logger = Logger.new(LOG)
def run(label)
  LOG.truncate(0); LOG.rewind
  result = yield
  puts JSON.generate([label, result, LOG.string.lines.grep(/WARN/).map { |s| s.sub(/.*WARN -- : /, '').gsub(/ at \S+:\d+/, ' at X').gsub(/0x\h+/, 'X').strip }])
rescue Exception => e
  puts JSON.generate([label, e.class.name, e.message.gsub(/0x\h+/, 'X')])
end

run('overridden disabled_warnings') do
  klass = Class.new(Hashie::Mash) do
    def self.disabled_warnings; [:size]; end
  end
  m = klass.new
  query = klass.disable_warnings?(:size)
  m[:size] = 7
  [query, m.to_hash]
end

run('reentrant respond_to? reenables warning') do
  klass = Class.new(Hashie::Mash) do
    disable_warnings
    def respond_to?(key, priv = false)
      self.class.disable_warnings(:other) if key == :size
      super
    end
  end
  m = klass.new
  m[:size] = 7
  [m.to_hash, klass.disable_warnings?(:size)]
end

run('respond_to_missing? changes stored hash contents') do
  klass = Class.new(Hashie::Mash) do
    disable_warnings
    attr_accessor :payload
    def respond_to_missing?(key, priv = false)
      payload[:observed] = true if key == :fresh
      super
    end
  end
  m = klass.new
  m.payload = {before: 1}
  m[:fresh] = m.payload
  m.to_hash
end

run('extra predicate call changes stored data') do
  klass = Class.new(Hashie::Mash)
  value = {before: 1}
  klass.define_singleton_method(:disable_warnings?) do |key = nil|
    value[:observed] = true if key == :fresh
    super(key)
  end
  m = klass.new
  m[:fresh] = value
  m.to_hash
end

run('extra predicate call raises before write') do
  klass = Class.new(Hashie::Mash) do
    def self.disable_warnings?(key = nil)
      raise 'not a conflict' if key == :fresh
      super
    end
  end
  m = klass.new
  begin
    m[:fresh] = 7
    error = nil
  rescue => e
    error = [e.class.name, e.message]
  end
  [error, m.to_hash]
end

run('frozen unconfigured class') do
  klass = Class.new(Hashie::Mash).freeze
  m = klass.new
  begin
    m[:size] = 7
    error = nil
  rescue => e
    error = e.class.name
  end
  [error, m.to_hash]
end

run('MethodAccessWithOverride') do
  klass = Class.new(Hashie::Mash) do
    disable_warnings
    include Hashie::Extensions::MethodAccessWithOverride
  end
  m = klass.new
  begin
    m.public_send(:'respond_to?=', 7)
    m[:fresh] = 9
    error = nil
  rescue => e
    error = [e.class.name, e.message]
  end
  [error, m.to_hash]
end

run('deterministic thread: extra query permits mutation') do
  entered, release = Queue.new, Queue.new
  klass = Class.new(Hashie::Mash)
  klass.define_singleton_method(:disable_warnings?) do |key = nil|
    result = super(key)
    if key == :fresh
      entered << true
      release.pop
    end
    result
  end
  m = klass.new
  worker = Thread.new { m[:fresh] = 9 }
  # No barrier is entered by base for the fresh key.
  while worker.alive? && entered.empty?; Thread.pass; end
  unless entered.empty?
    entered.pop
    m.regular_writer('from_thread', 3)
    release << true
  end
  worker.value
  m.to_hash
end

run('ractor plain write nonconflict') do
  if defined?(Ractor)
    worker = Ractor.new do
      begin
        m = Hashie::Mash.new
        m[:fresh] = 3
        m.to_hash
      rescue => e
        [e.class.name, e.message]
      end
    end
    worker.respond_to?(:value) ? worker.value : worker.take
  else
    'unavailable'
  end
end

run('configuration matrix') do
  cases = [[], [:size], ['size'], [:size, :size]]
  cases.product([false, true]).map do |keys, twice|
    k = Class.new(Hashie::Mash)
    m = k.new
    k.disable_warnings(*keys)
    k.disable_warnings(:keys) if twice
    child = Class.new(k)
    m[:size] = 7
    [keys, twice, m.to_hash, [:size, :keys, nil, 'size'].map { |v| [k.disable_warnings?(v), child.disable_warnings?(v)] }]
  end
end

run('direct ivars and returned array') do
  [nil, false, true].product([nil, false, [], [:size]]).map do |flag, list|
    k = Class.new(Hashie::Mash)
    k.instance_variable_set(:@disable_warnings, flag)
    k.instance_variable_set(:@disabled_warnings, list)
    before = k.disable_warnings?(:size)
    k.disabled_warnings << :keys
    [flag, list, before, k.disable_warnings?(:keys), k.new(size: 7).to_hash]
  end
end

run('private collision override') do
  klass = Class.new(Hashie::Mash) do
    disable_warnings
    private
    def _log_collision?(key); super && key != :size; end
  end
  klass.new(size: 4, fresh: 8).to_hash
end
