require 'hashie'
require 'json'
require 'logger'
require 'stringio'
class PrependReader < Hashie::Mash; end
module Exclusions
  def disabled_warnings; [:size]; end
end
PrependReader.singleton_class.prepend(Exclusions)
log = StringIO.new
Hashie.logger = Logger.new(log)
m = PrependReader.new(size: 8)
puts JSON.generate(['prepend', PrependReader.disable_warnings?(:size), m.to_hash, log.string.include?('WARN')])

class HashValue < Hash; end
class ArrayValue < Array; end
class StringValue < String; end
def flagged(*args); args.last; end
ruby2_keywords(:flagged)
payloads = [flagged(a: 1), HashValue[a: 2], ArrayValue.new([3, 4]), StringValue.new('text'), Object.new.freeze]
[Hashie::Mash, Class.new(Hashie::Mash) { disable_warnings }].each_with_index do |klass, i|
  payloads.each_with_index do |payload, j|
    m = klass.new
    m[:fresh] = payload
    v = m[:fresh]
    puts JSON.generate(['value', i, j, v.class.name || 'anonymous', v.frozen?, v.equal?(payload),
                        v.is_a?(Hash) ? Hash.ruby2_keywords_hash?(v) : nil,
                        v.is_a?(Hash) ? v.default_proc.nil? : nil])
  end
end
