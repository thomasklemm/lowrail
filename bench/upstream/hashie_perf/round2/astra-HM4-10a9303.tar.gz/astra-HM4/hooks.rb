require 'hashie'
require 'logger'
require 'json'
Hashie.logger = Logger.new(nil)
[1, :fresh, :size, :'fresh?', :'fresh='].each do |key|
  m = Hashie::Mash.new
  calls = []
  tp = TracePoint.new(:call, :c_call) do |t|
    if t.self.equal?(m) && [:respond_to?, :respond_to_missing?].include?(t.method_id)
      calls << t.method_id
    elsif t.self.equal?(Hashie::Mash) && t.method_id == :disable_warnings?
      calls << t.method_id
    end
  end
  tp.enable { m[key] = 7 }
  puts JSON.generate([key, key.class.name, calls, m.to_hash])
end

class Concurrent < Hashie::Mash
  disable_warnings
end
threads = Array.new(8) do |i|
  Thread.new do
    m = Concurrent.new
    200.times { |n| m["k#{n}"] = [i, n] }
    [m.size, m['k199']]
  end
end
puts JSON.generate(['threads', threads.map(&:value)])
