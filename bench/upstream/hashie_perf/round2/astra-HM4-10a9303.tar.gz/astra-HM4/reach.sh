#!/usr/bin/env bash
set -eu
out=.amp/in/orb-backup/astra-HM4/reach
mkdir -p "$out"
for pair in omniauth:omniauth/omniauth elasticsearch-model:elastic/elasticsearch-rails zendesk_api:zendesk/zendesk_api_client_rb restforce:restforce/restforce chef-zero:chef/chef-zero hashie:hashie/hashie; do
  gem=${pair%%:*}; repo=${pair#*:}
  curl -fsSL "https://rubygems.org/api/v1/gems/$gem.json" > "$out/$gem.gem.json"
  gh api "repos/$repo" > "$out/$gem.repo.json"
  branch=$(jq -r .default_branch "$out/$gem.repo.json")
  gh api "repos/$repo/commits/$branch" > "$out/$gem.head.json"
  jq '{name,version,downloads,version_created_at,dependencies}' "$out/$gem.gem.json"
  jq '{full_name,stargazers_count,pushed_at,archived,default_branch}' "$out/$gem.repo.json"
done
curl -fsSL https://raw.githubusercontent.com/omniauth/omniauth/2045f32693592360488c833b1505658dceddcd03/lib/omniauth/key_store.rb > "$out/omniauth-key_store.rb"
curl -fsSL https://raw.githubusercontent.com/omniauth/omniauth/2045f32693592360488c833b1505658dceddcd03/lib/omniauth/auth_hash.rb > "$out/omniauth-auth_hash.rb"
curl -fsSL https://raw.githubusercontent.com/elastic/elasticsearch-rails/41f4291407f4cd1b9f2c2b574e05853920086955/elasticsearch-model/lib/elasticsearch/model/hash_wrapper.rb > "$out/elasticsearch-hash_wrapper.rb"
for pair in omniauth:omniauth/omniauth elasticsearch-model:elastic/elasticsearch-rails zendesk_api:zendesk/zendesk_api_client_rb restforce:restforce/restforce chef-zero:chef/chef-zero; do
  gem=${pair%%:*}; repo=${pair#*:}
  version=$(jq -r .version "$out/$gem.gem.json")
  curl -fsSL "https://rubygems.org/downloads/$gem-$version.gem" > "$out/$gem.gem"
  mkdir -p "$out/$gem-release"
  tar -xOf "$out/$gem.gem" data.tar.gz | tar -xz -C "$out/$gem-release"
  gh api "repos/$repo/tags?per_page=30" > "$out/$gem.tags.json"
done
