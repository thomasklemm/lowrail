require 'hashie'
if ARGV.first == 'ractor-plain'
  require 'hashie/mash'
  p Ractor.new { Hashie::Mash.new(fresh: 3).to_hash }.take
elsif ARGV.first == 'ractor'
  class Quiet < Hashie::Mash
    disable_warnings
  end
  r = Ractor.new { Quiet.new(fresh: 3).to_hash }
  p(r.respond_to?(:value) ? r.value : r.take)
else
  class Selective < Hashie::Mash
    def self.disabled_warnings
      [:size]
    end
  end
  p Selective.disable_warnings?(:size)
  p Selective.new(size: 7).to_hash
end
