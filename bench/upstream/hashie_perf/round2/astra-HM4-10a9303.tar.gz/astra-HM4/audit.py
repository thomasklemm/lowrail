import json, pathlib, re, statistics, tarfile, math
root = pathlib.Path('/home/user/workspace/repo/bench/upstream/hashie_perf/round2')
out = pathlib.Path('/home/user/workspace/repo/.amp/in/orb-backup/astra-HM4')
reports = []
for folder in sorted(root.glob('wall/HM4-*')) + [root/'body/HM4', root/'body/HM4-module-f41c3b2']:
    if not (folder/'raw.tar.gz').exists():
        continue
    data = json.loads((folder/'results.json').read_text())
    rounds = {}
    with tarfile.open(folder/'raw.tar.gz') as tar:
        for member in tar.getmembers():
            match = re.search(r'wall-r(\d+)-(base2?|candidate)\.log$', member.name)
            if not match:
                continue
            r, side = int(match[1]), match[2]
            for line in tar.extractfile(member).read().decode().splitlines():
                if not line.startswith('wall '):
                    continue
                name, raw = line[5:].split('\t')
                cpu = sorted(json.loads(raw)['cpu'])
                estimate = cpu[int((len(cpu)-1)*0.1 + 0.5)]
                rounds.setdefault(name, {}).setdefault(r, {})[side] = math.log(estimate)
    for name, rs in rounds.items():
        changes = [row['candidate']-row[b] for row in rs.values() for b in ['base','base2']]
        aa = [row['base2']-row['base'] for row in rs.values()]
        change, a = math.exp(statistics.median(changes))-1, math.exp(statistics.median(aa))-1
        claimed = data['wall'][name]
        assert abs(change-claimed['change']) < 1e-10, (folder, name, change, claimed['change'])
        assert abs(a-claimed['aa']) < 1e-10
        reports.append(dict(path=str(folder.relative_to(root)), case=name, rounds=len(rs),
                            recomputed_change=change, recomputed_aa=a,
                            recorded_ci=claimed['change_ci'], recorded_aa_ci=claimed['aa_ci'],
                            claim=claimed['claim'], jit_flat=claimed.get('jit',{}).get('flat')))
print(json.dumps(reports, indent=2))
(out/'audit-wall.json').write_text(json.dumps(reports, indent=2))

duel = {}
for path in (out/'duel-raw').glob('*.log'):
    rows = []
    for line in path.read_text().splitlines():
        m = re.search(r'Z   (.*?)\s+\d+\.\d+s n=\d+\s+cpu (.*?)  allocations (.*)', line)
        if m:
            rows.append(dict(name=m[1], cpu=m[2], allocations=m[3]))
    duel[path.name] = rows
(out/'audit-duel.json').write_text(json.dumps(duel, indent=2))

for folder in [root/'body/HM4', root/'body/HM4-module-f41c3b2']:
    data = json.loads((folder/'results.json').read_text())
    samples = {}
    with tarfile.open(folder/'raw.tar.gz') as tar:
        for member in tar.getmembers():
            if not member.name.endswith('.callgrind'):
                continue
            text = tar.extractfile(member).read().decode()
            totals = re.findall(r'^totals: (\d+)', text, re.M)
            if totals:
                samples[member.name] = int(totals[-1])
    (out/('ir-raw-totals-'+folder.name+'.json')).write_text(json.dumps(samples, indent=2))
    names = list(data['wall'])
    checked = []
    for cell, expected in data['instructions'].items():
        mode, name = cell.split(' ', 1)
        index = names.index(name) + 1
        values = {}
        for side, field in [('base', 'base1'), ('base2', 'base2'), ('candidate', 'candidate')]:
            candidates = [(key, value) for key, value in samples.items()
                          if re.match(rf'raw/ir-{mode}-{index}-.*-{side}-n[0-9]+\.callgrind$', key)]
            zero = next(v for k, v in candidates if '-n0.' in k)
            nonzero = [(k, v) for k, v in candidates if '-n0.' not in k]
            key, total = nonzero[0]
            n = int(re.search(r'-n(\d+)\.callgrind$', key)[1])
            values[field] = (total-zero)/n
            assert abs(values[field]-expected[field]) < 1e-6, (folder, cell, field)
        checked.append(dict(cell=cell, **values))
    (out/('audit-ir-'+folder.name+'.json')).write_text(json.dumps(checked, indent=2))
    print(folder.name, 'instruction cells:', json.dumps(data['instructions']))
