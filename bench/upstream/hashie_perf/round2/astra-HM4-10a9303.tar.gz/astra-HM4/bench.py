import json, os, pathlib, random, statistics, subprocess, sys
root = pathlib.Path('/home/user/workspace/repo')
out = root / '.amp/in/orb-backup/astra-HM4'
versions = {
    '4-yjit': [str(pathlib.Path.home() / '.local/share/mise/installs/ruby/4.0.10/bin/ruby'), '--yjit'],
    '4-zjit': [str(pathlib.Path.home() / '.local/share/mise/installs/ruby/4.0.10/bin/ruby'), '--zjit'],
    'master-zjit': [str(root / '.amp/in/orb-backup/ruby-master/bin/ruby'), '--zjit'],
}
version = sys.argv[1]
rounds = int(sys.argv[2])
kinds = sys.argv[3:] or ['one', 'flat', 'suffix', 'nested', 'insert', 'overwrite']
rows = []
rng = random.Random(413)
with (out / ('timing-' + version + '.jsonl')).open('w') as log:
    for order in ['plain', 'mixed', 'inspected', 'mixed-inspected']:
        for kind in kinds:
            changes, aa = [], []
            for r in range(rounds):
                sides = ['base', 'base2', 'head']
                rng.shuffle(sides)
                values = {}
                for side in sides:
                    tree = root / '.amp/in/orb-backup' / ('hashie' if side == 'head' else 'hashie-base')
                    cmd = ['taskset', '-c', '0'] + versions[version] + ['-I', str(tree / 'lib'), str(out / 'bench.rb'), kind, order]
                    p = subprocess.run(cmd, text=True, capture_output=True, check=True)
                    row = json.loads(p.stdout)
                    row.update(round=r, side=side, command=cmd)
                    log.write(json.dumps(row) + '\n'); log.flush()
                    values[side] = sorted(row['samples'])[1]
                changes += [values['head'] / values['base'] - 1, values['head'] / values['base2'] - 1]
                aa.append(values['base2'] / values['base'] - 1)
            result = dict(version=version, kind=kind, order=order, rounds=rounds,
                          change=statistics.median(changes), aa=statistics.median(aa),
                          change_range=[min(changes), max(changes)], aa_range=[min(aa), max(aa)])
            rows.append(result)
            print(json.dumps(result), flush=True)
(out / ('timing-' + version + '-summary.json')).write_text(json.dumps(rows, indent=2))
