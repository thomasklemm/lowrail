# HM4 Astra evidence

Reviewed head: 10a93033975136664d7b7231986663e9c7689d91.
Base: 277e88e6ccc317497e6c20fb8b9e35abebc0fe19.
Thread: T-01a21f5c-5af9-70ac-9fd0-44b340063d1e.

`commit.diff` is the exact reviewed change, not a proposed fix. Clone thomasklemm/hashie, check out the two SHAs in separate worktrees, and run each Ruby script with `ruby -I /path/to/tree/lib script.rb`. No fork changes were published.

* `minimal.rb ractor`: quiet-subclass write, Ruby 3.0–4.0/master; base succeeds, head raises. `minimal.rb ractor-plain`: preload Mash then exercise the broader Ruby 3.0 regression. The older `minimal-*-ractor-plain-3.0.txt` pair records an initial missing-preload failure on both sides; the corrected `*-preloaded-3.0.txt` pair is the finding.
* `minimal.rb reader`: semipublic exclusions-reader override, true/no warning becomes false/warning.
* `ractors.rb [touch]`: quiet, partially quiet, plain subclass, base Mash; touch reads the public exclusions list before starting workers. Exceptions and partial stored state are captured.
* `adversarial.rb`: override mutations, query errors, configuration matrices, frozen classes, shipped method-override extension and deterministic thread barrier.
* `extended.rb`: prepend override and controls for identity/frozen state/keyword flags of values, including Hash/Array/String subclasses.
* `hooks.rb`: actual receiver TracePoint calls, plus independent-thread control.
* `run-correctness.sh`: exact paths/flags used for both sides and the original Lowrail `probes/quiet_diff.rb`. Ruby 4.0.10-zjit was attempted on a binary without ZJIT: its warning and interpreter outputs are kept, **not counted as ZJIT coverage**. Master was compiled at 0d399335b733776187e43a783e5f950c18ad881c with YJIT/ZJIT enabled; build log retained. Default miniruby configuration initially lacked a host Ruby; rebuilding with explicit `--with-baseruby` succeeded.
* `quiet-outputs.tar.xz`: every full original differential stdout, losslessly compressed inside the gzip archive to keep the review archive below 10 MB. Paths inside are relative to the Lowrail root. `quiet-sha256.txt` records hashes; `quiet-*.diff` keeps side-by-side run differences. Nothing in the original output was normalized away. Ruby 3.1 includes source/caret lines in exception messages.
* `bench.py VERSION 5`: six inputs, four process/configuration states, randomized base/base2/head, thread CPU time, GC off in measured windows, core 0, nine windows per process. CPU-time samples and commands are in `timing-*.jsonl`; summaries include A/A and observed ranges, **not confidence intervals**. These are diagnostic runs on a two-vCPU orb and have no JIT-flat or publication-grade claim. They cannot replace a1.xxlarge/30-round controlled evidence.
* `zjit-*-checked.txt`: exact-head mixed-process stats, base/A/A/head, `--zjit --zjit-stats --zjit-exec-mem-size=512 --zjit-mem-size=1024`; each explicitly reports zero `compile_error_out_of_memory`. Executed wrapper: `ARGV << "quiet-first"; load "bench/upstream/hashie_perf/round2/probes/zjit_mixed.rb"; puts "compile_error_out_of_memory=#{RubyVM::ZJIT.stats.fetch(:compile_error_out_of_memory)}"`. The other zjit logs retain the three order controls, also with base/A/A/head.
* `audit.py`: reads original retained archives under Lowrail round2, recomputes 80 wall median/A/A pairs and Callgrind per-call totals, and extracts Duel raw rows. `audit-wall.json` labels the original intervals as recorded, not recomputed. No new time measurement is inferred from this arithmetic audit.
* `reach.sh`, `reach/`, `reach.txt`: fetched GitHub/rubygems metadata, linked released source bytes, downloaded latest published gems, and current branch sources. `duel-run.json`, `fork-pr36.json`, `latest-issues.json` are read-only GitHub API results.
* `spec-*-4.0.10-bundled.log`, `rubocop.log`, `docs-head.log`: successful exact-tree validation. Earlier unbundled spec attempts and dependency/build logs are retained as failures, not reported as passing runs. Release-preparation tests use disposable local Git remotes, not GitHub.

`review.md` is the expanded review underlying the appended Lowrail round2 section, including the full sentence audit. The archive holds no executable builds, credentials, or changes to the candidate.
