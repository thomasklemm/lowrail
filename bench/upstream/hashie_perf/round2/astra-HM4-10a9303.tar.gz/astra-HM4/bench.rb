require 'hashie'
require 'json'
require 'logger'
Hashie.logger = Logger.new(nil)
class QuietBench < Hashie::Mash
  disable_warnings
end
kind, order = ARGV
Hashie::Mash.disabled_warnings if order.include?('inspected')
input = case kind
when 'one' then { 'a' => 1 }
when 'flat' then (0...20).to_h { |i| ["a#{i}", i] }
when 'suffix' then (0...20).to_h { |i| ["a#{i}?", i] }
when 'nested' then JSON.parse(File.read(File.expand_path('../../../..', __dir__) + '/bench/upstream/hashie_perf/round2/fixtures/github-org-repos.json')).first
else { 'a' => 1 }
end
op = if kind == 'insert'
  m = Hashie::Mash.new
  ->(klass) { m.clear; m['a'] = 1 }
elsif kind == 'overwrite'
  m = Hashie::Mash.new(input)
  ->(klass) { m['a'] = 1 }
else
  ->(klass) { klass.new(input) }
end
3000.times { QuietBench.new(input) } if order.start_with?('mixed')
5000.times { op.call(Hashie::Mash) }
n = kind == 'nested' ? 200 : 3000
samples = Array.new(9) do
  GC.start
  GC.disable
  before = Process.clock_gettime(Process::CLOCK_THREAD_CPUTIME_ID)
  n.times { op.call(Hashie::Mash) }
  elapsed = Process.clock_gettime(Process::CLOCK_THREAD_CPUTIME_ID) - before
  GC.enable
  elapsed / n
end
puts JSON.generate(ruby: RUBY_DESCRIPTION, kind: kind, order: order, samples: samples)
