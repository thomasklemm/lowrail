## Astra HM4: changes on 10a93033975136664d7b7231986663e9c7689d91

Reviewed by Astra in `T-01a21f5c-5af9-70ac-9fd0-44b340063d1e`, 2026-11-27. **Changes; do not open this head.** Independently cloned the fork, checked out the full head, verified its parent is `277e88e6ccc317497e6c20fb8b9e35abebc0fe19`, its range contains one commit, and the remote branch still names that head. No hashie branch was pushed and nothing was posted upstream. Evidence: `astra-HM4-10a9303.tar.gz` beside this record; scripts, raw outputs, fetched public metadata and the reviewed diff are inside. The orb has **2 vCPUs and 3,931 MiB RAM**, not a1.xxlarge; all new timings are diagnostic, not publication evidence. The provider did not expose a size-tier name through the inspected CLI/environment.

### R1: an ordinary quiet subclass loses working Ractor writes

```ruby
require 'hashie'
class Quiet < Hashie::Mash
  disable_warnings
end
r = Ractor.new { Quiet.new(fresh: 3).to_hash }
p(r.respond_to?(:value) ? r.value : r.take)
```

Base returns `{"fresh"=>3}`. Head raises `Ractor::IsolationError`: `can not get unshareable values from instance variables of classes/modules from non-main Ractors (@disabled_warnings from Quiet)` on 4.0.10, with version-specific wording elsewhere. In the version that catches the exception around `m[:fresh] = 3`, the stored state is `{}` on head versus `{"fresh"=>3}` on base. `disable_warnings(:size)` fails the same way even though `fresh` does not collide. Plain `Hashie::Mash` also regresses after a main-Ractor call to the public `Hashie::Mash.disabled_warnings` reader; an untouched plain subclass is the passing control on 3.1 and later. **On Ruby 3.0.7 even untouched plain `Hashie::Mash.new(fresh: 3)` regresses**, because that Ruby forbids these class-ivar accesses altogether. See `ractors.rb`, `minimal.rb ractor-plain`, and the per-Ruby outputs. This does not claim all Hashie operations were Ractor-safe before: it identifies writes that worked and now fail, without any overridden method. A real caller can hit it simply by building response objects in worker Ractors.

Moving the query earlier makes an otherwise unnecessary access to the unshareable class configuration. Rescuing the isolation error or freezing the public mutable Array is not an exact fix. The smallest rollback that restores this behavior is to restore the original `_log_collision?` ordering. All three refused forms were applied to separate scratch worktrees and executed with the same repro; **all three also break the quiet-class Ractor case** (`alternative-*-ractors.txt`). None is a correctness replacement.

### R2: the early return bypasses a semipublic configuration override

```ruby
require 'hashie'
class Selective < Hashie::Mash
  def self.disabled_warnings
    [:size]
  end
end
p Selective.disable_warnings?(:size)
Selective.new(size: 7)
```

Base returns `true` and logs nothing. Head returns `false` and logs a conflict warning for `size`; both store 7. No call to `disable_warnings` or private instance-variable manipulation is needed. `disabled_warnings` and `disable_warnings?` are both documented `@api semipublic`, not nodoc helpers. A caller that supplies a computed/shared exclusions list through the reader can hit this; none of the five cited gems currently uses that override, so this is a demonstrated extension-contract regression, not a claim about those gems. The smallest fix for this finding alone is removing `return false unless @disable_warnings || @disabled_warnings`; that leaves R1 and the reorder-only cost. The record's claim that filling the returned Array is covered is true, but does not cover an overridden reader that does not initialize that particular ivar.

### The accepted differences include stored values and exceptions, not only counts

`adversarial.rb` records warnings, results and the Mash after rescued exceptions. It demonstrates these additional boundaries:

* A quiet class with `respond_to?(key, priv = false)` that calls `self.class.disable_warnings(:other) if key == :size`, then `super`, warns and ends with `disable_warnings?(:size) == false` on base; head skips the callback, does not warn, and leaves that setting true. This is a public reflection override with observable configuration effects, not just fewer counted calls.
* A quiet subclass's `respond_to_missing?` that adds `payload[:observed] = true if key == :fresh`, then calls `super`, changes a later `m[:fresh] = m.payload`: base stores both `before: 1` and `observed: true`, head stores only `before: 1`. Conversely, adding that mutation in a class `disable_warnings?` override produces the extra stored value on head only. The latter override can also raise for `:fresh`; base successfully stores 7, head raises and leaves `{}`. These are synthetic effectful hooks, not discovered production callers; a delegated/lazy hook can have precisely these observable effects. The intrinsic hook-skipping tradeoff cannot be described as identical values for every caller.
* A deterministic Queue barrier inside the new query allows a second thread to insert `from_thread: 3` before `fresh: 9`; base never enters that barrier. This is the added-callback boundary, not evidence of an unsynchronized-Mash thread-safety promise. An ordinary eight-thread control, 200 writes to each independent quiet Mash, gives identical results.
* `Class.new(Hashie::Mash).freeze.new` followed by `m[:size] = 7` raises `FrozenError` and stores nothing on base; head logs a warning and stores 7. The record's frozen-query exception change also changes the public write outcome. Avoiding an otherwise unnecessary class mutation is reasonable, but the public exception change deserves explicit acceptance and disclosure, not a claim that frozen behavior is identical.
* `Class.new(Hashie::Mash) { disable_warnings; include Hashie::Extensions::MethodAccessWithOverride }.new.public_send(:'respond_to?=', 7)` fails with `ArgumentError` before storing on base; head stores the key, and a following ordinary write succeeds. This confirms the known 18 rows but also captures their previously omitted partial state. This is an improvement for a shipped extension and a user-controlled key; accept it explicitly and mention it if retaining this change. It is not merely an internal call-count difference.

The no-ivar-assignment difference alone is acceptable; the skipped/added hooks are acceptable only after explicitly narrowing the contract to hooks without observable effects, not under the current blanket exactness claim. The private `_log_collision?` override control returned identical state, and special handling of arbitrary private overrides is not requested. The shipped `PermissiveRespondTo` override remains a separate path; it does not gain this early skip.

The original `quiet_diff.rb` drops the Mash state from rescued rows, normalizes class identities, does not record value identity/keyword flags, and its hook cases only count calls. Hence its 66,976 matching rows do not establish the missing properties. I reran it unchanged as coverage, not as sufficient proof. Its behavior differences remain the 18 MethodAccessWithOverride rows plus the three explicitly accepted output lines; Ruby 3.1.7 additionally changes 72 source/caret lines in 36 NoMethodError highlights because the failing expression moved. These highlight-only differences are retained, not treated as a new behavior regression. Raw output has 66,999 lines normally (66,994 excluding the five `accepted` lines), and 67,107 with those 3.1 error highlights.

### Sentence-by-sentence upstream text audit

Read `git show --format=fuller` for the exact head, the complete item title/body, and the CHANGELOG diff. No comment was added by the commit; the benchmark follows the neighboring Duel declarations. The code is small/L0 syntactically, but its direct-ivar guard is not equivalent to the semipublic reader.

| Upstream sentence or claim | Command/source checked and disposition |
|---|---|
| Title and CHANGELOG: skip the conflict check in subclasses that disable warnings | Exact diff plus `hooks.rb`, the unchanged differential and the adversarial executions. True for the default collision helper; not an equivalence claim. The PermissiveRespondTo override is unchanged. |
| “Every Mash write asks respond_to?” (also first commit-message sentence) | `hooks.rb` uses TracePoint on the real receiver. Integer-key writes call neither receiver `respond_to?` nor class `disable_warnings?`. Change to String/Symbol-key writes through the default check, or remove “Every”. |
| An unset key runs `respond_to_missing?` (also commit message) | TracePoint: fresh `:fresh` does; unset `:size` does not because the built-in method exists. Qualify “a new, nonconflicting key”. |
| `respond_to_missing?` is “the most expensive step of building a Mash” | Opened `out/profile-stackprof-4.0.10-{interp,yjit}.txt`: in the YJIT issues workload `convert_value` is 62.6% inclusive versus `respond_to_missing?` 20.0%; even the repository profile's 49.0% is `Kernel#respond_to?`, not the missing-method hook alone. Cut the universal superlative or say it is expensive in the profiled fixture. |
| A subclass that disabled warnings does the work and discards the answer (also commit message) | Default-path source, tracing and quiet probes verify the wasted boolean result; effectful overrides prove that discarding the boolean is not discarding all effects. Do not use this as an exactness argument. |
| OmniAuth KeyStore is AuthHash's parent, omniauth 2.4.2; HashWrapper, elasticsearch-model 8.0.1 | Fetched both exact SHA permalinks, the latest published gem tarballs, release-tag API metadata and current default-branch sources. KeyStore line 8 disables warnings, AuthHash line 8 inherits KeyStore; HashWrapper lines 28–29 inherit Mash and disable warnings. Gem bytes match the linked files. Version/SHA claims pass. |
| `_log_collision?` now asks the class before `respond_to?` (also commit message) | Exact diff and TracePoint pass. |
| `disable_warnings?` answers false right away for a class that never disabled warnings, keeping it cheap (also commit message) | Exact diff verifies the default uninitialized-ivar path only. R2 disproves interpreting the guard as “no exclusions”; reading `disabled_warnings` once also defeats the fast path without disabling any warning. “Cheap” needs the limited workload qualification in the cost paragraph. |
| New benchmark builds the quiet subclass from the nested fixture (also commit message) | Read `benchmarks/extensions_benchmark.rb` and benchmark helper: `QuietMash.new(@repository)` and `once { @repository = repository }`. Pass. |
| Duel Ruby 4.0 CPU table | Opened run 46079366956 through GitHub API: success, exact head; PR 36 closed; logs show merge of that head into 277e88e and Ruby 4.0.10. Raw CPU rows are 0.458/0.655, 1.007/1.006 and 1.013/1.013, rounding correctly to 0.46/0.66 and 1.01. Pass for this cohort, not all workloads. |
| Last two rows are the cost; class asked once for every key | Correct direction for fresh nonconflicting keys. TracePoint shows zero queries for Integer keys and two for a fresh conflict such as `size` (including the logger's query), before and after. Prefer “adds a class query for new nonconflicting String/Symbol keys”. |
| Master ZJIT mixed-class slowdown, dynamic two-class dispatch; Ruby 4.0 does not show it | Recomputed exact-head wall medians from archived raw windows; reviewed original stats and reran the mixed-order stats probe on the exact head. Narrow the categorical last sentence to “not observed in the Ruby 4.0.10 cohort”; that local cohort has 20 rounds and fails its JIT-flat gate, and is not proof for all 4.0 inputs. The diagnostic-only master timing should not become a universal speed claim. |
| CHANGELOG #663 and attribution | Attribution matches both verified commit identities. Live issues API returned highest number 661: **next expected number 662**, not 663. Recheck at opening; no number is reserved. |

### Reach and currency

Live GitHub repository/default-head/tag APIs, rubygems.org gem metadata, latest released gem contents and the linked source files were fetched into `reach/`. All repositories below are unarchived. Downloads are cumulative gem downloads, not active installs or installations using hashie 6.

| Project | Stars | Downloads | Latest release/date | Last repository push | Released hashie constraint |
|---|---:|---:|---|---|---|
| omniauth | 8,102 | 235,368,604 | 2.4.2 / 2026-11-18 | 2026-11-27 | >= 3.5.2; allows 6 |
| elasticsearch-model | 3,079 | 78,460,281 | 8.0.1 / 2025-09-01 | 2025-10-08 | >= 0; allows 6 |
| restforce | 822 | 60,006,023 | 8.0.1 / 2025-12-29 | 2026-07-27 | >= 1.2.0, < 6.0; excludes 6 |
| zendesk_api | 410 | 47,179,798 | 3.1.2 / 2026-07-23 | 2026-11-17 | >= 3.5.2; allows 6 |
| chef-zero | 530 | 22,642,721 | 15.1.11 / 2026-05-28 | 2026-11-16 | >= 2.0, < 6.0; excludes 6 |

Every released source contains the stated quiet Mash subclass, and the fetched default-branch sources retain it. The body's two callers are in reach order. Elasticsearch is materially less current than OmniAuth (over a year since release/push) but remains its latest release with 78M downloads and is not demonstrated abandoned; keep it only as the secondary example, not evidence of recent maintenance. The impact's separate current-compatible and excluded-version groups are fair; a single combined ranking would put restforce ahead of zendesk_api. Keep restforce and chef-zero out of claims about existing hashie-6 users. Duel is the upstream project's chosen benchmark tool, not an impact caller: 21 stars, 8,764 downloads, 0.3.1 released 2026-11-22, pushed 2026-11-25, unarchived; its niche size is not a reason to replace the project's tool. Hashie itself: 3,035 stars, pushed 2026-11-27; its full rubygems metadata is retained too.

### Performance evidence and recommendation

`audit.py` independently recomputes the paired medians/A/A from **80 archived wall cells** and all three raw Callgrind totals per instruction cell in `body/HM4` and `body/HM4-module-f41c3b2`; they agree with `results.json`. The interval values are retained as recorded, not independently regenerated. Extracted Duel raw rows agree with the summaries, including 28 benchmarks, zero classified regressions, the one YJIT unsettled read-only benchmark, all current-head table rows and the refused-form rows. Duel's “same” classification is its regression threshold, not proof of zero cost. The local exact-head mixed-master cohort recomputes +9.108% with A/A +0.209%; its recorded intervals are [+7.408%, +9.836%] and [−1.192%, +2.606%]. The module-form +19.0% and reorder-only costs also reconcile with the retained raw cohorts. These source runs are still the smaller-orb evidence the author describes.

The independent sweep (`bench.rb`, `bench.py`, `timing-*.jsonl`) covered one scalar key, 20 fresh scalar keys, 20 suffixed keys, the nested repository fixture, clear-and-insert, and overwrite. Each ran in plain-only and quiet-first processes, both before and after merely calling **`Hashie::Mash.disabled_warnings`** in the main Ractor. That public reader initializes an empty Array without disabling any warning, so the head's new guard no longer takes its fast path. Each of the 48 cells has five randomized base/A/A/head rounds, nine GC-off thread-CPU windows per process on core 0. No JIT-flat gate was claimed; some other review checks overlapped these diagnostic runs, and observed ranges are noisy.

The slowest median in this finite sweep was the **nested fixture after both quiet-class warmup and inspection of the plain class's exclusions list**. Ruby 4.0.10/YJIT: +12.68%, A/A +0.25%, observed paired-change range [−0.75%, +14.42%], A/A range [−2.20%, +15.28%]. Master/ZJIT at `0d399335b733776187e43a783e5f950c18ad881c`: +8.53%, A/A +0.69%, change range [+3.10%, +14.64%], A/A range [−5.00%, +4.85%]. These ranges are not confidence intervals and these are **diagnostic medians, not established speed-loss claims**. A less noisy YJIT control, 20 fresh keys after only inspecting the list, was +8.85% (A/A −0.29%; change range [+6.86%, +11.40%], A/A [−2.16%, +1.22%]). No warning was disabled on the measured plain Mash. The new state-dependent cost deserves a publication-grade repeat before treating the body table's approximately 1% as representative.

The exact-head rerun of `probes/zjit_mixed.rb` confirms `send_fallback_send_polymorphic_fallback` rises from 20 per plain construction on base/A/A to 114 on head when the quiet subclass runs first. The plain-only control is 40 on both. `zjit-*-checked.txt` explicitly records `compile_error_out_of_memory=0` in base, A/A and head with the required 512/1024 memory flags. Thus the dispatch observation is no longer inferred solely from the two older heads' stats.

None of the refused forms is preferable as a ready-to-open change: the module form adds a second collision path and retains the quiet Ractor failure, reorder-only retains R1 and pays the larger ordinary-path cost, and flag-first additionally ignores direct mutations of the returned exclusions list. Removing only the direct-ivar guard fixes R2, not R1 or effectful-hook semantics. The smallest safe action is to withdraw the library reorder/guard and retain the benchmark separately if desired; a new optimization needs its own exactness argument. Do not grow method-owner checks, Ractor exception rescues or copied collision logic around these two lines merely to preserve the headline win.

The approximately 1% Duel cost is stated fairly for its one-benchmark processes. It cannot clear the mixed-process case, and the master warning must be framed as diagnostic rather than a release-wide result. Correctness already blocks this head. Independently, I would hold performance approval until the worst ordinary-path shape and mixed-class workload are repeated on a1.xxlarge with the required controls and the common-path tradeoff is accepted; these small-orb timings alone are not a formal new loss gate.

### Executed validation and limits

* Original differential plus the new adversarial/Ractor probes ran against both exact trees on **3.0.7, 3.1.7, 3.2.9, 3.3.10, 3.4.7, 4.0.10, 4.0.10/YJIT, and master/ZJIT**. Both new blockers reproduce across this matrix; R1 is broader on Ruby 3.0.7 as described above. The prebuilt 4.0.10 rejected `--zjit`; that attempted run and its warnings are kept, but it was interpreter execution and is not counted as ZJIT coverage.
* `bundle exec rake spec`, Ruby 4.0.10: **1,076 examples, 0 failures on base and head**. `bundle exec rake rubocop`: **156 files, no offenses** (also its 124-file subtask). `bundle exec rake docs:examples`: **359 examples, 0 failures**. Earlier unbundled suite attempts failed in release-preparation subprocesses because dependencies were missing; the complete bundled reruns above resolved that setup issue. No integration-app matrix or full suite on every Ruby is claimed.
* The unchanged probe covers all the requested Mash extensions, `Mash.quiet`, String/Symbol exclusions, repeated calls, inheritance/narrowing, late configuration, arbitrary keys/conversions, anonymous classes, and frozen receivers. New checks add the missed semipublic-reader override and prepend, public reflection mutations, query exceptions and partial state, frozen-class writes, direct ivars and mutation through the returned Array, Ractors and a deterministic threaded callback. Value identity, frozen-state and keyword-flag controls for ordinary values and Hash/Array/String subclasses match in `extended.rb`; the prepended exclusions reader reproduces R2.
* No candidate code was changed. Returning to base behavior is the smallest safe rollback; no optimization-preserving correction is established. This is a review with demonstrated counterexamples, not a proof that all other Ruby programs are equivalent.
