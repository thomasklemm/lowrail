require 'hashie'
require 'json'
class Quiet < Hashie::Mash
  disable_warnings
end
class Partial < Hashie::Mash
  disable_warnings(:size)
end
class Plain < Hashie::Mash; end
Hashie::Mash.disabled_warnings if ARGV.include?('touch')
[Hashie::Mash, Quiet, Partial, Plain].each do |klass|
  r = Ractor.new(klass) do |k|
    m = k.new
    begin
      m[:fresh] = 3
      [nil, m.to_hash]
    rescue => e
      [e.class.name, e.message, m.to_hash]
    end
  end
  puts JSON.generate([klass.name, r.respond_to?(:value) ? r.value : r.take])
end
