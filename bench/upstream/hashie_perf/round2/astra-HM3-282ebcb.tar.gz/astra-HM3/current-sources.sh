#!/usr/bin/env bash
set -eu
out=$(dirname "$0")/sources
for gem in omniauth snaky_hash oauth2 slack-ruby-client elasticsearch-model restforce zendesk_api faraday-mashify; do
  repo=$(jq -r .full_name "$out/$gem-repo.json")
  branch=$(jq -r .default_branch "$out/$gem-repo.json")
  gh api "repos/$repo/commits/$branch" > "$out/$gem-current-commit.json"
  sha=$(jq -r .sha "$out/$gem-current-commit.json")
  if [[ $gem == elasticsearch-model ]]; then path=elasticsearch-model/elasticsearch-model.gemspec; else path=$gem.gemspec; fi
  curl -fsSL "https://raw.githubusercontent.com/$repo/$sha/$path" > "$out/$gem-current.gemspec"
done
