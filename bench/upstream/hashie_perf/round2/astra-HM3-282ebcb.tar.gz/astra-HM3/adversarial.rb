# frozen_string_literal: true
require 'hashie'
require 'delegate'
require 'forwardable'
require 'logger'
Hashie.logger = Logger.new(nil)

class Payload < Hash; end
class A < Array; end
class S < String; end
EVENTS = []
class Duck
  def to_ary; EVENTS << :to_ary; [1, 7]; end
  def to_a; EVENTS << :to_a; [nil, 8]; end
  def to_hash; EVENTS << :to_hash; {a: 5}; end
  def to_s; EVENTS << :to_s; 'name='; end
  def to_proc; EVENTS << :to_proc; proc { |v| EVENTS << [:yield, v] }; end
end
class PrivateDuck < Duck
  private :to_ary, :to_a, :to_hash, :to_s, :to_proc
end
class Recording < Hashie::Mash
  def assign_property(name, value)
    EVENTS << [:assign, name, Hash === value && Hash.ruby2_keywords_hash?(value)]
    super
  end
end
class Zsuper < Recording
  ruby2_keywords def method_missing(name, *args, &block)
    super
  end
end
class Explicit < Recording
  ruby2_keywords def method_missing(name, *args, &block)
    super(name, *args, &block)
  end
end
class Dots < Recording
  def method_missing(...)
    super
  end
end
class Prepended < Recording
  prepend(Module.new do
    ruby2_keywords def method_missing(*args, &block)
      super
    end
  end)
end
class Forwarder
  extend Forwardable
  def_delegators :@mash, :name, :name=, :name?, :name!, :name_
  def initialize(mash); @mash = mash; end
end
def observe(value)
  case value
  when Hash
    [value.class.name, value.frozen?, Hash.ruby2_keywords_hash?(value), value.map { |k,v| [observe(k), observe(v)] }]
  when Array then [value.class.name, value.frozen?, value.map { |v| observe(v) }]
  when String then [value.class.name, value.frozen?, value.to_s]
  when Duck then value.class.name
  else value
  end
end
classes = [Hashie::Mash, Recording, Zsuper, Explicit, Dots, Prepended]
%i[DefineAccessors StrictKeyAccess SafeAssignment PermissiveRespondTo KeepOriginalKeys SymbolizeKeys].each do |ext|
  klass = Class.new(Recording) { include Hashie::Extensions::Mash.const_get(ext) }
  Object.const_set("Ext#{ext}", klass)
  classes << klass
end
class WithOverride < Recording
  include Hashie::Extensions::MethodAccessWithOverride
end
classes << WithOverride
shapes = {
  none: ->(c) { c.call }, nil: ->(c) { c.call(nil) }, multi: ->(c) { c.call(false, 4, 9) },
  keyword: ->(c) { c.call(a: 1) }, hash: ->(c) { c.call({a: 1}) },
  subkeyword: ->(c) { c.call(**Payload[a: 1]) }, subhash: ->(c) { c.call(Payload[a: 1]) },
  frozen_hash: ->(c) { c.call({a: 1}.freeze) }, array: ->(c) { c.call(A[1, 2].freeze) },
  string: ->(c) { c.call(S.new('x').freeze) },
  flagged: ->(c) { c.call(*[Hash.ruby2_keywords_hash(Payload[a: 1])]) },
  flagged_extra: ->(c) { c.call(Hash.ruby2_keywords_hash(Payload[a: 1]), 2) },
  kwargs_after_value: ->(c) { c.call(3, a: 1) }, empty: ->(c) { c.call(**{}) },
  duck_splat: ->(c) { c.call(*Duck.new) }, private_splat: ->(c) { c.call(*PrivateDuck.new) },
  duck_kwargs: ->(c) { c.call(**Duck.new) }, private_kwargs: ->(c) { c.call(**PrivateDuck.new) },
  duck_value: ->(c) { c.call(Duck.new) }, block: ->(c) { c.call(&Duck.new) },
  private_block: ->(c) { c.call(&PrivateDuck.new) }
}
classes.each do |klass|
  %i[name name= name? name! name_ missing missing=].each do |name|
    shapes.each do |shape, invoke|
      [false, true].each do |frozen|
        %i[send delegate forwarder method proc unbound bind_call super_method].each do |way|
          EVENTS.clear
          mash = klass.new(name: 'Ada')
          mash.freeze if frozen
          result = begin
            target = case way
                     when :delegate then SimpleDelegator.new(mash)
                     when :forwarder then Forwarder.new(mash)
                     else mash
                     end
            call = case way
                   when :method then target.method(name)
                   when :proc then target.method(name).to_proc
                   when :unbound then ->(*a, **k, &b) { Hashie::Mash.instance_method(:method_missing).bind(target).call(name, *a, **k, &b) }
                   when :bind_call then ->(*a, **k, &b) { Hashie::Mash.instance_method(:method_missing).bind_call(target, name, *a, **k, &b) }
                   when :super_method then ->(*a, **k, &b) { target.method(:method_missing).super_method.call(name, *a, **k, &b) }
                   else ->(*a, **k, &b) { target.public_send(name, *a, **k, &b) }
                   end
            observe(invoke.call(call))
          rescue Exception => e
            [e.class.name, e.message.lines.first.strip.gsub(/0x[0-9a-f]+/, 'ADDR')]
          end
          puts [klass.name, name, shape, frozen, way, result, observe(mash), EVENTS].inspect
        end
      end
    end
  end
end
puts ['signature', Hashie::Mash.instance_method(:method_missing).arity, Hashie::Mash.instance_method(:method_missing).parameters].inspect
