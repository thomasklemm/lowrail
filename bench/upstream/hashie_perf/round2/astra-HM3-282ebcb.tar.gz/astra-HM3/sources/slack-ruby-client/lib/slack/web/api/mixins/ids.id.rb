# frozen_string_literal: true
module Slack
  module Web
    module Api
      module Mixins
        module Ids
          private

          def id_for(key:, name:, prefix:, enum_method:, list_method:, options: {})
            return { 'ok' => true, key.to_s => { 'id' => name } } unless name[0] == prefix

            target = name[1..]
            public_send(enum_method, **options) do |list|
              list.public_send(list_method).each do |li|
                return Slack::Messages::Message.new('ok' => true, key.to_s => { 'id' => li.id }) if li.name == target
              end
            end

            error_message = "#{key}_not_found"
            error_class = Slack::Web::Api::Errors::ERROR_CLASSES[error_message] || Slack::Web::Api::Errors::SlackError
            raise error_class, error_message
          end
        end
      end
    end
  end
end
