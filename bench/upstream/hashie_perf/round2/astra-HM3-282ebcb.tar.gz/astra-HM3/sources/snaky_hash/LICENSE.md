# License

This project is made available under the following license.
Choose the option that best fits your use case:

- [MIT](https://github.com/ruby-oauth/snaky_hash/blob/main/MIT.md)

## Copyright Notice

- Copyright (c) 2022, 2025-2026 Peter H. Boling
