# Run Duel in CI

This page describes the GitHub Actions workflow that `duel init` writes,
and how to compare a branch that upgrades Ruby on CI. For how to run
Duel as a CI step on any CI service, and for the report that it adds to
a pull request, see [Run Duel in CI](../README.md#run-duel-in-ci).

## Catch slow creep

A limit lets through any slowdown that's smaller than the limit. For
example, a series of changes that are each 1.5% slower would each pass.
To catch that kind of slow creep, also compare against your last release
on a schedule. The slowdowns add up there until they're a regression.

The following GitHub Actions workflow does both. `duel init` writes a
short workflow that calls Duel's, which is this one with each setting
as an input (see
[Call Duel's reusable workflows](#call-duels-reusable-workflows)).
`duel init --standalone` writes the whole of it, as
`.github/workflows/perf.yml`, to change as you like, with a second
workflow that comments on a pull request when a benchmark fails (see
[Comment on a pull request](#comment-on-a-pull-request)):

```yaml
# .github/workflows/perf.yml
name: Perf

on:
  pull_request:
  merge_group: # (a merge queue's)
  push:
    branches: [main] # (and any other branch to guard, a stable one, say)
  schedule:
    - cron: "0 4 * * *"
  workflow_dispatch:

# A pull request's newer push cancels its run, if that's still going, as
# only its newest commit's result counts. Every other run (a push's, say)
# runs to the end, so that each push is compared.
concurrency:
  group: ${{ github.workflow }}-${{ github.event_name == 'pull_request' && github.event.pull_request.number || github.run_id }}
  cancel-in-progress: ${{ github.event_name == 'pull_request' }}

# The Duel job runs the branch's code (its benchmarks too), so it only
# reads. Commenting on a commit is the Comment on the commit job's, which
# runs none of it, and commenting on a pull request is the Perf comment
# workflow's.
permissions:
  contents: read
  pull-requests: read # for the pull request's labels (see c.accept_label)

jobs:
  duel:
    name: Duel
    runs-on: ubuntu-latest
    # Whether to comment (post, change or none), the run's status (passed,
    # failed or neutral), and the branch to mark a push passed on (or
    # nothing), from Duel.
    outputs:
      comment: ${{ steps.compare.outputs.comment }}
      status: ${{ steps.compare.outputs.status }}
      passed: ${{ steps.compare.outputs.passed }}
    steps:
      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1
        with:
          fetch-depth: 0 # the baseline comes from history, tags included
          persist-credentials: false
      # The labels of the pull request (or for a push, of the one that
      # merged it), for c.accept_label in .duel.rb, as a JSON array. They're
      # read as the job runs, and adding the label (or taking it off) runs
      # the job again: see the Perf comment workflow. (On a schedule, Duel
      # finds the last change merged with the label since the last
      # release itself.)
      - name: Find the pull request's labels
        id: labels
        if: github.event_name == 'pull_request' || github.event_name == 'merge_group' || github.event_name == 'push'
        continue-on-error: true # (without them, nothing's accepted)
        env:
          GH_TOKEN: ${{ github.token }}
          PR: ${{ github.event.pull_request.number }}
          QUEUED: ${{ github.event.merge_group.head_ref }}
        run: |
          # (In a merge queue, the last pull request queued, which the queue's
          # branch names: gh-readonly-queue/main/pr-123-<sha>.)
          if [ -n "$QUEUED" ]; then
            PR=${QUEUED##*/pr-}
            PR=${PR%%-*}
          fi
          if [ -n "$PR" ]; then
            labels=$(gh api "repos/$GITHUB_REPOSITORY/issues/$PR/labels" --jq '[.[].name]')
          else
            labels=$(gh api "repos/$GITHUB_REPOSITORY/commits/$GITHUB_SHA/pulls" --jq '[.[0].labels[]?.name]')
          fi
          echo "labels=$labels" >> "$GITHUB_OUTPUT"
      # (And whatever else your tests need set up: packages, services.)
      - uses: ruby/setup-ruby@f9c4492e86def3e644ab32a0ef185eda5b0c20d0 # v1.342.0
        id: ruby
        with:
          ruby-version: "3.4" # (or none, with a .ruby-version)
          bundler-cache: true
      # Against the branch it targets for a pull request, the queue's base
      # for a merge queue, what was there before for a push (or as
      # c.push_base in .duel.rb says, the last commit Duel passed), and the
      # last release on a schedule (slow creep), as Duel finds them, from
      # the run's event. Duel adds its report to
      # the job's summary, writes it to duel.md for the comment, and sets
      # the step's outputs to say whether to comment, as c.comment in
      # .duel.rb says, whatever the outcome.
      - name: Compare
        id: compare
        env:
          # (Run by hand, it compares anyway: with nothing changed, the code
          # with itself, which checks the setup.)
          DUEL_FORCE: ${{ github.event_name == 'workflow_dispatch' && '1' || '' }}
          DUEL_LABELS: ${{ steps.labels.outputs.labels }}
          # (On a schedule, for the last change a label accepted since the
          # last release, which Duel finds with gh.)
          GH_TOKEN: ${{ github.event_name == 'schedule' && github.token || '' }}
        run: bundle exec duel --markdown "$RUNNER_TEMP/duel/duel.md"
      # For a pull request, what Duel said, for the Perf comment workflow,
      # which can't see this job's outputs.
      - name: Say whether to comment
        if: ${{ !cancelled() && github.event_name == 'pull_request' }}
        env:
          PR: ${{ github.event.pull_request.number }}
          COMMENT: ${{ steps.compare.outputs.comment }}
          STATUS: ${{ steps.compare.outputs.status }}
        run: |
          mkdir -p "$RUNNER_TEMP/duel"
          printf 'pr=%s\ncomment=%s\nstatus=%s\n' "$PR" "$COMMENT" "$STATUS" > "$RUNNER_TEMP/duel/comment.env"
      # The report, for the comments.
      - name: Keep the report
        if: ${{ !cancelled() && (github.event_name == 'pull_request' || github.event_name == 'push') }}
        uses: actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9 # v7.0.2
        with:
          name: duel-report
          path: ${{ runner.temp }}/duel/
          if-no-files-found: ignore # none when Duel didn't get to compare
          retention-days: 1

  # The report, as a new comment on a pushed commit, which notifies its
  # author, when Duel says to, as for a pull request (see the Perf comment
  # workflow). It does only where a regression in a push passes, with
  # c.fail_on = :pull_requests in .duel.rb, so the comment says what the
  # check doesn't. Its last comment is the last one on any commit. This
  # job checks nothing out and runs none of the code.
  commit-comment:
    name: Comment on the commit
    needs: duel
    if: ${{ !cancelled() && github.event_name == 'push' && (needs.duel.outputs.comment == 'post' || needs.duel.outputs.comment == 'change') }}
    runs-on: ubuntu-latest
    permissions:
      contents: write # to comment on the commit with the report
    steps:
      - name: Get the report
        id: report
        continue-on-error: true # there's none when the Duel job failed before comparing
        uses: actions/download-artifact@9000827ccba6bdab643e8b6fd33ac0654aef8333 # v8.0.2
        with:
          name: duel-report
          path: ${{ runner.temp }}/report
      - uses: ruby/setup-ruby@f9c4492e86def3e644ab32a0ef185eda5b0c20d0 # v1.342.0
        if: steps.report.outcome == 'success'
        with:
          ruby-version: ruby
      # Duel's own code, from RubyGems (none of the push's).
      - name: Comment on the commit
        if: steps.report.outcome == 'success'
        env:
          GH_TOKEN: ${{ github.token }}
          DUEL_COMMENT: ${{ needs.duel.outputs.comment }}
          DUEL_STATUS: ${{ needs.duel.outputs.status }}
        run: |
          gem install duel --version '0.3.1' --no-document
          duel comment --report "$RUNNER_TEMP/report" --commit "$GITHUB_SHA" --marker 'duel'

  # With c.push_base = :last_passed in .duel.rb, a push is compared with
  # the last commit Duel passed, which a branch marks (each branch pushed
  # has its own), so slowdowns too small for any one push to fail add up
  # until they fail one. This job moves the branch (as Duel names it) to
  # a push that passed (or makes it), but never back: where a newer
  # push's run moved it first, it stays. It checks nothing out and runs
  # none of the code. To accept a regression, move the branch yourself
  # (for main, git push origin main:duel/passed/main).
  passed:
    name: Mark the commit passed
    needs: duel
    # One at a time for each branch, so that two runs can't both find no
    # branch and race to make it (a push's run doesn't wait for the one
    # before it). One that's running is never cancelled, and one that's
    # waiting gives way to a newer push's, which moves it further anyway.
    concurrency:
      group: ${{ github.workflow }}-passed-${{ github.ref_name }}
      cancel-in-progress: false
    if: ${{ !cancelled() && github.event_name == 'push' && needs.duel.outputs.passed != '' }}
    runs-on: ubuntu-latest
    permissions:
      contents: write # to move the branch
    steps:
      - uses: ruby/setup-ruby@f9c4492e86def3e644ab32a0ef185eda5b0c20d0 # v1.342.0
        with:
          ruby-version: ruby
      # Duel's own code, from RubyGems (none of the push's).
      - name: Move the branch to the commit
        env:
          GH_TOKEN: ${{ github.token }}
          BRANCH: ${{ needs.duel.outputs.passed }}
        run: |
          gem install duel --version '0.3.1' --no-document
          duel mark-passed "$BRANCH"
```

A newer push to a pull request cancels the pull request's run, if it's
still going, because only the newest commit's result counts. Every other
run, such as a push's to `main`, runs to the end, so each push is
compared.

The workflow compares the following:

- A pull request, against the branch that it targets: usually `main`,
  but a stable branch, or another pull request's branch in a stack of
  them, too.
- A merge queue's group, against the queue's base, the commit that the
  group merges into. With a merge queue, a required Duel check must run
  on `merge_group` too, or the queue waits for it forever. A regression
  fails a merge queue's run as it fails a pull request's, and the run
  reads the labels of the last pull request queued, for
  [`c.accept_label`](#accept-a-regression-with-a-label).
- A push to `main`, against the commit before the push, or with
  [`c.push_base = :last_passed`](#compare-a-push-with-the-last-commit-that-passed),
  the last commit that Duel passed. If that commit isn't in the history,
  such as after a force push or for a branch's first push, Duel reports
  that there's nothing to compare against, and passes.
- On a schedule, the last release, or with
  [`c.accept_label`](#accept-a-regression-with-a-label), the last commit
  since then that merged a pull request with the label. Until you tag
  your first release, Duel reports that there's nothing to compare
  against, and passes.
- When you run the workflow manually, your code against itself. This
  checks that the benchmarks run on the CI machines.

Duel compares a change that touches your code (`lib/` or `ext/`, or what
`c.watch` names), your benchmarks, `.duel.rb`, or, with
`c.ruby = :version_file`, your version file. Each version runs your
branch's benchmarks and configuration, so a change to only those compares
the same code with itself, which checks that they run and pass. A change
to only the workflow has nothing to compare: to check it, run the
workflow manually.

## Comment on a pull request

The workflow writes Duel's report
([Report on a pull request](../README.md#report-on-a-pull-request))
to a file, and comments on the pull request with it when
[`c.comment`](configuration.md#choose-when-to-comment-on-a-pull-request)
says to. By default, it comments when a benchmark fails, or when Duel
couldn't compare. Whatever `c.comment` says, a regression fails the
check, because `duel` exits with a nonzero status, and the job's
summary has the report.

The workflow never edits or deletes a comment, so the pull request
keeps every report that it posted. Once it posts one, it hides its
earlier ones as outdated, which GitHub collapses, so the newest is the
one in view. Each comment starts with a hidden
marker that records the run's status: `<!-- duel status=passed -->`,
`status=failed` (a run that couldn't compare too), or `status=neutral`
(nothing to compare). When a run's outcome wouldn't get a comment of
its own, the workflow still posts one if it commented on the pull
request before, and its last comment's status differs from this run's.
With the default, after a comment that a benchmark failed, the first
push that passes gets one comment saying so, and the pushes after it
get none. So the last comment is never stale. A comment from Duel 0.1.0,
whose marker has no status, counts as a comment with another status.

The workflow finds its comments by the marker's start. For a project
in a subdirectory of its repository, the marker names the directory,
such as `<!-- duel gems/parser status=failed -->`, so each of a
monorepo's workflows has comments of its own.

Duel decides, because it knows the outcome and reads `.duel.rb`. On
GitHub Actions, the Compare step's `duel` sets two step outputs, which
the Duel job passes on as its own: `comment`, and `status` (`passed`,
`failed`, or `neutral`). `comment` is one of the following:

| `comment` | What the Perf comment workflow does |
|---|---|
| `post` | Posts a new comment. |
| `change` | Posts a new comment only if the pull request has one from the workflow, and the last one's status isn't this run's. |
| `none` | Nothing. |

The Duel job runs the pull request's code, its benchmarks included, so
it only reads (`contents: read`). It keeps the report as an artifact
for a day, with a file, `comment.env`, that says what Duel decided:
the pull request's number, `comment`, and `status`. A second workflow,
`.github/workflows/perf-comment.yml`, posts the report. It runs when
the Perf workflow completes (`workflow_run`), with your repository's
own copy of the workflow and a token that can write, so a pull request
from a fork gets a comment too. It checks nothing out and runs none of
the pull request's code. It installs Duel from RubyGems, exactly the
release that wrote the workflow (or for Duel's reusable one, the
release it's from), and runs `duel comment`, so what runs with a token
that can write can't change under it: a fix to how it comments comes
with a new release of Duel and the workflow it writes. The pull
request's code ran in the Duel job, and could have written anything
into the artifact, so `duel comment` trusts only what Duel could have
said there: a number that names the pull request whose head the run
compared, and a `comment` and a `status` that Duel uses. The report's
Markdown, a fork's too, is the comment's body. When the Duel job fails before it compares, there's
no report, and no comment. GitHub runs a `workflow_run` workflow only
from your default branch, so the pull request that adds the workflow
gets no comment.

```yaml
# .github/workflows/perf-comment.yml
name: Perf comment

# Duel's report, as a new comment on the pull request, when Duel says to:
# always (post), or only when its last comment's status differs from the
# run's (change), so the latest comment is never stale. It never edits or
# deletes a comment, but hides Duel's earlier ones as outdated, so the
# newest is the one in view. It runs once the Perf workflow has, with
# this repository's own workflow and a token that can write, so a pull
# request from a fork gets a comment too. It checks nothing out and runs
# none of the pull request's code, only `duel comment` (see Duel's
# docs/ci.md), which trusts only what the Duel job could have said in
# what it kept: the pull request's number, if it names the pull request
# the run compared, and the comment and the status, if they're ones Duel
# says. Its report, a fork's too, is the comment, as Markdown.
#
# And when the label that accepts a regression (c.accept_label in
# .duel.rb) is added to a pull request, or taken off, it runs the Duel
# job again, which reads the labels as it runs: a run that failed, once
# the label's added, or one that passed, once it's taken off.
#
# (The workflow must be on the default branch before it runs at all.)
on:
  workflow_run:
    workflows: ["Perf"]
    types: [completed]
  # (This repository's own workflow, as for the comment, with a token
  # that can run a workflow again: it checks nothing out, and runs none
  # of the pull request's code.)
  pull_request_target:
    types: [labeled, unlabeled]

# Each Perf run's report has a run of its own, which nothing cancels, and
# a pull request's label changes run in turn.
concurrency:
  group: ${{ github.workflow }}-${{ github.event.pull_request.number || github.event.workflow_run.id }}
  cancel-in-progress: false

permissions: {}

jobs:
  comment:
    name: Comment
    if: ${{ github.event.workflow_run.event == 'pull_request' && github.event.workflow_run.conclusion != 'cancelled' }}
    runs-on: ubuntu-latest
    permissions:
      actions: read # to get the report from the Perf run
      pull-requests: write # to comment on the pull request with the report
    steps:
      - name: Get the report
        id: report
        continue-on-error: true # there's none when the Duel job failed before comparing
        uses: actions/download-artifact@9000827ccba6bdab643e8b6fd33ac0654aef8333 # v8.0.2
        with:
          name: duel-report
          path: ${{ runner.temp }}/report
          run-id: ${{ github.event.workflow_run.id }}
          github-token: ${{ github.token }}
      - uses: ruby/setup-ruby@f9c4492e86def3e644ab32a0ef185eda5b0c20d0 # v1.342.0
        if: steps.report.outcome == 'success'
        with:
          ruby-version: ruby
      # Duel's own code, from RubyGems (none of the pull request's), so a
      # fix to how it comments comes with a release of Duel.
      - name: Comment on the pull request
        if: steps.report.outcome == 'success'
        env:
          GH_TOKEN: ${{ github.token }}
          HEAD_SHA: ${{ github.event.workflow_run.head_sha }}
        run: |
          gem install duel --version '0.3.1' --no-document
          duel comment --report "$RUNNER_TEMP/report" --head "$HEAD_SHA" --marker 'duel'

  again:
    name: Run Duel again
    if: >-
      github.event_name == 'pull_request_target' && github.event.label.name == 'duel: accept'
    runs-on: ubuntu-latest
    permissions:
      actions: write # to run the Perf workflow's jobs again
    steps:
      - name: Run Duel again
        env:
          GH_TOKEN: ${{ github.token }}
          GH_REPO: ${{ github.repository }}
          HEAD_SHA: ${{ github.event.pull_request.head.sha }}
          ACTION: ${{ github.event.action }}
        run: |
          # The newest Perf run of the pull request's head commit, once it's
          # done (one that's running may have read the labels already).
          id=$(gh run list --workflow "Perf" --event pull_request --commit "$HEAD_SHA" --limit 1 \
            --json databaseId --jq '.[0].databaseId // empty')
          [ -n "$id" ] || exit 0
          gh run watch "$id" --interval 30 > /dev/null || true
          conclusion=$(gh run view "$id" --json conclusion --jq .conclusion)
          case "$ACTION:$conclusion" in
            labeled:failure) gh run rerun "$id" --failed ;;
            unlabeled:success) gh run rerun "$id" ;;
          esac
```

## Comment on a pushed commit

With [`c.fail_on = :pull_requests`](configuration.md#fail-only-a-pull-request),
a regression in a push to `main` passes, and the workflow's Comment on
the commit job comments on the pushed commit with the report instead.
GitHub notifies the commit's author. It comments as `c.comment` says,
the way the Comment job does on a pull request, but its last comment is
the workflow's last one on any commit. So with the default, each push
that fails gets a comment, the first push after them that passes gets
one, and the passing pushes after it get none.

By default, a push gets no comment: Duel sets the `comment` output to
`none`, and a regression fails the push's check instead. The Comment on
the commit job checks nothing out either, and it alone gets the
`contents: write` permission that a commit comment takes.

Like the comment workflow, the jobs for a push run Duel's own code,
from RubyGems: `duel comment --commit`, `duel mark-passed` and
`duel badge`. So a fix to one comes with a release of Duel, and none of
them runs the push's code.

The workflow that `duel init` writes has the Comment on the commit job
whatever `.duel.rb` says, as the job only runs where Duel says to
comment (see [The workflow](#catch-slow-creep)), so setting
`c.fail_on` later needs nothing of the workflow.

## Accept a regression with a label

With [`c.accept_label`](configuration.md#accept-a-regression-with-a-label),
a pull request with that label passes a regression. The Duel job's Find
the pull request's labels step reads the labels of the pull request,
or for a push, of the pull request that merged it, and passes them to
`duel` as a JSON array, in `DUEL_LABELS`. That takes the
`pull-requests: read` permission. Without the labels, such as when
GitHub's API fails, nothing is accepted.

The labels are read as the Duel job runs, so `perf-comment.yml` runs
the job again when the label changes. Its Run Duel again job runs on
`pull_request_target`, with this repository's own workflow, when a
label is added to a pull request or taken off. For the label `.duel.rb`
names, it waits for the Perf run of the pull request's head commit to
finish. Then it runs the failed jobs again where the label was added
to a run that failed, or the whole run again where the label was
taken off one that passed. The run the label accepts is commented on
as one that passed would be: with the default `c.comment = :failures`,
only where the last comment's status isn't its own, so the report that
failed isn't posted again. It checks nothing out and runs none of the
pull request's code, and its only permission is `actions: write`. The
workflows name the label as `.duel.rb` did when `duel init` wrote them,
so if you rename it, rename it in both workflows too.

On a schedule, the same step looks for the pull requests merged since
the last release with the label, and passes `duel` the last commit
that merged one, in `DUEL_ACCEPTED`. Duel compares with that commit
instead of the release, as what it slowed down was accepted.

## Compare a push with the last commit that passed

By default, the workflow compares each push with the commit before it.
A series of pushes that are each a little slower each pass, and a push
that the workflow doesn't compare, such as one whose run was cancelled,
is never compared. With
[`c.push_base = :last_passed`](configuration.md#compare-a-push-with-the-last-commit-that-passed),
the workflow compares each push with the last commit that Duel passed,
so the slowdowns add up until they fail a push.

A branch, `duel/passed/main` for `main`, marks that commit. Each
branch that the workflow guards has its own (see
[Guard other branches](#guard-other-branches)). When a push passes, or has
nothing to compare, Duel sets the `passed` output to `true`, and the
Mark the commit passed job moves the branch to the push, or creates the
branch. It never moves the branch back: when two pushes run at once and
the older one finishes last, the branch stays at the newer push. The
job runs one at a time for each branch, so two runs can't race to
create the branch. After a force push rewrites the branch's history,
it moves the branch anyway.
That job checks nothing out either, and it gets the `contents: write`
permission that moving a branch takes. Until the branch exists, and
when the push's history doesn't have its commit, Duel compares the push
with the commit before it. For a project in a subdirectory of its
repository, the branch names the directory, such as
`duel/passed-gems-parser/main`.

Git can't have a branch named `duel` and a branch named
`duel/passed/main` at once, because a branch's name is a path, and
`duel` can't be both a file and a folder. If your repository has a
branch named `duel`, say the one that added Duel, the job can't make
its branch, and its error says so. Delete that branch
(`git push origin --delete duel`), or rename it.

After a regression, the branch stays where it is, so every push fails
(or with [`c.fail_on = :pull_requests`](#comment-on-a-pushed-commit),
is reported) until one is no slower. To accept a regression, move the
branch yourself:

```sh
git push origin main:duel/passed/main
```

If you set `c.push_base` back to `:before`, you can delete the branches
too (`git push origin --delete duel/passed/main`): Duel no longer reads
them.

The workflow that `duel init` writes has the Mark the commit passed job
whatever `.duel.rb` says, as the job only runs where Duel names the
branch to move (its `passed` output), so setting `c.push_base` later
needs nothing of the workflow.

## Show whether the last push passed

With `--badge`, `duel init` adds the Update the badge job, which keeps a
badge that turns red when Duel fails. After each push to your default
branch, it writes `badge.svg` to a branch of its own, `duel/badge`, so
your README can show it, linked to your Perf workflow's runs:

```markdown
[![Duel](https://raw.githubusercontent.com/OWNER/REPO/duel/badge/badge.svg)](https://github.com/OWNER/REPO/actions/workflows/perf.yml)
```

The badge says "perf guarded", in green, when Duel passed the push. It
says "perf regressed", in red, when Duel failed the push or found a
regression, even one that passed, with
[`c.fail_on = :pull_requests`](#comment-on-a-pushed-commit), or that a
label accepted. It says "not measured", in grey, when the Duel job
failed before Duel could judge the push, as when its runner ran out of
memory or a step before Duel's failed. A job that fails after Duel
passed the push leaves it green. A push with nothing to compare leaves
the badge as it was, and so does a run that finishes after a newer
push's, so the badge is always the newest push's that Duel compared.
The branch holds one commit, with the badge alone, whose message names
that push. The job checks nothing out, and it gets the `contents: write`
permission that moving a branch takes. For a project in a subdirectory
of its repository, the branch names the directory, such as
`duel/badge-gems-parser`.

Until the first push to your default branch after you add the job, the
branch doesn't exist, and the badge doesn't show.

`duel init` writes the job only with `--badge` (for a Rails app,
`bin/rails generate duel:install --badge`), as without the jobs for
pushes, it's the workflow's only job that writes to the repository. To
add it later, remove the workflow, and run `duel init --badge` again (it
keeps `.duel.rb`), or add the job yourself:

```yaml
# .github/workflows/perf.yml, in jobs: (with duel init --badge)
  # Duel's badge, for the README: green (perf guarded), red (perf
  # regressed) or grey (not measured), as the last push to the default
  # branch that Duel compared left it. It's red where Duel failed the push
  # or found a regression, even one that passed (with
  # c.fail_on = :pull_requests in .duel.rb), and grey where the Duel job
  # failed before Duel could judge the push (its runner ran out of memory,
  # say). A push with nothing to compare leaves it as it was, and so does
  # a run for an older push than the badge's. This job writes the badge,
  # alone, to a branch of its own, which the README shows:
  #
  #   [![Duel](https://raw.githubusercontent.com/OWNER/REPO/duel/badge/badge.svg)](https://github.com/OWNER/REPO/actions/workflows/perf.yml)
  #
  # It checks nothing out, runs none of the code, and fetches nothing.
  badge:
    name: Update the badge
    needs: duel
    # One at a time, so that one run's check of which push the badge
    # shows can't interleave with another run's write (a push's run
    # doesn't wait for the one before it). A badge job that's running is
    # never cancelled, and one that's waiting gives way to a newer push's,
    # whose result the badge should show anyway.
    concurrency:
      group: ${{ github.workflow }}-badge
      cancel-in-progress: false
    if: ${{ !cancelled() && github.event_name == 'push' && github.ref_name == github.event.repository.default_branch && (needs.duel.result == 'failure' || needs.duel.outputs.status == 'passed' || needs.duel.outputs.status == 'failed') }}
    runs-on: ubuntu-latest
    permissions:
      contents: write # to move the badge's branch
    steps:
      - uses: ruby/setup-ruby@f9c4492e86def3e644ab32a0ef185eda5b0c20d0 # v1.342.0
        with:
          ruby-version: ruby
      # Duel's own code, from RubyGems (none of the push's).
      - name: Update the badge
        env:
          GH_TOKEN: ${{ github.token }}
          RESULT: ${{ needs.duel.result }}
          STATUS: ${{ needs.duel.outputs.status }}
        run: |
          gem install duel --version '0.3.1' --no-document
          duel badge duel/badge --status "$STATUS" --result "$RESULT"
```

## Guard other branches

The workflow compares the pushes to `main`. To guard another branch,
such as a stable branch that gets backports, add it to the workflow's
`push` branches:

```yaml
  push:
    branches: [main, 2-x-stable]
```

Duel compares a push to each branch with the commit before it, or with
`c.push_base = :last_passed`, with the last commit that Duel passed on
that branch, which a branch of its own marks: `duel/passed/2-x-stable`.
A pull request into the branch is compared with the branch, whatever
the workflow guards.

## Keep the workflows up to date

A release of Duel can change the workflows that `duel init` writes. To
see how yours differ from what the installed Duel writes, run it with
`--check`, and the options you ran it with (such as `--badge`):

```sh
bundle exec duel init --check
```

It says whether each workflow is the same, differs (and shows how, as
`diff -u` does), or is missing, and writes nothing. It exits with 1
where one isn't the same. For the short workflows that call Duel's, a
release mostly changes the tag they call. For the whole ones
(`--standalone`), copy in the changes you want, so that steps you
added to the Duel job (to install a database server, say) stay.
With `--gitlab`, it checks the GitLab CI jobs. In a Rails app, run
duel-rails's generator with `--check` instead:

```sh
bin/rails generate duel:install --check
```

## Call Duel's reusable workflows

Rather than copy Duel's whole workflows into your repository, the
workflows that `duel init` writes call Duel's reusable ones, which are
the same workflows with each setting as an input. It writes a Perf
workflow and a Perf comment workflow that call them, at the tag of the
Duel release you run it with, and pass on what your `.duel.rb` sets
(with `--standalone`, it writes the whole workflows instead):

```yaml
# .github/workflows/perf.yml
jobs:
  duel:
    uses: sferik/duel-ruby/.github/workflows/duel.yml@v0.3.1
    permissions:
      contents: read
      pull-requests: read # for the pull request's labels (see c.accept_label)
    with:
      ruby-version: "3.4"
  push:
    needs: duel
    if: ${{ !cancelled() && github.event_name == 'push' }}
    uses: sferik/duel-ruby/.github/workflows/duel-push.yml@v0.3.1
    permissions:
      contents: write # to comment on the commit, move the passed branch, and the badge's
    with:
      comment: ${{ needs.duel.outputs.comment }}
      status: ${{ needs.duel.outputs.status }}
      passed: ${{ needs.duel.outputs.passed }}
      result: ${{ needs.duel.result }}
```

Your workflows keep their triggers, their concurrency and their
permissions, which Duel's jobs can only narrow. The Duel job, which runs
the pull request's code, only reads (`contents: read`), as it does in
the whole workflow. The jobs for a push that write to the repository
(the [comment on a pushed commit](#comment-on-a-pushed-commit),
[marking a push passed](#compare-a-push-with-the-last-commit-that-passed)
and [the badge](#show-whether-the-last-push-passed)) are Duel's push
workflow's (`.github/workflows/duel-push.yml`), which your workflow
calls once the Duel job is done, only for a push, and grants
`contents: write` to alone. So a pull request's run is never given a
token that writes (see below).

Duel's Perf workflow (`.github/workflows/duel.yml`) takes these inputs:

| Input | Default | What it is |
| --- | --- | --- |
| `ruby-version` | `default` | The Ruby the Duel job runs (`default`: the one `.ruby-version` names). |
| `version-file` | `false` | Whether each version runs on the Ruby its own `.ruby-version` names ([`c.ruby = :version_file`](configuration.md)). |
| `jit` | `none` | The JIT the benchmarks run with on, as Ruby runs one at most: `none`, `yjit` (`RUBY_YJIT_ENABLE=1`), as a Rails app runs, say, or `zjit` (`RUBY_ZJIT_ENABLE=1`), on Ruby 4.0 or later. Duel fails where a version's Ruby doesn't run it (JRuby, or for ZJIT, Ruby 3.4, say). |
| `runs-on` | `ubuntu-latest` | The runner the Duel job runs on, Linux, macOS or Windows: a larger one, say, for steadier timings. See [On Windows](#on-windows). |
| `timeout-minutes` | `60` | How long the Duel job may take before it's cancelled. |
| `working-directory` | `.` | The project's directory, from the repository's root. |
| `gemfile` | none | A Gemfile of Duel's own, from the project's directory (`gemfiles/duel.gemfile`, say), which keeps Duel out of the project's other bundles. Duel and both versions' workers run in its bundle, so it needs what the benchmarks load (`eval_gemfile "../Gemfile"`, say). |
| `submodules` | `false` | Whether to check out the repository's submodules too (`true`, or `recursive`), as [actions/checkout](https://github.com/actions/checkout) takes it. |
| `setup` | none | Shell commands that set up whatever else your tests need (packages, services), before Ruby is set up. |
| `setup-after-ruby` | none | Shell commands that set up what needs Ruby first (on Windows, a package of Ruby's devkit, from `pacman`, say), before the bundle is installed. See [On Windows](#on-windows). With them, the bundle isn't cached. |
| `report` | none | A name for the call's report and check (`yjit`, say), where your workflow calls Duel's more than once: see below. |

It takes nothing that `.duel.rb` says, which Duel reads as it runs. It
says what Duel said, as its outputs, for Duel's push workflow and for
jobs of your own (a notice in a channel, say): `comment` (`post` or
`change`, or nothing), `status` (`passed`, `failed` or `neutral`) and
`passed` (the branch that marks the push passed, `duel/passed/main`
say, or nothing).

Duel's push workflow (`.github/workflows/duel-push.yml`) takes those
outputs as its inputs of the same names, and `result`, how the Duel
job's call ended (`needs.duel.result`), which the badge shows where it
failed. Its jobs run where they say to. It takes `working-directory`
and `report` too, as given to the Duel job's call, and `badge`
(`false` by default), whether to
[keep a badge](#show-whether-the-last-push-passed) for the README. The
names of the branches its jobs move, and of the badge's, and the
marker of its comments, come from `working-directory`.

To measure each version more than one way, call Duel's Perf workflow
more than once, each call with a `report` of its own:

```yaml
jobs:
  yjit:
    uses: sferik/duel-ruby/.github/workflows/duel.yml@v0.3.1
    permissions:
      contents: read
      pull-requests: read
    with:
      jit: yjit
      report: yjit
  zjit:
    uses: sferik/duel-ruby/.github/workflows/duel.yml@v0.3.1
    permissions:
      contents: read
      pull-requests: read
    with:
      ruby-version: "4.0"
      jit: zjit
      report: zjit
  interpreter:
    uses: sferik/duel-ruby/.github/workflows/duel.yml@v0.3.1
    permissions:
      contents: read
      pull-requests: read
    with:
      report: interpreter
```

Each call is a check of its own (`yjit / Duel (yjit)`), and the Perf
comment workflow comments with every call's report, as one comment,
each under its name. The comment's status is the most any call's
says: failed, if any failed, and passed only if every one passed. For
the jobs for a push, call Duel's push workflow after a call, with what
it said and its `report`:

```yaml
  yjit-push:
    needs: yjit
    if: ${{ !cancelled() && github.event_name == 'push' }}
    uses: sferik/duel-ruby/.github/workflows/duel-push.yml@v0.3.1
    permissions:
      contents: write
    with:
      comment: ${{ needs.yjit.outputs.comment }}
      status: ${{ needs.yjit.outputs.status }}
      passed: ${{ needs.yjit.outputs.passed }}
      result: ${{ needs.yjit.result }}
      report: yjit
```

Turn on `badge` in one such call at most, as each call's jobs run on
their own, and with `c.fail_on = :pull_requests` or
`c.push_base = :last_passed`, each one comments on a push, or marks it
passed, as its Duel says.

### On Windows

The Duel job runs its steps, and `setup` and `setup-after-ruby`, in
bash on every runner, not PowerShell: on Windows, Git's, and once Ruby
is set up, the bash of Ruby's devkit (MSYS2). setup-ruby sets the devkit
up, with its gcc, so a gem's C extension builds without help. A C
library that an extension links can come from the devkit too, with
`pacman`, which is there only once Ruby is set up, so install it in
`setup-after-ruby`, and the job installs the bundle after it. Add a call
for Windows next to the one for Linux, say:

```yaml
jobs:
  linux:
    uses: sferik/duel-ruby/.github/workflows/duel.yml@v0.3.1
    permissions:
      contents: read
      pull-requests: read
    with:
      report: linux
  windows:
    uses: sferik/duel-ruby/.github/workflows/duel.yml@v0.3.1
    permissions:
      contents: read
      pull-requests: read
    with:
      runs-on: windows-latest
      report: windows
      # (libyaml, say, for psych.)
      setup-after-ruby: pacman --sync --needed --noconfirm "${MINGW_PACKAGE_PREFIX}-libyaml"
```

`MINGW_PACKAGE_PREFIX` is the devkit's (setup-ruby sets it), and so is
`RI_DEVKIT`, its directory. Paths from bash there look like `/c/...`,
and Ruby reads `C:/...`: `cygpath -m` turns one into the other. To put
a directory on the `PATH` (with `$GITHUB_PATH`), mind the order: each
line goes before those written before it, and a DLL ahead of the
devkit's (a database's client library's, say) can keep its gcc from
running. Write them on one line, `;` between, the devkit's first.

Duel's Perf comment workflow (`.github/workflows/duel-comment.yml`)
takes `accept-label`, `marker`, and `perf-workflow` (the name of your
Perf workflow, `Perf` by default).

The jobs for pushes, and the badge's, write to the repository, so the
call of Duel's push workflow grants `contents: write`. GitHub checks
every job of a workflow it calls against what the caller grants,
whether the job runs or not, and a run where one asks for more fails
before it starts. That's why they're a workflow of their own: were they
the Perf workflow's, its call, and so a pull request's run, would have
to grant `contents: write` too.

With an accept label, your Perf comment workflow grants
`actions: write`, to run the Duel job again. The checks are named for
your job and Duel's, as in `duel / Duel`. To update Duel's workflows,
change the tag. `duel init --check` compares the workflows that call
them, and `duel init --check --standalone` the whole ones.

A tag can be moved, so you can name the commit it's at instead, with
the tag beside it, as Dependabot keeps them:

```yaml
    uses: sferik/duel-ruby/.github/workflows/duel.yml@<commit> # v0.3.1
```

Duel's workflows, the reusable ones and those `duel init` writes, name
each action they use by its commit too, and the jobs that write to the
repository (or comment) install exactly the release of Duel that wrote
them (`gem install duel --version '0.3.1'`), not the newest one.

## Run Duel on GitLab CI

`duel init --gitlab` writes GitLab CI jobs, in
`.gitlab/duel.gitlab-ci.yml`, instead of the GitHub Actions workflows.
Include them from your `.gitlab-ci.yml`:

```yaml
include:
  - local: .gitlab/duel.gitlab-ci.yml
```

The Duel job compares a merge request with the branch that it targets,
a push to your default branch with the commit before it (or with
[`c.push_base = :last_passed`](#compare-a-push-with-the-last-commit-that-passed),
the last commit that Duel passed), and on a schedule, your last
release. It runs on the `ruby` image of the version that your
`.ruby-version` names, or else of your Ruby. On GitLab, a branch that
upgrades Ruby can't compare each version on its own Ruby, because the
image has only one. Duel reads GitLab's variables: a merge request's
target, and its labels, for
[`c.accept_label`](configuration.md#accept-a-regression-with-a-label).
A push's labels aren't available.

With [`c.fail_on = :pull_requests`](configuration.md#fail-only-a-pull-request),
a regression outside a merge request makes `duel` exit with status 3,
and the job lets that fail (`allow_failure: exit_codes: [3]`), so the
pipeline shows a warning, not a failure.

The Duel job writes what it decided to a dotenv report (`DUEL_OUTPUT`):
`DUEL_COMMENT`, `DUEL_STATUS`, and `DUEL_PASSED`. The jobs after it act
on them. They check nothing out and run none of the code. GitLab's own
job token can't comment, so they need project access tokens, in masked
CI/CD variables. Without them, the jobs don't run, and the Duel job's
log and its `duel.md` artifact have the report.

- `DUEL_COMMENT_TOKEN`, with the Reporter role and the `api` scope, and
  not protected, so a merge request's pipeline has it, to comment on a
  merge request. Every job in that pipeline has it, the Duel job too,
  which runs the merge request's code, so give it no more than the
  Reporter role.
- `DUEL_TOKEN`, with the Developer role and the `api` scope, and
  protected, so only your protected branches' pipelines have it, to
  comment on a pushed commit and to mark a push passed.

The comment on a merge request comes from `duel comment`, on GitLab CI,
installed from RubyGems in a `ruby:slim` image, as on GitHub, so a fix
to it comes with a release of Duel. It trusts only a `DUEL_COMMENT` and
a `DUEL_STATUS` that Duel says, and comments only if the merge
request's head is still the one the pipeline compared. In a merged
results pipeline, the report names the merge request's own commit,
"merged with `main`", as it does on GitHub.

Three things GitLab does differently. Duel can't collapse its earlier
comments there, because only the Developer role can resolve a thread,
and the merge request's token has the Reporter role. Adding the label
that accepts a regression doesn't run the pipeline again, as GitLab has
no pipeline for a label, so run it again yourself (or push). And a
merge request from a fork runs its pipeline in the fork, without your
variables, so it gets no comment. The comment on a pushed commit looks
only at the comments on the commit before it for its last status.

```yaml
# .gitlab/duel.gitlab-ci.yml
# Duel on GitLab CI: https://github.com/sferik/duel-ruby/blob/main/docs/ci.md#run-duel-on-gitlab-ci
#
# Include it from .gitlab-ci.yml:
#
#   include:
#     - local: .gitlab/duel.gitlab-ci.yml
#
# It compares a merge request with the branch it targets, a push to the
# default branch with the commit before it (or as c.push_base in .duel.rb
# says, the last commit Duel passed), and on a schedule, the last release.
# The Duel job's log, and its duel.md artifact, have the report. Comments
# need project access tokens, in masked CI/CD variables:
#
# - DUEL_COMMENT_TOKEN (the Reporter role, with the api scope, and not
#   protected), to comment on a merge request. Every job of a merge
#   request's pipeline has it, the Duel job too, which runs the merge
#   request's code, so the token can do no more than comment.
# - DUEL_TOKEN (the Developer role, with the api scope, and protected, so
#   only the default branch's pipelines have it), to comment on a pushed
#   commit (see c.fail_on), and to mark a push passed (see c.push_base).

duel:
  image: ruby:3.4
  stage: test
  variables:
    GIT_DEPTH: 0 # the baseline comes from history, tags included
    DUEL_OUTPUT: duel.env # whether to comment, and mark a push passed
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
    # (Duel compares a push with the commit before it, and a schedule's
    # run with the last release, as CI_PIPELINE_SOURCE says.)
    - if: $CI_PIPELINE_SOURCE == "push" && $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH
    - if: $CI_PIPELINE_SOURCE == "schedule"
    # (Run by hand, it compares anyway: with nothing changed, the code
    # with itself, which checks the setup.)
    - if: $CI_PIPELINE_SOURCE == "web"
      variables:
        DUEL_FORCE: "1"
  # A regression outside a merge request, where only a merge request
  # fails (c.fail_on in .duel.rb), exits 3: a warning.
  allow_failure:
    exit_codes: [3]
  before_script:
    # The branch a merge request targets, the last commits Duel passed,
    # and the releases.
    - git fetch --quiet --tags origin "+refs/heads/duel/*:refs/remotes/origin/duel/*"
    - if [ -n "$CI_MERGE_REQUEST_TARGET_BRANCH_NAME" ]; then git fetch --quiet origin "$CI_MERGE_REQUEST_TARGET_BRANCH_NAME"; fi
    - bundle install
  script:
    - bundle exec duel --markdown duel.md
  artifacts:
    when: always
    paths:
      - duel.md
    reports:
      dotenv: duel.env
    expire_in: 1 day

# The report, as a new comment on the merge request, when Duel says to:
# always (post), or only when its last comment's status differs from this
# run's (change), so the latest comment is never stale. It never edits or
# deletes a comment. It runs `duel comment`, from RubyGems (none of the
# merge request's code), so a fix to how it comments comes with a release
# of Duel.
duel:comment:
  image: ruby:slim
  stage: .post
  needs: [duel]
  rules:
    - if: $DUEL_COMMENT_TOKEN && $CI_PIPELINE_SOURCE == "merge_request_event"
      when: always
  variables:
    GIT_STRATEGY: none # it runs none of the code
  script:
    - gem install duel --version '0.3.1' --no-document
    # (The merge request's head: in a merged results pipeline, not the
    # commit that merges it.)
    - duel comment --report . --head "${CI_MERGE_REQUEST_SOURCE_BRANCH_SHA:-$CI_COMMIT_SHA}" --marker 'duel'

# The report, as a new comment on a pushed commit, when Duel says to, as
# for a merge request: only where a regression in a push passes (see
# c.fail_on), so the comment says what the check doesn't. Its last comment
# is the commit before's. It runs `duel comment`, from RubyGems, signed in
# with DUEL_TOKEN.
duel:commit-comment:
  image: ruby:slim
  stage: .post
  needs: [duel]
  rules:
    - if: $DUEL_TOKEN && $CI_PIPELINE_SOURCE == "push" && $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH
      when: always
  variables:
    GIT_STRATEGY: none # it runs none of the code
  script:
    - gem install duel --version '0.3.1' --no-document
    - duel comment --report . --commit "$CI_COMMIT_SHA" --marker 'duel'

# With c.push_base = :last_passed in .duel.rb, a push is compared with the
# last commit Duel passed, which a branch marks (duel/passed/main for
# main), so slowdowns too small for any one push to fail add up until they
# fail one. This job moves the branch (as Duel names it, DUEL_PASSED) to a
# push that passed (or makes it), but never back: where a newer push's job
# moved it first, it stays. It runs `duel mark-passed`, from RubyGems,
# signed in with DUEL_TOKEN. To accept a regression, move the branch
# yourself (for main, git push origin main:duel/passed/main).
duel:passed:
  image: ruby:slim
  stage: .post
  needs: [duel]
  # One at a time, as each deletes the branch and makes it again: two at
  # once could both delete it, and the second to make it would fail.
  resource_group: duel/passed
  rules:
    - if: $DUEL_TOKEN && $CI_PIPELINE_SOURCE == "push" && $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH
  variables:
    GIT_STRATEGY: none # it runs none of the code
  script:
    - '[ -n "$DUEL_PASSED" ] || exit 0'
    - gem install duel --version '0.3.1' --no-document
    - duel mark-passed "$DUEL_PASSED"
```

## Run each version on its own Ruby on CI

With [`c.ruby = :version_file`](configuration.md#run-each-version-on-its-own-ruby),
each version runs on the Ruby that its own version file names. On CI, a
setup step such as `ruby/setup-ruby` installs the Ruby that
runs `duel` where no version manager looks. That's enough while both
versions ask for that Ruby. A branch that upgrades Ruby needs the
baseline's Ruby installed too, where Duel finds it. For example, for a
project with a `.ruby-version`, in the
[GitHub Actions workflow](#catch-slow-creep), once your Ruby and its
bundle are set up, ask Duel which commit the Compare step compares
with: `bundle exec duel base` prints it, as the run will find it, for
whatever event the run is for (where `HEAD` left the main branch for a
pull request, the commit before a push, or the last commit Duel passed,
and the last release on a schedule), with `.duel.rb`'s settings, or
nothing, without a baseline, such as for a branch's first push, or
before your first release. When that commit's `.ruby-version` names
another Ruby than yours, install that Ruby with a second
`ruby/setup-ruby` step, with the bundle for it (`bundler-cache: true`),
link it into `~/.rubies`, where Duel looks for Rubies the way that
chruby does, and put your own Ruby first on the `PATH` again, which the
second step took the place of. The baseline's workers load the same
bundle as the candidate's, and gems installed for one Ruby version don't
load on another, so without that bundle they can't load the code to
compare. `duel init` adds these steps for a project that has a
`.ruby-version`:

```yaml
      # (After the step that sets up the candidate's Ruby, id: ruby.)
      # Each version runs on the Ruby its own .ruby-version names (see
      # .duel.rb). When the baseline's names another Ruby than this code's,
      # that one is installed too, with its bundle, and linked where Duel
      # finds it (as chruby would), and the project's own Ruby, which runs
      # Duel, comes first again. The baseline is the one the Compare step
      # compares with, as Duel finds it (duel base).
      - name: Find the baseline's Ruby
        id: baseline
        env:
          # (On a schedule, for the last change a label accepted since the
          # last release, which Duel finds with gh.)
          GH_TOKEN: ${{ github.event_name == 'schedule' && github.token || '' }}
        run: |
          base=$(bundle exec duel base)
          # (None where the commit has no .ruby-version: git fails, which
          # fails the pipeline, under pipefail.)
          ruby_of() { git show "$1:./.ruby-version" 2>/dev/null | awk 'NF { print $1; exit }' || true; }
          ruby=
          # (None without a baseline: a branch's first push, or no release yet.)
          if [ -n "$base" ]; then
            ruby=$(ruby_of "$base")
            [ "$ruby" = "$(ruby_of HEAD)" ] && ruby=
          fi
          echo "ruby=$ruby" >> "$GITHUB_OUTPUT"
      - uses: ruby/setup-ruby@f9c4492e86def3e644ab32a0ef185eda5b0c20d0 # v1.342.0
        id: baseline-ruby
        if: steps.baseline.outputs.ruby != ''
        with:
          ruby-version: ${{ steps.baseline.outputs.ruby }}
          # The bundle for this Ruby too, which the baseline's workers load.
          # (Gems installed for one Ruby version don't load on another.)
          bundler-cache: true
      - name: Link the baseline's Ruby where Duel finds it
        if: steps.baseline.outputs.ruby != ''
        env:
          PREFIX: ${{ steps.baseline-ruby.outputs.ruby-prefix }}
          RUBY_PREFIX: ${{ steps.ruby.outputs.ruby-prefix }}
          MSYS: winsymlinks:nativestrict # (on Windows, bash's ln links, not copies)
        run: |
          # (The project's own Ruby first again, for the steps after: it
          # runs Duel.)
          echo "$RUBY_PREFIX/bin" >> "$GITHUB_PATH"
          # (On Windows, as bash's /c/..., not C:\..., which it can't run.)
          if command -v cygpath > /dev/null; then PREFIX=$(cygpath -u "$PREFIX"); fi
          mkdir -p ~/.rubies
          ln -sfn "$PREFIX" ~/.rubies/ruby-"$("$PREFIX/bin/ruby" -e 'print RUBY_VERSION')"
```
