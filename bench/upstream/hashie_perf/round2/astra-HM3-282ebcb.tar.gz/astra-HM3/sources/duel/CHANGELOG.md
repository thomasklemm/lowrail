# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/2.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.1] - 2026-11-22

### Added

- A plugin can say how many workers' resources the machine has room
  for at once, counting each version's, as its module's `worker_limit`
  (or `nil` for no limit), where they take something there's only so
  much of: a postgres's System V shared memory segment, say, which
  macOS allows 32 of in all. Duel runs no more workers at once than the
  fewest any plugin used says: it runs fewer benchmarks at a time, and
  then fewer workers of each version, as it does to fit the memory
  available, and says so ("Its plugins' resources allow 16 workers at
  once, as they say, so to fit: ..."), even where it can't tell the
  memory available. Where the `--jobs` and `--processes` (or
  `c.processes`) given would run more, it fails before starting any,
  saying how many they'd run and how many fit.

### Changed

- AGENT_PROMPT.md has the agent set up the badge that turns red when
  Duel fails a push to the default branch, by default: it runs
  `duel init --badge` (or `bin/rails generate duel:install --badge`)
  and shows that badge in the README, linked to the Perf workflow's
  runs. It shows Duel's own badge, which is always green, only where
  there's no job to keep one (on GitLab CI, or where the workflow
  doesn't run for pushes), and leaves out the badge's job where the
  README shows no badges. Its step about the workflow's jobs for
  pushes describes them as Duel 0.3.0 writes them.
- The Perf comment workflow that `duel init` writes has a concurrency
  group, as linters of workflows such as jactionlint ask for: each Perf
  run's report has a run of its own, which nothing cancels, and a pull
  request's label changes run in turn. The workflow that calls Duel's
  reusable one names its group with `-caller`, apart from any of the
  workflow it calls, where `github.workflow` is the caller's name too.

### Fixed

- A baseline checked out and built by an earlier run is built afresh
  where the Ruby running Duel changed since (a new patch release, say),
  rather than measured with a C extension built for the other Ruby,
  which can fail to load ("Library not loaded: .../libruby.3.4.dylib")
  or measure the wrong code: `rake compile` doesn't redo a build when
  nothing it's built from changed. A baseline whose build failed is
  built afresh on the next run too, not measured as it was left. Duel
  keeps what built the checkout (its commit, and the Ruby) in
  `tmp/duel`, which `duel clean` removes with the checkout.
- `duel init` writes the workflow's push trigger for the project's
  default branch: `.duel.rb`'s `c.main_branch`, the branch origin's
  HEAD names (the repository's default, in a clone of it), or else
  `main`, or `master`, whichever is there. It wrote `main` whatever
  the repository's was, so a project whose default branch is `master`
  ran Duel on no push until its workflow was changed by hand. The
  comment on moving the passed branch names it too, and so do the
  comments of the `.duel.rb` it writes on `c.fail_on` and
  `c.push_base`.

## [0.3.0] - 2026-11-20

### Added

- `c.release_tags` and `c.benchmarks` take a list of globs too:
  `c.release_tags = %w[v* my_gem-v*]` for a gem that renamed its tags
  (a tag that matches any of them is a release), and `c.benchmarks =
  %w[perf/**/*_duel.rb test/perf/*_duel.rb]` for benchmarks in two
  places (each glob's directory is watched). One glob works as before.
- `Duel.find_program` finds a plugin's server program, as
  duel-postgresql, duel-mysql, duel-redis and duel-memcached now all
  do: a path (one with a `/` or a `\` in it, `~` expanded) as it is,
  or a name in the first of the `PATH`'s directories that has it,
  either one ending with `.exe` on Windows too. `Duel.path?` says which
  it takes a server for, for the plugin's error that it isn't there.
- Duel's reusable Perf workflow runs on Windows (`runs-on:
  windows-latest`): the Duel job's steps run in bash on every runner (on
  Windows, not PowerShell), and paths it hands Ruby are Windows's there.
  A new input, `setup-after-ruby`, runs shell commands once Ruby is set
  up, before the bundle is installed, for what needs Ruby first: on
  Windows, a package of Ruby's devkit, from `pacman`, that a gem's C
  extension links. And `c.ruby = :version_file` finds a Ruby on
  Windows, whose program is `ruby.exe` (or `jruby.exe`).
- Duel fails a run where a worker's environment turns on one of CRuby's
  JITs (`RUBY_YJIT_ENABLE` or `RUBY_ZJIT_ENABLE`, as `1`, `true` or
  `yes`) that the worker doesn't run, saying which version's workers,
  which JIT, and on what Ruby. A Ruby without the JIT ignores its
  variable, so `jit: zjit` on Ruby 3.4, or `jit: yjit` on JRuby,
  measured without it, and nothing said so.
- ZJIT, the JIT compiler that's experimental in Ruby 4.0 and is due to
  ship in Ruby 4.1, is taken for a JIT as YJIT is: where a worker has
  it on (`RUBY_ZJIT_ENABLE=1`, or turned on as the app loads), Duel
  runs each benchmark until it's steady before it measures it, for up
  to ten seconds (or as `--warm` says). It measured from the first
  sample before, while ZJIT was still compiling. Duel's reusable Perf
  workflow takes the JIT to turn on as one input, `jit:` (`none`,
  `yjit` or `zjit`, as Ruby runs one at most), in place of its `yjit:
  true`.
- `duel comment --commit SHA` comments on a pushed commit, as Duel's
  outputs say (`DUEL_COMMENT` and `DUEL_STATUS`), on GitHub or GitLab.
  `duel mark-passed BRANCH` moves the branch that marks the last commit
  Duel passed forward to a push, or makes it, and `duel badge BRANCH`
  writes Duel's badge to its branch, on GitHub. The Comment on the
  commit, Mark the commit passed and Update the badge jobs that
  `duel init` writes (and Duel's reusable Perf workflow) run them,
  installed from RubyGems as the comment workflow's `duel comment` is,
  in place of the shell, `curl` and `jq` that they ran. So a fix to one
  comes with a release of Duel, without a change to the workflow.

### Changed

- A plugin's resource gives its server a port with `w.free_port`, in
  place of `w.port`, which read as the resource's one port, though each
  call is another: `port = w.free_port`, then that `port` for both the
  server's option and its URL.
- `duel_process` takes the Ruby code it runs as `code:`, in place of
  `ruby:`, which read as the Ruby to run it on, as `c.ruby`, `--ruby`
  and `DUEL_RUBY` mean: `duel_process "boot: require the library",
  code: %(require "my_gem")`.
- The settings that take a glob, a path, a name or a lambda
  (`c.benchmarks`, `c.watch`, `c.release_tags`, `c.library`, `c.build`,
  `c.main_branch` and `c.ruby`) fail as they're set, on a value they
  don't take, saying what to give (`c.watch = :lib: give a path, or a
  list of them`), as `c.comment` and the others do. A wrong one failed
  deep in a run (`String#+: no implicit conversion of Array into
  String`), or not at all. And `c.watch` takes one path too
  (`c.watch = "app"`), as `c.benchmarks` and `c.release_tags` take one
  glob.
- A metric judged like CPU time is `kind: :timed`, in place of
  `kind: :ratio`, as `judge: :timed`, `Definition#timed?` and the
  report's `timed` call what it measures: a metric's `measures` say
  `{"wait" => {kind: :timed, unit: "µs"}}`. (The JSON report's `ratio`,
  a timing's, is as it was.)
- A ratio metric's `sizes_samples: false` is `size_samples: false`
  (don't size samples by it), as `calibrate: false` and `skip: true`
  say what to do.
- A counted metric's slack is `per_iteration:` (how much more an
  iteration still isn't more) and `per_sample:` (how much more a
  sample, whatever its length), in place of `tolerance:` and
  `allowance:`, whose names didn't say which was which: in a metric's
  `measures`, `c.measure("retained_objects", per_sample: 32)`, and
  `Duel::Metric.within?(more, n, per_iteration:, per_sample:)`.
- A plugin's resource fails with `w.fail!(message)`, in place of
  `w.failed(message)`, which read like a question but raised
  `Duel::Failed`: `Duel.find_program(server) || w.fail!("no #{server}")`.
- The RBS signatures of `c.comment=`, `c.fail_on=`, `c.push_base=` and
  `c.accept_label=` take what each takes (`c.comment = :failure`, a
  typo for `:failures`, fails Steep), as the other settings' do. They
  took anything, and said nothing of what they return.
- The jobs of Duel's reusable Perf workflow for a push, which write to
  the repository (Comment on the commit, Mark the commit passed and
  Update the badge), are a reusable workflow of their own,
  `.github/workflows/duel-push.yml`, so a Perf workflow that calls
  Duel's grants `contents: read` to the Duel job's call, which runs the
  branch's code, and `contents: write` to the push workflow's alone,
  which it calls only for a push. Before, its one call granted
  `contents: write`, for a pull request's run too, as GitHub checks
  every job of a called workflow against what the caller grants,
  whether it runs or not. `duel init` writes both calls, the second
  passing on what the Duel job said (`comment`, `status`, `passed`, and
  `result`, how its call ended). The `badge` input is the push
  workflow's, not the Perf workflow's: a Perf workflow that passes it
  to `duel.yml` fails, so run `duel init --force` (or
  `duel init --check` to see the change).
- The jobs of Duel's workflows that write to the repository or comment
  (Comment on the commit, Mark the commit passed, Update the badge, and
  the Perf comment workflow's), reusable or as `duel init` writes them,
  install exactly the release of Duel that wrote them
  (`gem install duel --version '0.3.0'`), not the newest of its minor
  version (`~> 0.2.0`), and every action Duel's workflows use is named
  by its commit, with its release beside it
  (`ruby/setup-ruby@f9c4492… # v1.342.0`), as a tag can be moved.
  `docs/ci.md` shows how to name Duel's reusable workflows by commit
  too.
- `duel init` writes short workflows that call Duel's reusable ones, at
  the tag of the release that writes them, as `--reusable` did, which
  is gone. `--standalone` writes the whole workflows, as `duel init`
  did, to change as you like. `--check` compares the ones it would
  write with the same options, so `duel init --check --standalone`
  checks whole workflows that an earlier `duel init` wrote.
- The badge links to the project's Perf workflow's runs
  (`https://github.com/OWNER/REPO/actions/workflows/perf.yml`, or for a
  project in a subdirectory, `perf-<its path>.yml`), which say why it's
  green or red, not to the repository itself: in the README, the guide,
  AGENT_PROMPT.md's badge step, and the workflows that `duel init` and
  `rails generate duel:install` write, whose comments give the badge's
  Markdown. USERS.md, in Duel's repository, lists the projects using
  Duel: a pull request adds one, and AGENT_PROMPT.md's last step has the
  agent open one for the project it set Duel up in, if that's public.
- `Duel::Testing.measure`'s block is one iteration, which it runs `n:`
  times, as a worker runs a benchmark's block that takes no `n`. It ran
  the block once, and only told the metrics `n`, unless there was an
  `around_iteration` hook (the configuration's, or its own), so a
  plugin that added one changed how many times every test's block ran.
  A test that did its `n` iterations in the block does one.
- A `Duel::RakeTask` exits with `duel`'s own status. It exited 1 for
  status 2 (couldn't compare), and passed for status 3 (slower, but only
  warned, which GitLab's `allow_failure: exit_codes: [3]` relies on), so
  `rake duel` hid a slowdown that `duel` reported.
- Each of a run's settings can be set the same three ways: an option, a
  variable, or `.duel.rb`, in that order of precedence. `c.jobs` sets
  `--jobs`, and each option `.duel.rb` can set, and `--ruby`, has a
  variable, `DUEL_` and its name (`DUEL_LIMIT`, `DUEL_TIME_LIMIT`,
  `DUEL_RUBY`...), as `--base`, `--filter` and `--force` had.
  `--ruby` takes `version_file` too.
- `c.library` takes a lambda, given the root of a version's tree, that
  loads the version instead, which `c.load { |root| ... }` did:
  `c.library = ->(root) { require File.join(root, "config", "boot") }`.
  `c.load`, which hid `Kernel#load`, is gone.
- What a benchmark is judged on is one option, `judge:`, one or a list of
  `:timed`, `:counted` and `:peak_memory`, named as a result's measures
  are, and `[:timed, :counted]` by default. It replaces `only: :count`
  (`judge: :counted`), `only: :timing` (`judge: :timed`) and
  `peak_memory: true` (`:peak_memory` too, which needs `:timed`: with
  counts alone, it was quietly ignored), so `only: :timing, peak_memory:
  true` reads as `judge: %i[timed peak_memory]`. A metric sees it as
  `sample.benchmark.judge`, with `timed?`, `counted?` and
  `peak_memory?`, in place of `only` and `peak_memory`, and
  `Duel::Testing.measure` and `Duel::Testing.sample` take `judge:` too.
- The JSON report's schema is 2:
  - `status` is what the comparison found, and `exit` is `duel`'s exit
    status, with `passed_anyway` saying why a run that failed passed
    anyway (`"accept_label"`, or `"fail_on"`), which nothing said
    before: a regression a label accepted was `"passed"`.
  - A timing too close to its limit to settle is `"unsettled"`, as its
    benchmark's verdict is, not `"undecided"`, in the JSON report, the
    Markdown report and the terminal's.
  - A count, and peak memory, has a `verdict` (`"more"`, `"fewer"` or
    `"same"`) in place of `worse`.
  - `unsettled` (a benchmark's `verdict` says so), `errors` (each
    benchmark's `error` says so) and `comment` (the workflow's step
    output says so) are gone.
- On CI, Duel finds the baseline itself, from the run's event: for a
  push, the commit before it (on GitHub Actions, the event's `before`,
  and on GitLab CI, `CI_COMMIT_BEFORE_SHA`), for a merge queue, its
  base, and on a schedule, the last release. The workflows `duel init`
  writes gave it as `DUEL_BASE`, which now only names another, as
  `--base` does. (A `DUEL_BASE` that's the event's own is still taken
  for it, as the workflows earlier versions wrote give it.) And `duel
  base` prints the commit a run compares with, which the workflow's
  step that installs the baseline's Ruby reads, once the project's Ruby
  and bundle are set up, so it no longer finds the main branch and the
  last release in shell of its own, which `c.main_branch` and
  `c.release_tags` had to be copied into.
- The Perf workflow follows `.duel.rb`, rather than copying it. Its
  jobs for pushes, the comment on a pushed commit and marking a push
  passed, are always there (`duel init` wrote them only where `.duel.rb`
  asked, and said to write the workflow again if that changed), and run
  where Duel's outputs say to: its `passed` output is the branch that
  marks the push passed (`duel/passed/main`), not `true`, so the job
  moves the one Duel reads. Duel's reusable Perf workflow takes none of
  `.duel.rb`'s settings: `accept-label`, `release-tags`,
  `comment-on-pushes`, `mark-passed`, `passed-branch`, `badge-branch`
  and `marker` are gone, as Duel reads `.duel.rb`, and the names it
  needs come from `working-directory`. And on a schedule, Duel finds
  the last change a label accepted since the last release itself, with
  `gh` (`DUEL_ACCEPTED` still names one), which the workflow's labels
  step did, with `c.accept_label` and `c.release_tags` copied into it.
- `--comment` and `--fail-on` are gone: when the workflow comments, and
  which runs a regression fails, are `.duel.rb`'s to say (`c.comment`,
  `c.fail_on`), as the workflow passes neither, and outside CI, they
  changed nothing.
- `duel` fails on an argument that isn't an option (`duel v1.2.0`, say,
  for `duel --base v1.2.0`), which it ignored.
- `duel clean` removes `tmp/duel` and the baseline's git worktree, as
  `duel --clean` did, which took (and ignored) every other option, and
  is gone. It takes `--config`.
- `duel comment` comments on a GitLab merge request where `GITLAB_CI`
  says it runs on GitLab CI, without `--gitlab`, which the GitLab CI
  jobs `duel init --gitlab` writes no longer pass. (It's still taken,
  and does nothing, for the jobs that earlier versions wrote.)
- `--candidate-dir` is `--candidate`, as `--base` names the baseline,
  and `DUEL_CANDIDATE` sets it.
- `DUEL_FORCE` is `1` or `true` (or `0` or `false`, for off), and
  anything else fails. Any value forced before, `DUEL_FORCE=0` too.
- A `setup`, `teardown`, `before_sample` or `after_iterations` hook
  takes no parameter, at any level, and one that takes one fails before
  anything runs. The first three were given the benchmark if they took
  a parameter, which nothing needed. Only `around_iteration` takes one:
  its iteration.
- `c.accept_label` is `"duel: accept"` by default, the label that the
  `.duel.rb` `duel init` writes named, so a project set up by hand
  accepts a regression as one set up by `duel init` does. Set it to
  `nil` for no such label. That `.duel.rb` shows the label, and the
  build of a project with `ext/` (`bundle exec rake compile`, Duel's
  default there already), commented out, as the defaults they are.

### Fixed

- A process benchmark whose Ruby process of its own ended while it ran
  a command (killed, say) leaves that command running no longer: what's
  left of the Ruby process's group is killed as it's stopped, where the
  command went on, orphaned, for as long as it ran (for ever, for one
  that hung).
- The Perf workflow that `duel init --reusable` wrote granted
  `contents: read` unless it turned on a job that writes (marking a
  push passed, commenting on one, or the badge), but GitHub checks every
  job of a workflow it calls against what the caller grants, whether
  the job runs or not, so the run failed before it started. The jobs
  that write are now Duel's push workflow's, which the Perf workflow
  that `duel init` writes calls apart, with `contents: write`, and only
  for a push, while the Duel job's call still only reads (see Changed).
  Run `duel init --force` for a workflow that calls both
  (`duel init --check` shows the change).

## [0.2.0] - 2026-11-16

### Added

- Duel's workflows are reusable: `.github/workflows/duel.yml` and
  `duel-comment.yml`, in Duel's repository, are the Perf and Perf
  comment workflows that `duel init` writes, with each setting of
  `.duel.rb` they need as an input, plus a `setup` input, for what else a
  project's tests need, a `gemfile` input, for a bundle of Duel's own
  that keeps it out of the project's other bundles, a `yjit` input, to
  measure with YJIT on, and `runs-on`, `timeout-minutes` and
  `submodules` inputs for the Duel job. A workflow can call Duel's more
  than once (with YJIT and without, say), each call with a `report`
  input of its own, and the Perf comment workflow comments with every
  call's report, as one comment (`duel comment` merges the reports it's
  given as `duel-report*` directories). Duel's Perf workflow says what
  Duel said as its outputs. `duel init --reusable` writes short workflows
  that call them, at the release's tag, passing on what `.duel.rb` sets,
  and `--check --reusable` compares those. `rake workflows` renders the
  reusable workflows from the templates, and a test keeps them the
  same. See docs/ci.md.
- The start of Windows support (CRuby). CPU time there is the cycles
  the thread (or the process) was charged, in nanoseconds at a rate
  the run measures once for every worker, as Windows's own CPU times
  move in ticks of 15.6 ms, more than a sample takes. A process
  benchmark's CPU time and peak memory are its process's own (not what
  it starts, as on Unix), from a handle on it, as Windows keeps no
  account of a child's for its parent. Resident memory comes from the
  process's working set, the memory available from
  `GlobalMemoryStatusEx`, a process benchmark's process that hangs is
  killed with what it started by `taskkill /T`, and a resource's
  processes are killed as it stops, with what they started, as Windows
  can send them no other signal (an `at_stop` block can ask one to stop
  first). A run's lock
  works there too, though Windows can't read a held lock, so another
  run's isn't named. There are no instructions there. The tests run on
  macOS and Windows in CI too.
- `.duel.rb` sets a run's settings too, as their options do, for a run
  in CI, where the workflow runs `duel` with no options: `c.limit`,
  `c.confidence`, `c.processes`, `c.timeout`, `c.time_limit` and
  `c.warm`, each nil for Duel's own default, and an option given over
  it. The confidence of every interval (0.99) has an option of its own,
  `--confidence`. An option given a value out of its range (a
  confidence of 1.5, or a limit below 1) fails as an invalid argument.
- JRuby 10 on Windows. Its `jruby.exe` starts the JVM in a process of
  its own, so Duel starts each worker's JVM, and a process benchmark's
  of `ruby:` code, itself, with the command `jruby -Xcommand` prints:
  what's measured, waited for and killed is the JVM, not the launcher.
  A worker talks to the runner over a port of 127.0.0.1's where there
  are no Unix sockets (JRuby has none there). Where Process.spawn
  redirects nothing and doesn't wait (JRuby's there), workers, a
  resource's processes, and a process benchmark's Ruby process and its
  runs start through Open3, their output copied to their logs, and
  every command Duel runs through Open3 gets ENV (JRuby's gives the
  JVM's own environment, and ignores `unsetenv_others`), each variable by
  ENV's name for it (JRuby's PATH given doesn't replace ENV's Path), its
  program found by the PATH and PATHEXT (JRuby's runs only an .exe by
  name, so `gem` and `bundle`, which are .bat files, didn't run), and
  its arguments quoted as Windows takes them (Java took out the quotes
  in one, so `ruby: %(require "x")` ran `require x`). CPU time there is the cycles Windows charged,
  as on CRuby, not the JVM's CPU time, in Windows's ticks of 15.6 ms
  (and allocated bytes are read inside it, as reading the cycles, through
  Fiddle, allocates). A
  run's lock held by another run is told from the Java exception JRuby
  raises for one, and a process that's ended from its EPERM. The tests
  run on JRuby 10.0 and 10.1 on Windows in CI.
- `w.port`, in a prepare block: a port of 127.0.0.1's that's free, for
  a server to listen on where it can't on a Unix socket (the plugins'
  servers, on Windows). The Redis, memcached, MySQL and PostgreSQL
  plugins use it, in place of a method each of their own. And
  `Duel.unix_sockets?`, for a plugin's default: whether its server can
  listen on a Unix socket that a worker can reach (not on Windows, nor
  where Ruby has none), or should listen on that port.
- `Duel.windows?`, for a plugin that does something differently on
  Windows. The PostgreSQL plugin uses it for its `pg_ctl:` default.
- `Duel.load_config` is public: it loads a `.duel.rb` and returns its
  configuration, for a tool that reads a project's settings, as the
  Rails plugin's `duel:install` generator does.

### Changed

- On macOS, instructions are the benchmark thread's
  (`thread_selfcounts`), as they are on Linux, so they're no longer
  counted for benchmarks with threads of their own. Where the thread's
  can't be counted (in a virtual machine, say), they're the whole
  process's, as before.
- The Perf comment workflow and GitLab CI's comment job that `duel
  init` writes install Duel 0.2 (`~> 0.2.0`), whose `duel comment`
  merges the reports of a workflow that called Duel's reusable one more
  than once. `duel init --check` says to update an older one.

### Fixed

- `c.measure`'s `calibrate: false`, or `kind: :ratio`, for a measure of
  running totals (`config.metric`'s, as a plugin's Redis commands or
  queries are) is what decides whether reading it is calibrated. It was
  what the metric declared, so what reading it cost was taken away
  still.
- A command a prepare block runs (`w.run`) that a signal Ruby has no
  name for killed fails saying the signal's number, as a process
  benchmark's does. It said "SIG" with nothing after it, and on JRuby,
  raised an ArgumentError instead.
- A resource's program given its arguments, in a path with a space in
  it (`C:/Program Files/PostgreSQL/17/bin/initdb`, say), has its log
  named for the program (`initdb.log`), not the path's first word
  (`Program.log`).
- A process benchmark's Ruby process takes what it runs with (the
  environment, the directory, the log) as its input's first line, not
  as an argument: on Windows, an environment could be longer than a
  command may be, and JRuby's spawn there split the argument at its
  spaces.
- On a Mac that counts no instructions (a virtual machine, say),
  resident memory, and so peak memory, is measured all the same: it
  was left out with the instructions.
- `duel init` writes its files with LF line endings on Windows too,
  and `duel init --check` takes a workflow whose lines end with CRLF
  (as git can check it out on Windows) for the same.
- A process benchmark's process that doesn't end once its input is
  closed is killed ten seconds later, with what it started, rather
  than waited for without end.
- A process benchmark's run that doesn't end within the timeout is
  killed, where its reply could be waited for without end once the pipe
  said it was ready (as JRuby's on Windows says before it is).
- A benchmark's counts are taken once it's timed, not right after its
  warm-up: on JRuby, the bytes it allocates fall as the JIT compiles it,
  at different times in different workers, so a short warm-up (`--warm`
  or `c.warm`) could find one version's workers allocating a small
  object or two more than the other's, and fail it
  (https://github.com/sferik/duel-ruby/issues/6).
- A memory sample's peak can't count memory outside an iteration: a
  reading could land between a pause's changes, on JRuby, whose threads
  run at once.
- `duel init` writes LF line endings from templates checked out with
  CRLF, and a failure shows a log's lines without a Windows program's CR.
- On Windows, a resource's log is added to, as it is elsewhere: a
  command's output overwrote the start of it, as a child given a file
  opened to append writes from where the file's at.
- A process benchmark's command that can't start (there's no such
  program, say) fails saying why ("couldn't start: No such file or
  directory - ..."), not "the process running ... exited", and the next
  run goes on in the same Ruby process. It was that process that
  ended. (JRuby runs a program it can't find through the shell, which
  says why, and exits with 127.)

## [0.1.8] - 2026-11-12

### Added

- `duel comment`, which the Perf comment workflow now runs instead of
  a shell script: it installs Duel from RubyGems (the newest release of
  the same minor version) and comments with it, so a fix to how it
  comments comes with a release of Duel, without a change to the
  workflow. `duel init --check` shows how a project's workflows differ
  from what the installed Duel writes.
- Once the Perf comment workflow posts a comment, it hides Duel's
  earlier ones on the pull request as outdated (those not hidden
  already), which GitHub collapses, so the newest is the one in view.
- `duel init` offers to create the label that `c.accept_label` names,
  with `gh`, where it can (at a terminal, in a GitHub repository that
  hasn't the label). Where it doesn't, its next steps say to.
- A plugin can say how much memory what it starts for each worker
  takes at most (`def self.worker_memory`), and Duel counts at least
  that much for each worker as it fits them in the memory available. A
  server takes more as it's used than as it starts, when Duel measures
  it.
- `duel comment --gitlab`, which the GitLab CI jobs' comment job now
  runs instead of a shell script, as the GitHub workflow runs `duel
  comment`: it trusts only what Duel said, comments only if the merge
  request's head is still the run's, and comes from RubyGems, so a fix
  comes with a release. In a merged results pipeline, the report names
  the merge request's own commit, as on GitHub, and `duel init --gitlab`
  offers to create the accept label with `glab`.

### Changed

- On a pull request's run on GitHub Actions, the report names the pull
  request's own commit, "merged with `main`", instead of the commit
  that merges it, which GitHub makes for the run and isn't in the pull
  request.
- A run whose failures `c.accept_label` accepted says so in its
  heading, under 🟡 instead of 🔻: "1 benchmark failed, accepted".
- The Perf comment workflow posts a report from a fork's pull request
  as Markdown, like any other, instead of as text in a code block.
- A regression that `c.accept_label` accepts is commented on as a run
  that passed would be. With the default `c.comment = :failures`, Duel
  no longer posts the report again when the label is added, since the
  last comment already showed it failing.

### Fixed

- On TruffleRuby, Duel fits the workers in the memory available as
  they'll be once warm, not as they start: its workers grow some 2.9
  times as its JIT compiles, so where 8 of each version seemed to fit,
  they took 24 GB, more than a 16 GB CI runner has, and the runner
  stopped answering.

To pick up the Perf comment workflow's changes, run `duel init --check`
(or see duel-rails's generator's template), and copy them into
`.github/workflows/perf-comment.yml`.

## [0.1.7] - 2026-11-10

### Fixed

- Duel measures fewer benchmarks at once, and where even one
  benchmark's workers wouldn't fit, starts fewer workers, so that they
  fit in the memory available. Since 0.1.6 starts twelve workers of
  each version for each benchmark it measures at once, a plugin whose
  workers each start a server could run a machine out of memory: on a
  GitHub runner, duel-mysql's 48 MySQL servers took more than its
  16 GB, and the runner stopped answering until its job was lost. Duel
  starts one worker of each version first to find what a pair takes
  (with its resources), and allows each pair a quarter more, and 1 GB
  for everything else. It reads what's available from Linux's
  MemAvailable (or a container's cgroup limit, if lower) or macOS's
  `vm_stat`, and its first line says when it lowered either. A
  `--jobs` or `--processes` you give is kept as it is.
- The badge (in the workflow that `duel init --badge` writes) says
  "not measured", in grey, where the Duel job failed
  before Duel judged the push (its runner lost, say, or a step before
  Duel's failed), instead of "perf regressed". It's red only where
  Duel failed the push or found a regression, and a job that fails
  after Duel passed the push leaves it green.

## [0.1.6] - 2026-11-10

### Added

- The comment workflow that `duel init` writes runs the Duel job again
  when the label that accepts a regression (`c.accept_label`) is added
  to a pull request whose run failed, or taken off one whose run
  passed. Before, the label did nothing until someone ran the job again
  by hand. The job runs on `pull_request_target`, checks nothing out,
  and has only `actions: write`.
- On a schedule, the workflow compares with the last commit since the
  last release that merged a pull request with the label, instead of
  the release, so a slowdown accepted in its pull request doesn't fail
  every nightly run until the next release. Duel reads that commit from
  `DUEL_ACCEPTED`, and the report says what it compared with.
- The JSON report says, for each timing and across the board, how many
  worker processes of each version the interval is over (`processes`),
  or `null` where it's over pairs or benchmarks.
- The nightly bias check (`tasks/bias_check.rb`) also fails where more
  of a metric's intervals of identical code leave out 1 than their
  confidence allows, and runs on JRuby too, and on a pull request that
  changes how Duel measures or judges.

- On JRuby, Duel counts the bytes each benchmark allocates
  (`allocated_bytes`), as the JVM counts them for each thread (or every
  thread, for a benchmark with threads of its own), and fails one that
  allocates more than 32 bytes more an iteration. Before, JRuby had no
  allocation count. Where each JVM's JIT does away with different
  allocations (escape analysis), workers' counts differ, and Duel finds
  only as many more as they can tell apart.
- A count is over workers too: each worker's fewest in three rounds of
  a sample from every worker, and it fails when an interval for how many
  more the candidate's workers count than the baseline's lies above the
  tolerance. Before, it was each version's fewest of 3 samples, and on
  JRuby, where one worker's JIT can do away with an allocation another's
  doesn't, one worker's luck could fail identical code. Where every
  worker counts the same, as on CRuby, it's as exact as before. With
  fewer than 5 workers of each version, it's the fewest of 3 samples (10
  on JRuby), as before.
- On JRuby and TruffleRuby, a worker may take 5 minutes to load or to
  answer (`--timeout`), not 1: with `-Xbatch`, 16 JVMs starting at once
  could take longer than a minute.
- Counts of 9999.5 or more an iteration show as whole numbers (25736, not
  2.574e+04).

### Changed

- A timing's interval is over worker processes, not pairs of samples.
  Where things land in a process's memory (or on JRuby, what its JIT
  compiles) can make the same code faster or slower for the process's
  whole life, so the pairs of 3 workers of each version were far from
  independent, and with identical code on both sides, their intervals
  left out 1 several times as often as 99% intervals should. Each
  worker's median is now a sample, and the interval is the Mann-Whitney
  interval for the ratio of the candidate's workers to the baseline's.
  Duel takes rounds of a sample from every worker, up to some 120
  pairs, and starts 12 workers of each version by default (8 on JRuby
  and TruffleRuby). CPU-time intervals are about as wide as before, or
  narrower, and instruction counts' (which a process repeats almost
  exactly) a little wider. On JRuby, they're some 5% to 8% wide, as
  wide as each JVM's JIT makes them, so Duel leaves smaller timing
  regressions there unsettled. With fewer than 5 workers of each version
  (`--processes`, and `Duel::Testing.compare`'s 2), and for a process
  benchmark, the interval is over the pairs, as before, and the first
  line of the output says which.
- Across the board, the interval is over the workers too: each worker's
  score is how much faster or slower it was than its lane's other
  workers, at the median of the benchmarks it measured. A worker whose
  luck slowed it at every benchmark could fail identical code across
  the board.
- Without `--warm`, each worker warms a benchmark up until it's steady
  (the median of its samples over each of three half seconds in a row
  is no more than 1% faster than over the last half second that was),
  for up to a minute on JRuby and TruffleRuby, or 10 seconds with YJIT
  on. Before, it warmed up for 5 seconds, or 2, every time, and on
  JRuby, some code was still several times faster after that, so it
  was measured while it got faster. `--warm` still warms up for the time
  it says.
- On JRuby, each worker's JVM compiles in the foreground (`-Xbatch`) and
  collects garbage with the serial collector, after any options in
  `JRUBY_OPTS` (and without the serial collector where they choose
  another). Each JVM's JIT compiles the same code a little differently,
  and that made JRuby's intervals over workers twice as wide.
- A run measures for two hours at most by default (`--time-limit`), not
  half an hour, as on JRuby a benchmark can take half a minute to warm
  up.
- On JRuby and TruffleRuby, Duel measures one benchmark at a time for
  every four CPUs (`--jobs`), not every two: their JIT compilers keep the
  other CPUs busy, so more were no faster, and each worker is a JVM of
  some 500 MB.

### Fixed

- The comment workflow fences a fork's report with more backticks than
  any run of them in it even when the report has a NUL byte. GNU grep
  took such a report for binary and found no backticks, so the fence
  was three, and a line of three backticks in the report closed it. The
  workflow now drops NUL bytes, which GitHub doesn't take in a comment,
  and reads the report as text whatever's in it.
- The Mark the commit passed job runs one at a time for each branch
  (and on GitLab CI, one at a time). Before the branch that marks the
  last commit Duel passed existed, two pushes that passed at once could
  both try to make it, and the second failed, saying another branch
  kept it from being made. Where making the branch fails, the job now
  also looks for it again before it says so. Update the job in
  `.github/workflows/perf.yml` (or `.gitlab/duel.gitlab-ci.yml`) to pick
  this up.

## [0.1.5] - 2026-11-08

### Changed

- `duel init` writes the Comment on the commit job only where `.duel.rb`
  sets `c.fail_on = :pull_requests`, and the Mark the commit passed job
  only where it sets `c.push_base = :last_passed`, as with the defaults
  neither runs, and each asks for `contents: write`. It reads the
  settings from `.duel.rb` where there is one, and where that doesn't
  load (one of its plugins isn't installed, say), writes both, and says
  so. To add a job later, set its setting, remove the workflow, and run
  `duel init` again, or add it from the guide.
- `duel init` writes the Update the badge job only with `--badge`. It
  pushes a branch, so it needs `contents: write`, and without the jobs
  for pushes, it was the workflow's only job that writes to the
  repository. The workflow `duel init` writes by default now only reads.
  To keep a badge you already show, add `--badge` when you run
  `duel init` again, or keep the job you have.
- The `.duel.rb` that `duel init` writes sets
  `c.accept_label = "duel: accept"`, so a pull request that's slower on
  purpose can pass with that label. Duel's own default is still no
  label, so a `.duel.rb` you already have is unchanged.
- `require "duel/rake_task"` loads only the task, and the task loads
  Duel as it runs, so a Rakefile with Duel's task no longer loads all of
  Duel (and what it requires) for every other task, `rake test` included.

### Fixed

- The Perf comment workflow posted the report that a pull request's run
  wrote as Markdown, as `github-actions[bot]`. A fork's run runs the
  fork's code, which could write anything there, mentions, links and
  images included. A fork's report is now shown as text, in a code
  block, where it can't do any of that, and cut short where a comment
  couldn't hold it. A pull request from a branch of the repository, whose
  author can push to it anyway, still gets the Markdown. Update
  `.github/workflows/perf-comment.yml` to pick this up.
- The Update the badge job downloaded the badge's image from Duel's own
  repository, so a change there changed every project's badge, and a
  failed download failed the job. It now writes the image itself, and
  fetches nothing. Update it in `.github/workflows/perf.yml` to pick
  this up.
- Two pushes' runs of the Update the badge job could overlap, as a
  push's run doesn't wait for the one before it, and an older push's
  could write its badge over a newer one's after both had checked
  which push the badge was for. The job now runs one at a time. Update
  it in `.github/workflows/perf.yml` to pick this up.

## [0.1.4] - 2026-11-06

### Fixed

- In json's own repository, every baseline worker loaded the
  candidate's json, extensions and all, before the baseline's, as the
  worker loaded json for its own messages to the runner before it
  loaded the version. A worker and the runner now send each other
  their messages marshaled, so a worker loads nothing a version could
  be before it loads the version.
- A worker loaded etc, a gem, before it loaded the version it
  measures, for the page size that `/proc/self/statm` counts resident
  memory in. In etc's own repository, a worker would load the
  bundle's etc before the version's own. A worker now reads resident
  memory, in kB, from `/proc/self/status` (VmRSS), and loads no etc.
- A worker loaded fiddle, a gem, as Duel loaded, before it loaded the
  version it measures, so in fiddle's own repository, a worker would
  load the bundle's fiddle before the version's own. Duel now loads
  fiddle as it first calls into the operating system, once the
  version has loaded (and on JRuby, which Duel makes no such calls
  on, never).
- A worker that loaded a native extension twice, the candidate's that
  something required before the worker loaded the version and then the
  version's own over it, went unnoticed, as loading the version took
  the candidate's off `$LOADED_FEATURES`. Duel now fails, and names the
  extension and both of its files.
- On JRuby, peak memory came out short, by tens of megabytes at times,
  and a benchmark that needed more memory could pass. A peak is
  measured above what's in use after the garbage is collected, but
  JRuby's `GC.start` collects nothing, so the garbage left from before
  stayed in use until the benchmark's own objects made room. Duel now
  collects it with the JVM's own call (`java.lang.System.gc`).
- Where a repository's history was replaced, so the commit that
  `duel/passed/BRANCH` marks has no history in common with a push, the
  Mark the commit passed job failed, as GitHub can't compare the two.
  It now moves the branch to the push, as it does where history was
  rewritten. Update the job in `.github/workflows/perf.yml` to pick
  this up.

## [0.1.3] - 2026-11-04

### Added

- The workflow that `duel init` writes keeps a badge for the README
  that turns red when Duel fails a push to the default branch. Its
  Update the badge job writes `badge.svg` to a branch of its own,
  `duel/badge`, green ("perf guarded") when Duel passed the push, and
  red ("perf regressed") when the Duel job failed or found a
  regression, even one that passed.
- A run measures for 30 minutes at most (`--time-limit SECONDS`), not
  counting the builds. Past that, it starts no more measurements: a
  benchmark it hasn't measured fails as an error, and one that looked
  worse is judged on the measurements it has, so a run cut short never
  passes a regression. The report (and the JSON report's `cut_short`)
  says what it left undone. A benchmark that starts processes of its own
  and sat near its limit could be measured again for hours before.

### Changed

- The workers, their directories and sockets, and the resources that
  prepare blocks get are named `base` and `head` (`base-1`, `head-1`),
  not `baseline` and `candidate`: `Resource#name` (`w.name`, `v.name`)
  says so, and `Duel::Testing.prepare` names its worker `head-1` by
  default. The report still says baseline and candidate.
- A run removes its lock (`tmp/duel/lock`) when it ends, and
  `tmp/duel` (and `tmp`, if Duel made it) when that leaves them empty, so
  a project whose plugins build nothing to keep has nothing left there.
- When a run ends, the builds that prepare blocks made once
  (`Resource#cached`) and the run used replace the others of their name:
  a key's name is what's before its version and the hash it ends with
  (`mysql`, of `mysql-0.1.2-3f9c2a1b7e5d4c6a`). A database server or a
  plugin upgraded left its old build in `tmp/duel/cache` before, tens
  of megabytes (82 MB for MySQL's) each time.

### Fixed

- The candidate's workers could measure slower in every pair, with the
  same instruction counts, on code that hadn't changed. Their names
  (`candidate-1`, against `baseline-1`) were a byte longer, and so were
  the paths that a plugin's servers put in their environment
  (duel-postgresql's `DATABASE_URL`, `PGHOST` and
  `DUEL_POSTGRESQL_URL`, say). Where a process's stack starts depends on
  how long its arguments and environment are, and at some lengths, a
  tight loop runs the same instructions in more cycles: on macOS,
  server-free benchmarks of pg came out 1.2 to 1.55 times slower on the
  candidate with the plugin, and the same as the baseline without it.
  The two versions' names are now as long as each other.

- The workflow that `duel init` writes (and its GitLab CI jobs) no
  longer moves the branch that marks the last commit Duel passed
  backward. When two pushes ran at once and the older one finished
  last, the branch went back to the older push, so the next push was
  compared with it, and a regression already accepted counted again.
  Now the branch only moves forward, or after a force push rewrites
  its history.
- Where a branch named `duel` (or `duel/passed`) keeps the workflow that
  `duel init` writes from making `duel/passed/main` or `duel/badge`, as
  Git can't have both, the job's error now names that branch and says to
  delete it, instead of GitHub's bare `Reference update failed`.
- On JRuby, peak memory (`peak_memory: true`) is the most of the JVM's
  heap that a benchmark had in use, not resident memory, which barely
  moves there, as the JVM takes memory for its heap ahead of time: a
  benchmark that needed 24 MB more could pass. JRuby now has peak
  memory on macOS too.

## [0.1.2] - 2026-11-02

### Added

- `c.fail_on = :pull_requests` (or `duel --fail-on pull_requests`) fails
  a regression only in a pull request (or a merge queue), and outside
  GitHub Actions. On GitHub Actions, a regression in a push, the
  schedule, or a run by hand passes, with a warning, and the workflow
  that `duel init` writes comments on a pushed commit with the report,
  as `c.comment` says, which notifies the commit's author. The default,
  `:every_run`, fails every run, as before, and comments on no commit.
- `c.push_base = :last_passed` compares a push with the last commit
  that Duel passed, which a branch marks (`duel/passed/main` for
  `main`, and each branch the workflow guards has its own), instead of
  the commit before the push, so slowdowns too small for any one push to
  fail add up until they fail one. The workflow that `duel init` writes
  moves the branch when a push passes. The default, `:before`, compares
  a push with the commit before it, as before.
- `c.accept_label` names a pull request label that accepts a regression:
  with it, the regression passes, with a warning, and the report says
  so. The workflow that `duel init` writes passes the pull request's
  labels to `duel` (`DUEL_LABELS`), or for a push, the labels of the
  pull request that merged it. By default, there's no such label.
- `duel init --gitlab` writes GitLab CI jobs to include from
  `.gitlab-ci.yml`, instead of GitHub Actions workflows. They compare a
  merge request with the branch it targets, comment on it, and with
  project access tokens, comment on a pushed commit and mark a push
  passed. On GitLab CI, `duel` reads a merge request's target and labels,
  writes its decisions to `DUEL_OUTPUT` as variables, and where only a
  merge request fails (`c.fail_on`), exits with status 3 for a
  regression outside one, which the job lets fail, as a warning.
- The workflow that `duel init` writes runs for a merge queue
  (`merge_group`), and compares its group with the queue's base, so the
  Duel check can be required with a merge queue.

### Changed

- To upgrade a project that ran `duel init` before 0.1.2, delete
  `.github/workflows/perf.yml` (or `perf-<its path>.yml`, for a project
  in a subdirectory) and run `duel init` again, then carry over any
  edits of your own. It writes both workflows, and skips the files that
  exist, such as `.duel.rb`. Kept, the old workflow comments on a pull
  request itself, and with the new one, every comment comes twice.
- A pull request gets its comment from a second workflow that `duel init`
  writes, `.github/workflows/perf-comment.yml`, which runs once the Perf
  workflow has (`workflow_run`), with a token that can write, so a pull
  request from a fork gets a comment too. It runs none of the pull
  request's code, and trusts only what Duel could have said in the
  report's artifact. The Perf workflow no longer has a Comment job, and
  for a project in a subdirectory, it's named for the directory, as
  `Perf (gems/parser)`.
- The workflow that `duel init` writes cancels a pull request's run
  when a newer push to the pull request starts one. Every other run,
  such as a push's to `main`, still runs to the end.
- A push whose commit before it isn't in the history now reports that
  there's no commit to compare against, and passes, from `duel` itself.
  The workflow no longer checks this in its Compare step.

### Fixed

- On GitHub Actions, a pull request is compared with the branch that it
  targets (`GITHUB_BASE_REF`), not the main branch. A pull request into
  a stable branch, or into another pull request's branch, was compared
  with `main`.

## [0.1.1] - 2026-10-26

### Added

- `c.comment` chooses when the workflow that `duel init` writes
  comments on a pull request with the report: `:always`, `:results`
  (when a run passed or failed, but not with nothing to compare),
  `:failures` (when a benchmark failed or Duel couldn't compare, the
  default), or `:never`. `duel --comment MODE` overrides it, and any
  other value fails with the values it takes. On GitHub Actions, `duel`
  sets the step outputs `comment` (`post`, `change`, or `none`) and
  `status` (`passed`, `failed`, or `neutral`), whatever the outcome, and
  the workflow's Comment job acts on them, since it runs none of the
  branch's code and can't read `.duel.rb`. The JSON report's `comment`
  key has the same decision.

### Changed

- The workflow that `duel init` writes no longer comments on every pull
  request. By default, it comments only when a benchmark fails or Duel
  couldn't compare. Set `c.comment = :always` for the old behavior.
- The workflow never edits a comment. It used to update one comment on
  every push, and now posts a new one each time it comments, so the pull
  request keeps every report. Each comment's hidden marker records the
  run's status (`<!-- duel status=failed -->`, say). When a run wouldn't
  get a comment of its own, the workflow still posts one if its last
  comment on the pull request had another status, so after a failure the
  first run that passes says so, and the last comment is never stale. A
  comment from an earlier version, whose marker has no status, counts
  as one with another status.

- A change to only the benchmarks or the configuration is compared. Duel
  watches what decides how the code is measured, as well as the code
  that `c.watch` names: the benchmarks' directory (`c.benchmarks` up to
  its first wildcard, `duel/` by default), the configuration's file
  (`.duel.rb`), and, with `c.ruby = :version_file`, the version files at
  the project's root. Each version runs the candidate's benchmarks and
  configuration, so such a change compares the code with itself, which
  checks that they run and pass, where before Duel passed saying there
  was nothing to compare. "Nothing to compare" messages, and the
  candidate's `uncommitted_changes` in JSON, cover them too.
- The Markdown report (`--markdown`, the job's summary and the pull
  request comment) is shorter. Its heading starts with 🟢 when every
  benchmark passed (`🟢 Duel: 100% of benchmarks passed`), 🔻 when one
  failed or Duel couldn't compare (`🔻 Duel: 3 benchmarks failed`), and
  ⬜ when there's nothing to compare. One line names the two commits,
  bare, so GitHub links them, and how the baseline was chosen. Only the
  benchmarks that failed are in view, in a table of what got worse and
  by how much, or the error, and where the most extra CPU time went.
  Everything else is collapsed, and the report no longer names the
  plugins or explains how Duel decides outside the collapsed details.
  The terminal and JSON reports are unchanged.

### Security

- The workflow that `duel init` writes no longer gives the job that runs
  a pull request's code the `pull-requests: write` permission. The Duel
  job only reads (`contents: read`, and its checkout keeps no
  credentials), and keeps the report as an artifact for a day. A
  Comment job of its own, which checks nothing out and runs none of the
  pull request's code, downloads the report and comments with it, for a
  pull request from the same repository.

### Fixed

- With `c.ruby = :version_file`, the workflow installs the bundle for
  the baseline's Ruby too, when it differs from the candidate's. The
  baseline's workers load that bundle, and gems installed for one Ruby
  version don't load on another, so a branch that changed the Ruby's
  minor version failed before it compared anything.

- With `c.ruby = :version_file`, the workflow that `duel init` writes
  installs the baseline's Ruby for every event that compares, not only
  for a pull request. It finds the baseline that the Compare step uses
  (where HEAD left the main branch for a pull request and a manual run,
  the commit before a push, and the last release on a schedule, with
  the release tags' glob in `RELEASE_TAGS`), and installs its Ruby only
  when its `.ruby-version` names another Ruby than HEAD's. Its scripts
  take the workflow's values from environment variables, not `${{ }}`.

## [0.1.0] - 2026-10-24

The first release. Duel is open source under the MIT license, and
needs Ruby 3.4 or later (or JRuby 10, or TruffleRuby 40).

### Added

- `duel` and `Duel::RakeTask`: run every benchmark on a baseline (where
  HEAD left the main branch, a git ref, the last release tag, or a
  directory) and the candidate, side by side in worker processes of their
  own, and fail if the candidate is slower at any of them.
- `duel init`: sets Duel up in a gem or an app that isn't a Rails app.
  It writes `.duel.rb` (with `c.build` for `ext/`, and
  `c.ruby = :version_file` for a `.ruby-version`), an example benchmark
  with advice on writing good ones, and the GitHub Actions workflow in
  docs/ci.md, adds Duel's Rake task to the Rakefile, and adds
  `gem "stackprof", platforms: :mri` to the Gemfile, for profiles of
  regressions (in its `development` group, if it has one, and not if it
  mentions StackProf already). It overwrites nothing without `--force`,
  and writes nothing with `--dry-run`. The workflow compares pull
  requests, pushes, and, nightly, the last release, and comments on each
  pull request with Duel's report, updating one comment on every push.
- A report in Markdown, for a pull request. On GitHub Actions
  (`GITHUB_STEP_SUMMARY`), Duel adds it to the job's summary, and
  `--markdown PATH` writes it to a file, to post as a comment. It has the
  verdict, the two versions (and their Rubies, where they differ), a
  table of the benchmarks that changed, regressions first, with each
  timing's ratio and interval and the counts that changed, each
  regression explained as the terminal report explains it, and the
  benchmarks that were unsettled or failed. Those that didn't change are
  collapsed. A run with nothing to compare, or that couldn't compare,
  says so in Markdown too.
- `--json PATH`: writes the report as JSON, for a program to read, with
  a versioned schema (`"schema": 1`, documented in docs/json.md). It
  has the run's status and exit status, its settings, the two versions
  (each one's ref, commit, tree and Ruby), the plugins in use, and every
  benchmark: its verdict, each timing's ratio, interval, limit, pairs,
  verdict and each version's median an iteration, each count on both
  versions an iteration, peak memory, what metrics said, each
  regression's explanation, and why it failed or was skipped. Then the
  verdicts across the board, and the errors. It's written whatever the
  outcome, nothing to compare and couldn't compare included, but not for
  a command line that isn't valid.
- Timings (CPU time, and any timed metric of a plugin's) are judged by a
  99% distribution-free confidence interval for the median of paired
  ratios, and whatever looks slower is measured again in fresh processes
  before it fails. A measurement whose timings are all too close to
  call neither confirms a slowdown nor clears it, so Duel measures once
  more in its place, up to three more times. A benchmark that's slower
  in time in every measurement fails even when no one timing is slower
  in all of them (CPU time in one, instructions in the next), as long as
  none says the same or faster, after one measurement more.
  Allocations and counted metrics fail on any increase.
- Each version runs in several worker processes (three by default,
  `--processes`), paired in turn, so no one process's layout in memory
  biases a comparison.
- A git baseline is checked out next to the project, at a path as long
  and as deep as the project's, so work a version does on its own paths
  doesn't make the baseline measure slower. Duel says so when the two
  versions' paths still differ in length. A project in a subdirectory
  of its repository (a monorepo's) is compared with the same
  subdirectory of a checkout of the whole repository. Without a merge
  base with the main branch (unrelated histories, or a shallow clone),
  or in a repository without commits, Duel says why.
- The candidate is built (`c.build`) before every run, as a baseline is,
  so a stale or missing build never decides a comparison. Duel checks
  that each version's workers load only native extensions built in that
  version's tree, and fails, saying to set `c.build`, when one loads
  another version's build or an installed gem's. Gems installed in the
  project's directory (`vendor/bundle`, say) are installed gems, not
  builds.
- One run at a time in a project: a second `duel` fails, naming the
  first one's pid. The lock is an flock, so a run that crashed leaves
  nothing behind.
- With YJIT on in a worker (an app, Rails's say, may turn it on as it
  boots), each benchmark warms up for two seconds before it's measured,
  unless `--warm` says otherwise.
- Instruction counts from the CPU's counters (the benchmark thread's on
  Linux, and the process's on macOS), judged with a limit of their own
  (1%).
- Peak memory, for benchmarks that ask (`peak_memory: true`): each
  version's least in fresh workers.
- A StackProf profile of both versions with every regression in time,
  and where the extra CPU went, on CRuby with StackProf in the bundle.
  StackProf is optional, and Duel doesn't use it on JRuby or
  TruffleRuby, even where it's installed. Profiles cover what Duel measures: they
  leave out work inside `untimed` and an `around_iteration` hook's own
  work, keep what `after_iterations` does, hold the garbage collector
  off as samples do, and show what garbage collection gained on a line
  of its own, not ranked with the code. On macOS, they sample elapsed
  time, because CPU-time samples there pile up on code that makes
  system calls.
- Conventions: benchmarks in `duel/**/*_duel.rb`, the gemspec's library
  required from each version, `rake compile` for a baseline of a
  project with `ext/`, and the main branch from `origin/HEAD` (or
  `origin/main`, `origin/master`, and without a remote, `main` or
  `master`).
- Across the board: every benchmark's median ratio, judged together, so
  a slowdown too small for any one benchmark still fails. It takes 8
  benchmarks, so with fewer, the report leaves it out.
- A worker that doesn't load or answer within `--timeout` (60s) is
  killed, and its benchmark is an error. Samples are held to 64 MB of
  allocations while the garbage collector is held off. `duel --clean`
  removes what runs leave behind.
- `duel "name" do ... end`, in files named `*_duel.rb`, defines a
  benchmark: its block is timed, run as many times as a sample needs
  (or, given `|n|`, once a sample for n iterations). `once { }` in it
  runs its block once, untimed, before anything's measured, and
  `untimed { }` pauses measuring. Duel's own work in an iteration allocates nothing,
  so a benchmark that allocates nothing counts no allocations, and an
  `untimed` block adds none. `only: :count` (work that's mostly waiting)
  or `only: :timing` (work on threads of its own) narrows what it's
  judged on, and `peak_memory: true` adds its peak memory. `.duel.rb`
  covers what the conventions don't: building, loading, preparing each
  worker, and metrics of your own, which together make a plugin (a
  `duel-*` gem that `c.use` uses by name). Nothing else is built in.
- Hooks, with one set of names at every level: in `.duel.rb`
  (`c.setup { }`), at the top of a file of benchmarks (`setup { }`), and
  as an option of one benchmark (`duel "x", setup: -> { }`). They're
  `setup` and `teardown` (once in each worker, around a benchmark's
  samples), `before_sample` (before every sample, not measured, so every
  sample starts alike), `around_iteration` (around each iteration, which
  it's given to run, and which alone is measured), and
  `after_iterations` (after each sample's iterations, measured with
  them: work that they left for later, such as jobs that they
  enqueued). `.duel.rb`'s run first, then the file's, then the
  benchmark's own (teardown's in reverse, and around_iteration's nested,
  outermost first). A file's and a benchmark's own run in the
  benchmark's context. What pausing and resuming the metrics around
  each iteration leaves is learned in each worker and taken away, and
  pausing allocates nothing.
- Helpers that files of benchmarks share, in `duel/duel_helper.rb`. A
  helper named as one of the methods that Duel gives benchmarks
  (`once`, `untimed`, a hook, or a DSL method) fails the worker, naming
  its file and line.
- `duel_process "name", command` (or `ruby: code`): a benchmark of a
  whole process, booting an app or requiring a library, say. Each sample
  is the fastest of a few fresh processes for each version (as many as
  take about a second of CPU time, up to 3, or `runs:`), the versions'
  processes in turn, in its tree and with its environment, judged on its
  CPU time (its children's too) and its peak memory (with a CRuby
  runner: each version's lowest). The processes are started and
  measured by a small Ruby process of Duel's, one for each worker, that
  lasts as long as the worker, so its start-up is paid once and not for
  every process. It's judged after every pair of samples,
  and stops as soon as it's settled that it isn't slower, but it's found
  slower only after a round of 10 pairs, so stopping early can't make
  identical code look slower. It runs in no worker, so it takes none of
  `duel`'s options (a hook such as `around_iteration:`, `only:`, or
  `peak_memory:` raises an `ArgumentError`), and runs no hooks.
- `c.prepare(:worker) { |w| ... }` prepares each worker with a
  `Duel::Resource`: a directory of the worker's own, `spawn` (logged
  there, and stopped with the worker, by its `stop_signal:`), `run`,
  `wait_until` (failing if a process exits, or after `--timeout`),
  `failed`, `at_stop`, the version's `root` and `ruby`, and `env`, the
  version's environment, which the commands that it starts get under
  their own. The block returns the worker's environment, and two
  prepare blocks that set a variable differently fail.
- `c.prepare(:version) { |v| ... }`: prepares each version once for a
  run, in the runner, before its workers start (installing its bundle,
  say). It gets a `Duel::Resource` for the version and returns the
  environment that the version's workers and process benchmarks get.
- `c.ruby` and `duel --ruby`: each version's Ruby. `:version_file` (or
  `--ruby version-file`) runs each version on the Ruby that its own
  `.ruby-version`, `.tool-versions`, or `mise.toml` names, found with
  rbenv, chruby, mise, or asdf. A path, or a block given the version's
  tree, says which otherwise. A version file that asks for the Ruby that
  runs `duel` (as CI's setup step installs it, where no manager looks)
  gets that Ruby. The report shows each version's `RUBY_DESCRIPTION`
  when they differ, and a Ruby that isn't installed fails the run.
- `c.in_worker { |w| }`: set-up that runs only in workers, once the
  benchmarks have loaded. What it gives `w.at_stop` runs when the
  worker ends. It returns what the block made in each (a connection,
  say), as `value`, the worker's.
- `w.cached(key) { |dir| }`: what a prepare block builds once, for every
  worker of a run and later runs (a database's initial files, say).
- A run's workers start at once, each prepared, and stop at once.
- Metrics of running totals: `c.metric("name") { total }`, or several
  by their settings, and a sample measures what they grew by, less what
  reading a counted one adds to it (learned in each worker, unless
  `calibrate: false`). A `Duel::Metric` subclass covers the rest: its
  `measures` name what it measures, with their settings, its
  `start_sample` gets the sample (`n`, `benchmark`), and it can
  `pause_sample` and `resume_sample` around `untimed` blocks its own
  way.
- `open { }` and `close { }` on what `c.metric` returns, and `open` and
  `close` methods of a `Duel::Metric` subclass: a metric's own setup and
  teardown in each worker. `details`, `open`, `close`, and `costly`
  return the metric, to chain them.
- `costly` on what `c.metric` returns, and `self.costly?` on a
  `Duel::Metric` subclass: a metric that's costly to read (a round trip
  to a server, say) isn't paused around each iteration inside an
  `around_iteration` hook, but read only as each sample starts and
  stops. What the hook adds to it is learned in each worker, from three
  samples of 10 iterations in which it's paused around each iteration,
  and subtracted, so the hook's own work (a transaction's `BEGIN` and
  `ROLLBACK`, say) still isn't counted, and the metric measures what
  pausing would have. The plugins that read a server (duel-postgresql,
  duel-mysql, duel-redis and duel-memcached) say so.
- Settings for metrics: `floor` (on either version), `limit`, `unit_ns`,
  `sizes_samples`, `tolerance` (per iteration) and `allowance` (per
  sample). `c.measure(name, ...)` changes any measure's, Duel's own
  too, or skips it. Two metrics that measure the same name fail.
- A regression is explained an iteration, on each version
  (`cpu: 112.4µs → 121.5µs an iteration`), with what its metric says of
  it (`Metric#details`), and results carry each version's raw medians.
  Each benchmark's line shows its counts an iteration too.
- `unit:` for a measure (a time unit shows it as time, and gives
  `unit_ns`). Settings there aren't, and kinds there aren't, fail.
  `Metric#settings` has a metric's settings after `c.measure`'s changes,
  every one filled in. Running totals' `details { |stretches, sample| }`
  explains them, and their block can return `[totals, context]` to pass
  the context on (typed, with Steep). `Reading#total` reads one total.
  Units show with regressions, and on the summary line unless the
  measure's name ends in them. `Duel::Testing.measure` returns what
  metrics said (`#details`) with what they measured.
- `kind: :ratio` (judged by paired ratios, as CPU time is) and
  `:counted`, with `cpu_floor:` (a floor that's a share of CPU time) and
  `across: false` (not judged across the board).
- `c.use :redis`: uses a plugin by name. It requires `duel/redis` and
  calls the `configure` method of the module that the file registers
  with `Duel.plugin(:redis, self)`, given the configuration and the
  options. A plugin is configured once, however many times it's used, so
  a plugin that needs another (duel-rails, duel-activerecord) uses it
  too, and an app's own use of it, with options, comes first. A plugin
  that isn't in the bundle fails, naming the gem to add. The report, in
  the terminal and in Markdown, lists the plugins used. Workers load
  Duel and every Duel plugin that the runner loaded (the `duel` and
  `duel-*` gems) from where the runner did, ahead of the version's own
  bundle, so a version whose bundle lacks them (or has other versions of
  them) is measured with the same.
- A plugin's own DSL methods: those of its module's `DSL` module, which
  files of benchmarks get once `.duel.rb` uses the plugin. A name that's
  taken, by the DSL, another plugin, or every object, raises
  `Duel::Error` instead of replacing it. A benchmark that the method
  defines, and a hook that it adds, belong to the file of benchmarks
  that called it, which gets that file's hooks.
- `duel/testing`, for plugins' tests: `Duel::Testing.prepare` (which
  runs the configuration's `c.prepare(:version)` blocks, then its
  `c.prepare(:worker)` blocks, as a run does), `measure`, `in_worker`
  (which ends as a worker ends, closing its metrics), `metrics`,
  `compare` and `project`. `measure(config, **hooks)` measures the
  block as a benchmark with the configuration's hooks and its own, as
  `duel` takes them. With an `around_iteration` hook, the block is one
  iteration, run `n` times, each inside the hook, costly metrics and
  all. The block gets the benchmark's context, with `untimed`.
- `Duel::Testing.sample`, `reading` and `details`: stand-ins for a
  sample and for readings of running totals, to test or benchmark what a
  metric says of a sample. docs/plugins.md documents what `details` is
  given and when it runs.
- `Metric#setting(:allowance)`, for a metric of one measure, and
  `Metric#within?(more, n)` (and `Metric.within?`): whether a count is
  within its tolerance and allowance, as Duel judges it.
- A unit that's a word comes with its plural (`unit: %w[row rows]`: 1
  row, 2 rows), and a symbol (`"B"`) is one String.
- `Duel.measuring?`: whether a benchmark is being measured right now
  (not in setup or `untimed`), and `Duel.unmeasured!(name)`, for a
  plugin's helper to fail where what it does would be counted.
- Running totals are typed from their block (Integer totals stay
  Integer), and `Duel::Testing.measure` ends the worker it starts.
- `DUEL_BASE`, `DUEL_FILTER` and `DUEL_FORCE` set `--base`, `--filter`
  and `--force` where options are hard to pass (behind a rake task, or
  in a CI expression). An invalid regular expression for `--filter` or
  `DUEL_FILTER` is a usage error, with exit status 2.
- Mutation tested: mutant kills every change to Duel's code, in CI.
- RBS signatures in sig/, checked with Steep.
- The public API is what the README and the guide in docs/ document.
  Anything marked `@api private`, in lib/ and sig/, may change in any
  release.

[Unreleased]: https://github.com/sferik/duel-ruby/compare/v0.3.1...HEAD
[0.3.1]: https://github.com/sferik/duel-ruby/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/sferik/duel-ruby/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/sferik/duel-ruby/compare/v0.1.8...v0.2.0
[0.1.8]: https://github.com/sferik/duel-ruby/compare/v0.1.7...v0.1.8
[0.1.7]: https://github.com/sferik/duel-ruby/compare/v0.1.6...v0.1.7
[0.1.6]: https://github.com/sferik/duel-ruby/compare/v0.1.5...v0.1.6
[0.1.5]: https://github.com/sferik/duel-ruby/compare/v0.1.4...v0.1.5
[0.1.4]: https://github.com/sferik/duel-ruby/compare/v0.1.3...v0.1.4
[0.1.3]: https://github.com/sferik/duel-ruby/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/sferik/duel-ruby/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/sferik/duel-ruby/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/sferik/duel-ruby/releases/tag/v0.1.0
