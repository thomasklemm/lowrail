# frozen_string_literal: true

module OAuth2
  # Version namespace for this gem.
  module Version
    # Current gem version.
    VERSION = "2.1.0"
  end
  # Current gem version exposed at the traditional constant location.
  VERSION = Version::VERSION # Traditional Constant Location
end
