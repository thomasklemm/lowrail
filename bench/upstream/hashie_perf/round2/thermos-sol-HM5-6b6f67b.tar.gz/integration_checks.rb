# frozen_string_literal: true
require 'hashie'
require 'json'
require_relative 'sources/lib/omniauth/auth_hash'

auth = OmniAuth::AuthHash.new(provider: 'example', uid: '17', info: { first_name: 'Ada', last_name: 'Lovelace', email: 'a@example.org' })
p auth.to_hash
p auth.to_json
p OmniAuth::AuthHash::InfoHash.new(email: 'a@example.org').to_hash

klass = Class.new(Hashie::Mash) { include Hashie::Extensions::IndifferentAccess }
h = klass.new(item: 17)
reads = 0
h.define_singleton_method(:[]) { |key| reads += 1; super(key) }
p [h.method(:to_hash).owner, h.to_hash, h.to_json]
p reads
