# frozen_string_literal: true
require 'hashie'
Hashie::Hash.prepend(Module.new do
  def to_hash(*args)
    Hash.ruby2_keywords_hash(super)
  end
end)
