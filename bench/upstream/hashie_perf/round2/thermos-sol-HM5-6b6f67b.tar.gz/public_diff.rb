# frozen_string_literal: true
require 'hashie'
require 'json'
require 'stringio'
require 'logger'
Hashie.logger = Logger.new(StringIO.new)

class PlainSubHash < Hash; end
class PlainSubArray < Array; end
class PlainSubString < String; end
class DefinedDash < Hashie::Dash
  property :item
  property :other
end
class DefinedTrash < Hashie::Trash
  property :item, from: :input, with: ->(v) { v }
  property :other
end
class ZeroConversion
  def to_hash; { zero: 17 }; end
end
class OneConversion
  def to_hash(opts); { one: opts.keys }; end
end
class OptionalConversion
  def to_hash(opts = {}); { optional: opts.keys }; end
end
class RestConversion
  def to_hash(*args); { rest: args }; end
end
class TwoConversion
  def to_hash(a, b); { pair: [a, b] }; end
end
class KeywordConversion
  def to_hash(**opts); { keywords: opts }; end
end
class MissingConversion
  def respond_to_missing?(name, priv = false); name == :to_hash || super; end
  def method_missing(name, *args); name == :to_hash ? { missing: args } : super; end
end
class PrivateConversion
  private
  def to_hash; { private: 19 }; end
end
class NamedInfo < Hashie::Mash
  disable_warnings
  def to_hash
    super.merge('name' => 'derived')
  end
end
class MashChild < Hashie::Mash; end

def oid(o); BasicObject.instance_method(:__id__).bind(o).call; end
def klass(o); Object.instance_method(:class).bind(o).call.name; end
def frozen_state(o); Object.instance_method(:frozen?).bind(o).call; end
def tag_sources(o, tags, path = 'input')
  return if tags.key?(oid(o))
  tags[oid(o)] = path
  case o
  when Hash
    Hash.instance_method(:each_pair).bind(o).call.with_index do |(k, v), i|
      tag_sources(k, tags, "#{path}.k#{i}")
      tag_sources(v, tags, "#{path}.v#{i}")
    end
  when Array
    Array.instance_method(:each).bind(o).call.with_index { |v, i| tag_sources(v, tags, "#{path}.a#{i}") }
  end
end
def snapshot(o, tags, seen = {})
  id = oid(o)
  return ['cycle', seen[id]] if seen.key?(id)
  seen = seen.merge(id => seen.size)
  common = [klass(o), frozen_state(o), tags[id]]
  case o
  when Hash
    pairs = Hash.instance_method(:each_pair).bind(o).call.map { |k, v| [snapshot(k, tags, seen), snapshot(v, tags, seen)] }
    common + ['hash', Hash.ruby2_keywords_hash?(o), o.compare_by_identity?, !o.default_proc.nil?, snapshot(o.default, tags, seen), pairs]
  when Array
    common + ['array', Array.instance_method(:each).bind(o).call.map { |v| snapshot(v, tags, seen) }]
  when String
    common + ['string', o.encoding.name, o.valid_encoding?, String.instance_method(:unpack).bind(o).call('H*')]
  when Numeric, Symbol, TrueClass, FalseClass, NilClass
    common + [o.inspect]
  else
    common + [Object.instance_method(:singleton_methods).bind(o).call.sort]
  end
end

factories = {
  'hashie' => -> { Hashie::Hash.new },
  'mash' => -> { Hashie::Mash.new },
  'mash-sub' => -> { MashChild.new },
  'info' => -> { NamedInfo.new },
  'dash' => -> { DefinedDash.new },
  'trash' => -> { DefinedTrash.new },
  'clash' => -> { Hashie::Clash.new },
  'rash' => -> { Hashie::Rash.new },
  'indifferent' => -> { Hashie::Extensions::IndifferentAccess.inject!(Hashie::Hash.new) }
}
Hashie::Extensions::Mash.constants(false).sort.each do |name|
  mod = Hashie::Extensions::Mash.const_get(name)
  next unless mod.is_a?(Module)
  k = Class.new(Hashie::Mash)
  k.include(mod)
  factories[name.to_s] = -> { k.new }
end
factories['prepend-reader'] = -> do
  k = Class.new(Hashie::Mash)
  k.prepend(Module.new { def [](key); super; end })
  k.new
end
factories['singleton-reader'] = -> do
  h = Hashie::Hash.new
  h.define_singleton_method(:[]) { |key| super(key) }
  h
end
factories['extend-reader'] = -> do
  Hashie::Hash.new.extend(Module.new { def [](key); super; end })
end
values = {
  'scalar' => -> { 'value' }, 'nil' => -> { nil }, 'false' => -> { false },
  'hash' => -> { { a: 17 } }, 'subhash' => -> { PlainSubHash[a: 17] },
  'marked-hash' => -> { Hash.ruby2_keywords_hash(a: 17) },
  'identity-hash' => -> { {}.compare_by_identity.merge!('a' => 17) },
  'array' => -> { [17, Hashie::Hash[a: 29], [31]] },
  'hashie-array' => -> { Hashie::Array[17, Hashie::Hash[a: 29], [31]] },
  'subarray' => -> { PlainSubArray[17, Hashie::Hash[a: 29]] },
  'frozen-array' => -> { Hashie::Array[17, Hashie::Hash[a: 29]].freeze },
  'frozen-hash' => -> { Hashie::Hash[a: 17].freeze },
  'sub-string' => -> { PlainSubString.new("a\xFF".b) },
  'zero' => -> { ZeroConversion.new }, 'one' => -> { OneConversion.new },
  'optional' => -> { OptionalConversion.new }, 'rest' => -> { RestConversion.new },
  'two' => -> { TwoConversion.new }, 'keyword' => -> { KeywordConversion.new },
  'missing' => -> { MissingConversion.new }, 'private' => -> { PrivateConversion.new },
  'mash' => -> { Hashie::Mash.new(a: [17, 29]) },
  'dash' => -> { DefinedDash.new(item: 17, other: 29) },
  'singleton-to-hash' => -> { o = Object.new; o.define_singleton_method(:to_hash) { { singleton: 37 } }; o },
  'private-singleton-to-hash' => -> { o = Object.new; o.define_singleton_method(:to_hash) { { singleton: 37 } }; o.singleton_class.send(:private, :to_hash); o },
  'array-iterator' => -> { a = Hashie::Array[17, 29]; a.define_singleton_method(:each) { |&b| reverse_each(&b) }; a },
  'array-converter' => -> { a = [17]; a.define_singleton_method(:to_hash) { { converted: 41 } }; a },
  'frozen-conversion-result' => -> { o = Object.new; o.define_singleton_method(:to_hash) { { frozen: 43 }.freeze }; o }
}
options = [{}, { stringify_keys: true }, { symbolize_keys: true }, { stringify_keys: true, symbolize_keys: true }, { other: 47 }]
factories.each do |flabel, make|
  values.each do |vlabel, vmake|
    options.each_with_index do |opts, oi|
      [false, true].each do |freeze_receiver|
        [:none, :default, :proc].each do |default|
          [:to_hash, :to_json].each do |operation|
            tags = {}
            events = []
            h = nil
            result = begin
              h = make.call
              h[:item] = vmake.call
              h[:other] = Hashie::Array[Hashie::Hash[nested: 53], 59]
              h.default = :fallback if default == :default
              h.default_proc = proc { |_hash, key| events << ['default', key.to_s]; :fallback } if default == :proc
              tag_sources(h, tags)
              h.freeze if freeze_receiver
              result = operation == :to_hash ? h.to_hash(opts.dup) : h.to_json
              result = result.gsub(/0x[0-9a-f]+/, 'ADDR') if operation == :to_json && result.is_a?(String)
              ['ok', snapshot(result, tags)]
            rescue StandardError => e
              ['error', e.class.name, e.message.gsub(/0x[0-9a-f]+/, 'ADDR').gsub(/.*hashie-(base|head)\//, 'TREE/').sub(/\n.*/m, '')]
            end
            puts JSON.generate([[flabel, vlabel, oi, freeze_receiver, default, operation], result, h && snapshot(h, tags), events])
          end
        end
      end
    end
  end
end
