#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
for version in 3.1.7 3.2.10 3.3.10 3.4.7 4.0.10; do
  prefix="$root/rubies/$version"
  curl -fLsS "https://api.github.com/repos/ruby/ruby-builder/releases/tags/ruby-$version" > "$root/sources/ruby-builder-$version.json"
  archive="$root/builds/prebuilt-$version.tar.gz"
  test -f "$archive" || curl -fLsS "https://github.com/ruby/ruby-builder/releases/download/ruby-$version/ruby-$version-ubuntu-22.04-x64.tar.gz" -o "$archive"
  mkdir -p "$prefix"
  tar xzf "$archive" --strip-components=1 -C "$prefix"
  sudo mkdir -p "/opt/hostedtoolcache/Ruby/$version"
  sudo ln -s "$prefix" "/opt/hostedtoolcache/Ruby/$version/x64"
  "$prefix/bin/ruby" -e 'puts RUBY_DESCRIPTION; require "json"; require "logger"; puts JSON.generate(ok: true)'
done
