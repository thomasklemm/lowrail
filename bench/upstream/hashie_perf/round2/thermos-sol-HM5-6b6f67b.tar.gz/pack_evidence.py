import hashlib
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
out = root / 'review-payload'
out.mkdir(exist_ok=True)
dedup = {}
manifest = []
with tarfile.open(out / 'differentials.tar.xz', 'w:xz', preset=3) as tar:
    for path in sorted((root / 'evidence').glob('*.jsonl')):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        name = 'evidence/' + path.name
        info = tar.gettarinfo(str(path), arcname=name)
        if digest in dedup:
            info.type = tarfile.LNKTYPE
            info.linkname = dedup[digest]
            info.size = 0
            tar.addfile(info)
        else:
            dedup[digest] = name
            with path.open('rb') as data:
                tar.addfile(info, data)
        manifest.append(f'{digest}  {name}\n')
(out / 'differentials.sha256').write_text(''.join(manifest))
print('JSONL files', len(manifest), 'unique contents', len(dedup))

files = [root / 'RUNS.md']
files += sorted(root.glob('*.rb')) + sorted(root.glob('*.py')) + sorted(root.glob('*.sh')) + sorted(root.glob('*.yml'))
files += sorted(p for p in (root / 'sources').rglob('*') if p.is_file())
files += sorted(p for p in (root / 'evidence').rglob('*') if p.is_file() and p.suffix != '.jsonl')
files += [out / 'differentials.tar.xz', out / 'differentials.sha256']
destination = root.parents[3] / 'bench/upstream/hashie_perf/round2/thermos-sol-HM5-6b6f67b.tar.gz'
with tarfile.open(destination, 'w:gz', compresslevel=9) as tar:
    for path in files:
        name = path.name if path.parent == out else str(path.relative_to(root))
        tar.add(str(path), arcname=name, recursive=False)
print(destination, destination.stat().st_size)
assert destination.stat().st_size < 10_000_000
