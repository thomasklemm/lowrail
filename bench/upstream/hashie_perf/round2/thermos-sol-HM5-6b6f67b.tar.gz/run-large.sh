#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
repo=$(git rev-parse --show-toplevel)
out="$root/evidence/large-master-zjit-confirm30"
mkdir -p "$out"
exec 3>"$out/commands.sh"
counts='{"Hashie Array 0":20000,"Hashie Array 1":20000,"Hashie Array 20":2000,"Hashie Array 131072":3}'
orders=('base head base2' 'base base2 head' 'head base base2' 'head base2 base' 'base2 base head' 'base2 head base')
for round in $(seq 1 30); do
  for run in ${orders[$(((round-1)%6))]}; do
    side=${run%2}
    log="$out/r$round-$run.log"
    cmd=(env UPSTREAM_BENCH_WARMUP=20 taskset -c 1 "$root/rubies/master/bin/ruby" --zjit -I "$root/hashie-$side/lib" "$repo/script/upstream-bench" --worker wall "$root/large_body.rb" "$counts" 5)
    printf '%q ' "${cmd[@]}" >&3; printf '> %q 2>&1\n' "$log" >&3
    "${cmd[@]}" > "$log" 2>&1
  done
done
