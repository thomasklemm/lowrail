# frozen_string_literal: true
require 'hashie'
require 'json'

hash = Hashie::Hash.new
value = Object.new
value.define_singleton_method(:is_a?) do |klass|
  hash[:item] = 'replacement' if klass == Hashie::Array
  super(klass)
end
hash[:item] = value
puts "value callback: #{hash.to_hash[:item].equal?(value) ? 'original' : 'replacement'}"

hash = Hashie::Hash.new([:fallback])
key = Object.new
calls = 0
armed = false
key.define_singleton_method(:hash) do
  calls += 1 if armed
  hash.clear if armed && calls == 2
  13
end
hash[key] = [:stored]
armed = true
puts "key callback: #{hash.to_hash.values.inspect}"

klass = Class.new(Hashie::Hash) do
  def [](key)
    super.dup
  end
end
source = Object.new
hash = klass[item: source]
puts "copying reader identity: #{hash.to_hash[:item].equal?(source)}"

klass = Class.new(Hashie::Hash) do
  def [](key)
    @reads = (@reads || 0) + 1
    @reads.odd? ? super : [super]
  end
end
puts "alternating reader: #{klass[item: 13].to_hash.inspect}"
