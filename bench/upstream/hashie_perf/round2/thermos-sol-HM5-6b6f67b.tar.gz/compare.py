import collections
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
for base in sorted((root / 'evidence').glob('*-base.jsonl')):
    head = base.with_name(base.name.replace('-base.jsonl', '-head.jsonl'))
    if not head.exists():
        continue
    a, b = base.read_text().splitlines(), head.read_text().splitlines()
    differences = [(i + 1, x, y) for i, (x, y) in enumerate(zip(a, b)) if x != y]
    print(base.stem, len(a), len(b), 'differences', len(differences))
    for line, x, y in differences[:3]:
        print(line, 'BASE', x, 'HEAD', y)
