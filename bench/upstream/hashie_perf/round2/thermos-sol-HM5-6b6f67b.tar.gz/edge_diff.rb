# frozen_string_literal: true
require 'hashie'
require 'json'
require 'logger'
require 'stringio'
Hashie.logger = Logger.new(StringIO.new)

def row(name)
  puts "#{name}: #{yield.inspect.gsub(/0x[0-9a-f]+/, 'ADDR')}"
rescue StandardError => e
  puts "#{name}: #{e.class}: #{e.message.sub(/\n.*/m, '').gsub(/0x[0-9a-f]+/, 'ADDR')}"
end

[:hash, :json].each do |operation|
  [false, true].each do |freeze_receiver|
    [false, true].each do |array|
      row([operation, freeze_receiver, array, 'type-check-mutates']) do
        h = Hashie::Hash.new
        v = array ? Hashie::Array[17] : Object.new
        v.define_singleton_method(:is_a?) do |k|
          h[:item] = array ? Hashie::Array[29] : 'replacement' if k == Hashie::Array
          super(k)
        end
        h[:item] = v
        h.freeze if freeze_receiver
        result = operation == :json ? h.to_json : h.to_hash
        operation == :json ? result : [result[:item].equal?(v), result[:item] == 'replacement', (result[:item].to_a if result[:item].is_a?(Array))]
      end
    end
  end
end

[:delete, :clear, :replace, :freeze, :value_mutate, :option_mutate, :raise].each do |action|
  [Object, Array, Hashie::Array].each do |kind|
    row([action, kind, 'during-type-check']) do
      h = Hashie::Hash.new
      opts = {}
      v = kind == Object ? Object.new : kind[17, 29]
      v.define_singleton_method(:is_a?) do |k|
        if k == Hashie::Array
          case action
          when :delete then h.delete(:item)
          when :clear then h.clear
          when :replace then h[:item] = kind == Object ? 'replacement' : kind[31, 37]
          when :freeze then h.freeze
          when :value_mutate then self << 41 if respond_to?(:<<)
          when :option_mutate then opts[:symbolize_keys] = true
          when :raise then raise ArgumentError, 'type check failed'
          end
        end
        super(k)
      end
      h[:item] = v
      result = h.to_hash(opts)
      [result[:item].equal?(v), result[:item].class.name, (result[:item].to_a if result[:item].is_a?(Array)), h.keys, h.frozen?]
    end
  end
end

[:delete, :replace, :freeze].each do |action|
  row([action, 'fiber-between-type-and-conversion']) do
    h = Hashie::Hash.new
    v = Object.new
    v.define_singleton_method(:is_a?) { |k| Fiber.yield(:type_check) if k == Hashie::Array; super(k) }
    h[:item] = v
    f = Fiber.new { result = h.to_hash; [result[:item].equal?(v), result[:item], h.frozen?] }
    first = f.resume
    case action
    when :delete then h.delete(:item)
    when :replace then h[:item] = 'replacement'
    when :freeze then h.freeze
    end
    second = f.resume
    [first, second[0], second[1].class.name, second[1] == 'replacement', second[2]]
  end
end

[:core, :hashie, :subclass].each do |array_type|
  [{}, { stringify_keys: true }, { symbolize_keys: true }, { stringify_keys: true, symbolize_keys: true }].each do |opts|
    row([array_type, opts, 'colliding-output-keys']) do
      a = array_type == :hashie ? Hashie::Array[17] : array_type == :subclass ? Class.new(Array)[17] : [17]
      h = Hashie::Hash[:item => a, 'item' => [29], 13 => Hashie::Hash[x: 31]]
      h.to_hash(opts)
    end
  end
end

[:to_hash, :to_json].each do |operation|
  row([operation, 'conversion-mutation']) do
    h = Hashie::Hash.new
    converter = Object.new
    converter.define_singleton_method(:to_hash) { h.delete(:other); { changed: true } }
    h[:item] = converter
    h[:other] = 17
    h.public_send(operation)
  end
end

row('keyword-identity') do
  marked = Hash.ruby2_keywords_hash(a: 17)
  custom = Class.new(Hash)[a: 29]
  h = Hashie::Hash[item: marked, custom: custom]
  out = h.to_hash
  [Hash.ruby2_keywords_hash?(out[:item]), out[:item].equal?(marked), out[:custom].equal?(custom)]
end

[:hashie, :mash].each do |kind|
  row([kind, 'lookup-owners']) do
    h = kind == :mash ? Hashie::Mash.new : Hashie::Hash.new
    [h.method(:[]).owner.name, h.method(:to_hash).owner.name, h.method(:to_json).owner.name]
  end
end
