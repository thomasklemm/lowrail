import json
import math
from pathlib import Path
import re
from statistics import median

root = Path(__file__).resolve().parent
data = json.loads((root / 'evidence/confirm-master-zjit-loadpath/results.json').read_text())
print('Diagnostic only: 2-vCPU orb, not the required a1.xxlarge.')
print('Ruby master 0d399335b733776187e43a783e5f950c18ad881c, ZJIT, CPU 1, GC off.')
print('Normal sweep: 30 base/candidate/base2 rounds, 5 windows/process; upstream-bench estimator and bootstrap.')
for name, c in data['wall'].items():
    print(f'{name}: base {c["base"] * 1e6:.6f} us, head {c["candidate"] * 1e6:.6f} us; '
          f'change {c["change"] * 100:+.4f}% CI {[round(v * 100, 4) for v in c["change_ci"]]}; '
          f'AA {c["aa"] * 100:+.4f}% CI {[round(v * 100, 4) for v in c["aa_ci"]]}; '
          f'jit-flat={c["jit"]["flat"]}, harness-claim={c["claim"]}')
print('Worst relative point estimate in normal sweep:', max(data['wall'], key=lambda k: data['wall'][k]['change']))

counts = {0: 20000, 1: 20000, 20: 2000, 131072: 3}
print('Large-array sweep: 3 rounds only, 5 windows/process, per-process minimum (5-window 10th percentile). No speed claim.')
for size, calls in counts.items():
    name = f'Hashie Array {size}'
    processes = []
    flat = True
    for r in (1, 2, 3):
        one = {}
        for side in ('base', 'head', 'base2'):
            text = (root / f'evidence/large-master-zjit/r{r}-{side}.log').read_text()
            line = next(s for s in text.splitlines() if s.startswith(f'wall {name}\t'))
            one[side] = min(json.loads(line.split('\t')[1])['cpu']) / calls
            jit = next(s for s in text.splitlines() if s.startswith(f'jit {name}\t'))
            counters = re.findall(r'(\w+)=(\d+)>(\d+)', jit)
            flat &= len(counters) == 4 and all(before == after for _, before, after in counters)
        processes.append(one)
    baseline = math.exp(median([math.log(p['base'] * p['base2']) / 2 for p in processes]))
    head = median([p['head'] for p in processes])
    change = math.exp(median([math.log(p['head'] / p[b]) for p in processes for b in ('base', 'base2')])) - 1
    aa = [p['base2'] / p['base'] - 1 for p in processes]
    print(f'{name}: base {baseline * 1e6:.6f} us, head {head * 1e6:.6f} us; '
          f'relative point {change * 100:+.4f}%; AA per round {[round(v * 100, 4) for v in aa]}; '
          f'jit-flat={flat}; individual processes={processes}')

print('Large-array confirmation: 30 rounds, original upstream-bench wall_cell/bootstrap estimator; diagnostic only.')
large = json.loads((root / 'evidence/large-master-zjit-confirm30/results.json').read_text())
for name, c in large.items():
    print(f'{name}: base {c["base"] * 1e6:.6f} us, head {c["candidate"] * 1e6:.6f} us; '
          f'change {c["change"] * 100:+.4f}% CI {[round(v * 100, 4) for v in c["change_ci"]]}; '
          f'AA {c["aa"] * 100:+.4f}% CI {[round(v * 100, 4) for v in c["aa_ci"]]}; '
          f'jit-flat={c["jit_flat"]}, statistical-gates={c["claim"]}')
