# thermos-sol HM5 exact-head review

Review date 2026-11-27. Lowrail thread `T-01a21f3c-226a-77d4-8978-cd852e1e46ae`.
Both Thermos rubrics were applied in this thread, without delegation, as requested.
This is review evidence, not a patch to Hashie or permission to publish upstream.

## Pins and archive layout

- Head: `6b6f67b39c4f839154209f4d94ceadb416f82ddb`.
- Parent/base: `277e88e6ccc317497e6c20fb8b9e35abebc0fe19`.
- Duel run: `46077588957`, closed fork PR 33, merge `a52a15e2b6dddaeae2626e561cb82ed8893a9898`.
- Ruby master: `0d399335b733776187e43a783e5f950c18ad881c`, built with YJIT and ZJIT.
- Released Rubies: 3.0.7, 3.1.7, 3.2.10, 3.3.10, 3.4.7, 4.0.10; additional 4.0.7 interpreter control.

`evidence/commit.diff`, `remote-head.txt`, `duel-trees.txt` and the Ruby build/install logs retain provenance.
`sources/` holds the opened API records, released OmniAuth gem/source, Duel 0.3.1 gem/source and Ruby-builder metadata.
No interpreter binaries, build trees or credentials are in this archive. Sources remain available at their recorded public pins.
`evidence/HM5-reviewed.md` is the title/body/impact presented to review, before the pass was added.

The large JSONL outputs are in **differentials.tar.xz**, with exact-content duplicate files represented as tar hardlinks.
This preserves every original file and byte, not just a compressed summary; `differentials.sha256` lists their digests.
Extract the outer archive and then `tar xJf differentials.tar.xz`; run `sha256sum -c differentials.sha256` to check them.
Small raw logs, failed attempts, probe scripts and API responses are directly in the outer archive.

## Reproduce semantic checks

The original scratch root was `/home/user/workspace/repo/.amp/in/orb-backup/hm5`.
Scripts expect `hashie-base/lib`, `hashie-head/lib`, `rubies/VERSION/bin/ruby` next to them.
Clone thomasklemm/hashie at the exact head and create the base worktree at its parent. None of the scripts pushes or posts.

```sh
bash run-diff.sh 3.0.7 3.1.7 3.2.10 3.3.10 3.4.7 4.0.10 master
python3 compare.py
rubies/4.0.10/bin/ruby -I hashie-base/lib minimal_repros.rb
rubies/4.0.10/bin/ruby -I hashie-head/lib minimal_repros.rb
rubies/master/bin/ruby --zjit -I hashie-base/lib more_edges.rb
rubies/master/bin/ruby --zjit -I hashie-head/lib more_edges.rb
rubies/4.0.10/bin/ruby -I hashie-base/lib -I sources/lib integration_checks.rb
rubies/4.0.10/bin/ruby -I hashie-head/lib -I sources/lib integration_checks.rb
```

`run-diff.sh` also uses Lowrail's unchanged `bench/upstream/hashie_perf/round2/probes/to_hash_diff.rb`.
Its exact copy is `original_probe.rb`. `public_diff.rb` has 35,280 rows/configuration;
`edge_diff.rb` 49 cases; `more_edges.rb` 30 cases. Separate minimal repros were run on every release pin and master.
`evidence/master-differential-summary.txt` includes all 16 public-matrix configurations and zero ordinary differences.
Full callback/mutation differences are retained, including exceptions, both base and head; they are not filtered out of the archive.

Negative control for a property not observed by the author's probe:

```sh
rubies/4.0.10/bin/ruby -I hashie-head/lib -r ./flag_control.rb public_diff.rb > flag-control.jsonl
rubies/4.0.10/bin/ruby -I hashie-head/lib -r ./flag_control.rb original_probe.rb > original-flag-control.txt
```

The old probe output equals its ordinary head output; the independent probe changes 11,700 rows.
This intentionally broken control is not an alteration of the candidate and not evidence of a candidate keyword regression.

`integration_checks.rb` runs the actual released OmniAuth 2.4.2 AuthHash/InfoHash classes, not a replacement implementation.
It also counts reads in a Mash subclass with the IndifferentAccess serializer. Source was extracted from the kept gem;
the released `auth_hash.rb` was byte-compared with release commit `2045f32693592360488c833b1505658dceddcd03`.
Other standalone require probes are in `evidence/load-order.txt`.

## Tests and maintainability

With Ruby 4.0.10's bin directory first on PATH, in each of the base/head worktrees:

```sh
bundle install
bundle exec rake spec
```

Head additionally ran `bundle exec rake rubocop` and `bundle exec rake docs:examples`.
The worktrees' unmodified Gemfile/Gemfile.lock govern dependency resolution. Native gems from the initial 4.0.7 bundle
could not load under 4.0.10; reinstalling in the latter runtime resolved this. The retained failed logs do not count as test passes.
An additional head run on 4.0.7 passed the same three tasks. Other versions ran semantic probes, not complete gem suites.

`metrics.yml`, `evidence/metrics-{base,head}.json` and `evidence/flog-{base,head}.txt` retain per-method metrics.
Metrics were taken with RuboCop 1.91.0 and flog 4.10.0, separately from correctness tests.

## Timing methodology and limitations

Every new timing here is **diagnostic only**: this is a 2-vCPU orb, not the a1.xxlarge required by DECISIONS for
publishable numbers. The user explicitly required this review in this thread with no additional threads.
Do not move these diagnostic numbers into an upstream body or treat them as a policy-compliant blocking loss.
The body's existing Duel numbers are independently audited upstream evidence, not new timings from this small orb.

First ran the twelve-case screen with `script/upstream-bench` on 4.0.10/ZJIT, five base/head/base rounds,
five windows, 10 ms target, 10,000 warmup calls, CPU 1. All its timing claims were rejected: that release's stats
lack `compiled_side_exit_count`. The screen and its missing-counter evidence remain in `evidence/screen-4.0.10-zjit/`.

Master's stats provide the required compile/failure/side-exit/invalidation counters. The confirmation command was:

```sh
rubies/master/bin/ruby /home/user/workspace/repo/script/upstream-bench \
  --out evidence/confirm-master-zjit-loadpath --base "$PWD/hashie-base" --candidate "$PWD/hashie-head" \
  --ruby "$PWD/rubies/master/bin/ruby" --gems '' --modes '' \
  --wall 30 --wall-mode zjit --wall-windows 5 --wall-ms 10 --warmup 10000 --core 1 "$PWD/perf_body.rb"
bash run-large.sh
rubies/master/bin/ruby large_summary.rb
python3 performance_summary.py
```

The regular harness keeps calibration, per-process CPU and elapsed samples, A/A, bootstrap intervals,
JIT gates and complete generated commands. It rotates all six base/head/base2 process orders across 30 rounds.
`perf_body.rb` uses the selected tree's load path directly because the locally built master intentionally has no
OpenSSL extension; the first Bundler-based attempt therefore failed before timing. A second absolute require failed
to put sibling requires on the load path. Both failed attempts are kept; neither produced a speed result.

`large_body.rb` extends the sweep to Hashie::Array sizes 0, 1, 20 and 131,072 references (1 MiB raw reference storage).
It prewarms the common two-element Hashie::Array path 10,000 times before registering cases.
`run-large.sh` invokes the unmodified harness's GC-off wall worker, with 100 one-call windows and 20 call warmup,
then five timed windows. Each large window has only three calls to bound retained output memory.
The first three base/head/base2 rounds rotate process order, on CPU 1, with all three outputs retained in
`evidence/large-master-zjit/`. The full confirmation then runs **30 rounds and all six process orders** in
`evidence/large-master-zjit-confirm30/`. `large_summary.rb` reads the actual `wall_cell` and bootstrap definitions
from the saved harness, rather than implementing a competing estimator, and checks four JIT counters per process/case.
All four sizes were JIT-flat. The 131,072-element row passed the statistical gates for a local loss, but this
orb's size still disqualifies it as a publishable or policy-compliant blocking loss. Repeat on a1.xxlarge.
This is a bounded worst-input search, not a proof of the slowest possible arbitrary Ruby callback.

The README's timing paragraph and `evidence/performance-summary.txt` give the completed results.

## External claim checks

The README's sentence audit maps every upstream title/body/commit/CHANGELOG assertion to executed source probes or
opened API/raw-log evidence. GitHub API reads were made with `gh api`, RubyGems reads with its public gem API.
Current ownership/number checks were repeated at the end (`*-final.json` / stderr).
The 662 link is prospective and must be checked again at opening: issues share the numbering space.
No PR, comment, review, notification, fork push or upstream source change was made.
