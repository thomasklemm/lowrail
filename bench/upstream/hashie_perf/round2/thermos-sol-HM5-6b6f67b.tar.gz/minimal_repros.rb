# frozen_string_literal: true
require 'hashie'
h = Hashie::Hash.new
v = Object.new
v.define_singleton_method(:is_a?) do |type|
  h[:item] = :replacement if type == Hashie::Array
  super(type)
end
h[:item] = v
p h.to_hash[:item].equal?(v)

h = Hashie::Hash.new(:fallback)
n = 0
k = Object.new
k.define_singleton_method(:hash) { h.clear if (n += 1) == 3; 13 }
h[k] = :stored
p h.to_hash.values
