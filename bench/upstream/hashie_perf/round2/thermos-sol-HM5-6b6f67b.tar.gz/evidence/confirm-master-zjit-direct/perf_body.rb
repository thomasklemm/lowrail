# frozen_string_literal: true
require File.join(ENV.fetch('UPSTREAM_BENCH_TREE'), 'lib/hashie')
require 'json'
require 'logger'
Hashie.logger = Logger.new(nil)

receivers = {
  'empty Hashie' => Hashie::Hash.new,
  'empty Mash' => Hashie::Mash.new,
  'Hashie scalar Symbol key' => Hashie::Hash[item: 17],
  'Hashie scalar String key' => Hashie::Hash['item' => 17],
  'Mash scalar' => Hashie::Mash.new(item: 17),
  'Hashie core Array' => Hashie::Hash[item: [17, 29]],
  'Hashie Hashie Array' => Hashie::Hash[item: Hashie::Array[17, 29]],
  'Mash 20 keys' => Hashie::Mash.new((1..20).to_h { |i| ["key#{i}", i] }),
  'Hashie 20 keys' => Hashie::Hash[(1..20).to_h { |i| [i, i] }]
}
receivers.each do |name, receiver|
  UpstreamBench.report(name) { receiver.to_hash }
end
hash = Hashie::Hash[item: 'data']
UpstreamBench.report('Hashie stringify') { hash.to_hash(stringify_keys: true) }
UpstreamBench.report('Hashie symbolize') { hash.to_hash(symbolize_keys: true) }
UpstreamBench.report('Hashie json') { hash.to_json }
