Time per call, Ruby 4.0.10, ZJIT, 5 rounds of fresh processes on one core

| | Before | After | Change |
| --- | ---: | ---: | ---: |
| `empty Hashie` | 0.11 µs | 0.12 µs | not JIT-flat, no claim |
| `empty Mash` | 0.16 µs | 0.16 µs | not JIT-flat, no claim |
| `Hashie scalar Symbol key` | 0.31 µs | 0.30 µs | not JIT-flat, no claim |
| `Hashie scalar String key` | 0.32 µs | 0.30 µs | not JIT-flat, no claim |
| `Mash scalar` | 0.58 µs | 0.48 µs | not JIT-flat, no claim |
| `Hashie core Array` | 0.43 µs | 0.41 µs | not JIT-flat, no claim |
| `Hashie Hashie Array` | 0.59 µs | 0.57 µs | not JIT-flat, no claim |
| `Mash 20 keys` | 8.95 µs | 6.91 µs | not JIT-flat, no claim |
| `Hashie 20 keys` | 3.80 µs | 3.53 µs | not JIT-flat, no claim |
| `Hashie stringify` | 0.73 µs | 0.71 µs | not JIT-flat, no claim |
| `Hashie symbolize` | 0.59 µs | 0.56 µs | not JIT-flat, no claim |
| `Hashie json` | 1.08 µs | 1.09 µs | not JIT-flat, no claim |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/hm5/evidence/screen-4.0.10-zjit.
- JIT-flat: compiled_iseq_count, failed_iseq_count, compiled_side_exit_count, invalidation_time_ns unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- Wall: thread CPU time with GC off per window, the 10th-percentile window per process; change = median of every round's candidate / base and candidate / base2, A/A = median of base2 / base, 95% bootstrap intervals resampling rounds
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/hm5/hashie-base at 277e88e6cc
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/hm5/hashie-head at 6b6f67b39c
- wall empty Hashie: +1.1% [−0.2%, +1.5%] with A/A −1.5% [−3.6%, +0.4%] (50487 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall empty Mash: −1.6% [−2.0%, −0.6%] with A/A −0.4% [−5.6%, +1.9%] (36315 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Hashie scalar Symbol key: −1.9% [−3.0%, −1.5%] with A/A +0.9% [−1.2%, +3.5%] (16971 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Hashie scalar String key: −2.8% [−4.4%, −2.7%] with A/A +0.3% [−1.7%, +1.3%] (16639 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Mash scalar: −17.2% [−19.9%, −17.1%] with A/A −2.2% [−3.1%, +3.9%] (8493 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Hashie core Array: −4.8% [−6.7%, −1.5%] with A/A +0.7% [−3.9%, +3.5%] (11433 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Hashie Hashie Array: −2.8% [−5.1%, −1.7%] with A/A −1.2% [−6.5%, +7.5%] (8368 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Mash 20 keys: −22.2% [−24.9%, −20.2%] with A/A −0.7% [−4.0%, −0.0%] (587 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Hashie 20 keys: −5.3% [−6.9%, −4.5%] with A/A +0.2% [−8.5%, +4.1%] (1396 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Hashie stringify: −3.3% [−4.0%, −1.7%] with A/A +0.3% [−5.6%, +2.1%] (7048 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Hashie symbolize: −4.1% [−4.6%, −3.1%] with A/A −1.1% [−1.5%, +4.1%] (8535 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
- wall Hashie json: −3.7% [−5.2%, +5.7%] with A/A −3.1% [−13.6%, +6.0%] (4496 calls × 5 windows per process): not JIT-flat (r1 base compiled_side_exit_count missing, r1 candidate compiled_side_exit_count missing, r1 base2 compiled_side_exit_count missing, …), no claim
