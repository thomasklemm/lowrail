Time per call, Ruby 4.1.0dev, ZJIT, 30 rounds of fresh processes on one core

| | Before | After | Change |
| --- | ---: | ---: | ---: |
| `empty Hashie` | 0.07 µs | 0.07 µs | within noise |
| `empty Mash` | 0.07 µs | 0.07 µs | within noise |
| `Hashie scalar Symbol key` | 0.21 µs | 0.20 µs | −4.7% |
| `Hashie scalar String key` | 0.22 µs | 0.21 µs | −4.6% |
| `Mash scalar` | 0.30 µs | 0.27 µs | −9.8% |
| `Hashie core Array` | 0.22 µs | 0.21 µs | −3.3% |
| `Hashie Hashie Array` | 0.31 µs | 0.31 µs | within noise |
| `Mash 20 keys` | 4.63 µs | 3.78 µs | −18.0% |
| `Hashie 20 keys` | 3.09 µs | 2.82 µs | −8.7% |
| `Hashie stringify` | 0.44 µs | 0.41 µs | −4.4% |
| `Hashie symbolize` | 0.46 µs | 0.45 µs | −2.5% |
| `Hashie json` | 0.64 µs | 0.64 µs | within noise |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/hm5/evidence/confirm-master-zjit-loadpath.
- JIT-flat: compiled_iseq_count, failed_iseq_count, compiled_side_exit_count, invalidation_time_ns unchanged in every measured window (each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)
- Wall: thread CPU time with GC off per window, the 10th-percentile window per process; change = median of every round's candidate / base and candidate / base2, A/A = median of base2 / base, 95% bootstrap intervals resampling rounds
- base: ruby 4.1.0dev (2026-11-27T16:40:23Z master 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/hm5/hashie-base at 277e88e6cc
- candidate: ruby 4.1.0dev (2026-11-27T16:40:23Z master 0d399335b7) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/hm5/hashie-head at 6b6f67b39c
- wall empty Hashie: −0.6% [−1.6%, +1.3%] with A/A +0.4% [−2.8%, +1.5%] (160389 calls × 5 windows per process), JIT-flat in 90 processes: interval includes 0, no claim
- wall empty Mash: −0.0% [−1.1%, +1.0%] with A/A −0.2% [−2.1%, +1.6%] (184993 calls × 5 windows per process), JIT-flat in 90 processes: interval includes 0, no claim
- wall Hashie scalar Symbol key: −4.7% [−5.3%, −4.1%] with A/A −0.0% [−0.6%, +1.0%] (49476 calls × 5 windows per process), JIT-flat in 90 processes
- wall Hashie scalar String key: −4.6% [−5.3%, −4.2%] with A/A +0.4% [−0.3%, +1.2%] (46949 calls × 5 windows per process), JIT-flat in 90 processes
- wall Mash scalar: −9.8% [−10.3%, −9.5%] with A/A +0.4% [−0.5%, +0.7%] (33785 calls × 5 windows per process), JIT-flat in 90 processes
- wall Hashie core Array: −3.3% [−4.1%, −2.9%] with A/A +0.0% [−0.5%, +0.7%] (46574 calls × 5 windows per process), JIT-flat in 90 processes
- wall Hashie Hashie Array: −0.1% [−0.7%, +0.5%] with A/A +0.1% [−1.0%, +1.1%] (32989 calls × 5 windows per process), JIT-flat in 90 processes: interval includes 0, no claim
- wall Mash 20 keys: −18.0% [−18.5%, −17.5%] with A/A −0.1% [−1.5%, +0.9%] (2082 calls × 5 windows per process), JIT-flat in 90 processes
- wall Hashie 20 keys: −8.7% [−9.9%, −6.7%] with A/A −0.7% [−3.3%, +1.8%] (3196 calls × 5 windows per process), JIT-flat in 90 processes
- wall Hashie stringify: −4.4% [−6.3%, −3.0%] with A/A −1.6% [−5.4%, +1.4%] (23824 calls × 5 windows per process), JIT-flat in 90 processes
- wall Hashie symbolize: −2.5% [−3.1%, −1.6%] with A/A −0.5% [−1.9%, +1.6%] (22078 calls × 5 windows per process), JIT-flat in 90 processes
- wall Hashie json: −1.5% [−3.9%, +0.7%] with A/A +1.2% [−2.6%, +3.1%] (14890 calls × 5 windows per process), JIT-flat in 90 processes: interval includes 0, no claim
