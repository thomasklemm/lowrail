#!/usr/bin/env ruby
# frozen_string_literal: true

# Body numbers for an upstream PR: base against candidate, with base measured twice as an A/A in every cell.
# Usage and the benchmark script format: docs/upstream/body-numbers.md.

module UpstreamBench
  CASES = {}
  def self.report(name, &block) = CASES[name.to_s] = block
end

if ARGV.first == "--worker"
  _, mode, script, *rest = ARGV
  ARGV.clear
  warm_calls = Integer(ENV.fetch("UPSTREAM_BENCH_WARMUP", "3000"))
  load File.expand_path(script)
  # docs/bench.md's JIT-flat counters, read before and after each measured window; a missing one fails the gate.
  keys, stats = if defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?
    # Ruby master from about 2026-11 reports invalidation_time_ns but no invalidation_count; any rise means one ran.
    invalidation = (RubyVM::ZJIT.stats || {}).key?(:invalidation_count) ? :invalidation_count : :invalidation_time_ns
    [[:compiled_iseq_count, :failed_iseq_count, :compiled_side_exit_count, invalidation], -> { RubyVM::ZJIT.stats || {} }]
  elsif defined?(RubyVM::YJIT) && RubyVM::YJIT.enabled?
    [%i[compiled_iseq_count compiled_block_count invalidation_count], -> { RubyVM::YJIT.runtime_stats }]
  end
  jit = keys && -> { stats.().values_at(*keys) }
  window = ->(name, before, after) { puts "jit #{name}\t#{keys.zip(before, after).map { |k, b, a| "#{k}=#{b}>#{a}" }.join(" ")}" }
  case mode
  when "objects"
    UpstreamBench::CASES.each do |name, call|
      warm_calls.times { call.call }
      GC.start
      GC.disable
      # Two windows, so an allocation outside the calls (the first GC.stat, a lazy constant) cancels out.
      counts = [1000, 2000].map do |n|
        before = GC.stat(:total_allocated_objects)
        n.times { call.call }
        GC.stat(:total_allocated_objects) - before
      end
      GC.enable
      puts "objects #{name}\t#{(counts[1] - counts[0]) / 1000.0}"
    end
  when "ir"
    # The harness subtracts an N=0 run, so only the calls inside rb_ary_cycle remain.
    name, n = rest
    call = UpstreamBench::CASES.fetch(name)
    if jit
      # Warm up through the measured block itself; reverse_each yields from C like cycle (Array#each is Ruby under YJIT).
      block = proc { |c| c.call }
      Array.new(warm_calls, call).reverse_each(&block)
      GC.start
      GC.disable
      before = jit.()
      [call].cycle(Integer(n), &block)
      window.(name, before, jit.())
    else
      warm_calls.times { call.call }
      GC.start
      GC.disable
      [call].cycle(Integer(n)) { |c| c.call }
    end
  when "wall-calibrate", "wall"
    require "json"
    calls = mode == "wall" ? JSON.parse(rest[0]) : Hash.new(1)
    windows = mode == "wall" ? Integer(rest[1]) : 1
    cpu = -> { Process.clock_gettime(Process::CLOCK_THREAD_CPUTIME_ID) }
    mono = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
    # One GC-free window of n calls; JIT counters are read outside the timed part.
    measure = lambda do |call, n|
      GC.start
      GC.disable
      before = jit&.()
      w0 = mono.()
      c0 = cpu.()
      k = 0
      while k < n
        call.call
        k += 1
      end
      c1 = cpu.()
      w1 = mono.()
      after = jit&.()
      GC.enable
      [c1 - c0, w1 - w0, before, after]
    end
    # The warm-up runs measure itself: 100 one-call windows compile every branch of its loop, then warm_calls calls.
    UpstreamBench::CASES.each_value { |call| 100.times { measure.(call, 1) } }
    UpstreamBench::CASES.each_value { |call| measure.(call, warm_calls) }
    if mode == "wall-calibrate"
      UpstreamBench::CASES.each { |name, call| puts "calibrate #{name}\t#{measure.(call, warm_calls)[0] / warm_calls}" }
      exit
    end
    samples = UpstreamBench::CASES.to_h { |name, _| [name, { cpu: [], wall: [], moved: Array.new(keys&.size || 0, 0) }] }
    # Cases alternate window by window, so a slow stretch of the host spreads over all of them.
    windows.times do
      UpstreamBench::CASES.each do |name, call|
        c, w, before, after = measure.(call, calls.fetch(name))
        s = samples[name]
        s[:cpu] << c
        s[:wall] << w
        # Absolute deltas, so a counter that rises in one window and is reset in another can't cancel out.
        s[:moved] = s[:moved].zip(before.zip(after)).map { |m, (b, a)| m && b && a ? m + (a - b).abs : nil } if jit
      end
    end
    samples.each do |name, s|
      puts "wall #{name}\t#{JSON.generate(cpu: s[:cpu], wall: s[:wall])}"
      puts "jit #{name}\t#{keys.zip(s[:moved]).map { |k, m| "#{k}=#{m && 0}>#{m}" }.join(" ")}" if jit
    end
  when "ips"
    require "benchmark/ips"
    time, warmup = rest.map { Float(_1) }
    if jit
      # benchmark-ips calls Timing.time_us right after each timed interval, so a read there times nothing.
      gate = Class.new do
        # Every ivar is set here: a later shape change would recompile `interval` inside the first window.
        def initialize(read, report) = (@read, @report, @reads, @label, @before, @after = read, report, 0, nil, nil, nil)
        def warming(*) = nil
        def warmup_stats(*) = nil
        def running(label, _) = (@label, @reads, @before = label, 0, @read.())
        def interval = (@after = @read.(); @reads += 1)
        def add_report(*)
          raise "benchmark-ips did not call Timing.time_us after the timed intervals" if @reads.zero?
          @report.(@label, @before, @after)
        end
      end.new(jit, window)
      Benchmark::Timing.singleton_class.prepend(Module.new { define_method(:time_us) { |b, a| gate.interval; super(b, a) } })
    end
    Benchmark.ips do |x|
      x.config(time: time, warmup: warmup, suite: gate)
      UpstreamBench::CASES.each { |name, call| x.report(name) { call.call } }
      if gate
        # Each report's call_times and the gate's read run 3,000 times first, so neither compiles in a timed loop.
        x.list.each { |entry| 3000.times { entry.call_times(1) } }
        3000.times { Benchmark::Timing.time_us(0.0, 1.0) }
      end
    end
  end
  exit
end

require "fileutils"
require "json"
require "open3"
require "optparse"
require "shellwords"
require "time"

ROOT = File.expand_path("..", __dir__)
HEAP = { "RUBY_GC_HEAP_0_INIT_SLOTS" => "1000000", "RUBY_GC_HEAP_1_INIT_SLOTS" => "250000",
  "RUBY_GC_HEAP_2_INIT_SLOTS" => "100000", "RUBY_GC_HEAP_3_INIT_SLOTS" => "20000",
  "RUBY_GC_HEAP_4_INIT_SLOTS" => "10000" }.freeze
MODE_FLAGS = { "interp" => [], "yjit" => ["--yjit"], "zjit" => ["--zjit"] }.freeze
MODE_TITLES = { "interp" => "no JIT", "yjit" => "YJIT", "zjit" => "ZJIT" }.freeze

o = { gems: nil, with: [], n: 2000, warmup: 3000, ips: 0, ips_mode: "yjit", ips_time: 5, ips_warmup: 2, core: 1,
  wall: 0, wall_windows: 30, wall_ms: 50,
  names: %w[Before After], modes: nil }
parser = OptionParser.new do |p|
  p.banner = "Usage: script/upstream-bench --out NEW_DIR [--base TREE --candidate TREE] [--ruby R | --base-ruby R --candidate-ruby R] BENCH.rb"
  p.on("--out DIR", "Raw output, commands and table; must not exist") { o[:out] = File.expand_path(_1) }
  p.on("--base TREE", "Base Rails or gem checkout") { o[:base] = File.expand_path(_1) }
  p.on("--candidate TREE", "Candidate checkout") { o[:candidate] = File.expand_path(_1) }
  p.on("--tree TREE", "One checkout for both sides (when only the Ruby differs)") { o[:base] = o[:candidate] = File.expand_path(_1) }
  p.on("--gems LIST", Array, "Gems to load from each tree, e.g. activesupport,activemodel,actionview (default: the root gemspec)") { o[:gems] = _1 }
  p.on("--with GEM", "Extra Gemfile dependency, repeatable") { o[:with] << _1 }
  p.on("--ruby R", "Ruby for both sides: an executable or a mise version") { o[:base_ruby] = o[:candidate_ruby] = _1 }
  p.on("--base-ruby R") { o[:base_ruby] = _1 }
  p.on("--candidate-ruby R") { o[:candidate_ruby] = _1 }
  p.on("--valgrind PREFIX", "Prefix built by script/bench-valgrind (default $LOWRAIL_VALGRIND)") { o[:valgrind] = _1 }
  p.on("--modes LIST", Array, "interp,yjit,zjit (default: all the Rubies have)") { o[:modes] = _1 }
  p.on("-n N", Integer, "Calls per Callgrind window (default 2000)") { o[:n] = _1 }
  p.on("--preload SO", "LD_PRELOAD for every worker, e.g. fixrand.so for a fixed hash seed (control only)") { o[:preload] = File.expand_path(_1) }
  p.on("--warmup N", Integer, "Warm-up calls before each objects and Callgrind window (default 3000)") { o[:warmup] = _1 }
  p.on("--ips ROUNDS", Integer, "benchmark-ips rounds of base/candidate/base (default 0: none)") { o[:ips] = _1 }
  p.on("--ips-mode MODE", "interp, yjit or zjit (default yjit)") { o[:ips_mode] = _1 }
  p.on("--ips-time S", Float) { o[:ips_time] = _1 }
  p.on("--wall ROUNDS", Integer, "Wall-time cohort: rounds of fresh base/candidate/base processes (default 0: none)") { o[:wall] = _1 }
  p.on("--wall-mode MODE", "interp, yjit or zjit (default zjit when both Rubies have it, else yjit)") { o[:wall_mode] = _1 }
  p.on("--wall-windows N", Integer, "Timed windows per case and process (default 30)") { o[:wall_windows] = _1 }
  p.on("--wall-ms MS", Float, "Target length of one window (default 50)") { o[:wall_ms] = _1 }
  p.on("--core N", Integer, "CPU for benchmark-ips and --wall (default 1)") { o[:core] = _1 }
  p.on("--names BEFORE,AFTER", Array, "Column names (default Before,After)") { o[:names] = _1 }
end
parser.parse!
script = ARGV.shift
abort parser.banner unless script && ARGV.empty? && o[:out]
script = File.expand_path(script)
abort "#{o[:out]} exists; use a new directory" if File.exist?(o[:out])
o[:base_ruby] ||= RbConfig.ruby
o[:candidate_ruby] ||= o[:base_ruby]

def ruby_path(spec)
  return File.expand_path(spec) if spec.include?("/")
  out, status = Open3.capture2("mise", "where", "ruby@#{spec}")
  abort "unknown Ruby #{spec}" unless status.success?
  File.join(out.strip, "bin/ruby")
end

def capture(*cmd) = Open3.capture2e(*cmd).first.strip

out = o[:out]
FileUtils.mkdir_p(File.join(out, "raw"))
FileUtils.cp(script, File.join(out, File.basename(script)))
COMMANDS = File.open(File.join(out, "commands.sh"), "w")
COMMANDS.puts "# Every command script/upstream-bench ran, in order."
COMMANDS.sync = true

def run(env, cmd, log:, chdir: Dir.pwd)
  vars = env.map { |k, v| v ? "#{k}=#{v.shellescape}" : "-u #{k}" }.join(" ")
  COMMANDS.puts "(cd #{chdir.shellescape} && env #{vars} #{cmd.shelljoin}) > #{log.shellescape} 2>&1"
  ok = system(env, *cmd, chdir: chdir, out: log, err: [:child, :out])
  abort "failed, see #{log}" unless ok
  File.read(log)
end

sides = {}
{ "base" => [o[:base], o[:base_ruby]], "candidate" => [o[:candidate], o[:candidate_ruby]] }.each do |side, (tree, rb)|
  ruby = ruby_path(rb)
  env = HEAP.merge("RUBYOPT" => nil, "RUBY_YJIT_ENABLE" => nil, "UPSTREAM_BENCH_WARMUP" => o[:warmup].to_s, "PATH" => "#{File.dirname(ruby)}:#{ENV.fetch("PATH")}")
  # An app's script boots from this checkout itself (with --gems ""), since its bundle cannot be rebuilt here.
  env["UPSTREAM_BENCH_TREE"] = tree if tree
  env["LD_PRELOAD"] = o[:preload] if o[:preload]
  gems = []
  if tree
    names = o[:gems] || Dir[File.join(tree, "*.gemspec")].map { File.basename(_1, ".gemspec") }
    gems = names.map do |name|
      dir = [File.join(tree, name), tree].find { File.file?(File.join(_1, "#{name}.gemspec")) }
      abort "no #{name}.gemspec in #{tree}" unless dir
      %(gem #{name.dump}, path: #{dir.dump})
    end
  end
  gems += o[:with].map { %(gem #{_1.dump}) }
  gems << %(gem "benchmark-ips") if o[:ips] > 0
  unless gems.empty?
    dir = File.join(out, side)
    FileUtils.mkdir_p(dir)
    File.write(File.join(dir, "Gemfile"), "source \"https://rubygems.org\"\n#{gems.join("\n")}\n")
    env["BUNDLE_GEMFILE"] = File.join(dir, "Gemfile")
    run(env, [File.join(File.dirname(ruby), "bundle"), "install"], log: File.join(out, "raw", "#{side}-bundle.log"))
  end
  sides[side] = { ruby: ruby, env: env, tree: tree,
    description: capture(env, ruby, "-e", "print RUBY_DESCRIPTION"),
    zjit: system(env, ruby, "--zjit", "-e", "exit defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?", out: File::NULL, err: File::NULL),
    head: tree && capture("git", "-C", tree, "rev-parse", "HEAD"),
    dirty: tree && !capture("git", "-C", tree, "status", "--porcelain", "--untracked-files=no").empty? }
end

if sides.values.all? { _1[:env]["BUNDLE_GEMFILE"] }
  third_party = sides.values.map do |s|
    File.read("#{s[:env]["BUNDLE_GEMFILE"]}.lock").split(/\n\n/).grep_v(/\APATH\n/).join("\n\n")
  end
  abort "base and candidate resolved different third-party gems; compare #{out}/*/Gemfile.lock" unless third_party.uniq.size == 1
end
same_ruby = sides["base"][:description] == sides["candidate"][:description]
abort "base and candidate are identical: same tree and same Ruby" if sides.values.map { _1[:ruby] }.uniq.size == 1 && o[:base] == o[:candidate]

modes = o[:modes] || ["interp", "yjit", *("zjit" if sides.values.all? { _1[:zjit] })]
wall_mode = o[:wall_mode] || (sides.values.all? { _1[:zjit] } ? "zjit" : "yjit")
unless modes.empty?
  prefix = File.expand_path(o[:valgrind] || ENV["LOWRAIL_VALGRIND"] || abort("pass --valgrind PREFIX (build it with script/bench-valgrind)"))
  manifest = File.join(prefix, "share/lowrail/valgrind.json")
  abort "#{prefix} is not a script/bench-valgrind prefix" unless File.file?(manifest)
  FileUtils.cp(manifest, File.join(out, "valgrind.json"))
  valgrind = File.join(prefix, "bin/valgrind")
end

worker = ->(side, mode, *args) do
  s = sides.fetch(side)
  [s[:ruby], *MODE_FLAGS.fetch(mode), *("-rbundler/setup" if s[:env]["BUNDLE_GEMFILE"]), File.expand_path(__FILE__), "--worker", *args]
end
cases = nil
runs = %w[base candidate base2]
side_of = ->(run) { run.delete_suffix("2") }

# Objects: deterministic, but still run base twice so a nondeterministic case shows.
# With --modes "" (ips or wall only), the objects pass still runs in that mode: it names the cases and needs no Valgrind.
objects = (modes.empty? ? [*(o[:ips_mode] if o[:ips] > 0), *(wall_mode if o[:wall] > 0)].uniq : modes).to_h do |mode|
  [mode, runs.to_h do |r|
    text = run(sides[side_of[r]][:env], worker[side_of[r], mode, "objects", script], log: File.join(out, "raw", "objects-#{mode}-#{r}.log"))
    [r, text.scan(/^objects (.+)\t(\S+)$/).to_h { [_1, Float(_2)] }]
  end]
end
cases = objects.values.first.fetch("base").keys
abort "#{script} defines no UpstreamBench.report cases" if cases.empty?

# JIT workers print "jit NAME\tKEY=BEFORE>AFTER ..." for each measured window; the gate checks them per cell.
jit = {}
record_jit = ->(cell, mode, text, log, names, window) do
  return if mode == "interp"
  seen = text.scan(/^jit (.+)\t(.*)$/).to_h do |name, counters|
    [name, counters.scan(/(\w+)=(\d*)>(\d*)/).to_h { |k, b, a| [k, [b, a].map { _1.empty? ? nil : Integer(_1) }] }]
  end
  names.each do |name|
    (jit["#{cell} #{name}"] ||= []) << { window: window, counters: seen.fetch(name) { abort "no JIT counters for #{name} in #{log}" } }
  end
end
windows = ->(mode, key) { mode == "interp" ? [] : jit.fetch(key) { abort "no JIT windows for #{key}" } }

instructions = modes.to_h do |mode|
  [mode, cases.each_with_index.to_h do |name, index|
    [name, runs.to_h do |r|
      side = side_of[r]
      counts = [0, o[:n]].map do |n|
        log = File.join(out, "raw", "ir-#{mode}-#{index + 1}-#{name.gsub(/\W+/, "_")}-#{r}-n#{n}")
        cmd = [valgrind, "--verbose", "--tool=callgrind", "--collect-atstart=no", "--toggle-collect=rb_ary_cycle",
          *("--smc-check=all" unless mode == "interp"), "--callgrind-out-file=#{log}.callgrind", "--log-file=#{log}.valgrind.log",
          *worker[side, mode, "ir", script, name, n.to_s]]
        record_jit.(mode, mode, run(sides[side][:env], cmd, log: "#{log}.log"), "#{log}.log", [name], "#{r} n#{n}")
        vlog = File.read("#{log}.valgrind.log")
        abort "Valgrind brk reservation exhausted in #{log}.valgrind.log; nothing is reported" if vlog.match?(/brk segment overflow|Cannot map memory to grow brk segment/)
        # bench.md: the dump's trailing totals line, since Valgrind 3.19 can wrap summary (and the log's Collected).
        Integer(File.read("#{log}.callgrind").scan(/^totals: (\d+)/).last&.first || abort("no totals line in #{log}.callgrind"))
      end
      [r, (counts[1] - counts[0]) / o[:n].to_f]
    end]
  end]
end

ips = nil
if o[:ips] > 0
  ips = Hash.new { |h, k| h[k] = Hash.new { |hh, kk| hh[kk] = [] } }
  o[:ips].times do |round|
    runs.each do |r|
      side = side_of[r]
      cmd = ["taskset", "-c", o[:core].to_s, *worker[side, o[:ips_mode], "ips", script, o[:ips_time].to_s, o[:ips_warmup].to_s]]
      log = File.join(out, "raw", "ips-r#{round + 1}-#{r}.log")
      text = run(sides[side][:env], cmd, log: log)
      text.split("Calculating -------------------------------------").last.scan(/^\s*(.+?)\s+([\d.]+)([kMB]?) \(±\s*[\d.]+%\) i\/s/) do |name, value, unit|
        ips[name][r] << Float(value) * { "" => 1, "k" => 1e3, "M" => 1e6, "B" => 1e9 }.fetch(unit)
      end
      record_jit.("ips", o[:ips_mode], text, log, cases, "r#{round + 1} #{r}")
    end
  end
end

# Wall-time cohort (docs/upstream/body-numbers.md): one calibration process, then ROUNDS rounds of fresh
# base, candidate and base processes on one core, in the six orders in turn.
wall = nil
if o[:wall] > 0
  taskset = ["taskset", "-c", o[:core].to_s]
  log = File.join(out, "raw", "wall-calibrate.log")
  text = run(sides["base"][:env], [*taskset, *worker["base", wall_mode, "wall-calibrate", script]], log: log)
  calls = text.scan(/^calibrate (.+)\t(\S+)$/).to_h { |name, s| [name, [1, (o[:wall_ms] / 1000.0 / Float(s)).round].max] }
  wall = { calls: calls, rounds: Hash.new { |h, k| h[k] = [] } }
  orders = runs.permutation.to_a
  o[:wall].times do |round|
    procs = orders[round % orders.size].to_h do |r|
      side = side_of[r]
      log = File.join(out, "raw", "wall-r#{round + 1}-#{r}.log")
      text = run(sides[side][:env], [*taskset, *worker[side, wall_mode, "wall", script, JSON.generate(calls), o[:wall_windows].to_s]], log: log)
      record_jit.("wall", wall_mode, text, log, cases, "r#{round + 1} #{r}")
      [r, text.scan(/^wall (.+)\t(.*)$/).to_h { |name, json| [name, JSON.parse(json)] }]
    end
    cases.each { |name| wall[:rounds][name] << runs.to_h { |r| [r, procs[r].fetch(name)] } }
  end
end

# A change counts only when it is larger than the spread between the two base runs.
def compare(b1, cand, b2)
  base = (b1 + b2) / 2.0
  aa = base.zero? ? 0.0 : (b2 - b1).abs / base
  change = base.zero? ? (cand.zero? ? 0.0 : Float::INFINITY) : cand / base - 1
  { base: base, base1: b1, base2: b2, candidate: cand, change: change, aa: aa, claim: change.abs > aa }
end

def int(x) = x.round.to_s.reverse.scan(/\d{1,3}/).join(",").reverse
# Objects per call can be fractional (a cache that sometimes skips an allocation); the exact value is in results.json.
def num(x) = (x - x.round).abs < 0.05 ? int(x) : format("%.1f", x)
def pct(x) = format("%+.1f%%", x * 100).sub("-", "−")
def rate(x) = x >= 1e6 ? format("%.2fM", x / 1e6) : x >= 1e3 ? format("%.1fk", x / 1e3) : format("%.0f", x)
def dur(s) = s >= 1e-3 ? format("%.3f ms", s * 1e3) : format("%.2f µs", s * 1e6)

# Wall cohort: each process gives the WALL_QUANTILE of its windows' thread CPU time per call. The change is the median
# of every round's two log ratios candidate/base and candidate/base2: a difference of two iid process values is
# symmetric, so this median centres on zero under the null even when process noise is skewed (candidate minus the
# mean of both bases doesn't). The A/A is base2/base. Seeded percentile-bootstrap 95% CIs resample whole rounds.
WALL_QUANTILE = 0.1
def median(xs) = (s = xs.sort; n = s.size; n.odd? ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0)
# rounds: one Array of values per round; each resample draws whole rounds and takes the median of their values.
def bootstrap(rounds)
  rng = Random.new(1)
  medians = Array.new(5000) { median(Array.new(rounds.size) { rounds[rng.rand(rounds.size)] }.flatten) }.sort
  [medians[124], medians[4875]]
end
def wall_cell(rounds, calls)
  est = rounds.map { |r| r.transform_values { |w| Math.log(w["cpu"].sort[((w["cpu"].size - 1) * WALL_QUANTILE).round] / calls) } }
  change = est.map { [_1["candidate"] - _1["base"], _1["candidate"] - _1["base2"]] }
  aa = est.map { [_1["base2"] - _1["base"]] }
  ex = ->(x) { Math.exp(x) - 1 }
  c = { base: Math.exp(median(est.map { (_1["base"] + _1["base2"]) / 2 })), candidate: Math.exp(median(est.map { _1["candidate"] })),
    change: ex.(median(change.flatten)), change_ci: bootstrap(change).map(&ex), aa: ex.(median(aa.flatten)), aa_ci: bootstrap(aa).map(&ex) }
  c[:aa_pass] = c[:aa_ci][0] <= 0 && c[:aa_ci][1] >= 0
  # A bootstrap over fewer than 10 rounds is too coarse to claim anything.
  c.merge(claim: rounds.size >= 10 && c[:aa_pass] && (c[:change_ci][0] > 0 || c[:change_ci][1] < 0))
end
def ci(c) = "[#{pct(c[0])}, #{pct(c[1])}]"
def wall_verdict(c, rounds)
  return verdict(c) if c[:jit] && !c[:jit][:flat]
  flat = c[:jit] ? ", JIT-flat in #{c[:jit][:windows].size} processes" : ""
  if !c[:aa_pass] then "#{flat}: A/A interval excludes 0, no claim"
  elsif c[:claim] then flat
  elsif rounds < 10 then "#{flat}: fewer than 10 rounds, no claim"
  else "#{flat}: interval includes 0, no claim"
  end
end

# JIT-flat (docs/bench.md): a JIT cell counts only when no window compiled or invalidated, whatever its A/A.
def gate(cell, windows)
  return cell if windows.empty?
  moved = windows.flat_map do |w|
    w[:counters].filter_map { |k, (b, a)| "#{w[:window]} #{k} #{b && a ? format("%+d", a - b) : "missing"}" unless b && b == a }
  end
  cell.merge(claim: cell[:claim] && moved.empty?, jit: { flat: moved.empty?, moved: moved, windows: windows })
end
def change(c) = c[:jit] && !c[:jit][:flat] ? "not JIT-flat, no claim" : c[:claim] ? pct(c[:change]) : "within noise"
def verdict(c)
  return ": not JIT-flat (#{c[:jit][:moved].first(3).join(", ")}#{", …" if c[:jit][:moved].size > 3}), no claim" if c[:jit] && !c[:jit][:flat]
  "#{", JIT-flat in #{c[:jit][:windows].size} windows" if c[:jit]}#{": inside the A/A, no claim" unless c[:claim]}"
end

before, after = o[:names]
ruby_label = same_ruby ? "Ruby #{sides["base"][:description][/\Aruby (\S+)/, 1]}" : "base and candidate Ruby"
results = { script: script, at: Time.now.utc.iso8601, n: o[:n], warmup: o[:warmup], preload: o[:preload], heap: HEAP, sides: sides.transform_values { _1.except(:env) },
  objects: {}, instructions: {}, ips: {}, wall: {} }
md = []
notes = []
modes.each do |mode|
  md << "Objects and Callgrind instructions per call, #{ruby_label}, #{MODE_TITLES.fetch(mode)}"
  md << ""
  md << "| | Objects, #{before.downcase} | Objects, #{after.downcase} | Instructions, #{before.downcase} | Instructions, #{after.downcase} | Change |"
  md << "| --- | ---: | ---: | ---: | ---: | ---: |"
  cases.each do |name|
    ob = compare(*runs.map { objects[mode][_1].fetch(name) })
    ir = gate(compare(*runs.map { instructions[mode][name][_1] }), windows.(mode, "#{mode} #{name}"))
    results[:objects][[mode, name].join(" ")] = ob
    results[:instructions][[mode, name].join(" ")] = ir
    notes << "#{mode} #{name}: objects differ between the two base runs (#{num(ob[:base1])}, #{num(ob[:base2])})" unless ob[:aa].zero?
    objs = ob[:aa].zero? ? [num(ob[:base]), num(ob[:candidate])] : ["–", "–"]
    md << "| `#{name}` | #{objs.join(" | ")} | #{int(ir[:base])} | #{int(ir[:candidate])} | #{change(ir)} |"
    notes << "#{mode} #{name}: instructions #{pct(ir[:change])} with A/A #{format("%.2f%%", ir[:aa] * 100)} " \
      "(base #{int(ir[:base1])} / #{int(ir[:base2])}, candidate #{int(ir[:candidate])})#{verdict(ir)}"
  end
  md << ""
end
if ips
  md << "benchmark-ips, #{ruby_label}, #{MODE_TITLES.fetch(o[:ips_mode])}, best of #{o[:ips]} on one core"
  md << ""
  md << "| | #{before} | #{after} | Change |"
  md << "| --- | ---: | ---: | ---: |"
  ips.each do |name, r|
    c = gate(compare(*runs.map { r[_1].max }), windows.(o[:ips_mode], "ips #{name}"))
    results[:ips][name] = c.merge(rounds: r)
    md << "| `#{name}` | #{rate(c[:base])} i/s | #{rate(c[:candidate])} i/s | #{change(c)} |"
    notes << "ips #{name}: #{pct(c[:change])} with A/A #{format("%.2f%%", c[:aa] * 100)} (best base #{rate(c[:base1])} / " \
      "#{rate(c[:base2])}, candidate #{rate(c[:candidate])})#{verdict(c)}"
  end
  md << ""
end
if wall
  md << "Time per call, #{ruby_label}, #{MODE_TITLES.fetch(wall_mode)}, #{o[:wall]} rounds of fresh processes on one core"
  md << ""
  md << "| | #{before} | #{after} | Change |"
  md << "| --- | ---: | ---: | ---: |"
  wall[:rounds].each do |name, rounds|
    c = gate(wall_cell(rounds, wall[:calls].fetch(name)), windows.(wall_mode, "wall #{name}"))
    results[:wall][name] = c.merge(calls: wall[:calls].fetch(name), windows: o[:wall_windows], quantile: WALL_QUANTILE, rounds: rounds)
    md << "| `#{name}` | #{dur(c[:base])} | #{dur(c[:candidate])} | #{change(c)} |"
    notes << "wall #{name}: #{pct(c[:change])} #{ci(c[:change_ci])} with A/A #{pct(c[:aa])} #{ci(c[:aa_ci])} " \
      "(#{wall[:calls].fetch(name)} calls × #{o[:wall_windows]} windows per process)" \
      "#{wall_verdict(c, rounds.size)}"
  end
  md << ""
end
md << "Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in #{out}."
unless jit.empty?
  md << "- JIT-flat: #{jit.values.map { _1.first[:counters].keys.join(", ") }.uniq.join("; ")} unchanged in every measured window " \
    "(each Callgrind N and N = 0 run; each benchmark-ips report from `running` to its last timed interval; every timed wall window)"
end
if wall
  md << "- Wall: thread CPU time with GC off per window, the #{(WALL_QUANTILE * 100).round}th-percentile window per process; change = median " \
    "of every round's candidate / base and candidate / base2, A/A = median of base2 / base, 95% bootstrap intervals resampling rounds"
end
sides.each do |side, s|
  md << "- #{side}: #{s[:description]}#{s[:tree] && ", #{s[:tree]} at #{s[:head][0, 10]}#{" (dirty)" if s[:dirty]}"}"
end
md += notes.map { "- #{_1}" }
File.write(File.join(out, "results.json"), JSON.pretty_generate(results))
File.write(File.join(out, "table.md"), md.join("\n") + "\n")
puts md
