# frozen_string_literal: true
require 'hashie'
require 'json'
require 'logger'
Hashie.logger = Logger.new(nil)
warm = Hashie::Hash[item: Hashie::Array[17, 29]]
10_000.times { warm.to_hash }
sizes = [0, 1, 20, 131_072]
sizes.each do |size|
  array = Hashie::Array.new(size, 17)
  h = Hashie::Hash[item: array]
  UpstreamBench.report("Hashie Array #{size}") { h.to_hash }
end
