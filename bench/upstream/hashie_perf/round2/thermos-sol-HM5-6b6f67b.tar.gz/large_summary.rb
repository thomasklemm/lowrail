# frozen_string_literal: true
require 'json'
root = File.expand_path(__dir__)
driver = File.read(File.join(root, 'evidence/upstream-bench-reviewed.rb'))
estimators = driver[/WALL_QUANTILE = 0\.1\n.*?(?=\ndef ci\()/m]
raise 'harness estimator not found' unless estimators
eval(estimators, TOPLEVEL_BINDING, 'upstream-bench estimators')
out = File.join(root, 'evidence/large-master-zjit-confirm30')
counts = { 0 => 20_000, 1 => 20_000, 20 => 2000, 131_072 => 3 }
results = counts.to_h do |size, calls|
  name = "Hashie Array #{size}"
  flat = true
  rounds = (1..30).map do |r|
    %w[base candidate base2].to_h do |side|
      file_side = side == 'candidate' ? 'head' : side
      lines = File.readlines(File.join(out, "r#{r}-#{file_side}.log"))
      samples = JSON.parse(lines.find { |s| s.start_with?("wall #{name}\t") }.split("\t", 2).last)
      counters = lines.find { |s| s.start_with?("jit #{name}\t") }.scan(/(\w+)=(\d+)>(\d+)/)
      flat &&= counters.size == 4 && counters.all? { |_, before, after| before == after }
      [side, samples]
    end
  end
  cell = wall_cell(rounds, calls)
  cell[:jit_flat] = flat
  cell[:claim] &&= flat
  [name, cell.merge(calls: calls, rounds: rounds)]
end
File.write(File.join(out, 'results.json'), JSON.pretty_generate(results))
puts JSON.pretty_generate(results.transform_values { |v| v.reject { |k, _| k == :rounds } })
