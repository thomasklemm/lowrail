#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
repo=$(git rev-parse --show-toplevel)
for version in "$@"; do
  ruby="$root/rubies/$version/bin/ruby"
  modes=(interp)
  "$ruby" --yjit -e 'exit(defined?(RubyVM::YJIT) && RubyVM::YJIT.enabled? ? 0 : 1)' 2>/dev/null && modes+=(yjit)
  "$ruby" --zjit -e 'exit(defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled? ? 0 : 1)' 2>/dev/null && modes+=(zjit)
  for mode in "${modes[@]}"; do
    flags=()
    [ "$mode" = interp ] || flags+=("--$mode")
    "$ruby" "${flags[@]}" -v
    for side in base head; do
      "$ruby" "${flags[@]}" -I "$root/hashie-$side/lib" "$root/public_diff.rb" > "$root/evidence/$version-$mode-$side.jsonl" 2> "$root/evidence/$version-$mode-$side.stderr"
      "$ruby" "${flags[@]}" -I "$root/hashie-$side/lib" "$root/edge_diff.rb" > "$root/evidence/edge-$version-$mode-$side.txt" 2>&1
      "$ruby" "${flags[@]}" -I "$root/hashie-$side/lib" "$root/repros.rb" > "$root/evidence/repros-$version-$mode-$side.txt" 2>&1
      "$ruby" "${flags[@]}" -I "$root/hashie-$side/lib" "$repo/bench/upstream/hashie_perf/round2/probes/to_hash_diff.rb" > "$root/evidence/original-$version-$mode-$side.txt" 2>&1
    done
  done
done
python3 "$root/compare.py"
