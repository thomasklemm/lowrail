#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
export PATH="$HOME/.cargo/bin:$PATH"
for version in 3.0.7 3.1.7 3.2.10 3.3.10 3.4.7 4.0.10; do
  prefix="$root/rubies/$version"
  if [ ! -x "$prefix/bin/ruby" ]; then
    curl -fLsS "https://cache.ruby-lang.org/pub/ruby/${version%.*}/ruby-$version.tar.xz" -o "$root/builds/ruby-$version.tar.xz"
    tar xJf "$root/builds/ruby-$version.tar.xz" -C "$root/builds"
    (
      cd "$root/builds/ruby-$version"
      ./configure --prefix="$prefix" --disable-install-doc --with-out-ext=openssl --disable-yjit
      make -j2
      make install
    ) > "$root/evidence/ruby-$version-build.log" 2>&1
  fi
  "$prefix/bin/ruby" -v
done
git clone --quiet --depth 1 https://github.com/ruby/ruby.git "$root/builds/ruby-master"
git -C "$root/builds/ruby-master" rev-parse HEAD > "$root/evidence/ruby-master-pin.txt"
(
  cd "$root/builds/ruby-master"
  export PATH="$HOME/.local/share/mise/installs/ruby/4.0.7/bin:$PATH"
  ./autogen.sh
  ./configure --prefix="$root/rubies/master" --disable-install-doc --enable-yjit --enable-zjit --with-out-ext=openssl
  make -j2
  make install
) > "$root/evidence/ruby-master-build.log" 2>&1
"$root/rubies/master/bin/ruby" --zjit -v
