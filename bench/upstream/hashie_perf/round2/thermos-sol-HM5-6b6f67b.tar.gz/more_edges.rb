# frozen_string_literal: true
require 'hashie'
require 'json'

def row(name)
  puts "#{name}: #{yield.inspect.gsub(/0x[0-9a-f]+/, 'ADDR')}"
rescue StandardError => e
  puts "#{name}: #{e.class}: #{e.message.sub(/\n.*/m, '').gsub(/0x[0-9a-f]+/, 'ADDR')}"
end

[:public, :private].each do |visibility|
  [:singleton, :extend, :prepend, :missing].each do |kind|
    [0, 1, -1].each do |arity|
      row([visibility, kind, arity]) do
        events = []
        impl = Module.new
        impl.define_method(:to_hash, arity == 0 ? -> { events << :convert; { a: 17 }.freeze } : arity == 1 ? ->(opts) { events << [:convert, opts]; { b: 29 } } : ->(*args) { events << [:convert, args]; { c: 31 } })
        impl.send(visibility, :to_hash)
        v = Object.new
        case kind
        when :extend then v.extend(impl)
        when :prepend then v.singleton_class.prepend(impl)
        when :singleton then v.define_singleton_method(:to_hash, impl.instance_method(:to_hash)); v.singleton_class.send(visibility, :to_hash)
        when :missing
          v.define_singleton_method(:respond_to_missing?) { |name, _priv = false| name == :to_hash }
          v.define_singleton_method(:method_missing) { |name, *args| name == :to_hash ? (events << args; { missing: 37 }) : super(name, *args) }
        end
        h = Hashie::Hash[item: v]
        [h.to_hash(symbolize_keys: true), events]
      end
    end
  end
end

row('private advertised conversion') do
  v = Object.new
  v.define_singleton_method(:to_hash) { { a: 17 } }
  v.singleton_class.send(:private, :to_hash)
  v.define_singleton_method(:respond_to?) { |name, _priv = false| name == :to_hash || super(name) }
  Hashie::Hash[item: v].to_hash
end

row('array subclass iteration override') do
  v = Class.new(Hashie::Array) do
    def each
      yield 17
      yield Hashie::Hash[nested: 29]
    end
    def map; raise 'map must not run'; end
    def to_a; raise 'to_a must not run'; end
  end[31]
  Hashie::Hash[item: v].to_hash
end

[:hashie, :mash].each do |receiver|
  row([receiver, 'missing entry default']) do
    h = receiver == :hashie ? Hashie::Hash.new : Hashie::Mash.new
    events = []
    h.define_singleton_method(:each_key) { |&b| b.call(:missing) }
    h.default_proc = proc { |_hash, key| events << key; events.size }
    [h.to_hash, events]
  end
end

row('retained lookup identity') do
  h = Hashie::Hash.new
  reads = []
  v = Object.new
  h[:item] = v
  h.define_singleton_method(:[]) { |key| result = super(key).dup; reads << result; result }
  out = h.to_hash
  [out[:item].equal?(reads[0]), out[:item].equal?(reads[-1]), reads.length]
end

row('result metadata') do
  value = Hash.ruby2_keywords_hash(a: 17).freeze
  hash = Hashie::Hash[item: value]
  out = hash.to_hash
  [out.class.name, out.frozen?, out.default, out.default_proc, out.compare_by_identity?, Hash.ruby2_keywords_hash?(out), out[:item].equal?(value), Hash.ruby2_keywords_hash?(out[:item]), out[:item].frozen?]
end
