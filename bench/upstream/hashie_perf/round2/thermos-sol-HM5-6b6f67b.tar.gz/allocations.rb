# frozen_string_literal: true
require 'hashie'
require 'json'
require 'logger'
Hashie.logger = Logger.new(nil)
fixture = JSON.parse(File.read(File.join(__dir__, 'hashie-head/benchmarks/fixtures/repository.json')))
cases = {
  'duel nested Mash' => [Hashie::Mash.new(fixture), :to_hash],
  'duel nested Mash json' => [Hashie::Mash.new(fixture), :to_json],
  'scalar hash' => [Hashie::Hash[a: 17], :to_hash],
  'empty hash' => [Hashie::Hash.new, :to_hash]
}
cases.each do |name, (receiver, method)|
  10_000.times { receiver.public_send(method) }
  GC.start
  GC.disable
  before = GC.stat(:total_allocated_objects)
  10_000.times { receiver.public_send(method) }
  after = GC.stat(:total_allocated_objects)
  GC.enable
  puts [name, after - before, (after - before) / 10_000.0].inspect
end
