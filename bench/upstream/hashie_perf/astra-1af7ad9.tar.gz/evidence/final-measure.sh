#!/usr/bin/env bash
set -euo pipefail
root=/home/user/workspace/repo
dir="$root/.amp/in/orb-backup/hm2-astra"
export PATH="$dir/valgrind/bin:$HOME/.local/share/mise/installs/ruby/4.0.10/bin:$PATH"
export UPSTREAM_BENCH_WARMUP=100
export RUBY_GC_HEAP_0_INIT_SLOTS=200000 RUBY_GC_HEAP_1_INIT_SLOTS=50000
ruby -I "$dir/final/lib" "$root/script/upstream-bench" --worker objects "$dir/evidence/worst.rb" > "$dir/evidence/objects-final.log"
for name in 1-1-Symbol 1-1-String 16-0-Symbol 16-0-String 1048576-2-Symbol 1048576-2-String; do
  for n in 0 100; do
    log="$dir/evidence/ir-$name-final-$n"
    valgrind --tool=callgrind --collect-atstart=no --toggle-collect=rb_ary_cycle --callgrind-out-file="$log.callgrind" --log-file="$log.valgrind" ruby -I "$dir/final/lib" "$root/script/upstream-bench" --worker ir "$dir/evidence/worst.rb" "$name" "$n" > "$log.log" 2>&1
    if grep -Eq 'brk segment overflow|Cannot map memory to grow brk segment' "$log.valgrind"; then
      echo "invalid brk run $log"
      exit 1
    fi
  done
done
ruby -I "$dir/final/lib" "$root/script/upstream-bench" --worker objects "$dir/evidence/split-count.rb" > "$dir/evidence/split-count-final.log"
