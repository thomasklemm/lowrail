HM2 final Astra follow-up, 2026-11-27
Thread T-01a21ea6-c103-7055-b928-054d2f8d8df1
Base 9e313f308f3270995c2c978e92f0f216b861861b
Final head 1af7ad9a203fef81be51abb46869eabf6db5d34e (final directory)
This supplements astra-eae505a.tar.gz, which holds the master controls, tools,
scripts and earlier findings. Same Ruby 4.0.10 a704b7cd95 and pinned Valgrind.

Run final-measure.sh from Lowrail root; its six final instruction counts use
the earlier base/base2 controls. Counts are (totals for N=100 - N=0) / 100.
instructions-final.json includes all four candidates and both base counts.
Run final-strict.rb from base, revised and final with ruby -I CHECKOUT/lib.
Other probes use default-proc.rb, non-symbol.rb, adversarial.rb and
c1_diff-current.rb from the earlier archive. Final outputs use the same
normalization as the earlier outputs. The source c1_diff.rb did not change.

Targeted spec command and metrics commands are in the earlier README.txt.
Final full rake spec failed to load guard. Direct ruby -Ilib -S rspec also
stopped before any examples for missing yard and ruby-gem-release. Kept both.

Final Duel data fetched with:
gh pr view 26 --repo thomasklemm/hashie --json headRefOid,statusCheckRollup,comments
gh run view 46063675164 --repo thomasklemm/hashie --json status,conclusion,jobs
gh run view 46063675164 --repo thomasklemm/hashie --log
GitHub compare API compares final with wrapper 0e7794cfd9a9be82f5f2ad3f3bd1ae13b04e6f6c.
The histories diverge, but final-duel-mash.rb from the wrapper contents API is
byte-identical to final/lib/hashie/mash.rb. Wrapper differences are recorded.
No workflow was triggered by this reviewer.

final-approved-reply.txt is the exact body of the reply's text fence, with
one trailing newline, SHA-256:
42d0e6df51851d656b8691903b4440ed06d2e0a863207da61b26b29607c193c1
