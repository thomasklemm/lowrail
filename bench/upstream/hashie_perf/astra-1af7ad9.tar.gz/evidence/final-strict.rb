require 'hashie'
class Name < String
  attr_reader :conversions
  def to_s
    @conversions = (@conversions || 0) + 1
    "name#{@conversions}"
  end
end
klass = Class.new(Hashie::Mash) { include Hashie::Extensions::Mash::StrictKeyAccess }
name = Name.new('missing')
begin
  klass.new.send(:method_missing, name)
rescue StandardError => e
  p [e.class.name, e.message, name.conversions]
end
