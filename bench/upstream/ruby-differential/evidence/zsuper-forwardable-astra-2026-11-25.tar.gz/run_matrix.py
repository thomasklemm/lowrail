import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
ruby_dir = pathlib.Path(sys.argv[1]).resolve()
out = root / sys.argv[2]
out.mkdir(exist_ok=True)
modes = {
    "interp": [],
    "yjit": ["--yjit"],
    "zjit": ["--zjit"],
    "t1": ["--zjit", "--zjit-call-threshold=1"],
    "t2": ["--zjit", "--zjit-call-threshold=2"],
}
cases = "direct values block frozen sendforward alias method_copy bmethod prepend refinement method_missing leading anonymous rest positional ruby2_keywords keywords two_keywords zero_positional mutation alias_mutation prepend_mutation remove_mutation fiber_mutation polymorphic reject_keywords unknown_keyword".split()
programs = [(root / "probe.rb", [case], case) for case in cases]
programs += [(root / name, [], name) for name in ["zsuper_kw_fwd.rb", "t1_recompile.rb", "ar_insert_model.rb"]]
rows = []
for script, args, label in programs:
    control = None
    for mode, flags in modes.items():
        command = [str(ruby_dir / "ruby"), "--disable-gems", *flags, str(script), *args]
        result = subprocess.run(command, cwd=ruby_dir, text=True, capture_output=True, timeout=60)
        (out / f"{label}-{mode}.log").write_text(" ".join(command) + "\n" + result.stdout + result.stderr + f"\nexit={result.returncode}\n")
        observation = (result.returncode, result.stdout, result.stderr)
        if mode == "interp":
            control = observation
        verdict = "PASS" if result.returncode == 0 and observation == control else "FAIL"
        row = f"{label}\t{mode}\t{verdict}\texit={result.returncode}"
        print(row, flush=True)
        rows.append(row)
(out / "summary.tsv").write_text("\n".join(rows) + "\n")
