class Base
  def m(*args, **kw, &block)
    [args, kw, block && block.call(:yielded)]
  end
  alias other m
end
class Middle < Base
  def m(...) = super
end
class Top < Middle
  def m(a, k: nil)
    a + 1
    super
  end
end

shape = ARGV.fetch(0)
case shape
when "direct", "values", "block", "frozen"
when "sendforward"
  Middle.class_eval("def m(...) = other(...)")
when "alias"
  Middle.class_eval("def other(...) = super; alias m other")
when "method_copy"
  source = Module.new { def m(...) = super }
  Middle.define_method(:m, source.instance_method(:m))
when "bmethod"
  Middle.define_method(:m) { |*args, **kw, &block| super(*args, **kw, &block) }
when "prepend"
  Middle.class_eval("def m(a, k: nil) = super")
  Middle.prepend(Module.new { def m(...) = super })
when "refinement"
  module Refined
    refine Middle do
      def m(...) = super
    end
  end
  using Refined
  Top.class_eval("def m(a, k: nil); a + 1; super; end")
when "method_missing"
  Middle.class_eval("remove_method :m")
  Base.class_eval("undef_method :m; def method_missing(name, ...) = other(...)")
when "leading"
  Middle.class_eval("def m(x, ...) = super")
when "anonymous"
  Middle.class_eval("def m(*, **, &) = super")
when "rest"
  Middle.class_eval("def m(*args, **kw, &block) = super")
when "positional"
  Middle.class_eval("def m(a, opts) = [[a], opts, nil]")
when "ruby2_keywords"
  Middle.class_eval("ruby2_keywords def m(*args, &block); super; end")
when "keywords"
  Middle.class_eval("def m(a, k: 31, z: 47) = [[a], {k: k}, nil]")
when "two_keywords"
  Top.class_eval("def m(a, k: nil, z: 47); a + 1; super; end")
when "zero_positional"
  Top.class_eval("def m(k: nil) = super")
when "mutation", "alias_mutation", "prepend_mutation", "remove_mutation", "fiber_mutation"
  Middle.class_eval("def m(a, k: nil) = super")
  Top.class_eval("def m(a, k: nil); a + 1; $hook&.call; super; end")
when "polymorphic"
  module Shared
    def m(a, k: nil)
      a + 1
      super
    end
  end
  Top.include(Shared)
  Top.class_eval("remove_method :m")
  class Plain < Base
    def m(a, k: nil) = super
  end
  class OtherTop < Plain
    include Shared
  end
when "reject_keywords"
  Middle.class_eval("def m(a, **nil); end")
when "unknown_keyword"
  Middle.class_eval("def m(a, z: nil); end")
else
  raise shape
end

o = Top.new
o.freeze if shape == "frozen"
results = []
check = ->(a, k, block = nil) do
  receiver = shape == "polymorphic" && a.even? ? OtherTop.new : o
  expected_kw = shape == "two_keywords" ? {k: k, z: 47} : {k: k}
  expected = [shape == "zero_positional" ? [] : [a], expected_kw, block && :yielded]
  if %w[reject_keywords unknown_keyword].include?(shape)
    begin
      receiver.m(a, k: k)
      raise "expected ArgumentError"
    rescue ArgumentError => e
      results << [e.class.name, e.message]
    end
  else
    got = shape == "zero_positional" ? receiver.m(k: k) : receiver.m(a, k: k, &block)
    raise "#{shape}: #{got.inspect} != #{expected.inspect}" unless got == expected
    results << got
  end
end
100.times { check.call(3, 19) }
check.call(3.5, 19) unless shape == "polymorphic"

if shape.end_with?("mutation")
  change = -> do
    case shape
    when "alias_mutation"
      Middle.class_eval("def other(...) = super; alias m other")
    when "prepend_mutation"
      Middle.prepend(Module.new { def m(...) = super })
    when "remove_mutation"
      Middle.class_eval("remove_method :m")
    else
      Middle.class_eval("def m(...) = super")
    end
    $hook = nil
  end
  if shape == "fiber_mutation"
    $hook = -> { Fiber.yield }
    fiber = Fiber.new { check.call(7, 23) }
    fiber.resume
    change.call
    fiber.resume
  else
    $hook = change
    check.call(7, 23)
  end
end

200.times do |i|
  k = shape == "values" ? [nil, false, 19, [29].freeze, {inner: 31}.freeze][i % 5] : 23
  check.call(i, k, shape == "block" ? ->(x) { x } : nil)
end
puts "#{shape}: #{results.uniq.inspect}"
