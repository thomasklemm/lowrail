module DatabaseStatements
  def insert(arel, name = nil, pk = nil, id_value = nil, sequence_name = nil, binds = [], returning: nil)
    [arel, name, pk, id_value, sequence_name, binds, returning]
  end
end
module QueryCache
  def insert(...)
    @dirty = true
    super
  end
end
module PostgreSQLStatements
  def insert(arel, name = nil, pk = nil, id_value = nil, sequence_name = nil, binds = [], returning: nil)
    returning ||= pk ? [pk] : nil
    super
  end
end
class Abstract; include DatabaseStatements; include QueryCache; end
class PG < Abstract; include PostgreSQLStatements; end
class Other < Abstract; end
c = PG.new
2000.times do |i|
  got = c.insert(i.even? ? "sql" : :arel, "Load", "id", nil, nil, [i])
  raise "iteration #{i}: #{got.inspect}" unless got == [i.even? ? "sql" : :arel, "Load", "id", nil, nil, [i], ["id"]]
  Other.new.insert("x") if i % 7 == 0
end
puts "ok"
