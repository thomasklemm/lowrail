class Base
  def m(*args, **kw) = [args, kw]
end
class Middle < Base
  def m(...) = super
end
class Top < Middle
  def m(a, k: nil)
    a + 1
    super
  end
end
o = Top.new
o.m(1, k: 2)
o.m(1.5, k: 2)
200.times do |i|
  got = o.m(1, k: 2)
  raise "iteration #{i}: #{got.inspect}" unless got == [[1], {k: 2}]
end
puts "ok"
