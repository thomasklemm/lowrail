# Zsuper forwarding review evidence

Review thread: https://ampcode.com/threads/T-01a214a7-4022-7060-91cf-eacfc0be2f69

Source: thomasklemm/ruby 2dc14101c3c62b4555e6efaa471ad5e63e5a6ac5; parent f2c3f457ff.
headline3: k0kubun/ruby e0fc4df7caa482a4b58c87123af8a3f643d8a109 plus the same patch.
The reviewed fixed headline3 tree is in h3-fixed-tree.txt. h3-fix.diff is the complete patch.
Base suite controls retain only the added tests. All probes run with --disable-gems.

Toolchain: Linux x86-64, GCC 14.2.0, Rust 1.100.0 (0ef1bc386), Ruby 4.0.9 baseruby,
cargo-nextest 0.9.152. Commands ran with baseruby and cargo on PATH, CARGO_BUILD_JOBS=2.

Build from the source root:

```sh
./autogen.sh
./configure --enable-zjit=dev --enable-yjit --disable-install-doc
make -j2
make zjit-test CARGO=cargo ZJIT_TEST_FEATURES=disasm ZJIT_TESTS='-j 2'
make test-all TESTS=test/ruby/test_zjit_cli.rb
make test-all TESTS='test/ruby/test_keyword.rb test/ruby/test_super.rb' RUN_OPTS='--disable-gems --zjit --zjit-call-threshold=2'
make test-all TESTS='test/ruby/test_keyword.rb test/ruby/test_super.rb' RUN_OPTS='--disable-gems --zjit --zjit-call-threshold=1'
```

Run `python3 run_matrix.py /absolute/path/to/ruby-source label` from the extracted evidence directory.
It writes label/summary.tsv and a log with the command, stdout, stderr and exit code for each case/mode.
The three standalone repros are zsuper_kw_fwd.rb, t1_recompile.rb and ar_insert_model.rb.
The latter two reproduce the author's scripts (comments omitted); probe.rb is independent review coverage.

Four source states were tested sequentially in one checkout with incremental rebuilds:

1. h2-fixed: exact 2dc14101c3.
2. h2-base: 2dc14101c3 with hir.rs restored from f2c3f457ff (h2-no-fix.diff).
3. h3-base: e0fc4df7ca with codegen_tests.rs copied from 2dc14101c3 (h3-base-added-tests.diff).
4. h3-fixed: clean e0fc4df7ca followed by `git cherry-pick --no-commit 2dc14101c3`.

The two wrong-*.diff files apply to the respective fixed states: wrong-caller-guard on h2, and
wrong-disable-all-conversions on h3. Targeted runs used these filters, respectively:

```sh
make zjit-test CARGO=cargo ZJIT_TEST_FEATURES=disasm ZJIT_TESTS="-j 2 -E 'test(test_zsuper_with_keyword_params_to_forwardable)'"
make zjit-test CARGO=cargo ZJIT_TEST_FEATURES=disasm ZJIT_TESTS="-j 2 -E 'test(test_zsuper_with_keyword_params)'"
```

Both mutants were removed. h3-restored-super-tests.log is the final exact-patch run with `-E 'test(/super/)'`.
The full-suite sampling failure is retained on all four states, with no retry-until-green.
The 15 default-skipped tests were not enabled. No real Rails app suite or performance benchmark was run.

HIR and stats logs use `--zjit --zjit-call-threshold=2 --zjit-dump-hir`, or threshold 1 and `--zjit-stats`
for t1_recompile.rb. h3-fixed-mutation-stats.log uses threshold 2 and `probe.rb mutation`.
Absolute paths and runtime addresses in the logs identify this review's disposable checkout, not required install paths.
