#!/usr/bin/env bash
set -euo pipefail
root=/home/user/workspace/repo
out=$root/.amp/in/orb-backup/bt1-body-line
for version in base head release; do
  case $version in
    base) ruby=$root/.amp/in/orb-backup/ruby-base/build/ruby ;;
    head) ruby=$root/.amp/in/orb-backup/ruby/build-head/ruby ;;
    release) ruby=/home/user/.local/share/mise/installs/ruby/4.0.9/bin/ruby ;;
  esac
  "$ruby" --disable-gems "$root/bench/upstream/ruby-differential/evidence/backtrace-format/body-example.rb" > "$out/$version-example.stdout" 2> "$out/$version-example.stderr" || test "$version" = base
  "$ruby" --version > "$out/$version-version.txt"
  for kind in caller bt; do
    for round in 1 2; do
      for n in 100 300; do
        stem=$out/$kind-$version-$round-$n
        env K=$kind N=$n RUBY_GC_HEAP_INIT_SLOTS=1000000 \
          valgrind --tool=callgrind --callgrind-out-file="$stem.callgrind" \
          "$ruby" --disable-gems .amp/in/orb-backup/bt.rb \
          > "$stem.stdout" 2> "$stem.stderr"
        echo "$kind $version $round $n $(grep '^summary:' "$stem.callgrind")"
      done
    done
  done
done
