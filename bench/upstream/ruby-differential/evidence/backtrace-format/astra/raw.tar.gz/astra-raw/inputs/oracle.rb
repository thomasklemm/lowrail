require 'json'
require ENV.fetch('PROBE')

def snapshot(value)
  case value
  when String
    cr = Probe.coderange(value)
    valid = value.valid_encoding?
    ascii = value.ascii_only?
    {hex: value.unpack1('H*'), encoding: value.encoding.name, cr: cr,
     valid: valid, ascii: ascii, scanned_cr: Probe.coderange(value)}
  when Array then value.map { snapshot(_1) }
  else value
  end
end

def capture(id)
  result = yield
  puts JSON.generate([id, snapshot(result)])
rescue Exception => e
  puts JSON.generate([id, {error: e.class.name, message: snapshot(e.message)}])
end

encs = %w[UTF-8 ASCII-8BIT US-ASCII Shift_JIS EUC-JP ISO-8859-1 Windows-1252 UTF-16LE UTF-16BE UTF-32LE UTF-32BE ISO-2022-JP]
raws = ['plain', '', "a\0b.rb", "\xc3\xa9", "\x82\xa0", "\xff\xfe", "\xe9", "\xc3", "a%sb%d", 'x' * 300]
files = encs.product(raws).map { |enc, raw| raw.b.force_encoding(enc) }
encs.each { |enc| files << 'é.rb'.encode(enc) rescue nil }
names = encs.product(['foo', "\xc3\xa9", "\x82\xa0", "\xe9", "\xc3"])
names = names.select { |enc, raw| Encoding.find(enc).ascii_compatible? && raw.b.force_encoding(enc).valid_encoding? }
body = %q{; [caller(0,3), caller_locations(0,3).map { |l| [l.path, l.label, l.to_s, l.inspect] }, (begin; raise 'boom'; rescue => e; [e.backtrace, e.full_message(highlight: false)]; end)]; end}
files.each_with_index do |file, fi|
  next if ENV['STRESS'] && ![0,3,5,9,70,73,80,83].include?(fi)
  names.each_with_index do |(enc, raw), ni|
    next if ENV['STRESS'] && ![0,1,8].include?(ni)
    capture([fi, ni, file.unpack1('H*'), file.encoding.name, raw.b.unpack1('H*'), enc]) do
      k = Class.new
      source = ('def '.b + raw.b + body.b).force_encoding(enc)
      k.class_eval(source, file, 7)
      obj = k.new
      GC.stress = true if ENV['STRESS']
      begin
        obj.send(raw.b.force_encoding(enc))
      ensure
        GC.stress = false if ENV['STRESS']
      end
    end
  end
  capture([fi, 'cfunc']) do
    eval('[1].map { caller_locations(0, 3).map { |l| [l.path, l.label, l.to_s] } }', binding, file, 31)
  end
  capture([fi, 'eval']) do
    eval('eval("caller(0, 3)")', binding, file, 45)
  end
end

class PathString < String
  def to_s = raise('to_s called')
  def to_str = raise('to_str called')
end
['normal.rb', 'é.rb', "a\0b.rb"].each_with_index do |path, i|
  capture(['subclass', i]) { eval('caller(0,1)', binding, PathString.new(path).freeze) }
  path = path.dup
  def path.to_s = raise('singleton to_s called')
  capture(['singleton', i]) { eval('caller(0,1)', binding, path.freeze) }
end
capture(['conversion']) do
  calls = []
  path = Object.new
  path.define_singleton_method(:to_str) { calls << :to_str; Fiber.yield if false; 'duck.rb' }
  [eval('caller(0,1)', binding, path), calls]
end
