#include "ruby.h"
#include "ruby/encoding.h"
static VALUE cr(VALUE self, VALUE s) { return INT2NUM(ENC_CODERANGE(s)); }
void Init_probe(void) { rb_define_singleton_method(rb_define_module("Probe"), "coderange", cr, 1); }
