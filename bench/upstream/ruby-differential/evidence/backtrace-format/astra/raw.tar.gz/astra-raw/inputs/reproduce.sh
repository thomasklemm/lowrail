#!/usr/bin/env bash
set -euo pipefail
root=/home/user/workspace/repo
scratch=$root/.amp/in/orb-backup
export PATH=/home/user/.local/share/mise/installs/ruby/4.0.9/bin:$PATH
# Run in each built tree's build directory, with oracle.rb and probe.c two levels above it.
gcc -shared -fPIC -I../include -I.ext/include/x86_64-linux ../../probe.c -o probe.so
PROBE=$PWD/probe.so ./ruby --disable-gems -I../lib -I.ext/common -I.ext/x86_64-linux ../../oracle.rb
PROBE=$PWD/probe.so STRESS=1 ./ruby --disable-gems -I../lib -I.ext/common -I.ext/x86_64-linux ../../oracle.rb
make test-all TESTS='ruby/test_backtrace.rb ruby/test_exception.rb'
make btest
# Head's added test on either build; base must fail with ArgumentError, head must pass.
make test-all TESTS="$scratch/ruby/test/ruby/test_backtrace.rb --name=/test_backtrace_with_nul_in_path/"

# From head's build directory.
taskset -c 0 make benchmark ITEM=vm_backtrace_to_s \
  COMPARE_RUBY="$scratch/ruby-base/build/ruby" OPTS='--repeat-count 10'

# From the Lowrail root. Kept as separate commands because the directories above differ.
taskset -c 0 ruby -I"$scratch/ruby/benchmark/lib" "$scratch/ruby/benchmark/benchmark-driver/exe/benchmark-driver" \
  --executables='release::/home/user/.local/share/mise/installs/ruby/4.0.9/bin/ruby --disable-gems' \
  --executables="base::$scratch/ruby-base/build/ruby --disable-gems" \
  --executables="base-again::$scratch/ruby-base/build/ruby --disable-gems" \
  --executables="head::$scratch/ruby/build-head/ruby --disable-gems" \
  --repeat-count 10 --output=markdown --output-compare -v \
  "$scratch/ruby/benchmark/vm_backtrace_to_s.yml" "$scratch/size.yml"
bash "$scratch/measure.sh"
python3 "$scratch/compare.py" /tmp/bt1-oracle-base.jsonl /tmp/bt1-oracle-head.jsonl
