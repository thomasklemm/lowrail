#!/usr/bin/env bash
set -euo pipefail
root=/home/user/workspace/repo
out=$root/.amp/in/orb-backup/measurements
mkdir -p "$out"
for kind in caller bt raise; do
  for round in 1 2; do
    for version in base head release; do
      case $version in
        base) ruby=$root/.amp/in/orb-backup/ruby-base/build/miniruby ;;
        head) ruby=$root/.amp/in/orb-backup/ruby/build-head/miniruby ;;
        release) ruby=/home/user/.local/share/mise/installs/ruby/4.0.9/bin/ruby ;;
      esac
      for n in 100 300; do
        stem=$out/$kind-$version-$round-$n
        env K=$kind N=$n RUBY_GC_HEAP_INIT_SLOTS=1000000 \
          valgrind --tool=callgrind --callgrind-out-file="$stem.callgrind" \
          "$ruby" --disable-gems "$root/bench/upstream/ruby-differential/evidence/backtrace-format/bt.rb" \
          > "$stem.stdout" 2> "$stem.stderr"
        echo "$kind $version $round $n $(grep '^summary:' "$stem.callgrind")"
      done
    done
  done
done
