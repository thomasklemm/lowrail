import collections
import json
import sys

def public(value):
    if isinstance(value, dict):
        return {k: public(v) for k, v in value.items() if k != 'cr'}
    if isinstance(value, list):
        return [public(v) for v in value]
    return value

base = [json.loads(line) for line in open(sys.argv[1])]
head = [json.loads(line) for line in open(sys.argv[2])]
assert len(base) == len(head)
stats = collections.Counter()
samples = collections.defaultdict(list)
for a, b in zip(base, head):
    assert a[0] == b[0]
    if a == b:
        kind = 'identical'
    elif public(a) == public(b):
        kind = 'cached_coderange_only'
    elif isinstance(a[1], dict) and a[1].get('error') == 'ArgumentError' and bytes.fromhex(a[1]['message']['hex']) == b'string contains null byte':
        kind = 'nul_error_removed'
    else:
        kind = 'other_public_difference'
    stats[kind] += 1
    if len(samples[kind]) < 2:
        samples[kind].append([a, b])
print(json.dumps(dict(stats), indent=2))
for kind in ['other_public_difference', 'cached_coderange_only']:
    for sample in samples[kind]:
        print(kind, json.dumps(sample))
