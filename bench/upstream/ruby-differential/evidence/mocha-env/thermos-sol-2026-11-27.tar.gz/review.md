# MO1 thermos-sol review

Verdict: **approve** on final head `a3134958dc38c52d9c498a09d9bcd269184ee1dd`. No open must-fixes. The explicit create/read branches, single why-comment and release-version link labels close all three findings. No introduced correctness/security defect was found in the source audit or executed probes. Both fresh Ruby builds and the requested suites passed again on the final tree; only the three new acceptance tests fail on master without the fix.

Reviewer: `thermos-sol`. Date: 2026-11-27. Review thread: https://ampcode.com/threads/T-01a21cf2-b2b4-7269-8728-97b2f75358db.

## Scope and identity

Read Lowrail's AGENTS.md, docs/DECISIONS.md and docs/upstream/ruby41-differential-409.md. Applied the supplied patch with `git am` to freerange/mocha main `99da677165a5ef21cc5ad21da733e82fc6aa2636`. The applied commit is `78b0c0a1c0019de13c145659b755f4f66ebe21b2`; git am creates new committer metadata. The original patch and applied commit have identical stable patch ID `3ba707b61c9ba0ec0201883e3809b1454208bc7c`. `git diff --check` passed.

During review, Lowrail main `0db89ae4` replaced original head `3d3f63b4c136e807c6f532f97fc90794080ba364` with `2db1c867821c6ea4af94348c772afacd62c6e519`. Applied the regenerated patch independently with git am and verified both applied trees are exactly `b415c4733d630d458bf9be4ccfe889851ff63ac1`, with the same stable patch ID. The full code review and runtime matrix therefore carry to that second head. Rechecked its revised body sentence by sentence and its trailer-free message. `static/replacement-head.txt` keeps these checks.

Reran the three new acceptance tests, the 23-case probe and the four framework/identity outcomes on the freshly applied replacement patch with pinned master; all pass. The normalized probe records match the fully validated earlier tree. Raw rerun logs are in `results-current` inside the archive.

The correctness/security and maintainability audits ran independently and in parallel as read-only subagents within this thread. No other threads were created. The parent performed the builds, runtime probes, citation checks and synthesis. No upstream branch, PR, comment or issue was created or changed.

## Final-head confirmation

Lowrail main `1ec29f9f` supplies head `a3134958dc38c52d9c498a09d9bcd269184ee1dd`. Applied its patch independently with `git am` to the original base. The final tree is `2f051289ea90da14cc4cb7dab06aea82f8dc3230`. Against the audited second tree, only the create/read branch shape and the predicate comment change; the acceptance tests and commit message are unchanged. The helper is a private/nodoc capability predicate without user conversions; its repeated call in the explicit branches introduces no supported-contract difference. Rechecked every added comment, the message and the body.

`bash final-checks.sh` reruns the complete unit/acceptance, isolated and both integration suites on both freshly built Ruby pins, plus the repro, lifecycle/identity probes and actual RuboCop lint task. All pass. `python3 validate-final.py` verifies all 29 command statuses and exact probe records against the earlier independently validated outcomes. The no-Ractor Ruby 2.7.8 probe and three acceptance tests also pass on this final tree. Raw logs are in `results-final`; `static/final-head.txt` records source identity.

The scratch Ractor probe race is resolved: it now waits for `Ractor#value` before taking the initial inspect snapshot, because inspect itself includes changing running/terminated state. All four original base/head probe logs, the second-head probe and the final-head probes were rerun with this stabilized harness. The original anomalous log remains in `results-current/probe-initial.log`, explained in `static/probe-race-note.txt`. No candidate source was changed to resolve the harness race.

## Findings closed

1. **Explicit create/read branches:** `mocha` now uses distinct `if mocha_shareable? && instantiate` and `elsif mocha_shareable?` branches. No assignment remains inside a conditional modifier; read-only lookup still does not instantiate. This closes the shape-checklist finding without a new abstraction.
2. **One necessary why-comment:** the predicate keeps only “Classes and modules can still have instance variables when shareable.” The Ruby-version narrative remains in the commit message. The frozen-string magic comment and YARD `@private` annotations fit Mocha's conventions and can stay.
3. **Released versions in caller link labels:** the body now names [Capistrano 3.20.1](https://github.com/capistrano/capistrano/blob/f40817b449c113a4fce039a318b92e63e1d10c85/spec/lib/capistrano/configuration/servers_spec.rb#L275-L276) and [Sure v0.7.6-hotfix.2](https://github.com/we-promise/sure/blob/c241a66da7634118b485a9ee561f7c94bbe4efc3/test/models/provider/jev_test.rb#L359-L360). The targets, quoted calls and reach-based order are correct. No additional project citation is needed.

Also resolved on the revised head/body: the Amp-Thread-ID trailer is gone; the universal “same as before on every Ruby” claim is cut; and `risky: true` is recorded. No must-fixes remain. This pass does not replace the required final-head Astra pass.

## PR body checked sentence by sentence

| Text | Check and conclusion |
| --- | --- |
| Title: “Keep mocks of shareable objects such as ENV out of instance variables” | Matches the new identity-Hash path; the body explains the Module exception. |
| “On Ruby master (4.1), stubbing a method on ENV raises:” and its code example | Ran the kept standalone repro and new acceptance tests on pinned master before/after. Confirmed `Ractor::IsolationError: can't modify instance variables of a shareable Object` without the fix and success with it. |
| “Ruby 4.1 no longer allows instance variables on objects that are Ractor-shareable but not frozen (Bug #22291), and ENV is one.” | Opened Bug #22291 and read ruby/ruby `73055acd572a458d0a2e90edeedc3027c86cc917`, including the ivar guard and ENV tests. It forbids writes, with classes/modules excluded. “Allows instance variables” is understandable shorthand for storing them; “allows setting instance variables” would be more precise. |
| “Mocha keeps a stubbed object's mock in @mocha, so every ENV.stubs and ENV.expects fails.” | Confirmed in Mocha v3.1.0 and main source. It describes nonempty real stubs/expectations; empty Hash arguments create no expectations and are not affected. Removing “every” avoids an unnecessary absolute. |
| “Tests in Capistrano 3.20.1 and Sure v0.7.6-hotfix.2 do this.” | Both exact release-pinned files contain the stated ENV calls at the cited lines; Sure requires Mocha and Capistrano configures it as RSpec's mock framework. Both projects remain active and relevant, ordered by reach. The final labels now name the correct release versions. |
| “For such objects the mock now lives in a Hash keyed by identity, set and cleared where @mocha was.” | Confirmed the `compare_by_identity` registry, lazy construction and final-entry deletion via `StubbedMethod#unstub`. Executed probes with forbidden receiver `hash` and `eql?` calls; neither was invoked. |
| “Classes and modules are shareable but still take instance variables, so they keep @mocha, as does every other object.” | Confirmed `Module === self` exclusion and direct commands setting ivars on shareable unfrozen classes/modules. Ordinary receivers retain the old branch; frozen receivers remain rejected at the public API boundary. |
| Previously: “Stubbing behaves the same as before on every Ruby.” | Confirmed removed from the revised body. No replacement overclaim is present. |

## Commit message checked sentence by sentence

| Text | Check and conclusion |
| --- | --- |
| Title, identical to the proposed PR title | Accurate and focused on the behavior. |
| “Ruby 4.1 forbids instance variables on objects that are Ractor-shareable but not frozen [Bug #22291], so stubbing a method on ENV raised Ractor::IsolationError when Mocha stored the object's mock in @mocha.” | The Ruby change and Mocha store are directly verified. The statement accurately describes the regression; “forbids setting instance variables” is slightly more precise. |
| “The mock of such an object now lives in a Hash keyed by identity, with the same lifetime @mocha had.” | For the supported public stubbing lifecycle, registration and cleanup follow the same receiver boundary. This is not a promise that private `mocha` calls without registered stub methods are independently swept at teardown. No such public escape path was found. |
| “Classes and modules are shareable too, but still allow instance variables, so they keep using @mocha.” | Accurate, verified against Ruby's type exceptions and the Module guard. |
| Previously: `Amp-Thread-ID: ...` | Confirmed removed from the regenerated patch and applied commit. The message is otherwise unchanged and contains no trailers. |

## Currency and caller relevance

Read GitHub repository metadata, latest-release metadata and Rubygems' API on 2026-11-27. The projects are not archived or disabled. Sure has 18,160 stars and was pushed on 2026-11-27; its current main is `12cd4e1a57f029d4ff59cce5dda7950d08221940`, and its latest release is v0.7.6-hotfix.2 from 2026-11-21 at the now-cited `c241a66da7634118b485a9ee561f7c94bbe4efc3`. Capistrano has 13,011 stars, was pushed on 2026-11-02, and has 91,641,504 gem downloads; latest v3.20.1 was released on 2026-05-16 at the now-cited `f40817b449c113a4fce039a318b92e63e1d10c85`. Neither default branch has removed the relevant calls. The revised body cites only these two callers.

Mocha has 1,280 stars, 101,626,702 gem downloads, latest v3.1.0 from 2026-03-14 and last push 2026-09-22; its current main is the reviewed base. Ruby has 23,870 stars and was pushed on 2026-11-27. Download totals are relevance checks, not performance measurements. Capistrano's large released-gem reach makes it a strong leading citation; cross-project star counts alone are not a usage ranking.

## Why no broader cache rewrite is required

Mockery still creates, registers, verifies and expires each mock. Public stubbing registers replacement methods with Central before allocating the mock. `StubbedMethod#unstub` removes a method's expectations and clears the receiver cache only after the last expectation is removed. The identity Hash is accessed only in ObjectMethods lookup/reset, so it does not scatter ownership policy across unrelated files.

A per-Mockery cache would change the existing receiver-scoped behavior across nested setup calls. Moving all receivers there would broaden this compatibility fix; moving only shareable receivers would introduce different lifetime semantics. Adding a Mockery accessor while retaining both backends adds plumbing without removing the predicate.

A simple rescue around `@mocha ||= mock_impersonating(self)` creates/registers the mock before assignment fails. Correct fallback must retain that result, avoid duplicate registration, handle subsequent read-only lookups, and clear the fallback during unstubbing. It also needs safe handling on pre-Ractor Ruby. That is not clearly simpler than a direct capability predicate.

## Readability and complexity

Cold read: shareable non-Module receivers use external identity storage; classes/modules and other receivers retain ivars; read-only lookup never instantiates; reset deletes only that receiver's external entry. The no-Ractor guard preserves older interpreters. The final explicit branches make these decisions understandable without additional helper layers.

On the initial tree, `object_methods.rb` grows from 183 to 200 lines. Flog 4.10.0 reports `mocha` 3.7 → 9.6, `reset_mocha` 1.1 → 2.8 and the new predicate 4.5. The extra storage backend explains the modest absolute increase. Repository RuboCop Metrics checks report no offenses on base or that head. Full `rake lint` with the real lint Gemfile inspects 235 files with no offenses, including a fresh final-head rerun; this is not the no-RuboCop “skipping linting” task result. Ruby 2.2 parser targeting accepts the changed files.

The three new tests use Mocha's existing acceptance helpers and assert observable stubbing, verification and restoration. A kept test for two-method partial cleanup or reuse after failed verification would strengthen the contract, but absence of those additional tests is not itself a blocker after executing the probes.

## Runtime verification

Built both requested Rubies from source with `script/ruby-differential build`: tag v4.0.9 (`3e93b23afcec3433f6aecc34b5d832799d754238`) and master `f3e180b5ebc835f87c2ff7ccb8474a1bf18b0115`, both with YJIT/ZJIT enabled. The runtime checks used the interpreter; no JIT-mode support or speed claim is made. The build configuration and commands are in `static/build-pins.txt` and `static/build-*-command.log` inside the evidence archive.

| Check | Fresh Ruby 4.0.9 | Fresh pinned master |
| --- | --- | --- |
| Three new acceptance tests on base | pass | exactly three failures |
| Three new acceptance tests on patch | pass | pass |
| `bundle exec rake test`, base plus the new tests | 457 unit / 448 acceptance tests pass | units pass; only the three new acceptance tests fail |
| `bundle exec rake test`, patch | 457 unit / 448 acceptance tests pass | 457 unit / 448 acceptance tests pass |
| `bundle exec rake test:isolated`, patch | all 128 files pass | all 128 files pass |
| Minitest integration task | 12 tests pass | 12 tests pass |
| Test::Unit integration task | 13 tests pass | 13 tests pass |
| Standalone repro on base / patch | pass / pass | IsolationError / pass |
| Base/head differential probe | 23 cases checked | 23 cases checked |
| Framework error cleanup, invoked never, zero retained entries, two Ractor identities | pass | pass |

`python3 validate.py built409 master` checks all 18 command statuses per Ruby, the 23 base/head probe outcomes, and four framework/identity outcomes against independent expectations. It reports both matrices match. The only probe result changes on master are the intended repairs for ENV and Ractor receivers; the same-receiver nested failure remains an existing limitation. On 4.0.9 all observable probe results match base, apart from the diagnostic presence of an empty new registry.

Also built Ruby 2.7.8 with mise to execute a real no-Ractor interpreter. Its 19 applicable base/head probe results match apart from the empty-registry diagnostic, and the three new acceptance tests pass with Minitest 5.15.0. An initial attempt to install Minitest 5.27.0 was rejected because it requires Ruby >=3.1; that setup failure and the compatible replacement are retained in the evidence. Ruby 2.2 was checked by source/API compatibility and RuboCop's parser target, not executed. Alternate Ruby engines were not run.

Evidence is kept in `bench/upstream/ruby-differential/evidence/mocha-env/thermos-sol-2026-11-27.tar.gz`: the report, runner, differential and framework probes, independent expectation validator, static checks and raw test logs. No allocation, instruction or speed claim is made.

## Exactness boundaries

The differential harness covers ordinary objects, String/Array/Hash subclasses, method_missing/respond_to_missing?, private/prepended methods, class/any_instance paths, frozen controls, ENV lookup/expectations/never/unstub, partial unstubbing, consecutive scopes, nested Mockery setup, a thread invoking an active ENV stub, Ractor instances and identity overrides. The framework probe runs an intentionally erroring Minitest test followed by a fresh test and checks restoration, plus invoked `.never` and independent Ractor receivers.

`Ractor.make_shareable` freezes the tested ordinary Object, Array, Hash and String values; classes/modules remain shareable and unfrozen and retain working ivars. `Ractor::Port.new` and `Ractor.shareable_proc` results are already frozen on both pins and remain rejected with Mocha::StubbingError. ENV and Ractor instances are the tested shareable-unfrozen receivers. Neither tested Ruby exposed another unfrozen ordinary object through make_shareable.

No new implicit conversion, caller result accumulation or adoption of an accumulator is added, so those checklist entries are not applicable. The new user-receiver call is the nodoc predicate; its internal capability test does not invoke receiver `hash`, `eql?`, `class`, `is_a?` or conversion overrides. Existing global core-method and private/nodoc override exclusions apply.

Mocha explicitly disclaims thread safety. A thread invoking a stub is tested, but concurrent independent tests and non-main-Ractor Mocha support are not claimed. Nested same-receiver/same-method failure must be compared with base before attribution. Skipping required teardown is not supported and already retains Mockery state on base; normal exception paths must still clean up through the framework adapter.
