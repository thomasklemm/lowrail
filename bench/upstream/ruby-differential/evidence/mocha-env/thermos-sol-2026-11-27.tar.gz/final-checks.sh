#!/usr/bin/env bash
set -uo pipefail
work=/home/user/workspace/repo/.amp/in/orb-backup/mo1-review
root=/home/user/workspace/repo
out="$work/results-final"
mkdir -p "$out"
: > "$out/status.tsv"

run() {
  local label="$1" bin="$2" name="$3"
  shift 3
  (cd "$work/mocha-final" && env -i HOME="$HOME" PATH="$bin:/usr/local/bin:/usr/bin:/bin" "$@") > "$out/$label-$name.log" 2>&1
  local result=$?
  printf '%s\t%s\t%s\n' "$label" "$name" "$result" | tee -a "$out/status.tsv"
  tail -5 "$out/$label-$name.log"
}

for label in built409 master; do
  if [[ "$label" == built409 ]]; then
    bin="$work/rdiff/rubies/ruby-4.0.9/bin"
  else
    bin="$work/rdiff/rubies/master-f3e180b5eb/bin"
  fi
  run "$label" "$bin" version ruby -v
  run "$label" "$bin" bundle bundle install --quiet
  run "$label" "$bin" new-tests ruby -Itest test/acceptance/stub_env_test.rb
  run "$label" "$bin" test bundle exec rake test
  run "$label" "$bin" probe ruby -Ilib "$work/probe.rb"
  run "$label" "$bin" integration-probe ruby -Ilib "$work/integration_probe.rb"
  run "$label" "$bin" repro ruby -Ilib "$root/bench/upstream/ruby-differential/repros/mocha_env_stub_test.rb"
  run "$label" "$bin" isolated bundle exec rake test:isolated
  run "$label" "$bin" minitest-bundle bundle install --gemfile gemfiles/Gemfile.minitest.latest --quiet
  run "$label" "$bin" minitest env MOCHA_RUN_INTEGRATION_TESTS=minitest bundle exec --gemfile gemfiles/Gemfile.minitest.latest rake test
  run "$label" "$bin" test-unit-bundle bundle install --gemfile gemfiles/Gemfile.test-unit.latest --quiet
  run "$label" "$bin" test-unit env MOCHA_RUN_INTEGRATION_TESTS=test-unit bundle exec --gemfile gemfiles/Gemfile.test-unit.latest rake test
done
bin="$work/rdiff/rubies/ruby-4.0.9/bin"
run built409 "$bin" lint-bundle bundle install --gemfile gemfiles/Gemfile.rubocop --quiet
run built409 "$bin" lint bundle exec --gemfile gemfiles/Gemfile.rubocop rake lint
bin=/home/user/.local/share/mise/installs/ruby/2.7.8/bin
run ruby27 "$bin" version ruby -v
run ruby27 "$bin" new-tests ruby -Itest test/acceptance/stub_env_test.rb
run ruby27 "$bin" probe ruby -Ilib "$work/probe.rb"
