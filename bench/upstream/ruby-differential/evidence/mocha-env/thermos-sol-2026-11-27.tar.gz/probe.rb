require 'json'
require 'mocha/api'
Object.new.extend(Mocha::API)

def scope
  Mocha::Mockery.setup(Mocha::Hooks::NullAssertionCounter.new)
  yield
ensure
  Mocha::Mockery.teardown
end

def check(label)
  value = yield
  puts JSON.generate(case: label, result: value)
rescue Exception => e
  message = e.is_a?(Mocha::ExpectationError) ? 'expectation error (receiver details omitted)' : e.message.lines.first.to_s.strip
  puts JSON.generate(case: label, error: e.class.name, message: message)
end

def receiver(value = :original)
  Object.new.tap { |obj| obj.define_singleton_method(:probe) { value } }
end

def lifecycle(obj)
  values = []
  scope do
    obj.stubs(:probe).returns(:stubbed)
    values << obj.probe
    obj.unstub(:probe)
    values << obj.probe
    obj.expects(:probe).returns(:expected)
    values << obj.probe
    Mocha::Mockery.verify
  end
  values << obj.probe
  scope do
    obj.expects(:probe).never
    Mocha::Mockery.verify
  end
  values << obj.probe
end

check('ruby') { RUBY_DESCRIPTION }
check('ordinary') { lifecycle(receiver) }
check('subclass') { lifecycle(Class.new(String).new('text').tap { |obj| obj.define_singleton_method(:probe) { :original } }) }
check('collection_subclasses') do
  [Class.new(Array).new, Class.new(Hash).new].map do |obj|
    obj.define_singleton_method(:probe) { :original }
    lifecycle(obj)
  end
end
check('method_missing') do
  obj = Class.new do
    def method_missing(*)
      :original
    end
    def respond_to_missing?(*)
      true
    end
  end.new
  lifecycle(obj)
end
check('private_and_prepend') do
  obj = receiver
  obj.singleton_class.prepend(Module.new { def probe; :prepended; end })
  obj.singleton_class.send(:private, :probe)
  scope do
    obj.stubs(:probe).returns(:stubbed)
    value = obj.send(:probe)
    obj.unstub(:probe)
    [value, obj.send(:probe), obj.respond_to?(:probe)]
  end
end
check('private') do
  obj = receiver
  obj.singleton_class.send(:private, :probe)
  scope do
    obj.stubs(:probe).returns(:stubbed)
    values = [obj.send(:probe), obj.respond_to?(:probe)]
    obj.unstub(:probe)
    values + [obj.send(:probe), obj.respond_to?(:probe)]
  end
end
check('any_instance') do
  klass = Class.new { def probe; :original; end }
  scope do
    klass.any_instance.stubs(:probe).returns(:stubbed)
    [klass.new.probe, klass.new.probe]
  end + [klass.new.probe]
end
check('frozen') do
  scope { receiver.freeze.stubs(:probe) }
end
check('frozen_class') do
  scope { Class.new.freeze.stubs(:new) }
end
check('env') do
  vals = []
  scope do
    ENV.stubs(:key?).with('MO1_MISSING_KEY').returns(true)
    vals << ENV.key?('MO1_MISSING_KEY')
    ENV.unstub(:key?)
    vals << ENV.key?('MO1_MISSING_KEY')
    ENV.expects(:key?).with('MO1_MISSING_KEY').returns(:expected)
    vals << ENV.key?('MO1_MISSING_KEY')
    Mocha::Mockery.verify
  end
  vals << ENV.key?('MO1_MISSING_KEY')
  scope { ENV.expects(:key?).never; Mocha::Mockery.verify }
  scope { ENV.stubs(:key?).returns(:new_context); vals << ENV.key?('MO1_MISSING_KEY') }
  vals << ENV.key?('MO1_MISSING_KEY')
end
check('error_cleanup') do
  begin
    scope { ENV.stubs(:key?).returns(true); raise 'test error' }
  rescue RuntimeError
  end
  scope { ENV.expects(:key?).with('MO1_MISSING_KEY').returns(:fresh); value = ENV.key?('MO1_MISSING_KEY'); Mocha::Mockery.verify; [value] } + [ENV.key?('MO1_MISSING_KEY')]
end
check('nested_ordinary') do
  obj = receiver
  scope do
    obj.stubs(:probe).returns(:outer)
    inner = scope { obj.stubs(:probe).returns(:inner); obj.probe }
    [inner, obj.probe]
  end
end
check('nested_env') do
  scope do
    ENV.stubs(:key?).returns(:outer)
    inner = scope { ENV.stubs(:key?).returns(:inner); ENV.key?('MO1_MISSING_KEY') }
    [inner, ENV.key?('MO1_MISSING_KEY')]
  end
end
check('nested_env_distinct_methods') do
  scope do
    ENV.stubs(:key?).returns(:outer)
    inner = scope { ENV.stubs(:fetch).returns(:inner); ENV.fetch('MO1_MISSING_KEY') }
    [inner, ENV.key?('MO1_MISSING_KEY')]
  end
end
check('env_partial_unstub') do
  scope do
    ENV.stubs(:key?).returns(true)
    ENV.stubs(:fetch).returns(:retained)
    ENV.unstub(:key?)
    values = [ENV.key?('MO1_MISSING_KEY'), ENV.fetch('MO1_MISSING_KEY')]
    ENV.unstub(:fetch)
    values << ENV.fetch('MO1_MISSING_KEY', :original)
  end
end
check('env_identity') do
  scope do
    ENV.expects(:hash).never
    ENV.expects(:eql?).never
    ENV.stubs(:key?).returns(:identity)
    value = ENV.key?('MO1_MISSING_KEY')
    ENV.unstub(:key?)
    Mocha::Mockery.verify
    value
  end
end
check('thread_env') do
  scope do
    ENV.stubs(:key?).returns(:threaded)
    Thread.new { ENV.key?('MO1_MISSING_KEY') }.value
  end
end
check('retained_hash_entries') do
  defined?(Mocha::ObjectMethods::SHAREABLE_MOCKS) ? Mocha::ObjectMethods::SHAREABLE_MOCKS.size : :no_global_hash
end
if defined?(Ractor)
  check('make_shareable') do
    [Object.new, [], {}, 'text', Class.new, Module.new].map do |obj|
      Ractor.make_shareable(obj)
      [obj.class.name, obj.frozen?, Ractor.shareable?(obj)]
    end
  end
  check('ractor') do
    obj = Ractor.new { 47 }
    returned = obj.value
    original = obj.inspect
    values = scope do
      obj.stubs(:inspect).returns('stubbed')
      [obj.inspect]
    end
    values + [obj.inspect == original, returned]
  end
  if defined?(Ractor::Port)
    check('port') do
      obj = Ractor::Port.new
      scope { obj.stubs(:inspect).returns('stubbed'); [obj.inspect, obj.frozen?, Ractor.shareable?(obj)] }
    end
  end
  if Ractor.respond_to?(:shareable_proc)
    check('shareable_proc') do
      obj = Ractor.shareable_proc { :original }
      scope { obj.stubs(:call).returns(:stubbed); [obj.call, obj.frozen?, Ractor.shareable?(obj)] }
    end
  end
end
