require 'json'
require 'minitest'
require 'mocha/minitest'

class ErrorCleanupProbe < Minitest::Test
  def test_error
    ENV.stubs(:key?).with('MO1_PROBE_MISSING').returns(true)
    raise 'intentional test error'
  end

  def test_next
    ENV.expects(:key?).with('MO1_PROBE_MISSING').returns(:fresh)
    assert_equal :fresh, ENV.key?('MO1_PROBE_MISSING')
  end
end

first = ErrorCleanupProbe.new(:test_error).run
second = ErrorCleanupProbe.new(:test_next).run
puts JSON.generate(case: 'framework_error_cleanup', first_errors: first.failures.map { |f| f.class.name }, second_errors: second.failures.map { |f| f.class.name }, original_restored: ENV.key?('MO1_PROBE_MISSING') == false)
abort 'unexpected integration result' unless first.failures.size == 1 && second.failures.empty? && ENV.key?('MO1_PROBE_MISSING') == false

Mocha::Mockery.setup(Mocha::Hooks::NullAssertionCounter.new)
begin
  ENV.expects(:key?).never
  begin
    ENV.key?('MO1_PROBE_MISSING')
    abort 'never did not reject call'
  rescue Minitest::Assertion
    puts JSON.generate(case: 'never_called', result: 'correctly rejected')
  end
ensure
  Mocha::Mockery.teardown
end
puts JSON.generate(case: 'map_after_integration', entries: defined?(Mocha::ObjectMethods::SHAREABLE_MOCKS) ? Mocha::ObjectMethods::SHAREABLE_MOCKS.size : 'no map')

if defined?(Ractor)
  objects = [Ractor.new { :first }, Ractor.new { :second }]
  objects.each do |obj|
    obj.define_singleton_method(:hash) { raise 'must not hash receiver' }
    obj.define_singleton_method(:eql?) { |_| raise 'must not compare receiver' }
  end
  Mocha::Mockery.setup(Mocha::Hooks::NullAssertionCounter.new)
  begin
    objects[0].stubs(:name).returns('first stub')
    objects[1].stubs(:name).returns('second stub')
    values = objects.map(&:name)
    abort 'identity failure' unless values == ['first stub', 'second stub']
    puts JSON.generate(case: 'identity', result: values)
  ensure
    Mocha::Mockery.teardown
  end
  objects.each(&:value)
end
