#!/usr/bin/env bash
set -uo pipefail
root=/home/user/workspace/repo
work="$root/.amp/in/orb-backup/mo1-review"
bin="$1/bin"
label="$2"
out="$work/results-$label"
mkdir -p "$out"
export PATH="$bin:/usr/local/bin:/usr/bin:/bin"

run() {
  local checkout="$1" name="$2"
  shift 2
  (cd "$work/$checkout" && env -i HOME="$HOME" PATH="$PATH" "$@") > "$out/$name.log" 2>&1
  local result=$?
  printf '%s\t%s\t%s\n' "$label" "$name" "$result" | tee -a "$out/status.tsv"
  tail -6 "$out/$name.log"
  return 0
}

run mocha version ruby -v
run mocha gems gem install rake minitest introspection:0.0.1 test-unit --no-document
run mocha bundle bundle install --quiet
run mocha-base bundle-base bundle install --quiet
run mocha-base new-tests-base ruby -Itest test/acceptance/stub_env_test.rb
run mocha new-tests-head ruby -Itest test/acceptance/stub_env_test.rb
run mocha-base test-base bundle exec rake test
run mocha test-head bundle exec rake test
run mocha isolated bundle exec rake test:isolated
run mocha minitest-bundle bundle install --gemfile gemfiles/Gemfile.minitest.latest --quiet
run mocha minitest env MOCHA_RUN_INTEGRATION_TESTS=minitest bundle exec --gemfile gemfiles/Gemfile.minitest.latest rake test
run mocha test-unit-bundle bundle install --gemfile gemfiles/Gemfile.test-unit.latest --quiet
run mocha test-unit env MOCHA_RUN_INTEGRATION_TESTS=test-unit bundle exec --gemfile gemfiles/Gemfile.test-unit.latest rake test
run mocha probe-head ruby -Ilib "$work/probe.rb"
run mocha-base probe-base ruby -Ilib "$work/probe.rb"
run mocha integration-probe-head ruby -Ilib "$work/integration_probe.rb"
run mocha-base repro-base ruby -Ilib "$root/bench/upstream/ruby-differential/repros/mocha_env_stub_test.rb"
run mocha repro-head ruby -Ilib "$root/bench/upstream/ruby-differential/repros/mocha_env_stub_test.rb"
cat "$out/status.tsv"
