import json
import pathlib

root = pathlib.Path(__file__).parent
out = root / 'results-final'
status = [line.split('\t') for line in (out / 'status.tsv').read_text().splitlines()]
assert len(status) == 29, status
assert all(code == '0' for _, _, code in status), status

def records(path):
    return {row['case']: row for line in path.read_text().splitlines()
            if line.startswith('{') for row in [json.loads(line)]}

for label in ['built409', 'master', 'ruby27']:
    probe_name = 'mocha-probe.log' if label == 'ruby27' else 'probe-head.log'
    previous = records(root / ('results-' + label) / probe_name)
    current = records(out / (label + '-probe.log'))
    assert current == previous, (label, current, previous)
    if label != 'ruby27':
        previous = records(root / ('results-' + label) / 'integration-probe-head.log')
        current = records(out / (label + '-integration-probe.log'))
        assert current == previous, (label, current, previous)
    print(label + ': final-head probe records match validated original-tree outcomes')
print('All 29 final-head command statuses are zero')
