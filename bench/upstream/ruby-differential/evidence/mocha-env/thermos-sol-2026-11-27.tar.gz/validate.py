import json
import pathlib
import sys

root = pathlib.Path(__file__).parent
common = ["stubbed", "original", "expected", "original", "original"]
expected = {
    "ordinary": common,
    "subclass": common,
    "collection_subclasses": [common, common],
    "method_missing": common,
    "private_and_prepend": ["stubbed", "prepended", True],
    "private": ["stubbed", False, "original", False],
    "any_instance": ["stubbed", "stubbed", "original"],
    "env": [True, False, "expected", False, "new_context", False],
    "error_cleanup": ["fresh", False],
    "nested_env_distinct_methods": ["inner", "outer"],
    "env_partial_unstub": [False, "retained", "original"],
    "env_identity": "identity",
    "thread_env": "threaded",
    "ractor": ["stubbed", True, 47],
    "make_shareable": [[name, True, True] for name in ["Object", "Array", "Hash", "String"]]
    + [["Class", False, True], ["Module", False, True]],
}
shareable_cases = {
    "env", "error_cleanup", "nested_env", "nested_env_distinct_methods",
    "env_partial_unstub", "env_identity", "thread_env", "ractor",
}
frozen_cases = {"frozen", "frozen_class", "port", "shareable_proc"}

def records(path):
    return {row["case"]: row for line in path.read_text().splitlines()
            if line.startswith('{') for row in [json.loads(line)]}

for label in sys.argv[1:]:
    out = root / ("results-" + label)
    status = [line.split('\t') for line in (out / 'status.tsv').read_text().splitlines()]
    assert len(status) == 18, status
    for _, name, code in status:
        want = 1 if label == 'master' and name in {'new-tests-base', 'test-base', 'repro-base'} else 0
        assert int(code) == want, (label, name, code, want)
    for side in ['base', 'head']:
        rows = records(out / ('probe-' + side + '.log'))
        assert len(rows) == 23, (label, side, rows.keys())
        for name, row in rows.items():
            if name == 'ruby':
                assert 'revision 3e93b23afc' in row['result'] if label == 'built409' else 'f3e180b5eb' in row['result']
            elif label == 'master' and side == 'base' and name in shareable_cases:
                assert row['error'] == 'Ractor::IsolationError', (label, side, name, row)
            elif name in frozen_cases:
                assert row['error'] == 'Mocha::StubbingError', (label, side, name, row)
                assert row['message'].startswith("can't stub method on frozen object:"), row
            elif name in {'nested_ordinary', 'nested_env'}:
                assert row['error'] == 'Mocha::ExpectationError', (label, side, name, row)
            elif name == 'retained_hash_entries':
                assert row['result'] == (0 if side == 'head' else 'no_global_hash'), row
            else:
                assert row['result'] == expected[name], (label, side, name, row, expected[name])
    integration = records(out / 'integration-probe-head.log')
    assert integration['framework_error_cleanup']['first_errors'] == ['Minitest::UnexpectedError']
    assert integration['framework_error_cleanup']['second_errors'] == []
    assert integration['framework_error_cleanup']['original_restored'] is True
    assert integration['never_called']['result'] == 'correctly rejected'
    assert integration['map_after_integration']['entries'] == 0
    assert integration['identity']['result'] == ['first stub', 'second stub']
    print(label + ': exit statuses, 23 base/head probe cases and four integration outcomes match independent expectations')
