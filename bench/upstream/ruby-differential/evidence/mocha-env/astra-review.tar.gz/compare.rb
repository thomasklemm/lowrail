require 'json'

root = File.join(__dir__, 'results')
read = lambda do |path|
  File.read(path).lines.reject { |line| line.include?('warning: Ractor API is experimental') }.join
    .gsub(%r{/rbuild/rubies/(ruby409|master)/}, '/rbuild/rubies/PIN/')
end
comparisons = [
  ['ruby409-base-vs-head', 'ruby409', 'mocha-base', 'ruby409', 'mocha'],
  ['master-base-vs-head', 'master', 'mocha-base', 'master', 'mocha'],
  ['ruby409-base-vs-master-head', 'ruby409', 'mocha-base', 'master', 'mocha']
]
report = comparisons.to_h do |label, left_pin, left_tree, right_pin, right_tree|
  files = Dir[File.join(root, left_pin, "#{left_tree}-{probe,extra}-*.log")].sort
  differences = files.filter_map do |left|
    suffix = File.basename(left).delete_prefix(left_tree)
    right = File.join(root, right_pin, right_tree + suffix)
    a, b = read.call(left), read.call(right)
    { scenario: suffix, before: a, after: b } unless a == b
  end
  [label, { compared: files.size, differences: differences }]
end
puts JSON.pretty_generate(report)
