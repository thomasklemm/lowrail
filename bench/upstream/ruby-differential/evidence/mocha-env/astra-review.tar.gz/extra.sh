#!/usr/bin/env bash
set -u
root=$(realpath "$(dirname "$0")")
pin=$1
bin="$root/rbuild/rubies/$pin/bin"
mkdir -p "$root/results/$pin"
for tree in mocha-base mocha; do
  for scenario in saved_mock saved_env_method failed_expectation_then_next_test return_contract extended_prepend_and_missing thread_setup fiber outside_test; do
    env -i HOME=/home/user PATH="$bin:/usr/bin:/bin" LANG=C.UTF-8 \
      "$bin/ruby" -I"$root/$tree/lib" "$root/extra.rb" "$scenario" \
      > "$root/results/$pin/$tree-extra-$scenario.log" 2>&1
    echo "$tree $scenario exit=$?"
  done
done
