require 'fileutils'
require 'json'
require 'open3'

root = File.expand_path(__dir__)
pin = ARGV.fetch(0)
bin = File.join(root, 'rbuild/rubies', pin, 'bin')
out = File.join(root, 'results', pin)
FileUtils.mkdir_p(out)
env = { 'PATH' => "#{bin}:/usr/bin:/bin", 'HOME' => ENV.fetch('HOME'), 'LANG' => 'C.UTF-8', 'GEM_HOME' => nil, 'GEM_PATH' => nil,
        'BUNDLE_GEMFILE' => nil, 'RUBYOPT' => nil }
statuses = {}
run = lambda do |label, tree, extra, *command|
  puts "#{pin} #{label}: #{command.join(' ')}"
  log = File.join(out, "#{label}.log")
  ok = system(env.merge(extra), *command, chdir: File.join(root, tree), out: log, err: [:child, :out], unsetenv_others: true)
  statuses[label] = { command: command, env: extra, exit: $?.exitstatus, ok: ok }
  File.write(File.join(out, 'status.json'), JSON.pretty_generate(statuses))
  puts "#{label}: exit=#{$?.exitstatus}"
end
run.call('install', 'mocha', {}, File.join(bin, 'gem'), 'install', 'ruby2_keywords', 'minitest', 'rake', 'introspection', 'test-unit', 'benchmark', 'rubocop', 'rubocop-rake', '--no-document')
cases = %w[basic expects unstub verify_failure raises thread multi nested next_test teardown_order erroring collision private_collision prepend_collision ractor_shareable_stub singleton any_instance hash_equality env_hash_equality frozen freeze_after_stub ractor_object port_object shareable_proc ractor_usage in_ractor subclasses class_module standalone]
%w[mocha-base mocha].each do |tree|
  run.call("#{tree}-versions", tree, {}, File.join(bin, 'ruby'), '-v')
  run.call("#{tree}-gems", tree, {}, File.join(bin, 'gem'), 'list')
  run.call("#{tree}-bundle", tree, {}, File.join(bin, 'bundle'), 'install', '--quiet')
  %w[test test:isolated].each do |task|
    run.call("#{tree}-#{task.tr(':', '-')}", tree, {}, File.join(bin, 'bundle'), 'exec', 'rake', task)
  end
  %w[minitest test-unit].each do |suite|
    integration_env = { 'BUNDLE_GEMFILE' => File.join(root, tree, 'gemfiles', "Gemfile.#{suite}.latest"), 'MOCHA_RUN_INTEGRATION_TESTS' => suite }
    run.call("#{tree}-#{suite}-bundle", tree, integration_env, File.join(bin, 'bundle'), 'install', '--quiet')
    run.call("#{tree}-integration-#{suite}", tree, integration_env, File.join(bin, 'bundle'), 'exec', 'rake', 'test')
  end
  lint_env = { 'BUNDLE_GEMFILE' => File.join(root, tree, 'gemfiles/Gemfile.rubocop') }
  run.call("#{tree}-lint-bundle", tree, lint_env, File.join(bin, 'bundle'), 'install', '--quiet')
  run.call("#{tree}-lint", tree, lint_env, File.join(bin, 'bundle'), 'exec', 'rake', 'lint')
  cases.each do |name|
    run.call("#{tree}-probe-#{name}", tree, {}, File.join(bin, 'ruby'), '-Ilib', File.join(root, 'probe.rb'), name)
  end
  run.call("#{tree}-repro", tree, {}, File.join(bin, 'ruby'), '-Ilib', File.expand_path('../../../../bench/upstream/ruby-differential/repros/mocha_env_stub_test.rb', root))
end
