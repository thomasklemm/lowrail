require 'json'
require 'mocha/api'
include Mocha::API

def outcome
  yield
rescue Exception => e
  [e.class.name, e.message.gsub(/0x[0-9a-f]+/, '0xOBJECT')]
end

def test
  mocha_setup
  value = yield
  mocha_verify
  value
ensure
  mocha_teardown
end

case ARGV.fetch(0)
when 'saved_mock'
  saved = nil
  test { saved = mock('saved'); saved.stubs(:value).returns(123) }
  puts JSON.generate(outcome { test { saved.value } })
when 'saved_env_method'
  saved = nil
  test { ENV.stubs(:key?).returns(true); saved = ENV.method(:key?) }
  puts JSON.generate(outcome { test { ENV.stubs(:key?).returns('fresh'); saved.call('MO1_AST') } })
when 'failed_expectation_then_next_test'
  first = outcome { test { ENV.expects(:key?).with('MO1_AST') } }
  second = outcome { test { ENV.expects(:key?).with('MO1_AST').returns('fresh'); ENV.key?('MO1_AST') } }
  puts JSON.generate([first, second, ENV.key?('MO1_AST')])
when 'return_contract'
  puts JSON.generate(outcome do
    test do
      a = ENV.stubs(key?: false, fetch: nil)
      b = ENV.expects(:[]).with('MO1_AST').returns('expected')
      [a.class.name, b.class.name, ENV.key?('MO1_AST'), ENV.fetch('MO1_AST'), ENV['MO1_AST']]
    end
  end)
when 'extended_prepend_and_missing'
  target = Object.new
  target.extend(Module.new { def existing; 'original'; end })
  target.singleton_class.prepend(Module.new { def existing; "prepended:#{super}"; end })
  def target.method_missing(name, *args)
    name == :dynamic ? 'dynamic original' : super
  end
  def target.respond_to_missing?(name, include_private = false)
    name == :dynamic || super
  end
  puts JSON.generate(outcome do
    during = test do
      target.stubs(:existing).returns('stub')
      target.expects(:dynamic).returns('dynamic stub')
      [target.existing, target.dynamic]
    end
    [during, target.existing, target.dynamic]
  end)
when 'thread_setup'
  puts JSON.generate(outcome do
    test do
      Thread.new { ENV.stubs(:key?).returns(true) }.join
      [ENV.key?('MO1_AST'), Thread.new { ENV.key?('MO1_AST') }.value]
    end
  end)
when 'fiber'
  puts JSON.generate(outcome do
    test do
      fiber = Fiber.new do
        ENV.stubs(:key?).returns(true)
        Fiber.yield ENV.key?('MO1_AST')
        ENV.key?('MO1_AST')
      end
      [fiber.resume, ENV.key?('MO1_AST'), fiber.resume]
    end
  end)
when 'outside_test'
  test {}
  puts JSON.generate([outcome { ENV.stubs(:key?) }, outcome { ENV.expects(:key?) }, outcome { ENV.unstub(:key?) }])
end
