require 'fileutils'
require 'open3'
require 'json'

root = __dir__
out = File.join(root, 'shape-results')
FileUtils.mkdir_p(out)
cases = %w[basic expects unstub verify_failure raises thread multi nested next_test teardown_order erroring collision private_collision prepend_collision ractor_shareable_stub singleton any_instance hash_equality env_hash_equality frozen freeze_after_stub ractor_object port_object shareable_proc ractor_usage in_ractor subclasses class_module standalone]
extras = %w[saved_mock saved_env_method failed_expectation_then_next_test return_contract extended_prepend_and_missing thread_setup fiber outside_test]
report = {}
%w[ruby409 master].each do |pin|
  bin = File.join(root, 'rbuild/rubies', pin, 'bin')
  env = { 'PATH' => "#{bin}:/usr/bin:/bin", 'HOME' => '/home/user', 'LANG' => 'C.UTF-8' }
  report[pin] = { comparisons: 0, differences: [], tests: {} }
  { 'probe.rb' => cases, 'extra.rb' => extras }.each do |script, names|
    names.each do |name|
      results = %w[mocha-confirm mocha-shape].map do |tree|
        text, status = Open3.capture2e(env, File.join(bin, 'ruby'), '-Ilib', File.join(root, script), name,
          chdir: File.join(root, tree), unsetenv_others: true)
        File.write(File.join(out, "#{pin}-#{tree}-#{script}-#{name}.log"), text)
        [text, status.exitstatus]
      end
      report[pin][:comparisons] += 1
      report[pin][:differences] << name unless results[0] == results[1]
    end
  end
  %w[test/unit/object_methods_test.rb test/acceptance/stub_env_test.rb].each do |file|
    text, status = Open3.capture2e(env, File.join(bin, 'ruby'), '-Ilib', '-Itest', file,
      chdir: File.join(root, 'mocha-shape'), unsetenv_others: true)
    File.write(File.join(out, "#{pin}-#{File.basename(file)}.log"), text)
    report[pin][:tests][file] = status.exitstatus
  end
end
File.write(File.join(out, 'summary.json'), JSON.pretty_generate(report))
puts JSON.pretty_generate(report)
abort 'confirmation failed' unless report.values.all? { |r| r[:differences].empty? && r[:tests].values.all?(&:zero?) }
