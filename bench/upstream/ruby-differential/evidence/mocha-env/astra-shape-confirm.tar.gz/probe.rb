require 'json'
require 'mocha/api'
include Mocha::API

def session
  mocha_setup
  value = yield
  mocha_verify
  value
ensure
  mocha_teardown
end

def result
  yield
rescue Exception => e
  [e.class.name, e.message.gsub(/0x[0-9a-f]+/, '0xOBJECT')]
end

name = ARGV.fetch(0)
value = result do
  case name
  when 'basic', 'expects', 'unstub', 'verify_failure', 'raises', 'thread', 'multi', 'nested', 'next_test', 'teardown_order'
    observed = []
    session do
      case name
      when 'basic'
        ENV.stubs(:[]).with('MO1_AST').returns('stub')
        observed << ENV['MO1_AST']
      when 'expects'
        ENV.expects(:fetch).with('MO1_AST').returns('expected').twice
        2.times { observed << ENV.fetch('MO1_AST') }
      when 'unstub'
        ENV.stubs(:key?).with('MO1_AST').returns(true)
        observed << ENV.key?('MO1_AST')
        ENV.unstub(:key?)
        observed << ENV.key?('MO1_AST')
      when 'verify_failure'
        ENV.expects(:fetch).with('MO1_AST')
      when 'raises'
        ENV.stubs(:fetch).raises(ArgumentError, 'test-error')
        observed << result { ENV.fetch('MO1_AST') }
      when 'thread'
        ENV.stubs(:key?).with('MO1_AST').returns(true)
        observed << Thread.new { ENV.key?('MO1_AST') }.value
      when 'multi'
        ENV.stubs(:key?).returns(true)
        ENV.stubs(:fetch).returns('stub')
        ENV.unstub(:key?)
        observed << [ENV.key?('MO1_AST'), ENV.fetch('MO1_AST')]
      when 'nested'
        ENV.stubs(:key?).returns(true)
        session do
          ENV.stubs(:fetch).returns('inner')
          observed << [ENV.key?('MO1_AST'), ENV.fetch('MO1_AST')]
        end
        observed << ENV.key?('MO1_AST')
      when 'next_test'
        ENV.stubs(:key?).returns(true)
      when 'teardown_order'
        obj = Object.new
        obj.stubs(:call).returns('object')
        ENV.stubs(:key?).returns(true)
        obj.stubs(:other).returns('other')
        observed << [obj.call, obj.other, ENV.key?('MO1_AST')]
      end
    end
    observed << ENV.key?('MO1_AST')
    if name == 'next_test'
      session do
        ENV.expects(:key?).with('MO1_AST').returns('fresh')
        observed << ENV.key?('MO1_AST')
      end
    end
    observed
  when 'erroring'
    error = result { session { ENV.stubs(:key?).returns(true); raise 'body failed' } }
    [error, ENV.key?('MO1_AST'), session { ENV.stubs(:key?).returns('fresh'); ENV.key?('MO1_AST') }]
  when 'collision'
    obj = Object.new
    def obj.mocha_shareable?; raise 'application method called'; end
    session { obj.stubs(:value).returns(42); obj.value }
  when 'private_collision'
    klass = Class.new do
      private
      def mocha_shareable?; raise 'private application method called'; end
    end
    session { obj = klass.new; obj.stubs(:value).returns(42); obj.value }
  when 'prepend_collision'
    obj = Object.new
    obj.singleton_class.prepend(Module.new { def mocha_shareable?; raise 'prepended method called'; end })
    session { obj.stubs(:value).returns(42); obj.value }
  when 'ractor_shareable_stub'
    session { Ractor.stubs(:shareable?).returns(false); Ractor.shareable?(ENV) }
  when 'singleton'
    session { ENV.singleton_class.stubs(:name).returns('stub'); ENV.singleton_class.name }
  when 'any_instance'
    session { ENV.singleton_class.any_instance.stubs(:key?).returns(true); ENV.key?('MO1_AST') }
  when 'hash_equality'
    obj = Object.new
    def obj.hash; raise 'hash called'; end
    def obj.==(other); raise 'equality called'; end
    def obj.eql?(other); raise 'eql called'; end
    session { obj.stubs(:value).returns(42); obj.value }
  when 'env_hash_equality'
    def ENV.hash; raise 'hash called'; end
    def ENV.==(other); raise 'equality called'; end
    def ENV.eql?(other); raise 'eql called'; end
    session { ENV.stubs(:key?).returns(true); ENV.key?('MO1_AST') }
  when 'frozen'
    obj = Object.new.freeze
    session { obj.stubs(:value).returns(42) }
  when 'freeze_after_stub'
    obj = Object.new
    session do
      obj.stubs(:value).returns(42)
      obj.freeze
      p invocation_after_freeze: result { obj.value }
    end
  when 'ractor_object', 'port_object', 'shareable_proc'
    obj = case name
          when 'ractor_object' then Ractor.current
          when 'port_object' then Ractor::Port.new
          when 'shareable_proc' then Ractor.shareable_proc { 42 }
          end
    p receiver: [obj.class.name, Ractor.shareable?(obj), obj.frozen?]
    session { obj.stubs(:inspect).returns('stub'); obj.inspect }
  when 'ractor_usage'
    session { ENV.stubs(:key?).returns(true); Ractor.new { result { ENV.key?('MO1_AST') } }.value }
  when 'in_ractor'
    Ractor.new { result { session { local_receiver = Object.new; local_receiver.stubs(:value).returns(42); local_receiver.value } } }.value
  when 'subclasses'
    [Class.new(Hash).new, Class.new(Array).new, Class.new(String).new].map do |obj|
      def obj.to_a; raise 'to_a called'; end
      def obj.to_hash; raise 'to_hash called'; end
      session { obj.stubs(:value).returns(42); obj.value }
    end
  when 'class_module'
    [Class.new, Module.new].map { |obj| session { obj.stubs(:value).returns(42); obj.value } }
  when 'standalone'
    Object.new.respond_to?(:stubs)
  else
    raise name
  end
end
puts JSON.generate(case: name, result: value)
