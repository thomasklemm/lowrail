class ReloadValue
  def to_s
    "from reloaded code"
  end
end
