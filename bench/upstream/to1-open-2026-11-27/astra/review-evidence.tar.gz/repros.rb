# frozen_string_literal: true
rails = File.expand_path(ARGV.fetch(0))
%w[activesupport actionview actionpack activemodel].each { |c| $LOAD_PATH.unshift(File.join(rails, c, "lib")) }
require "active_support"
require "active_support/core_ext"
require "action_view"

def report(name)
  print "#{name}: "
  p yield
rescue Exception => e
  puts "#{e.class}: #{e.message.gsub(/0x[0-9a-f]+/, "0xID")}"
end

def view
  Object.new.extend(ActionView::Helpers::TagHelper)
end

report("frozen receiver") { view.freeze.tag(:br) }

report("mutated name") do
  name = +"input"
  value = Object.new
  value.define_singleton_method(:to_s) { name.replace("br"); "value" }
  view.tag(name, id: value)
end

report("encoding error precedence") do
  value = Object.new
  value.define_singleton_method(:to_s) { raise "later attribute" }
  view.tag("x-é", a: "\xff".b, b: value)
end

report("custom self-closing-tag-string") { view.tag.self_closing_tag_string("text", id: "a") }
report("custom append-tag-options") { view.tag.append_tag_options("text", id: "a") }

report("nodoc append_tag_option accumulator") do
  v = view
  seen = []
  v.tag.singleton_class.prepend(Module.new do
    define_method(:append_tag_option) do |output, *args|
      seen << output.dup
      super(output, *args)
    end
  end)
  v.tag.input(id: "a")
  seen
end

report("nodoc self_closing_tag_string interception") do
  v = view
  seen = []
  v.tag.singleton_class.prepend(Module.new do
    define_method(:self_closing_tag_string) do |*args|
      seen << "called"
      super(*args)
    end
  end)
  v.tag(:input, id: "a")
  seen
end

report("nodoc tag_options interception (known)") do
  v = view
  seen = []
  v.tag.singleton_class.prepend(Module.new do
    define_method(:tag_options) do |*args|
      seen << "called"
      super(*args)
    end
  end)
  v.tag(:input, id: "a")
  seen
end
