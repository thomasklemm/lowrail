# frozen_string_literal: true
require "json"
rails = File.expand_path(ARGV.fetch(0))
%w[activesupport actionview actionpack activemodel].each { |c| $LOAD_PATH.unshift(File.join(rails, c, "lib")) }
require "active_support"
require "active_support/core_ext"
require "action_view"

def view
  Object.new.extend(ActionView::Helpers::TagHelper)
end

def snapshot(value)
  if value.is_a?(String)
    [value.class.name, value.bytes, value.encoding.name, value.valid_encoding?, value.frozen?, value.html_safe?]
  else
    value
  end
end

def check(label)
  log = []
  result = begin
    snapshot(yield(log))
  rescue Exception => e
    [e.class.name, e.message.gsub(/0x[0-9a-f]+/, "0xID").sub(/ for #<Object:.*\z/m, " for Object")]
  end
  puts JSON.generate([label, result, log])
end

[nil, false, {}, { id: "a" }].each do |options|
  [false, true].each do |warm|
    check("frozen view #{options.inspect} warm=#{warm}") do
      v = view
      v.tag if warm
      v.freeze.tag(:br, options)
    end
  end
end

names = ["input", "x-é", "x-é".b, "x-é".encode("ISO-8859-1"), "x-あ".encode("Shift_JIS")]
values = ["", "ascii", "é", "é".b, "\xff".b, "é".encode("ISO-8859-1"), "あ".encode("Shift_JIS"), "x".encode("UTF-16LE"), "\xff".dup.force_encoding("UTF-8")]
names.each_with_index do |name, n|
  values.each_with_index do |a, i|
    values.each_with_index do |b, j|
      [false, true].each do |escape|
        check("encoding #{n},#{i},#{j},#{escape}") do |log|
          later = Object.new
          later.define_singleton_method(:to_s) { log << "later"; b }
          view.tag(name, { a: a, b: later }, false, escape)
        end
      end
    end
    check("encoding exception #{n},#{i}") do |log|
      later = Object.new
      later.define_singleton_method(:to_s) { log << "later"; raise "later error" }
      view.tag(name, { a: a, b: later })
    end
  end
end

class LoggedHash < Hash
  attr_accessor :events, :effect
  def blank?
    events << "blank"
    super
  end
  def each_pair
    events << "each_pair"
    super do |k, v|
      events << "yield #{k}"
      yield(k, v)
      effect&.call(self, k)
    end
    events << "done"
    "unexpected return"
  end
end

[:ordinary, :mutate, :freeze, :raise, :fiber].each do |mode|
  check("Hash subclass #{mode}") do |log|
    h = LoggedHash[a: "one", b: "two"]
    h.events = log
    h.effect = case mode
    when :mutate then ->(hash, key) { hash[:b] = "three" if key == :a }
    when :freeze then ->(hash, _) { hash.freeze }
    when :raise then ->(*) { raise "hash error" }
    when :fiber then ->(_, key) { Fiber.yield(key) }
    end
    f = Fiber.new { view.tag(:input, h) }
    r = f.resume
    while f.alive?
      log << "suspended #{r}"
      r = f.resume
    end
    r
  end
end

[:to_s, :to_str, :include?, :gsub, :html_safe?].each do |method|
  [false, true].each do |escape|
    check("String singleton #{method} #{escape}") do |log|
      s = +"a\"<b>"
      s.define_singleton_method(method) do |*args|
        log << method.to_s
        super(*args)
      end
      view.tag(:input, { value: s.freeze }, false, escape)
    end
  end
end

check("reentrant conversion") do |log|
  v = view
  val = Object.new
  val.define_singleton_method(:to_s) do
    log << v.tag.input(id: "inner")
    v.tag(:br)
  end
  v.tag(:input, { value: val })
end

check("public safe_join prepend") do |log|
  v = view
  mod = Module.new do
    define_method(:safe_join) do |*args|
      log << "safe_join"
      super(*args).freeze
    end
  end
  v.singleton_class.prepend(mod)
  v.tag.input(class: ["a", "b"], aria: { label: ["x", "y"] })
end

check("thread conversion") do |log|
  v = view
  ready = Queue.new
  resume = Queue.new
  val = Object.new
  val.define_singleton_method(:to_s) { ready << true; resume.pop; "outer" }
  t = Thread.new { v.tag(:input, { id: val }) }
  ready.pop
  log << v.tag.input(id: "inner")
  resume << true
  t.value
end

check("reload view helper during conversion") do |log|
  v = view
  val = Object.new
  val.define_singleton_method(:to_s) do
    v.singleton_class.prepend(Module.new do
      define_method(:safe_join) do |*args|
        log << "reloaded safe_join"
        super(*args)
      end
    end)
    "outer"
  end
  v.tag(:input, { a: val, b: ["b", "c"] })
end

check("private tag_options prepend boundary") do |log|
  v = view
  v.tag.singleton_class.prepend(Module.new do
    define_method(:tag_options) do |*args|
      log << "tag_options"
      super(*args)
    end
  end)
  v.tag(:input, { id: "a" })
end

check("private append_tag_option accumulator boundary") do |log|
  v = view
  v.tag.singleton_class.prepend(Module.new do
    define_method(:append_tag_option) do |output, *args|
      log << output.dup
      super(output, *args)
    end
  end)
  v.tag.input(id: "a")
end

check("private self_closing_tag_string override boundary") do |log|
  v = view
  v.tag.singleton_class.prepend(Module.new do
    define_method(:self_closing_tag_string) do |*args|
      log << "self_closing_tag_string"
      super(*args)
    end
  end)
  v.tag(:input, { id: "a" })
end

[:self_closing_tag_string, :append_tag_options].each do |name|
  check("custom tag collision #{name}") { view.tag.public_send(name, "text", id: "a") }
end

check("mutate name during value conversion") do |log|
  name = +"input"
  val = Object.new
  val.define_singleton_method(:to_s) { name.replace("br"); log << name.dup; "value" }
  view.tag(name, { id: val })
end

check("mutate name during hash iteration") do |log|
  name = +"input"
  opts = { id: "a" }
  opts.define_singleton_method(:each_pair) do |&block|
    name.replace("br")
    log << name.dup
    super(&block)
  end
  view.tag(name, opts)
end

check("mutate name across threads") do |log|
  name = +"input"
  ready = Queue.new
  resume = Queue.new
  val = Object.new
  val.define_singleton_method(:to_s) { ready << true; resume.pop; "a" }
  t = Thread.new { view.tag(name, { id: val }) }
  ready.pop
  name.replace("br")
  resume << true
  t.value
end

check("frozen ActionView Base") do
  ActionView::Base.with_empty_template_cache.with_view_paths([]).freeze.tag(:br)
end

check("Zeitwerk reload during attribute conversion") do |log|
  require "zeitwerk"
  loader = Zeitwerk::Loader.new
  loader.push_dir(File.expand_path("reload_fixture", __dir__))
  loader.enable_reloading
  loader.setup
  old_class = ReloadValue
  val = Object.new
  val.define_singleton_method(:to_s) do
    loader.reload
    log << (old_class != ReloadValue)
    ReloadValue.new.to_s
  end
  view.tag(:input, { a: old_class.new, b: val, c: ["x", "y"] })
ensure
  loader&.unload
  loader&.unregister
end

class AdversarialString < String
  attr_accessor :events
  [:to_s, :to_str, :include?, :gsub, :gsub!, :html_safe?].each do |method|
    define_method(method) do |*args|
      events << method.to_s
      super(*args)
    end
  end
end

[:value, :key, :name].each do |position|
  [false, true].each do |escape|
    check("String subclass #{position} #{escape}") do |log|
      s = AdversarialString.new(position == :name ? "input" : "a\"<b>")
      s.events = log
      s.freeze
      v = view
      case position
      when :value then v.tag(:input, { value: s }, false, escape)
      when :key then v.tag(:input, { s => "x" }, false, escape)
      when :name then v.tag(s, { a: "x" }, false, escape)
      end
    end
  end
end

check("duck options via method_missing") do |log|
  options = Object.new
  options.define_singleton_method(:respond_to_missing?) { |*| true }
  options.define_singleton_method(:method_missing) do |name, *args, &block|
    log << name.to_s
    { a: "b" }.public_send(name, *args, &block)
  end
  view.tag(:input, options)
end

check("private to_s conversion") do |log|
  value = Object.new
  value.define_singleton_method(:to_s) { log << "private to_s"; "hello" }
  value.singleton_class.send(:private, :to_s)
  view.tag(:input, { a: value })
end

check("name singleton conversion mutates builder public method") do |log|
  v = view
  name = Object.new
  name.define_singleton_method(:to_str) { log << "to_str"; "input" }
  name.define_singleton_method(:to_s) do
    log << "to_s"
    v.tag.singleton_class.prepend(Module.new do
      define_method(:input) { |**opts| "reloaded" }
    end)
    "input"
  end
  v.tag(name, { a: "b" })
end
