rails = ARGV.fetch(0)
%w[activesupport actionview actionpack activemodel].each { |c| $LOAD_PATH.unshift(File.join(rails, c, "lib")) }
require "active_support"
require "active_support/core_ext"
require "action_view"

def probe(label, mod)
  view = ActionView::Base.empty
  view.tag.singleton_class.prepend(mod)
  [:legacy, :input, :content, :attributes].each do |call|
    result = begin
      case call
      when :legacy then view.tag(:input, id: "original")
      when :input then view.tag.input(id: "original")
      when :content then view.content_tag(:p, "text", id: "original")
      when :attributes then view.tag.attributes(id: "original")
      end
    rescue => e
      [e.class.name, e.message.lines.first.chomp]
    end
    puts [label, call, result].inspect
  end
end

probe("forward ellipsis, transform return", Module.new do
  def tag_options(...)
    super&.gsub("original", "replacement")
  end
end)
probe("forward splat, freeze return", Module.new do
  def tag_options(*args)
    super&.freeze
  end
end)
probe("forward ellipsis, recover error", Module.new do
  def tag_options(...)
    super
    raise ArgumentError, "attribute rejected"
  rescue ArgumentError
    ' data-error="recovered"'
  end
end)
probe("fixed arity", Module.new do
  def tag_options(options, escape = true)
    super
  end
end)
