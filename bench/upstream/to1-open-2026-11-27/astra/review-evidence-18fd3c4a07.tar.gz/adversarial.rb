rails = File.expand_path(ARGV.fetch(0))
%w[activesupport actionview actionpack activemodel].each { |c| $LOAD_PATH.unshift(File.join(rails, c, "lib")) }
require "active_support"
require "active_support/core_ext"
require "action_view"
require "json"

EVENTS = []
def record(label)
  EVENTS.clear
  value = begin
    r = yield
    if r.is_a?(String)
      [r.class.name, r.bytes, r.encoding.name, r.frozen?, r.html_safe?]
    else
      r
    end
  rescue Exception => e
    [e.class.name, e.message.gsub(/0x[0-9a-f]+/, "0xID").lines.first.chomp]
  end
  puts JSON.generate([label, value, EVENTS])
end
def view = ActionView::Base.empty
def call(v, kind, options, escape = true)
  case kind
  when :tag then v.tag("input", options, false, escape)
  when :input then v.tag.input(**options, escape: escape)
  when :attributes then v.tag.attributes(options)
  when :content then v.content_tag(:span, "hello", options, escape)
  end
end
def string(value = "one", method = :to_s, &block)
  s = +value
  s.define_singleton_method(method, &block)
  s
end

class FancyString < String
  def to_s
    EVENTS << "String#to_s"
    "<replacement>".freeze
  end
end
class FancyHash < Hash
  def each_pair
    EVENTS << "each_pair"
    yield :id, "first"
    yield :data, { count: 4, list: [1, 2] }
    yield :class, ["one", { two: true }]
  end
end
class OddString < String
  def include?(*)
    EVENTS << "include?"
    true
  end
  def gsub(*)
    EVENTS << "gsub"
    "returned".freeze
  end
end

factories = {
  "normal" => -> { { id: "a\"b<>é", disabled: true, data: { x: [1, 2] }, aria: { labelledby: ["a", "b"] } } },
  "hash subclass" => -> { FancyHash[:a, 1] },
  "hash override empty" => -> { h = { id: "a" }; h.define_singleton_method(:empty?) { EVENTS << "empty?"; false }; h },
  "hash frozen" => -> { { id: "x".freeze }.freeze },
  "string subclass" => -> { { id: FancyString.new("old") } },
  "intermediate subclass" => -> { x = Object.new; x.define_singleton_method(:to_s) { EVENTS << "convert"; OddString.new('a"b') }; { id: x } },
  "private conversion" => -> { x = Object.new; x.define_singleton_method(:to_s) { EVENTS << "private to_s"; "p" }; x.singleton_class.send(:private, :to_s); { id: x } },
  "safe subclass" => -> { { id: ActiveSupport::SafeBuffer.new('<i>"&') } },
  "string singleton" => -> { { id: string { EVENTS << "singleton to_s"; "new".freeze } } },
  "string extended" => -> { s = +"old"; s.extend(Module.new { def to_s = "extended" }); { id: s } },
  "string prepend" => -> { s = +"old"; s.singleton_class.prepend(Module.new { def to_s = "prepended" }); { id: s } },
  "exception after attrs" => -> { x = Object.new; x.define_singleton_method(:to_s) { EVENTS << "raises"; raise ArgumentError, "bad attribute" }; { id: "ok", title: x, after: "unused" } },
  "mutate later attr" => -> { s = +"before"; x = Object.new; x.define_singleton_method(:to_s) { s.replace("after"); "first" }; { id: x, title: s } },
  "delete later attr" => -> { h = {}; x = Object.new; x.define_singleton_method(:to_s) { h.delete(:title); "first" }; h.merge!(id: x, title: "later"); h },
  "add during iteration" => -> { h = {}; x = Object.new; x.define_singleton_method(:to_s) { h[:added] = "x"; "first" }; h[:id] = x; h },
  "json duck" => -> { x = Object.new; x.define_singleton_method(:to_json) { EVENTS << "to_json"; '{"x":2}' }; { data: { x: x } } },
  "array subclass" => -> { a = Class.new(Array) { def join(*) = "joined" }.new(["a", "b"]); { id: a, class: a } },
  "nil attrs" => -> { { id: nil, disabled: false, data: { x: nil }, aria: { label: [] } } }
}
[:tag, :input, :content, :attributes].each do |kind|
  [true, false].each do |escape|
    factories.each do |label, factory|
      record([kind, escape, label]) { call(view, kind, factory.call, escape) }
    end
  end
end

[false, true].each do |warm|
  [nil, false, {}, { id: "x" }].each do |options|
    record(["frozen view", warm, options]) do
      v = view
      v.tag if warm
      v.freeze.tag(:input, options)
    end
  end
end
record("frozen builder") { v = view; v.tag.freeze; v.tag.input(id: "x") }
record("custom self_closing_tag_string") { view.tag.self_closing_tag_string("text", id: "a") }
record("custom append_tag_options") { view.tag.append_tag_options("text", id: "a") }

%w[UTF-8 US-ASCII ASCII-8BIT ISO-8859-1 UTF-16LE UTF-16BE UTF-32LE].each do |enc|
  ["", "a", "é", "\xff".b].each do |text|
    [:tag, :input].each do |kind|
      record(["encoding", enc, text.bytes, kind]) do
        call(view, kind, { id: text.dup.force_encoding(enc), after: "b" })
      end
    end
  end
end

[:tag, :input].each do |kind|
  record(["view safe_join prepend", kind]) do
    v = view
    v.singleton_class.prepend(Module.new do
      def safe_join(...)
        EVENTS << "safe_join"
        "[#{super}]".html_safe
      end
    end)
    call(v, kind, { class: ["a", "b"], aria: { labelledby: ["x", "y"] } })
  end
  [:ellipsis, :splat].each do |shape|
    record(["merge options prepend", kind, shape]) do
      v = view
      mod = if shape == :ellipsis
        Module.new do
          def tag_options(options, ...)
            super(options.merge("data-state" => "s"), ...)
          end
        end
      else
        Module.new do
          def tag_options(options, *args)
            super(options.merge("data-state" => "s"), *args)
          end
        end
      end
      v.tag.singleton_class.prepend(mod)
      call(v, kind, { id: "first" })
    end
  end
  record(["reentrant conversion", kind]) do
    v = view
    x = Object.new
    x.define_singleton_method(:to_s) { v.tag.img(src: "/nested.png") }
    call(v, kind, { id: "outer", title: x })
  end
  record(["fiber interleave", kind]) do
    v = view
    x = Object.new
    x.define_singleton_method(:to_s) { Fiber.yield :paused; "value" }
    f = Fiber.new { call(v, kind, { id: "outer", title: x }) }
    [f.resume, call(v, kind, { id: "inner" }), f.resume]
  end
  record(["thread interleave", kind]) do
    v = view
    entered, resume = Queue.new, Queue.new
    x = Object.new
    x.define_singleton_method(:to_s) { entered << true; resume.pop; "value" }
    t = Thread.new { call(v, kind, { id: "outer", title: x }) }
    entered.pop
    inner = call(v, kind, { id: "inner" })
    resume << true
    [inner, t.value]
  end
  record(["reload suspended", kind]) do
    v = view
    x = Object.new
    x.define_singleton_method(:to_s) { Fiber.yield :paused; "value" }
    f = Fiber.new { call(v, kind, { id: "outer", title: x }) }
    before = f.resume
    verbose, $VERBOSE = $VERBOSE, nil
    load File.join(rails, "actionview/lib/action_view/helpers/tag_helper.rb")
    $VERBOSE = verbose
    [before, f.resume, call(v, kind, { id: "after reload" })]
  end
end
