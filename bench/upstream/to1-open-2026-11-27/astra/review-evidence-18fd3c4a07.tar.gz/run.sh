#!/usr/bin/env bash
set -euo pipefail
root=/home/user/workspace/repo
scratch="$root/.amp/in/orb-backup/to1-review"
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.10/bin:$PATH"
export GEM_PATH="$root/.lowrail/gate-gems/4.0.7-x86_64-linux-229531a6cfbf07e3caef30dbac24a2a3f3fed482:$(ruby -e 'puts Gem.path.join(":")')"
ruby -v
for tree in main head; do
  git -C "$scratch/$tree" rev-parse HEAD
  for probe in encoding overrides adversarial; do
    ruby "$scratch/$probe.rb" "$scratch/$tree" > "$scratch/$probe-$tree.txt"
  done
  ruby "$root/bench/upstream/to1-open-2026-11-27/to1_probe.rb" "$scratch/$tree" > "$scratch/probe-$tree.txt"
  ruby "$root/bench/upstream/to1-open-2026-11-27/astra_check.rb" "$scratch/$tree" > "$scratch/astra-$tree.txt"
  ruby "$root/bench/upstream/to1-open-2026-11-27/turbo_boost_prepend.rb" "$scratch/$tree" > "$scratch/turbo-$tree.txt"
done
cmp "$scratch/probe-main.txt" "$scratch/probe-head.txt"
cmp "$scratch/turbo-main.txt" "$scratch/turbo-head.txt"
sha256sum "$scratch/probe-"*.txt "$scratch/turbo-"*.txt
ruby "$scratch/check_raw.rb" "$root/bench/upstream/to1-open-2026-11-27" "$scratch" > "$scratch/raw-check.txt"
