rails = ARGV.fetch(0)
%w[activesupport actionview].each { |c| $LOAD_PATH.unshift(File.join(rails, c, "lib")) }
require "active_support"
require "active_support/core_ext"
require "action_view"
v = Object.new.extend(ActionView::Helpers::TagHelper)
value = "é".dup.force_encoding("US-ASCII")
[v.tag(:input, id: value), v.tag.input(id: value)].each do |html|
  p [html.encoding.name, html.valid_encoding?, html.bytes]
  begin
    p html.encode("UTF-16LE").bytes
  rescue => e
    p [e.class.name, e.message]
  end
end
