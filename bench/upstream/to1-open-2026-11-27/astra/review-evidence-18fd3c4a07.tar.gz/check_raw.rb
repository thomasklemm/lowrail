require "json"
root, scratch = ARGV
def med(values)
  sorted = values.sort
  n = sorted.length
  (sorted[(n - 1) / 2] + sorted[n / 2]) / 2.0
end
def ci(rounds)
  rng = Random.new(1)
  samples = Array.new(5000) { med(Array.new(rounds.length) { rounds[rng.rand(rounds.length)] }.flatten) }.sort
  [samples[124], samples[4875]].map { Math.exp(_1) - 1 }
end
%w[yjit zjit].each do |mode|
  folder = "#{root}/body/TO1-wall-#{mode}"
  dest = "#{scratch}/#{mode}"
  Dir.mkdir(dest) unless Dir.exist?(dest)
  raise unless system("tar", "xzf", "#{folder}/raw.tar.gz", "-C", dest)
  data = JSON.parse(File.read("#{folder}/results.json"))
  data.fetch("wall").each do |name, cell|
    rounds = (1..30).map do |r|
      %w[base candidate base2].to_h do |side|
        raw = File.read("#{dest}/raw/wall-r#{r}-#{side}.log")
        row = raw.lines.find { _1.start_with?("wall #{name}\t") }
        windows = JSON.parse(row.split("\t", 2).last)
        raise "raw/json mismatch #{mode} #{name} #{r} #{side}" unless windows == cell.fetch("rounds")[r - 1][side]
        jit = raw.lines.find { _1.start_with?("jit #{name}\t") }.split("\t", 2).last
        counters = jit.split.map { _1.split("=", 2) }.to_h.transform_values { _1.split(">").map(&:to_i) }
        saved = cell.fetch("jit").fetch("windows").find { _1.fetch("window") == "r#{r} #{side}" }.fetch("counters")
        raise "jit mismatch" unless counters == saved && counters.values.all? { |a, b| a == b }
        [side, Math.log(windows.fetch("cpu").sort[3] / cell.fetch("calls"))]
      end
    end
    changes = rounds.map { |r| [r["candidate"] - r["base"], r["candidate"] - r["base2"]] }
    aa = rounds.map { |r| [r["base2"] - r["base"]] }
    computed = { "change" => Math.exp(med(changes.flatten)) - 1, "aa" => Math.exp(med(aa.flatten)) - 1,
      "change_ci" => ci(changes), "aa_ci" => ci(aa) }
    computed.each { |k, v| raise "computed mismatch #{mode} #{name} #{k}" unless v == cell[k] }
    raise "nonflat" unless cell.fetch("jit").fetch("flat") && cell.fetch("jit").fetch("windows").length == 90
    puts "#{mode} #{name}: #{computed.transform_values { |v| Array(v).map { (_1 * 100).round(3) } }} claim=#{cell['claim']}, raw verified"
  end
end

%w[blog writebook casa].each do |app|
  rows = %w[main-4.0.10 main-4.0.102 to1-4.0.10].map do |label|
    json = JSON.parse(File.read("#{scratch}/objects/#{label}/#{app}-interpreter.json"))
    objects = json.fetch("workloads").first.fetch("gc_enabled_objects_per_op").sort
    [json.fetch("rails"), json.fetch("ruby"), objects[objects.length / 2]]
  end
  a, b, h = rows.map(&:last)
  puts "#{app}: #{rows.inspect}; mean base #{(a + b) / 2}, head #{h}, delta #{h - (a + b) / 2}"
end
