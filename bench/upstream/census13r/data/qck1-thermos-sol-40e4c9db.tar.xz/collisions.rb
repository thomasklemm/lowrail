require "active_record"
require "json"

expected_source = File.join(ENV.fetch("RAILS"), "activerecord")
raise "wrong Active Record source" unless Gem.loaded_specs.fetch("activerecord").full_gem_path == expected_source

adapter = ENV.fetch("DB", "sqlite3")
ActiveRecord::Base.establish_connection(adapter: adapter,
  database: adapter == "sqlite3" ? ":memory:" : "qck1_probe", query_cache: 3,
  prepared_statements: ENV.fetch("PS", "true") == "true")
connection = ActiveRecord::Base.lease_connection
ActiveRecord::Base.connection_pool.enable_query_cache!
events = []
ActiveSupport::Notifications.subscribe("sql.active_record") do |*, payload|
  events << (payload[:cached] ? "cache" : "db") unless payload[:name] == "SCHEMA"
end

class CollidingBinds < Array
  def hash = 123
  private
    def eql?(other) = super
end

class PrivateSQL < String
  private
    def eql?(other) = super
end

placeholder = adapter == "sqlite3" ? "?" : "$1"
sql = PrivateSQL.new("SELECT CAST(#{placeholder} AS INTEGER)")
other_sql = PrivateSQL.new("SELECT CAST(#{placeholder} AS INTEGER) + 100")
raise "probe did not create a collision" unless [sql, CollidingBinds[11]].hash == [sql, CollidingBinds[37]].hash
query = ->(sql, n, async = false) do
  result = connection.select_all(sql, "Collisions", CollidingBinds[n], async: async)
  result = result.result if result.respond_to?(:result)
  result.rows.fetch(0).fetch(0)
end
record = ->(label, expected, expected_events, &block) do
  connection.clear_query_cache
  events.clear
  result = block.call
  raise [label, result, events].inspect unless result == expected && events == expected_events
  puts JSON.generate(label: label, result: result, events: events)
end

record.call("colliding private-equality bind arrays, LRU", [11, 37, 59, 11, 71, 11, 37],
  %w[db db db cache db cache db]) { [11, 37, 59, 11, 71, 11, 37].map { query.call(sql, _1) } }
record.call("distinct private-equality SQL strings", [11, 111, 11, 111],
  %w[db db cache cache]) { [sql, other_sql, sql, other_sql].map { query.call(_1, 11) } }
record.call("colliding async lookup", [11, 37, 11, 37, 59],
  %w[db db cache cache db]) do
  [query.call(sql, 11), query.call(sql, 37), query.call(sql, 11, true),
    query.call(sql, 37, true), query.call(sql, 59, true)]
end

key_class = ActiveRecord::ConnectionAdapters::QueryCache::Store
frozen_binds = [11].freeze
factory = if key_class.const_defined?(:Key)
  -> { key_class::Key.new(sql, frozen_binds) }
else
  -> { [sql, frozen_binds] }
end
1000.times { factory.call.hash }
GC.start
GC.disable
before = GC.stat(:total_allocated_objects)
100_000.times { factory.call.hash }
allocated = GC.stat(:total_allocated_objects) - before
GC.enable
puts JSON.generate(label: "standalone key objects", objects_per_lookup: allocated.fdiv(100_000))
