# QCK1 follow-up on 40e4c9db8fcb00afc252ab554ebaa778efd51180

2026-11-27, thermos-sol, T-01a21eb9-c0e3-733d-b394-fbdeda571174. Both rubrics applied personally, no delegation. Code correctness, maintainability and allocation parity pass. The overall changes verdict remains only until the promised exact-head instruction/census/timing evidence and body replace the old-head claims.

Base: 2e299253f942ab94041cc6f210ac9d33884c210d. Ruby: 4.0.10 a704b7cd95, interpreter and YJIT. PostgreSQL 17.12. Rails source checkout rails-final is unmodified; reviewed.diff and pins.txt identify it. No master Ruby, ZJIT, independent Callgrind or wall-time run is claimed here.

## Differential probes

From the Lowrail root, scratch is `$PWD/.amp/in/orb-backup/qck1`; the checkouts are rails-base and rails-final. The probe Gemfile is ../Gemfile, retained here as probe-Gemfile. Run probe.rb and collisions.rb in each configuration:

```
RAILS="$scratch/rails-final" DB=sqlite3 PS=true BUNDLE_GEMFILE="$scratch/Gemfile" mise exec ruby@4.0.10 -- bundle exec ruby "$scratch/probe.rb"
RAILS="$scratch/rails-final" DB=sqlite3 PS=true BUNDLE_GEMFILE="$scratch/Gemfile" mise exec ruby@4.0.10 -- bundle exec ruby "$scratch/recheck-40e4c9db/collisions.rb"
```

Repeat with DB=postgresql and PS=false; also run PS=true on each database with ruby --yjit. The archive retains all twelve observations files per harness, six per Rails tree. probe.rb's actual Switchman module is retained at switchman/lib/switchman/active_record/query_cache.rb, originally from dc8a54325d0dc21da59ab72f82b7f421dd87645a. To replay this archived copy, place that directory beside probe.rb. The shard accessor is stubbed; this is not Switchman's full suite.

The 29-observation probe has only the same accepted unprefixed private cache_sql-override difference as the preceding Struct revision: one async cache hit becomes a database query. Actual Switchman has its existing async miss on both trees and unchanged synchronous hits. Every other case, including all original private/non-reflexive equality failures, mutable arguments, raw binds, subclasses, eviction, error and fiber cases, matches the base per adapter/configuration.

collisions.rb asserts that its two different bind arrays have genuinely identical composite hashes before exercising them. It asserts asymmetric result values and notification sequences for colliding private-equality bind Array subclasses, distinct private-equality SQL String subclasses, LRU eviction/promotion and async lookups. All outputs are byte-identical base/head on both adapters, PS on/off and YJIT. The standalone count gives 1.00001 objects per key on both trees (100,001 objects over 100,000 iterations). An initial draft incorrectly assumed overriding String#hash forced distinct SQL strings' native composite hashes to collide; the new collision assertion caught that assumption before this retained run. The final harness asserts same-SQL bind-array collisions and labels the distinct-SQL case accurately.

## Allocations

Run in order base/final/base2 (base2 is the same base checkout), with RAILS and UPSTREAM_BENCH_TREE both pointing to that checkout and BUNDLE_GEMFILE to the probe bundle:

```
UPSTREAM_BENCH_WARMUP=500 RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000 RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000 mise exec ruby@4.0.10 -- ruby -rbundler/setup script/upstream-bench --worker objects bench/upstream/census13r/qck1_body.rb
```

Repeat with ruby --yjit. All four rows match exactly across base/head/base in each mode. Interpreter: find miss 51.999, hit 38; three-bind where miss 91, hit 77 objects/call. YJIT: find miss 51.999, hit 38; three-bind where miss 93, hit 79. key-initialize-iseq.txt confirms opt_newarray_send in the exact constructor. This removes the preceding ivar-backed Struct's extra object. These are allocation counts, not timings or JIT-flat performance claims.

## Relevant suites and maintainability

From rails-final/activerecord, with RAILS set to rails-final, BUNDLE_GEMFILE set to rails-final/Gemfile, BUNDLE_WITHOUT=job:storage:cable:rubocop:mdl:doc and ARCONN=sqlite3 or postgresql:

```
mise exec ruby@4.0.10 -- ruby -rbundler/setup -Itest /absolute/path/to/qck1/suites.rb
```

The harness asserts the loaded source directory and prints cache_sql's source location. SQLite: 1,133 runs, 3,220 assertions, zero failures/errors, one skip. PostgreSQL: 1,135 runs, 3,222 assertions, zero failures/errors, one skip. These match retained base results in the initial archive. Seed 8181; includes query_cache, finder, bind_parameter, relation_test, relation/*, statement_cache and asynchronous_queries. The root bundle lock is retained as rails-Gemfile.lock.

With the probe bundle, `bundle exec flog -am FILE` gives total 189.4 on base and 193.8 on head; new Key#initialize 2.4. `bundle exec rubocop --config /dev/null --enable-pending-cops --only Metrics --format json FILE` gives the same six existing offenses on both; this is a consistent default-Metrics comparison, not the full Rails style bundle. The three-member Struct uses built-in comparison and an ordinary field reader for its cached hash; it adds no predicate or exceptional branch. L1. No new upstream test is required merely to retest native comparison.
