require "active_record"
ActiveRecord::ConnectionAdapters::QueryCache::Store.prepend(Module.new do
  def compute_if_absent(key)
    super do
      result = yield
      if key.is_a?(ActiveRecord::ConnectionAdapters::QueryCache::Store::Key)
        key.hash = [key.sql, key.binds].hash
      end
      result
    end
  end
end)
