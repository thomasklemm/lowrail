require "active_record"
require "json"

adapter = ENV.fetch("DB", "sqlite3")
config = { adapter: adapter, database: adapter == "sqlite3" ? ":memory:" : "qck1_probe",
  prepared_statements: ENV.fetch("PS", "true") == "true", query_cache: 100 }
ActiveRecord::Base.establish_connection(config)
connection = ActiveRecord::Base.lease_connection
connection.enable_query_cache!
events = []
ActiveSupport::Notifications.subscribe("sql.active_record") do |*, p|
  events << (p[:cached] ? "cache" : "db") unless p[:name] == "SCHEMA"
end
sql = adapter == "sqlite3" ? "SELECT CAST(? AS TEXT)" : "SELECT CAST($1 AS TEXT)"
query = ->(binds, async = false) do
  result = connection.select_all(sql, "Mutation", binds, async: async)
  result = result.result if result.respond_to?(:result)
  result.rows
end
show = ->(label, &block) do
  ActiveRecord::Base.remove_connection
  ActiveRecord::Base.establish_connection(config)
  connection = ActiveRecord::Base.lease_connection
  connection.enable_query_cache!
  events.clear
  result = block.call
  puts JSON.generate(label: label, result: result, events: events, size: connection.query_cache.size)
end
type = ActiveRecord::Type::String.new
make = ->(s) { ActiveModel::Attribute.with_cast_value("v", s, type) }

show.call("WithCastValue mutation before lookup") do
  value = +"alpha"
  bind = make.call(value)
  first = query.call([bind])
  value.replace("beta")
  [first, query.call([bind]), query.call([make.call("beta")]), query.call([make.call("alpha")])]
end

[false, true].each do |attribute|
  show.call("mutable #{attribute ? 'WithCastValue' : 'raw'} at Hash growth") do
    value = +"alpha"
    binds = [attribute ? make.call(value) : value]
    first = query.call(binds)
    value.replace("beta")
    8.times { |i| query.call(["unrelated-#{i}"]) }
    [first, query.call([attribute ? make.call("beta") : "beta"]), query.call(binds), query.call(["alpha"])]
  end
end

show.call("mutation in notification after database execution") do
  value = +"alpha"
  once = true
  subscriber = ActiveSupport::Notifications.subscribe("sql.active_record") do |*, p|
    if p[:name] == "Mutation" && !p[:cached] && once
      once = false
      value.replace("beta")
    end
  end
  begin
    [query.call([value]), query.call(["beta"]), query.call(["alpha"])]
  ensure
    ActiveSupport::Notifications.unsubscribe(subscriber)
  end
end

class NormalizingType < ActiveRecord::Type::String
  def serialize(value)
    value.downcase!
    value
  end
end
show.call("WithCastValue custom serializer mutates value") do
  value = +"ALPHA"
  bind = ActiveModel::Attribute.with_cast_value("v", value, NormalizingType.new)
  [query.call([bind]), query.call([bind]), query.call([bind], true), value]
end
