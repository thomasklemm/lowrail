# QCK1 Astra review, 2026-11-28

Reviewer thread T-01a220fa-b1b7-77fd-b146-9b88fdd27581. Performed personally, no agents or other threads. Verdict: changes. Rails base 2e299253f942ab94041cc6f210ac9d33884c210d; head 40e4c9db8fcb00afc252ab554ebaa778efd51180. Final item text is the snapshot from Lowrail 4852fc7ad4fe9e182cfc748bb848891ce5669fe2. Rails trees were not edited.

The coordinator independently reproduced the miss and held QCK1 at dc218eb655767bf37656214730ee5a64b9debe66. That held snapshot is also retained. The subsequent IN-list wall additions are outside this audit; the body is unchanged. Recomputing after the yield is only a local repair experiment, not an approved replacement: it keeps only hit savings and needs a why-comment, which puts it at readability L3.

## New finding

`mutation.rb` exercises accepted attribute binds and public custom type serialization. A WithCastValue bind containing `+"ALPHA"` and a String type whose `serialize(value)` calls `value.downcase!; value` is queried twice synchronously, then asynchronously. Main returns alpha with database/cache/cache and one cache entry; head returns alpha with database/database/cache and two entries. Hashing the attribute does not serialize it. The new key keeps the pre-serialization hash across the miss's execution block, whereas main hashes again before insertion.

The fresh-store logs reproduce this on SQLite/PostgreSQL with prepared statements true/false, in interpreter and YJIT. The final harness recreates the connection pool for each case so both raw and WithCastValue Hash-growth tests start with a small Hash. The initial shared-store mutation logs are retained but are not evidence about the second growth case, since Hash#clear retains the already-expanded representation. None of these probes override a private Rails method or a global core method. The private override in reused/probe.rb is a different, separately labelled accepted boundary.

`refresh-experiment.rb` prepends a local Store experiment that recomputes a Key's composite hash after the yield and before insertion. `raw/refresh-experiment.jsonl` restores database/cache/cache and one entry. It sacrifices the claimed synchronous-miss saving; it is not a production patch or a reviewed replacement head.

Other differences are not newly wrong results: main returns stale alpha for beta after mutation of resident raw/WithCastValue keys followed by the ninth insertion, while head returns beta. A notification subscriber mutating a bind after query execution also exposes a stale main result. Do not demand reproducing those stale results as a repair. The type-serialization finding mutates before the initial insertion, not while the key is resident.

## Reproduce probes and own-Gemfile suites

Create detached Rails worktrees at the exact base/head above. Copy the retained `rails-Gemfile.lock` into both trees; use each tree's own root Gemfile, not a shared path-gem bundle. The runs used Ruby 4.0.10 a704b7cd95, sqlite3 2.5.0 (SQLite 3.47.2), pg 1.6.3 and local PostgreSQL 17.12. Install with `BUNDLE_WITHOUT=job:storage:cable:rubocop:mdl:doc bundle install`. PostgreSQL probes use a disposable `qck1_probe` database owned by the local user. The Rails suites create/use their ordinary disposable AR test databases.

From the Lowrail root, with `review` pointing to the extracted archive and `RAILS` set to one worktree:

```sh
export BUNDLE_GEMFILE="$RAILS/Gemfile"
export BUNDLE_WITHOUT=job:storage:cable:rubocop:mdl:doc
DB=sqlite3 PS=true mise exec ruby@4.0.10 -- ruby -rbundler/setup "$review/mutation.rb"
DB=sqlite3 PS=true mise exec ruby@4.0.10 -- ruby -rbundler/setup "$review/reused/probe.rb"
DB=sqlite3 PS=true mise exec ruby@4.0.10 -- ruby -rbundler/setup "$review/reused/collisions.rb"
ARCONN=sqlite3 mise exec ruby@4.0.10 -- ruby -rbundler/setup -C "$RAILS/activerecord" -Itest "$review/reused/suites.rb"
```

Repeat both trees, DB/ARCONN postgresql, PS=false; the probe/collision/initial mutation runs also used `ruby --yjit` with PS=true on both databases. The final fresh-pool mutation harness ran with `ruby --yjit` for both PS=true and false on both databases. The original census probe is copied as `reused/census-probe.rb`; its command is `ruby -rbundler/setup ... true` (and false), with RAILS and BUNDLE_GEMFILE selecting each tree. It is SQLite-only. The own-Gemfile suite counts match: SQLite 1133 runs/3220 assertions and PostgreSQL 1135/3222, zero failures/errors and one skip each. The harness checks the loaded Active Record source, prints cache_sql's source location, and uses seed 8181.

The reused probe, collision and suite scripts came from the already committed qck1-thermos-sol-40e4c9db archive. They were read and reexecuted here, not represented as newly written independent harnesses. The Switchman module they load matches the released 4.3.9 file byte for byte; this is not a full Switchman installation or suite. The new mutation, refresh experiment, and evidence auditor were written here.

## Measurements versus audits

`raw/objects-*.log`: fresh base/head/base allocation workers from `script/upstream-bench --worker objects bench/upstream/census13r/qck1_body.rb`, warmup 500, interpreter and YJIT, with each tree's own Gemfile. All four counts are identical within each mode. These use the suite's sqlite3 2.5.0; do not substitute their absolute counts for the body's different bundle.

`worst-pinned/` is a new unfavorable-input instruction cohort. `commands.sh` records every command, bundle locks record dependencies, and the tool manifest records the pinned Valgrind build. `slowest.rb` uses short SQL and one raw bind with an always-empty async cache. Ruby 4.0.10, fixed heap, warmup 500, N=1000 minus N=0, base/head/base. Instructions rise 0.9% with A/A 0.03%; objects remain 42. No elapsed-time claim is made. The first `/usr` Valgrind attempt was correctly refused by the benchmark tool; its failure log remains. The successful cohort uses script/bench-valgrind's manifest-backed build.

`audit.rb` rereads committed existing body evidence, not a new performance run. Its ROOT expects its original `.amp/in/orb-backup/qck1-astra` placement inside Lowrail; adjust ROOT when running from an extracted archive elsewhere. It verifies exact clean head/base and same Ruby pins, extracts interpreter Callgrind totals, reconstructs all 180 wall-worker logs and their JIT deltas, recomputes estimates and all seeded 5000-resample interval endpoints, and recalculates census medians. `raw/evidence-audit-final.txt` is decisive output. Some hand-written IN-list rows truncate rather than round by less than one instruction. The earlier audit output is retained as an intermediate. `raw/body-object-audit.txt` checks raw base/base2/candidate object logs are identical. The removed final A/A body sentence and unsupported IN-list JIT note are not current findings.

No new Ruby master/ZJIT execution or wall-time measurement was performed. The existing pinned-master/ZJIT cohort was audited. The body does not cite the new adverse-input run.

## Minimum-version checks and extension inventory

`raw/min-versions*.log/json` record script/min-versions on query_cache_test.rb and bind_parameter_test.rb, exact base/head. These supplementary runs use the tool's generated bundles, not the own-Gemfile suite bundles. Build recipes/manifests and generated Gemfiles/locks are retained under `minimum/`. An initial local mirror had no main ref; changing that disposable mirror's origin to canonical Rails allowed the tool to fetch. The first Ruby-floor bundle attempt failed on a missing transient compact-index file; the retained retry is the final outcome. No test failure was suppressed.

`gems/` contains the three fetched release packages and unpacked sources. Fresh metadata and bounded GitHub code-search results are in `raw/`. Switchman writes shard-prefixed Array keys; active_record_host_pool prefixes SQL before calling super; activerecord-precompiled uses an independent three-member namespace key. No released key-reader break was found. This is a bounded inventory, not proof for all extensions. No project from this inventory is cited in the PR body.

The review record in docs/upstream/rails-82-leads-2026-11-27.md, section QCK1 astra, is the verdict and sentence audit. This archive preserves supporting output; it does not authorize an upstream action.
