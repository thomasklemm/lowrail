# Changelog

## 0.1.0 (2026-10-19)

First release. An ahead-of-time compiler for ActiveRecord query chains on
SQLite: the build rewrites chains in app source into calls on precompiled
Sites that run ActiveRecord's own SQL directly on the SQLite handle, keeping
the original chain as the fallback.

- Chains rooted at a model constant: `all`, `where`/`where.not` (hash
  conditions, belongs_to keys, Array values as IN lists), `order` (literals,
  `Arel.sql("...")`), `group`, `limit`, `offset`, static scopes,
  `includes`/`preload`; terminators `to_a`, `first`/`last`/`take` (and `!`),
  `find`, `find_by`/`find_by!`, `count`, `exists?` (with conditions or an id),
  `pluck`, `sum`/`maximum`/`minimum`/`average`, plus `each`/`map`/... with a block.
- Chains rooted at a collection association (`user.posts.where(...)`,
  has_many :through, HABTM), one Site per owner model.
- Precompiled preloads, including through/HABTM associations; whole
  `includes` trees run without the Preloader, mirroring Preloader::Batch
  (rounds, deferral, batching of equal queries).
- friendly_id `friendly.find`, ar_lazy_preload's `auto_preload`, deterministic
  encrypted attributes (including `extend_queries`).
- Fast-path queries are instrumented as `sql.active_record` (logs with
  `filter_attributes`, APM, query counts; `ActiveRecordPrecompiled.active_record_events
  = false` to skip) and as `sql.active_record_precompiled`, and use ActiveRecord's query
  cache store when it is on.
- A schema guard: if the runtime table layout differs from the build's, those
  sites use ActiveRecord.
- `ar_precompile:scopes` reports which scopes compile, and how to fix the rest.
- `ar_precompile:schema:dump` writes the production schema to
  `config/ar_precompile_schema_cache.yml`; the build uses it for a SQLite
  database whose file is missing or has no tables (and removes that file), so
  it runs without the database (`docker build`). Migrations newer than the
  dump run on its tables, rebuilt in memory, so the build sees the schema
  production will have after the deploy.
  The build switches to the dumps after loading the app, so databases that
  models connect to as they load (`connects_to`) get theirs too.
- Loaded Sites keep one copy of each string, bind, preload plan and option
  they share, and allocate caches on first use; a Site object has six
  instance variables (64 bytes on Ruby 4.1, 80 on 4.0; `bench/memory.rb`).

Supports Ruby 3.4+, ActiveRecord 8.0, 8.1 and main (8.2; association keys as
ActiveRecord::Key, October 2026), the sqlite3 adapter;
JRuby 10 with Rails 8.1 and activerecord-jdbc master. The gem no longer
depends on the sqlite3 gem itself (the app's adapter brings its driver).
