# frozen_string_literal: true

require "fileutils"

module ActiveRecordPrecompiled
  # The build needs the production schema (columns, in order, with their
  # types; primary keys), never rows. ActiveRecord's schema cache holds just
  # that, so a dump made on production and committed lets the build run where
  # the production database isn't, as in `docker build`: each SQLite database
  # without a database file becomes an empty in-memory one that answers schema
  # questions from its dump.
  #
  # The dumps are kept apart from ActiveRecord's own (db/schema_cache.yml),
  # which the app would load at boot: at runtime the schema guard must compare
  # against the real database.
  module SchemaDump
    MissingSchema = Class.new(StandardError)

    PATH = "config/ar_precompile_schema_cache.yml"

    # `mode`: "auto" (the default) uses a dump for each database whose file is
    # missing; "dump" uses the dumps even if it isn't; "database" never does.
    MODES = %w[auto dump database].freeze

    class << self
      # Writes the dump of each SQLite database; run it where the production
      # database is, and commit the files.
      def dump(root, out: nil)
        sqlite_pools.uniq { it.db_config.name }.map do |pool|
          path = path(root, pool.db_config)
          ActiveRecord::Tasks::DatabaseTasks.dump_schema_cache(pool, path)
          out&.puts "activerecord-precompiled: wrote the #{pool.db_config.name} schema to #{relative(root, path)}"
          path
        end
      end

      # Points the databases that need it at their dumps; the paths used.
      def use(root, mode: nil, out: nil)
        mode = (mode.nil? || mode.empty?) ? "auto" : mode
        raise ArgumentError, "AR_PRECOMPILE_SCHEMA must be one of #{MODES.join(", ")}, not #{mode.inspect}" unless MODES.include?(mode)
        return [] if mode == "database"

        used = sqlite_pools.filter_map do |pool|
          db_config = pool.db_config
          missing = missing(root, pool)
          next if mode == "auto" && !missing

          path = path(root, db_config)
          unless File.file?(path)
            message = "no #{db_config.name} database at #{db_config.database} and no schema dump at #{relative(root, path)}"
            hint = "run `RAILS_ENV=production bin/rails ar_precompile:schema:dump` where the production database is, and commit the file"
            raise MissingSchema, "activerecord-precompiled: #{message}; #{hint}" if db_config.primary?

            # Solid Cache/Queue/Cable and the like: chains on their models stay
            # with ActiveRecord, and nothing creates an empty database file.
            out&.puts "activerecord-precompiled: #{message}; queries on it are left to ActiveRecord (to compile them, #{hint})"
            repoint(pool, nil)
            remove(root, missing, out) if missing.is_a?(String)
            next
          end
          out&.puts "activerecord-precompiled: #{db_config.name} schema from #{relative(root, path)}"
          migrate(root, repoint(pool, path), path, out)
          remove(root, missing, out) if missing.is_a?(String)
          path
        end
        if used.any?
          # The empty in-memory database has no schema_migrations to check the dump against.
          ActiveRecord::ConnectionAdapters::SchemaReflection.use_schema_cache_dump = true
          ActiveRecord::ConnectionAdapters::SchemaReflection.check_schema_cache_dump_version = false
        end
        used
      end

      # PATH for the primary database, config/ar_precompile_<name>_schema_cache.yml for others.
      def path(root, db_config)
        File.join(root.to_s, db_config.primary? ? PATH : "config/ar_precompile_#{db_config.name}_schema_cache.yml")
      end

      private

      def sqlite_pools
        ActiveRecord::Base.connection_handler.connection_pool_list(:all).select { it.db_config.adapter.to_s.start_with?("sqlite") }
      end

      # Whether the database is missing: true if its file is; the file if it
      # has no tables, which is what connecting while the app loads, before
      # the build, leaves behind (Rails 8's pragmas write a 4 KB header).
      def missing(root, pool)
        database = pool.db_config.database.to_s
        return false if database.empty? || database == ":memory:" || database.start_with?("file:")

        file = File.expand_path(database, root.to_s)
        return true unless File.exist?(file)

        pool.with_connection { it.data_sources.empty? } && file
      end

      # Out of the image: the app would start on it instead of failing.
      def remove(root, file, out)
        FileUtils.rm_f(["", "-wal", "-shm", "-journal"].map { file + it })
        out&.puts "activerecord-precompiled: removed #{relative(root, file)}, a database with no tables (as connecting while the app loads creates)"
      end

      # The same connection (class, role, shard), on an empty in-memory
      # database with the dump (if any) as its schema cache.
      def repoint(pool, path)
        config = pool.db_config
        memory = ActiveRecord::DatabaseConfigurations::HashConfig.new(
          config.env_name, config.name, config.configuration_hash.merge(database: ":memory:", schema_cache_path: path),
        )
        pool_config = pool.pool_config
        ActiveRecord::Base.connection_handler.establish_connection(
          memory, owner_name: pool_config.connection_descriptor, role: pool_config.role, shard: pool_config.shard,
        )
      end

      # A dump older than the newest migration lacks its changes: rebuild the
      # dumped tables, columns in order, and run the newer migrations on them,
      # as production will. SQLite adds a column last and rebuilds a changed
      # table in place, so the order comes out as production's. If a migration
      # can't run on empty tables, the build uses the dump as it is, and the
      # sites it changes fall back to ActiveRecord at runtime.
      def migrate(root, pool, path, out)
        dump = {}
        ActiveRecord::ConnectionAdapters::SchemaCache._load_from(path).encode_with(dump)
        dumped = dump["version"].to_i
        pending = pool.migration_context.migrations.select { it.version > dumped }
        return pool if pending.empty?

        versions = pending.map(&:version).join(", ")
        pool = repoint(pool, nil)
        pool.with_connection do |connection|
          dump["columns"].each { |table, columns| create_table(connection, table, columns, dump["primary_keys"][table]) }
          dump["indexes"].each_value do |indexes|
            indexes.each { connection.add_index(it.table, it.columns, name: it.name, unique: it.unique, where: it.where, order: it.orders) }
          end
          pool.schema_migration.create_table
          pool.migration_context.migrations.each { pool.schema_migration.create_version(it.version.to_s) if it.version <= dumped }
          verbose, ActiveRecord::Migration.verbose = ActiveRecord::Migration.verbose, false
          begin
            pool.migration_context.migrate
          ensure
            ActiveRecord::Migration.verbose = verbose
          end
        end
        out&.puts "activerecord-precompiled: applied migrations #{versions} to #{relative(root, path)}; " \
          "dump it again once they have run on production"
        pool
      rescue StandardError => e
        e = e.cause || e # the Migrator's "this and all later migrations canceled"
        message = "activerecord-precompiled: #{relative(root, path)} is at schema version #{dumped}, and migrations " \
          "#{versions} didn't run on it (#{e.class}: #{e.message.lines.first&.strip}); building from it as it is, " \
          "so the queries they change run on ActiveRecord: dump it again once they have run on production"
        out ? out.puts(message) : ActiveRecordPrecompiled.warn(message)
        repoint(pool, path)
      end

      # The table as the dump has it: columns in order, types, defaults, keys.
      def create_table(connection, table, columns, primary_key)
        keys = Array(primary_key)
        definitions = columns.map do |column|
          sql = +"#{connection.quote_column_name(column.name)} #{column.sql_type}"
          sql << " PRIMARY KEY" if keys == [column.name]
          sql << " AUTOINCREMENT" if keys == [column.name] && column.auto_increment?
          sql << " NOT NULL" unless column.null
          if column.default_function
            sql << " DEFAULT (#{column.default_function})"
          elsif !column.default.nil?
            sql << " DEFAULT #{connection.quote(column.default)}"
          end
          sql << " COLLATE #{connection.quote_column_name(column.collation)}" if column.collation
          sql
        end
        definitions << "PRIMARY KEY (#{keys.map { connection.quote_column_name(it) }.join(", ")})" if keys.size > 1
        connection.execute("CREATE TABLE #{connection.quote_table_name(table)} (#{definitions.join(", ")})")
      end

      def relative(root, path) = path.delete_prefix("#{root}/")
    end
  end
end
