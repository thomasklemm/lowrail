# frozen_string_literal: true

require "prism"

module ActiveRecordPrecompiled
  # Decides whether a scope always builds the same SQL shape, so its SQL can
  # be captured at build time. Static means: one chain of all/where/where.not/order/
  # limit/offset and other static scopes, whose arguments are literals or the
  # scope's own parameters. Enum scopes are static by construction.
  # Anything else raises NotStatic with a reason and a hint.
  class ScopeAnalyzer
    NotStatic = Class.new(StandardError)
    Analysis = Data.define(:arity, :param_columns)

    def initialize
      @trees = {}
    end

    # The belongs_to behind a non-column `where` key: `where(site: x)` binds
    # x (or, for a record, its primary key) to `site_id`. Returns the
    # reflection, or why the key can't be compiled.
    def self.belongs_to_key(model, key)
      reflection = model.reflect_on_association(key.to_sym)
      return "`#{key}` is not a column of #{model.name}" unless reflection
      return "`#{key}` is a #{reflection.macro} association; only belongs_to keys are compiled" unless reflection.belongs_to?
      return "`#{key}` is a polymorphic association" if reflection.polymorphic?
      return "`#{key}` has a composite key" if [reflection.foreign_key, Keys.join_primary_key(reflection)].any?(Array)

      reflection
    end

    def analyze(model, name, depth = 0)
      body = Scopes.body_for(model, name) or raise NotStatic, "`#{name}` is not a scope"
      raise NotStatic, "#{model.name}'s table `#{model.table_name}` doesn't exist" if depth.zero? && !model.table_exists?
      if body == :extension
        raise NotStatic, "it has an extension block (`scope ... do ... end`); define those methods elsewhere"
      end
      if (redefined = redefinition(model, name))
        raise NotStatic, "redefined by #{redefined}; remove that method or the scope"
      end

      analyze_body(model, body, depth)
    end

    # Scopes Rails generates: enum values, has_rich_text (with_rich_text_*),
    # has_*_attached (with_attached_*). Their source interpolates names, but
    # once defined they always build the same relation.
    GENERATED_BY = %w[active_record/enum.rb action_text/attribute.rb active_storage/attached/model.rb].freeze

    def generated_scope?(body)
      body.respond_to?(:source_location) && body.arity.zero? &&
        GENERATED_BY.any? { body.source_location&.first.to_s.end_with?(it) }
    end

    # "path:line" of a method that replaced the scope ActiveRecord generated.
    def redefinition(model, name)
      file, line = model.method(name).source_location
      file.to_s.end_with?("active_record/scoping/named.rb") ? nil : "#{file}:#{line}"
    end

    # A lambda that isn't a named scope, such as an association's scope.
    def analyze_proc(model, body) = analyze_body(model, body, 0)

    private

    def analyze_body(model, body, depth)
      raise NotStatic, "it nests scopes too deeply" if depth > 5
      return Analysis.new(0, {}) if generated_scope?(body)

      file, line = body.source_location
      raise NotStatic, "its source can't be found (defined with eval?)" unless file && File.file?(file)

      lambdas = lambdas_at(file, line)
      raise NotStatic, "its lambda can't be found at #{file}:#{line}" if lambdas.empty?
      raise NotStatic, "#{file}:#{line} has more than one lambda; put the scope on its own line" if lambdas.size > 1

      node = lambdas.first
      params = parameters(node)
      raise NotStatic, "it doesn't take the parameters its source shows" unless body.arity == params.size

      statements = node.body&.body || []
      raise NotStatic, "its body must be a single query chain" unless statements.size == 1

      param_columns = {}
      check_chain(statements.first, model, params, param_columns, depth)
      Analysis.new(params.size, param_columns)
    end

    def lambdas_at(file, line)
      tree = (@trees[file] ||= Prism.parse_file(file).value)
      found = []
      tree.breadth_first_search do |n|
        if n.is_a?(Prism::LambdaNode) && n.location.start_line == line
          found << n
        elsif n.is_a?(Prism::CallNode) && %i[lambda proc].include?(n.name) && n.receiver.nil? &&
            n.block.is_a?(Prism::BlockNode) && n.location.start_line == line
          found << n.block
        end
        false
      end
      found
    end

    def parameters(node)
      return [] if node.parameters.nil?
      unless node.parameters.is_a?(Prism::BlockParametersNode)
        raise NotStatic, "it uses `it` or numbered parameters; name them: ->(x) { ... }"
      end

      p = node.parameters.parameters
      return [] if p.nil?
      plain = p.optionals.empty? && p.rest.nil? && p.posts.empty? && p.keywords.empty? && p.keyword_rest.nil? && p.block.nil?
      unless plain && p.requireds.all?(Prism::RequiredParameterNode)
        raise NotStatic, "it takes optional, splat, keyword or block parameters; use plain required ones"
      end

      p.requireds.map(&:name)
    end

    def check_chain(expr, model, params, param_columns, depth)
      calls = []
      cur = expr
      while cur.is_a?(Prism::CallNode)
        calls.unshift(cur)
        cur = cur.receiver
      end
      if cur || calls.empty?
        raise NotStatic, "`#{code((cur || expr).slice)}` is not a query method; start the body with where/order/limit/offset or a scope"
      end

      calls.each_with_index do |call, i|
        raise NotStatic, "`#{code(call.slice)}` has a block or `&.`" if call.block || call.safe_navigation?

        # `where.not(hash)`: the bare `where` only opens the chain.
        if call.name == :where && call.arguments.nil?
          unless calls[i + 1]&.name == :not
            raise NotStatic, "`#{code(call.slice)}.#{calls[i + 1]&.name}` is not supported; use where(...) or where.not(...)"
          end

          next
        end
        if call.name == :not && !(i.positive? && calls[i - 1].name == :where && calls[i - 1].arguments.nil?)
          raise NotStatic, "`not` without `where`"
        end

        check_call(call, call.arguments&.arguments || [], model, params, param_columns, depth)
      end
    end

    def check_call(call, nodes, model, params, param_columns, depth)
      case call.name
      when :all
        raise NotStatic, "`all` takes no arguments" unless nodes.empty?
      when :where, :not
        unless nodes.size == 1 && (nodes.first.is_a?(Prism::KeywordHashNode) || nodes.first.is_a?(Prism::HashNode))
          raise NotStatic, "`#{code(call.message_loc&.slice)}(#{code(call.arguments&.slice)})` uses an SQL string or other non-hash condition; " \
            "use hash conditions like where(age: a)"
        end
        nodes.first.elements.each { check_condition(it, model, params, param_columns) }
      when :order, :includes, :preload
        nodes.each { literal!(it, "#{call.name} argument") }
        raise NotStatic, "`#{call.name}` needs arguments" if nodes.empty?
      when :limit, :offset
        unless nodes.size == 1 && nodes.first.is_a?(Prism::IntegerNode)
          raise NotStatic, "`#{call.name}` needs an integer literal"
        end
      else
        unless Scopes.body_for(model, call.name)
          raise NotStatic, "`#{call.name}` is not where/order/limit/offset/includes/preload/all or a scope"
        end

        begin
          inner = analyze(model, call.name, depth + 1)
        rescue NotStatic => e
          raise NotStatic, "it uses `#{call.name}`, which can't be compiled: #{e.message}"
        end
        raise NotStatic, "`#{code(call.slice)}` passes the wrong number of arguments" unless inner.arity == nodes.size

        nodes.each_with_index do |node, i|
          if (index = param_index(node, params))
            param_columns[index] ||= inner.param_columns[i]
          else
            literal!(node, "argument to #{call.name}")
          end
        end
      end
    end

    def check_condition(assoc, model, params, param_columns)
      unless assoc.is_a?(Prism::AssocNode) && (assoc.key.is_a?(Prism::SymbolNode) || assoc.key.is_a?(Prism::StringNode))
        raise NotStatic, "`#{code(assoc.slice)}` is not a `column: value` condition"
      end

      column = assoc.key.unescaped
      value = assoc.value
      unless model.columns_hash.key?(column)
        reflection = ScopeAnalyzer.belongs_to_key(model, column)
        raise NotStatic, reflection if reflection.is_a?(String)
        raise NotStatic, "`#{code(assoc.slice)}`: a range on an association" if value.is_a?(Prism::RangeNode)
      end

      if value.is_a?(Prism::RangeNode)
        [value.left, value.right].compact.each { check_value(it, value, column, params, param_columns) }
      else
        check_value(value, value, column, params, param_columns)
      end
    end

    # `whole` is the condition's value (the range, if `node` is one end of it).
    def check_value(node, whole, column, params, param_columns)
      if (index = param_index(node, params))
        param_columns[index] = column
      elsif !literal?(node)
        fixed = whole.slice.sub(node.slice, "x")
        raise NotStatic, "`#{code(node.slice)}` in `#{column}:` is computed when the scope runs; make it a parameter: " \
          "->(x) { where(#{column}: #{code(fixed)}) } and pass the value from the caller"
      end
    end

    # Source quoted in a reason: one line, and short.
    def code(text)
      text = text.to_s.gsub(/\s+/, " ").strip
      text.size > 60 ? "#{text[0, 57]}..." : text
    end

    def param_index(node, params)
      node.is_a?(Prism::LocalVariableReadNode) && node.depth.zero? ? params.index(node.name) : nil
    end

    def literal!(node, what)
      raise NotStatic, "#{what} `#{code(node.slice)}` is not a literal" unless literal?(node)
    end

    def literal?(node)
      case node
      when Prism::SymbolNode, Prism::StringNode, Prism::IntegerNode, Prism::FloatNode,
           Prism::NilNode, Prism::TrueNode, Prism::FalseNode then true
      when Prism::ArrayNode then node.elements.all? { literal?(it) }
      when Prism::RangeNode then [node.left, node.right].compact.all? { literal?(it) }
      when Prism::HashNode, Prism::KeywordHashNode
        node.elements.all? { it.is_a?(Prism::AssocNode) && literal?(it.key) && literal?(it.value) }
      else false
      end
    end
  end
end
