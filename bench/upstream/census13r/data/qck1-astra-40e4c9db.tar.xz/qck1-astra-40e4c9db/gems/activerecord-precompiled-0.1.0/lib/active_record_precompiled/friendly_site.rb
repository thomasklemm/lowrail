# frozen_string_literal: true

module ActiveRecordPrecompiled
  # `Model.friendly.find(id)` from friendly_id, as precompiled Sites taken in
  # the order FriendlyId::FinderMethods#find tries them:
  #
  # * a Numeric id is "unfriendly": find by primary key;
  # * a String is looked up by slug, then (with :history) by old slug, then,
  #   if it parses as an integer, by primary key.
  #
  # Anything else, any step that can't take the fast path, and a miss (which
  # raises FriendlyId's own RecordNotFound) run the original chain.
  class FriendlySite
    def self.define(name, **options)
      Sites.send(:remove_const, name) if Sites.const_defined?(name, false)
      Sites.const_set(name, new(**options))
    end

    def initialize(slug:, id:, history: nil)
      @slug = Sites.const_get(slug, false)
      @history = history && Sites.const_get(history, false)
      @id = Sites.const_get(id, false)
    end

    def call(id, &fallback)
      catch do |tag|
        give_up = ->(*) { throw tag }
        return @id.call(id, &give_up) if id.is_a?(Integer)

        if id.is_a?(String)
          record = @slug.call(id, &give_up) || @history&.call(id, &give_up)
          return record if record
          return @id.call(id, &give_up) if integer?(id)
        end
      end
      fallback.call(id)
    end

    private

    # FriendlyId's potential_primary_key? for an integer primary key.
    def integer?(id)
      Integer(id, 10)
      true
    rescue ArgumentError
      false
    end
  end
end
