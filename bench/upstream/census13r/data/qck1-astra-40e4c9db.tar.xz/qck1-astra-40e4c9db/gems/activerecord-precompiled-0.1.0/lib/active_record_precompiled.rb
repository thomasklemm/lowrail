# frozen_string_literal: true

require "active_record"
require "active_record_precompiled/version"
require "active_record_precompiled/keys"
require "active_record_precompiled/site"
require "active_record_precompiled/friendly_site"
require "active_record_precompiled/assoc_site"
require "active_record_precompiled/preload"
require "active_record_precompiled/scopes"

# Ahead-of-time compiler for ActiveRecord queries on SQLite.
#
# At deploy time ActiveRecordPrecompiled::Build rewrites query chains such as
# `User.where(name: n).first` into calls on a precompiled ActiveRecordPrecompiled::Site,
# which runs ActiveRecord's own SQL directly on the SQLite3 handle. The
# original chain is kept as a block and used whenever the fast path does not
# apply (nil/array arguments, an active `scoping` block, other adapters, ...).
module ActiveRecordPrecompiled
  # Holds one constant per rewritten call site, defined by the BEGIN block
  # appended to each rewritten file.
  module Sites; end

  INTERNED = {}

  class << self
    attr_writer :enabled, :active_record_events

    def enabled? = @enabled != false

    # Fast-path queries are instrumented as `sql.active_record` (logs, APM,
    # query counts, the request's "ActiveRecord: ...ms"); false skips that.
    def active_record_events? = @active_record_events != false

    # One frozen copy of each string and (nested) Array the BEGIN blocks
    # define: sites repeat model names, fingerprints, binds and bind tuples.
    def intern(value)
      case value
      when String then -value
      when Array
        value = value.map { intern(it) }.freeze
        INTERNED[value] ||= value
      else value
      end
    end

    def warn(message)
      logger = defined?(Rails) && Rails.respond_to?(:logger) && Rails.logger
      logger ? logger.warn(message) : Kernel.warn(message)
    end
  end

  autoload :Rewriter, "active_record_precompiled/rewriter"
  autoload :Capture, "active_record_precompiled/capture"
  autoload :Build, "active_record_precompiled/build"
  autoload :ScopeAnalyzer, "active_record_precompiled/scope_analyzer"
  autoload :ScopeCheck, "active_record_precompiled/scope_check"
  autoload :SchemaDump, "active_record_precompiled/schema_dump"
end

ActiveRecordPrecompiled::Scopes.install!
ActiveRecordPrecompiled::Preload.install!

require "active_record_precompiled/railtie" if defined?(Rails::Railtie)
