# frozen_string_literal: true

module ActiveRecordPrecompiled
  # Rewrites application files in place. Meant to run once per release, on the
  # production host (or in the production image build), after the app has
  # booted and the database schema is in place. Never commit the output.
  class Build
    NotProduction = Class.new(StandardError)
    Report = Data.define(:files_changed, :sites, :skipped)

    def initialize(root:, paths: %w[app lib], env: ENV["RAILS_ENV"] || ENV["RACK_ENV"], dry_run: false, force: false, out: nil)
      @root = root.to_s
      @paths = paths
      @env = env
      @dry_run = dry_run
      @force = force
      @out = out
    end

    def run
      unless @force || @env == "production"
        raise NotProduction, "activerecord-precompiled rewrites source in place; run it with RAILS_ENV=production, " \
          "or override with FORCE=1 (rake), --force (CLI) or force: true (Ruby)"
      end

      Capture.verify!

      files_changed = sites = 0
      skipped = []
      files.each do |file|
        relative = file.delete_prefix("#{@root}/")
        result = Rewriter.new(path: relative).rewrite(File.read(file))
        skipped.concat(result.skipped)
        result.skipped.each { @out&.puts "activerecord-precompiled: skipped #{it}" }
        next if result.sites.zero?

        files_changed += 1
        sites += result.sites
        @out&.puts "activerecord-precompiled: #{relative} (#{result.sites} queries)"
        File.write(file, result.source) unless @dry_run
      end
      @out&.puts "activerecord-precompiled: #{sites} queries in #{files_changed} files#{" (dry run)" if @dry_run}"
      Report.new(files_changed, sites, skipped)
    end

    private

    def files
      @paths.flat_map { Dir.glob(File.join(@root, it, "**", "*.rb")) }.sort
    end
  end
end
