# frozen_string_literal: true

module ActiveRecordPrecompiled
  class Railtie < Rails::Railtie
    rake_tasks do
      namespace :ar_precompile do
        desc "Rewrite ActiveRecord queries into precompiled SQLite calls, in place " \
          "(production only unless FORCE=1; DRY_RUN=1 to preview; AR_PRECOMPILE_PATHS=app,lib; " \
          "AR_PRECOMPILE_SCHEMA=auto|dump|database)"
        task build: :environment do
          # After loading the app: rake doesn't eager load, and models connect
          # to their databases (connects_to) as they load.
          Rails.application.eager_load!
          ActiveRecordPrecompiled::SchemaDump.use(Rails.root, mode: ENV["AR_PRECOMPILE_SCHEMA"], out: $stdout)
          ActiveRecordPrecompiled::Build.new(
            root: Rails.root,
            paths: ENV.fetch("AR_PRECOMPILE_PATHS", "app,lib").split(","),
            env: Rails.env,
            dry_run: ENV["DRY_RUN"] == "1",
            force: ENV["FORCE"] == "1",
            out: $stdout,
          ).run
        end

        namespace :schema do
          desc "Write the schema the build needs to #{ActiveRecordPrecompiled::SchemaDump::PATH}, for builds " \
            "without the database (docker build); run on production and commit it (FORCE=1 elsewhere)"
          task dump: :environment do
            unless Rails.env.production? || ENV["FORCE"] == "1"
              abort "activerecord-precompiled: the build needs the production schema; run this with " \
                "RAILS_ENV=production where the production database is, or override with FORCE=1"
            end
            Rails.application.eager_load! # every database a model connects to
            ActiveRecordPrecompiled::SchemaDump.dump(Rails.root, out: $stdout)
          end
        end

        desc "List every scope and whether activerecord-precompiled can compile it (read-only, any environment)"
        task scopes: :environment do
          Rails.application.eager_load!
          ActiveRecordPrecompiled::ScopeCheck.new(root: Rails.root).run(out: $stdout)
        end
      end
    end
  end
end
