# frozen_string_literal: true

module ActiveRecordPrecompiled
  # The columns an association joins on. Rails 8.0 and 8.1 have
  # join_primary_key/join_foreign_key on reflections and
  # LoaderQuery#association_key_name; Rails main dropped the first two (for
  # *_key_definition and association routes) and renamed the third
  # destination_key_name. These answer as the old methods did, on either.
  module Keys
    JOIN_KEYS = ActiveRecord::Reflection::AbstractReflection.method_defined?(:join_foreign_key)

    LOADER_KEY = if ActiveRecord::Associations::Preloader::Association::LoaderQuery.method_defined?(:association_key_name)
      :association_key_name
    else
      :destination_key_name
    end

    class << self
      # The key on the associated table: what its rows are matched on.
      def join_primary_key(reflection, klass = nil)
        return klass ? reflection.join_primary_key(klass) : reflection.join_primary_key if JOIN_KEYS

        reflection = reflection.source_reflection while reflection.through_reflection?
        return reflection.foreign_key unless reflection.belongs_to?

        reflection.polymorphic? ? reflection.association_primary_key(klass) : reflection.association_primary_key
      end

      # The key on the owner's table: the value the associated rows match.
      def join_foreign_key(reflection)
        return reflection.join_foreign_key if JOIN_KEYS

        reflection = reflection.source_reflection while reflection.through_reflection?
        reflection.belongs_to? ? reflection.foreign_key : reflection.active_record_primary_key
      end

      # The column a Preloader query looks its keys up in.
      def loader_key(loader_query) = loader_query.public_send(LOADER_KEY)
    end
  end
end
