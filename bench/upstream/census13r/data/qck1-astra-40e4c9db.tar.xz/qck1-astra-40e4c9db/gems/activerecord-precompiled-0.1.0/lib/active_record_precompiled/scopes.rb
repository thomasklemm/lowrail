# frozen_string_literal: true

module ActiveRecordPrecompiled
  # Remembers every scope's body when the scope is defined, so the build can
  # read its source and decide whether it is static. Installed when the gem
  # loads, which Bundler does before the app's models.
  module Scopes
    module Recorder
      def scope(name, body, &block)
        super.tap { (@__ar_precompiled_scopes ||= {})[name.to_sym] = block ? :extension : body }
      end
    end

    def self.install!
      named = ActiveRecord::Scoping::Named::ClassMethods
      named.prepend(Recorder) unless named <= Recorder
    end

    # The body given to `scope`, looked up through STI parents; :extension if
    # the scope has an extension block; nil if `name` is not a scope.
    def self.body_for(model, name)
      model.ancestors.each do |klass|
        break if klass == ActiveRecord::Base
        next unless klass.is_a?(Class)

        body = klass.instance_variable_get(:@__ar_precompiled_scopes)&.[](name.to_sym)
        return body if body
      end
      nil
    end
  end
end
