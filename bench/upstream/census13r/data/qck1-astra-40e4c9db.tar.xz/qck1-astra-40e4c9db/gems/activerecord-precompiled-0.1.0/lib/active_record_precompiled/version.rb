# frozen_string_literal: true

module ActiveRecordPrecompiled
  VERSION = "0.1.0"
end
