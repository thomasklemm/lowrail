# frozen_string_literal: true

module ActiveRecordPrecompiled
  # Build-time only: runs a real ActiveRecord terminator (`first`, `count`,
  # `find`, ...) but intercepts the query at the adapter, so we get the exact
  # SQL and binds ActiveRecord would send, without touching any data.
  module Capture
    Query = Data.define(:sql, :binds)

    Broken = Class.new(StandardError)

    # Every relation read (records, count, pluck, exists?, find_by_sql) goes
    # through `select_all`, on 8.0/8.1 and on Rails main, where the private
    # `select` it used to call is gone. Compile the SQL and binds the way
    # `select_all` does and return an empty result instead of running it.
    module AdapterHook
      def select_all(arel, name = nil, binds = [], preparable: nil, **)
        log = Thread.current[:__ar_precompiled_capture]
        return super unless log

        sql, binds, = to_sql_and_binds(arel_from_relation(arel), binds, preparable)
        log << Query.new(sql, binds)
        ActiveRecord::Result.empty
      end
    end

    # Placeholder for a runtime argument. ActiveRecord keeps it as the
    # `value_before_type_cast` of the bind it creates (possibly a dup, hence
    # the index), which tells us which `?` belongs to which argument. It is a
    # String so that types which validate input (enums) can be satisfied.
    # `record_key` is set for a belongs_to key (`where(site: x)`): the runtime
    # value may be a record, whose primary key ActiveRecord binds instead.
    class Sentinel < String
      attr_reader :index, :record_key

      def self.for(type, index, record_key: nil)
        sentinel = new(index, record_key:)
        return sentinel if bindable?(sentinel, type)

        label = type.respond_to?(:mapping, true) && type.send(:mapping).keys.first
        label ? new(index, label.to_s, record_key:) : sentinel
      end

      # Would ActiveRecord turn this value into a plain `column = ?` bind?
      def self.bindable?(value, type)
        attribute = ActiveRecord::Relation::QueryAttribute.new("probe", value, type)
        !attribute.nil? && !attribute.unboundable?
      end

      def initialize(index, text = "__ar_precompiled_arg_#{index}__", record_key: nil)
        super(text)
        @index = index
        @record_key = record_key
        freeze
      end
    end

    # Proves the hook still sees queries on this Rails version. Without this a
    # Rails change would make every chain "run 0 queries" and the build would
    # succeed while rewriting nothing.
    def self.verify!
      pool = ActiveRecord::Base.connection_handler.connection_pool_list(:all)
        .find { it.db_config.adapter.to_s.start_with?("sqlite") }
      return unless pool

      captured = pool.with_connection { |conn| queries { conn.select_all("SELECT 1 AS ar_precompiled_probe") } }
      return if captured.any? { it.sql.include?("ar_precompiled_probe") }

      raise Broken, "activerecord-precompiled cannot capture queries on ActiveRecord #{ActiveRecord.version}; " \
        "nothing was rewritten. This ActiveRecord version is not supported yet."
    end

    def self.install!
      ActiveRecord::ConnectionAdapters::SQLite3Adapter.prepend(AdapterHook) unless
        ActiveRecord::ConnectionAdapters::SQLite3Adapter <= AdapterHook
    end

    # Yields, returning every query ActiveRecord tried to run. Errors raised
    # because the result was empty (RecordNotFound) are expected.
    def self.queries
      install!
      log = []
      previous = Thread.current[:__ar_precompiled_capture]
      Thread.current[:__ar_precompiled_capture] = log
      begin
        ActiveRecord::Base.uncached { yield }
      rescue ActiveRecord::RecordNotFound
      ensure
        Thread.current[:__ar_precompiled_capture] = previous
      end
      log
    end
  end
end
