# frozen_string_literal: true

module ActiveRecordPrecompiled
  # A chain on a collection association: `owner.posts.where(name: n).first`
  # becomes `AssocSite.call(owner.posts, n) { |proxy, n| proxy.where(name: n).first }`.
  # The build compiled one Site per model with such an association, with the
  # owner's key as its first bind; the CollectionProxy says which owner and
  # which key this call is for.
  #
  # The original chain runs when the proxy isn't one of those, when the owner
  # is a new record or loads strictly, and, for a terminator called on the
  # association itself (`posts.first`, `posts.count`), when the association is
  # loaded or holds unsaved records: ActiveRecord may answer from memory then.
  class AssocSite
    def self.define(name, **options)
      Sites.send(:remove_const, name) if Sites.const_defined?(name, false)
      Sites.const_set(name, new(**options))
    end

    # `owners`: owner class name => [Site name, owner key attribute].
    def initialize(association:, direct:, owners:)
      @association = association
      @direct = direct
      @owners = owners
      @by_class = {}.compare_by_identity
    end

    def call(proxy, *args, &fallback)
      return fallback.call(proxy, *args) unless proxy.is_a?(ActiveRecord::Associations::CollectionProxy)

      association = proxy.proxy_association
      owner = association.owner
      site, key_name = entry_for(owner.class)
      return fallback.call(proxy, *args) unless site && association.reflection.name == @association
      return fallback.call(proxy, *args) if owner.new_record? || owner.strict_loading? || association.reflection.strict_loading?
      return fallback.call(proxy, *args) if @direct && (association.loaded? || !association.target.empty?)

      key = owner._read_attribute(key_name)
      return fallback.call(proxy, *args) unless key.is_a?(Integer) || key.is_a?(String)

      result = site.call(key, *args) { fallback.call(proxy, *args) }
      case result
      when ActiveRecord::Base then loaded(association, result)
      when Array then result.each { loaded(association, it) if it.is_a?(ActiveRecord::Base) }
      end
      result
    end

    private

    # As AssociationRelation#exec_queries: the record points back to the
    # owner and takes its strict_loading mode.
    def loaded(association, record)
      association.set_inverse_instance_from_queries(record)
      association.set_strict_loading(record)
    end

    def entry_for(klass)
      @by_class.fetch(klass) do
        site, key = @owners[klass.name]
        @by_class[klass] = site ? [Sites.const_get(site, false), key] : nil
      end
    end
  end
end
