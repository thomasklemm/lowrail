# frozen_string_literal: true

# Bundler requires the gem by its name.
require "active_record_precompiled"
