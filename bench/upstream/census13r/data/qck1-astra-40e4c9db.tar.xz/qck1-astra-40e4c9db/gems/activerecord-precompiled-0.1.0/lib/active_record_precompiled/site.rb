# frozen_string_literal: true

require "bigdecimal"
require "digest"
require "date"
require "active_support/time_with_zone"

module ActiveRecordPrecompiled
  # A precompiled query. `sql` and `binds` were captured from ActiveRecord at
  # build time; each bind is either `[:arg, index, attribute]` (a runtime
  # argument, serialized with the attribute's type exactly like a
  # Relation::QueryAttribute) or `[:val, value]` (a constant already in
  # database form). `[:arg, index, attribute, key]` is a belongs_to key:
  # a record argument binds its `key` (`where(site: site)` binds site.id).
  # `[:enc, index, attribute, size, state]` is a deterministic encrypted
  # attribute, encrypted at runtime (see Rewriter#encrypted_spec).
  class Site
    # Values ActiveRecord turns into a single `column = ?` bind. Anything else
    # (nil, Array, Range, Relation, records, ...) changes the SQL shape.
    SCALARS = [String, Symbol, Integer, Float, BigDecimal, true, false, Time, Date, ActiveSupport::TimeWithZone].freeze
    FALLBACK = Object.new.freeze
    # Arrays longer than this go to ActiveRecord (as preloads do; well under
    # SQLite's bind limit), and at most this many IN-list shapes are cached.
    MAX_LIST = 100
    MAX_SHAPES = 256
    # Published for fast-path queries only; fallbacks emit `sql.active_record` as usual.
    EVENT = "sql.active_record_precompiled"
    AR_EVENT = "sql.active_record"
    # On JRuby the sqlite3 adapter is activerecord-jdbc's.
    JDBC = RUBY_ENGINE == "jruby"
    # ActiveRecord's query payload has `affected_rows` from 8.1 on.
    AFFECTED_ROWS = ActiveRecord.gem_version >= Gem::Version.new("8.1")
    QUERY_NAMES = { count: "Count", group_count: "Count", calculate: nil, group_calculate: nil, exists: "Exists?", pluck: "Pluck" }.freeze

    def self.define(name, **options)
      Sites.send(:remove_const, name) if Sites.const_defined?(name, false)
      Sites.const_set(name, new(**options))
    end

    # Identifies the table layout the SQL was built against. Column order
    # matters: it decides attribute order whenever the SQL lists columns.
    def self.fingerprint(columns) = Digest::SHA256.hexdigest(columns.map { it.join(":") }.join(","))[0, 16]
    def self.schema_of(model) = fingerprint(model.columns.map { [it.name, it.sql_type] })

    # What a Site needs besides its SQL and binds, one object for all Sites
    # with the same: every Site is allocated as large as the Site with the
    # most instance variables, so they are kept here. `lists` are the bind
    # positions an Array may take (see Rewriter#in_lists), `ids` the argument
    # indices that must be an Integer or String id, `calc` [operation, column]
    # for sum/maximum/minimum/average. `lazy: false` for a bare
    # `Model.find(id)`: ActiveRecord answers it from a cached statement, not
    # Relation#load, so ar_lazy_preload doesn't see it. The preload
    # `registry` and `trees` are built on first use from the other members.
    STATIC_OPTIONS = %i[model_name schema lists ids group calc lazy preload plans].freeze
    Options = Struct.new(*STATIC_OPTIONS, :registry, :trees) do
      def self.for(**options)
        values = ActiveRecordPrecompiled.intern(options.values_at(*STATIC_OPTIONS))
        OPTIONS[values] ||= new(*values)
      end
    end
    OPTIONS = {}

    attr_reader :kind, :sql, :binds

    def initialize(model:, kind:, sql:, binds:, schema: nil, lists: nil, ids: nil, group: nil, calc: nil, preload: nil, preload_plans: nil, lazy: true)
      @options = Options.for(model_name: model, schema:, lists:, ids:, group:, calc:, lazy:, preload:,
                             plans: preload_plans&.map { Preload::Plan.for(it) })
      @kind = kind
      @sql = -sql
      @binds = ActiveRecordPrecompiled.intern(binds)
    end

    # The model, or false if its schema differs from the build's.
    def model
      @model = verified_model if @model.nil?
      @model
    end

    def call(*args, &fallback)
      options = @options
      return fallback.call(*args) unless ActiveRecordPrecompiled.enabled? && (model = self.model) && model.current_scope.nil?
      return fallback.call(*args) if options.preload && temporary_lazy_preload?
      return fallback.call(*args) if options.ids&.any? { !(args[it].is_a?(Integer) || args[it].is_a?(String)) }

      result = model.with_connection do |conn|
        next FALLBACK unless conn.is_a?(ActiveRecord::ConnectionAdapters::SQLite3Adapter)

        values, lists = type_cast_binds(conn, model, args)
        next FALLBACK if values.equal?(FALLBACK)

        execute(conn, lists ? shape(lists)[0] : @sql, values, lists)
      end
      return fallback.call(*args) if result.equal?(FALLBACK)

      materialize(model, *result) { fallback.call(*args) }
    end

    private

    # Checked once per site: if the runtime schema is not the one the build
    # saw, the frozen SQL may select the wrong columns, so defer to AR for good.
    def verified_model
      model = Object.const_get(@options.model_name)
      return model if @options.schema.nil? || Site.schema_of(model) == @options.schema

      ActiveRecordPrecompiled.warn("activerecord-precompiled: #{@options.model_name} schema differs from build time; " \
        "using ActiveRecord for this query. Build from a fresh checkout after db:migrate.")
      false
    end

    # [values, lists]: the bind values, and for each bind given an Array the
    # number of values in its IN list (nil if there are none).
    def type_cast_binds(conn, model, args)
      values = []
      lists = nil
      @binds.each_with_index do |bind, at|
        case bind[0]
        when :val then values << bind[1]
        when :key then values << Site.db_value(conn, args[bind[1]]) # checked by AssocSite
        when :enc then values.concat(encrypted_binds(conn, model, args, bind) || (return FALLBACK))
        else
          value = args[bind[1]]
          if value.is_a?(Array) && @options.lists&.include?(at)
            return FALLBACK if value.empty? || value.size > MAX_LIST

            # One value is the scalar SQL, as in PredicateBuilder::ArrayHandler.
            if value.size > 1
              value.each do |element|
                cast = cast_arg(conn, model, bind, element, list: true)
                return FALLBACK if cast.equal?(FALLBACK)

                values << cast
              end
              (lists ||= {})[at] = value.size
              next
            end
            value = value[0]
          end
          cast = cast_arg(conn, model, bind, value)
          return FALLBACK if cast.equal?(FALLBACK)

          values << cast
        end
      end
      [values, lists]
    end

    # An argument in database form, or FALLBACK if ActiveRecord would build
    # different SQL for it. In an IN list (`list`), HomogeneousIn drops
    # values that don't serialize, so those fall back too.
    def cast_arg(conn, model, bind, value, list: false)
      value = value.public_send(bind[3]) if bind[3] && value.is_a?(ActiveRecord::Base)
      return FALLBACK unless SCALARS.any? { it === value }
      return FALLBACK if value.respond_to?(:infinite?) && value.infinite?

      type = model.type_for_attribute(bind[2])
      return FALLBACK unless type.serializable?(value)

      serialized = type.serialize(value)
      # Mirrors QueryAttribute#nil?: AR would emit `IS NULL` here.
      return FALLBACK if serialized.nil? && (list || type.respond_to?(:subtype) || type.respond_to?(:normalizer))

      Site.db_value(conn, serialized)
    end

    # [SQL, bind names] for the IN lists of these sizes (bind position =>
    # size; nil for none), cached per shape; the names are filled in when
    # first needed.
    def shape(lists)
      (@shapes ||= {})[lists] || begin
        shape = [lists ? list_sql(lists) : @sql, nil]
        @shapes.size < MAX_SHAPES ? (@shapes[lists] = shape) : shape
      end
    end

    # The SQL with IN lists of these sizes.
    def list_sql(lists)
      sql = +@sql
      lists.map { |at, size| [*Site.list_span(@sql, at), size] }.sort_by { -it[0] }.each do |start, stop, negated, size|
        sql[start...stop] = "#{negated ? " NOT IN" : " IN"} (#{Array.new(size, "?").join(", ")})"
      end
      sql.freeze
    end

    # [start, stop, negated]: where the `= ?` (`!= ?`) of bind `at` is, the
    # part an IN list replaces.
    def self.list_span(sql, at)
      question = placeholder_offset(sql, at)
      negated = sql[question - 4, 5] == " != ?"
      [negated ? question - 4 : question - 3, question + 1, negated]
    end

    # Offset of the n-th `?` placeholder, skipping quoted strings and names.
    def self.placeholder_offset(sql, n)
      seen = -1
      sql.scan(/'(?:[^']|'')*'|"(?:[^"]|"")*"|\?/) do
        next unless $~[0] == "?"

        seen += 1
        return $~.begin(0) if seen == n
      end
      nil
    end

    # A deterministic encrypted attribute: the ciphertext, then (with
    # extend_queries) the value as each previous type stores it. Only Strings
    # get the extra values, so anything else, or a different encryption setup
    # than the build saw, would change the SQL.
    def encrypted_binds(conn, model, args, (_, index, attribute, size, state))
      value = args[index]
      type = model.type_for_attribute(attribute)
      return nil unless value.is_a?(String) && Site.encrypted?(type) && Site.encryption_state(type) == state

      types = size == 1 ? [type] : [type, *type.previous_types]
      return nil unless types.size == size

      types.map { Site.db_value(conn, it.serialize(value)) }
    end

    def self.encrypted?(type)
      defined?(ActiveRecord::Encryption::EncryptedAttributeType) && type.is_a?(ActiveRecord::Encryption::EncryptedAttributeType)
    end

    # What decides how ActiveRecord binds a deterministic encrypted value.
    def self.encryption_state(type)
      extended = defined?(ActiveRecord::Encryption::ExtendedDeterministicQueries::RelationQueries) &&
        ActiveRecord::Relation <= ActiveRecord::Encryption::ExtendedDeterministicQueries::RelationQueries
      [type.previous_types.size, extended ? 1 : 0]
    end

    def execute(conn, sql, values, lists)
      Site.execute(conn, sql, values, "#{@options.model_name} #{QUERY_NAMES.fetch(@kind, "Load") || @options.calc[0].capitalize}", self, lists)
    end

    public

    # [name, type] per bind, for the `sql.active_record` payload: the
    # attribute names let log filtering (filter_attributes) apply.
    def bind_names(lists)
      shape(lists)[1] ||= begin
        model = self.model
        @binds.each_with_index.flat_map do |bind, at|
          case bind[0]
          when :val, :key then [[bind[2], ActiveModel::Type.default_value]]
          when :enc then Array.new(bind[3], [bind[2], model.type_for_attribute(bind[2])])
          else Array.new(lists&.[](at) || 1, [bind[2], model.type_for_attribute(bind[2])])
          end
        end
      end
    end

    private

    CACHE_KEY = :active_record_precompiled

    # Runs precompiled SQL; [columns, rows]. Shared with preload plans.
    #
    # With ActiveRecord's query cache on (QueryCache#select_all), the result
    # is kept in the connection's own cache store: the same store, so the
    # same lifetime (cleared by any write, by `uncached`, LRU-evicted), under
    # a key of our own. A hit is published like ActiveRecord's ("CACHE").
    def self.execute(conn, sql, values, name, names = nil, shape = nil)
      return query(conn, sql, values, name, names, shape) unless conn.query_cache_enabled

      key = [CACHE_KEY, sql, values]
      hit = true
      result = conn.lock.synchronize do
        conn.query_cache.compute_if_absent(key) do
          hit = false
          query(conn, sql, values, name, names, shape)
        end
      end
      cache_hit(conn, sql, values, name, names, shape, result[1].size) if hit
      result
    end

    # QueryCache#cache_notification_info, for a hit.
    def self.cache_hit(conn, sql, values, name, names, shape, row_count)
      notifier = ActiveSupport::Notifications.notifier
      if ActiveRecordPrecompiled.active_record_events? && notifier.listening?(AR_EVENT)
        ActiveSupport::Notifications.instrumenter.instrument(
          AR_EVENT,
          sql: sql, binds: attributes(names&.bind_names(shape), values), type_casted_binds: values, name: name,
          connection: conn, transaction: conn.current_transaction.user_transaction.presence, cached: true,
          row_count: row_count, precompiled: true,
        )
      end
      if notifier.listening?(EVENT)
        ActiveSupport::Notifications.instrumenter.instrument(EVENT, sql: sql, name: name, binds: values, cached: true, row_count: row_count)
      end
    end

    # Instrumented as ActiveRecord instruments a query (AbstractAdapter#log),
    # so logs, APM and query counts see it, and as `sql.active_record_precompiled`.
    # `names.bind_names(shape)` gives the binds' names, only when needed.
    def self.query(conn, sql, values, name, names = nil, shape = nil)
      notifier = ActiveSupport::Notifications.notifier
      own = notifier.listening?(EVENT)
      ar = ActiveRecordPrecompiled.active_record_events? && notifier.listening?(AR_EVENT)
      return run(conn, sql, values) unless own || ar

      return instrument_own(conn, sql, values, name) unless ar

      binds = attributes(names&.bind_names(shape), values)
      payload = {
        sql: sql, name: name, binds: binds, type_casted_binds: values, async: false, allow_retry: false,
        connection: conn, transaction: conn.current_transaction.user_transaction.presence,
        row_count: 0, precompiled: true,
      }
      payload[:affected_rows] = 0 if AFFECTED_ROWS
      ActiveSupport::Notifications.instrumenter.instrument(AR_EVENT, payload) do
        (own ? instrument_own(conn, sql, values, name) : run(conn, sql, values)).tap { payload[:row_count] = it[1].size }
      end
    end

    def self.instrument_own(conn, sql, values, name)
      ActiveSupport::Notifications.instrumenter.instrument(EVENT, sql: sql, name: name, binds: values) do |payload|
        run(conn, sql, values).tap { payload[:row_count] = it[1].size }
      end
    end

    def self.attributes(names, values)
      values.each_with_index.map do |value, i|
        name, type = names&.[](i)
        ActiveModel::Attribute.with_cast_value(name, value, type || ActiveModel::Type.default_value)
      end
    end

    # The same steps as SQLite3::DatabaseStatements#perform_query, minus
    # logging, query cache and Arel compilation.
    def self.run(conn, sql, values)
      return run_jdbc(conn, sql, values) if JDBC
      conn.__send__(:with_raw_connection) do |db|
        stmt = statement(conn, db, sql)
        stmt.reset!
        stmt.bind_params(values) unless values.empty?
        rows = stmt.to_a
        conn.__send__(:verified!)
        [stmt.columns, rows]
      end
    end

    # A serialized value as the driver binds it. activerecord-jdbc binds
    # serialized values itself (a Time becomes "... 03:04:05.000000"), so on
    # JRuby it is left as is, as ActiveRecord leaves it.
    def self.db_value(conn, value) = JDBC ? value : conn.type_cast(value)

    # Constants baked into generated code: plain values only.
    def self.db_constant(conn, value)
      value = db_value(conn, value)
      [String, Integer, Float, NilClass, *([TrueClass, FalseClass] if JDBC)].any? { it === value } ? value : FALLBACK
    end

    # JRuby: activerecord-jdbc's raw connection runs the prepared statement,
    # as its internal_exec_query does inside `log` (instrumented above instead).
    def self.run_jdbc(conn, sql, values)
      result = conn.__send__(:with_raw_connection) do |raw|
        if values.empty?
          raw.execute_query(sql)
        else
          binds = values.map { ActiveModel::Attribute.with_cast_value(nil, it, ActiveModel::Type.default_value) }
          cached = conn.__send__(:fetch_cached_statement, sql) if conn.instance_variable_get(:@jdbc_statement_cache_enabled)
          raw.execute_prepared_query(sql, binds, cached)
        end
      end
      [result.columns, result.rows]
    end

    def self.statement(conn, db, sql)
      pool = conn.instance_variable_get(:@statements)
      if pool
        pool[sql] ||= db.prepare(sql)
      else
        cache = (db.instance_variable_get(:@__ar_precompiled) || db.instance_variable_set(:@__ar_precompiled, {}))
        stmt = cache[sql]
        stmt = cache[sql] = db.prepare(sql) if stmt.nil? || stmt.closed?
        stmt
      end
    end

    # ar_lazy_preload's auto_preload: Relation#load registers what it loaded,
    # so the records' associations load in batches later.
    def self.lazy_preload(records)
      return unless defined?(ArLazyPreload) && ArLazyPreload.config.auto_preload?

      ArLazyPreload::Context.register(records: records)
    end

    def materialize(model, columns, rows)
      case @kind
      when :records then load_records(model, columns, rows)
      when :one then rows.empty? ? nil : load_records(model, columns, rows[0, 1]).first
      when :one! then rows.empty? ? yield : load_records(model, columns, rows[0, 1]).first
      when :last then rows.empty? ? nil : load_records(model, columns, [rows.last]).first
      when :count then rows[0][0].to_i
      when :group_count then group_count(model, rows)
      when :calculate then calculated(model, rows.dig(0, 0))
      when :group_calculate then grouped(model, rows) { calculated(model, it) }
      when :exists then !rows.empty?
      when :pluck then pluck(model, columns, rows)
      else raise ArgumentError, "unknown site kind #{@kind.inspect}"
      end
    end

    # As Relation#load: instantiate, then hand includes/preload to ActiveRecord.
    def load_records(model, columns, rows)
      records = model._load_from_sql(ActiveRecord::Result.new(columns, rows))
      preload = @options.preload
      if preload && !records.empty?
        registry = preload_registry
        preload.each_with_index do |associations, i|
          if (tree = preload_tree(model, i, associations, registry))
            tree.call(records, registry)
          else
            Preload.with(registry) { ActiveRecord::Associations::Preloader.new(records: records, associations: associations).call }
          end
        end
      end
      Site.lazy_preload(records) if @options.lazy
      records
    end

    # Inside ar_lazy_preload's TemporaryPreloadConfig.within_context, records
    # preloaded by includes/preload get a context too; ActiveRecord does that.
    def temporary_lazy_preload?
      defined?(ArLazyPreload::Contexts::TemporaryPreloadConfig) && ArLazyPreload::Contexts::TemporaryPreloadConfig.enabled?
    end

    def preload_registry
      return nil unless @options.plans

      @options.registry ||= Preload.registry(@options.plans)
    end

    # A Preload::Tree for the i-th includes/preload value, if it qualifies;
    # built once, from the plans that passed verification.
    def preload_tree(model, i, associations, registry)
      return nil unless registry

      trees = (@options.trees ||= {})
      return trees[i] if trees.key?(i)

      plans, inner = @options.plans.select(&:loader_query).partition { it.via.nil? }
      trees[i] = Preload::Tree.build(model, associations, plans.to_h { [[it.owner_name, it.name], it] }, inner.to_h { [it.via, it] })
    end

    # As a grouped Calculations#count: the count comes first, then the group
    # columns, cast with their attribute types; one column keys by its value.
    def group_count(model, rows) = grouped(model, rows, &:to_i)

    def grouped(model, rows)
      types = @options.group.map { model.type_for_attribute(it) }
      rows.each_with_object({}) do |row, result|
        key = types.size == 1 ? types[0].deserialize(row[1]) : types.each_with_index.map { |type, i| type.deserialize(row[i + 1]) }
        result[key] = yield row[0]
      end
    end

    # Calculations#type_cast_calculated_value, with the column's type.
    def calculated(model, value)
      operation, column = @options.calc
      type = model.type_for_attribute(column)
      type = type.subtype if type.is_a?(ActiveRecord::Enum::EnumType)
      case operation
      when "sum" then type.deserialize(value || 0)
      when "average" then %i[integer decimal].include?(type.type) ? value&.to_d : type.deserialize(value)
      else type.deserialize(value)
      end
    end

    def pluck(model, columns, rows)
      types = columns.map { model.type_for_attribute(it) }
      if types.one?
        type = types[0]
        rows.map { |(value)| type.deserialize(value) }
      else
        rows.map { |row| Array.new(row.size) { types[it].deserialize(row[it]) } }
      end
    end
  end
end
