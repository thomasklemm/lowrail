# frozen_string_literal: true

module Switchman
  module ActiveRecord
    module Migration
      module Compatibility
        module V5_0 # rubocop:disable Naming/ClassAndModuleCamelCase
          def create_table(*args, **options)
            options[:id] = :bigserial unless options.key?(:id)
            super
          end
        end
      end

      def connection
        conn = super
        if conn.shard != ::ActiveRecord::Base.current_switchman_shard
          ::ActiveRecord::Base.connection_pool.switch_database(conn)
        end
        conn
      end
    end

    module Migrator
      # significant change: use the shard name instead of the database name
      # in the lock id. Especially if you're going through pgbouncer, the
      # database name you're accessing may not be consistent
      def generate_migrator_advisory_lock_id
        db_name_hash = Zlib.crc32(Shard.current.name)
        shard_name_hash = ::ActiveRecord::Migrator::MIGRATOR_SALT * db_name_hash
        # Store in internalmetadata to allow other tools to be able to lock out migrations
        @internal_metadata[:migrator_advisory_lock_id] = shard_name_hash.to_s
        shard_name_hash
      end

      def use_advisory_lock?
        super && pending_migrations.any?
      end
    end

    module MigrationContext
      def migrate(...)
        schema_cache_holder = ::ActiveRecord::Base.connection_pool
        schema_cache_holder = schema_cache_holder.schema_reflection
        previous_schema_cache = schema_cache_holder.instance_variable_get(:@cache)

        schema_cache_holder.instance_variable_get(:@cache)

        reset_column_information
        schema_cache_holder.clear!

        begin
          super
        ensure
          if ::Rails.version < "7.2"
            schema_cache_holder.set_schema_cache(previous_schema_cache)
          else
            schema_cache_holder.instance_variable_set(:@cache, previous_schema_cache)
          end
          reset_column_information
        end
      end

      def migrations
        return @migrations if instance_variable_defined?(:@migrations)

        migrations_cache = Thread.current[:migrations_cache] ||= {}
        key = Digest::MD5.hexdigest(migration_files.sort.join(","))
        @migrations = migrations_cache[key] ||= super
      end

      private

      def reset_column_information
        ::ActiveRecord::Base.descendants.reject { |m| m <= UnshardedRecord }.each(&:reset_column_information)
      end
    end
  end
end
