require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
connection = ActiveRecord::Base.lease_connection
connection.enable_query_cache!
connection.clear_query_cache
UpstreamBench.report("empty cache async miss") do
  connection.select_all("SELECT ?", nil, [11], async: true).result
end
