require "json"
require "zlib"
require "open3"

ROOT = File.expand_path("../../../..", __dir__)
BODY = File.join(ROOT, "bench/upstream/census13r/body")
HEAD = "40e4c9db8fcb00afc252ab554ebaa778efd51180"
BASE = "2e299253f942ab94041cc6f210ac9d33884c210d"

%w[QCK1-exact QCK1-exact-master QCK1-wall-yjit QCK1-wall-zjit QCK1-ips].each do |name|
  data = JSON.parse(File.read("#{BODY}/#{name}/results.json"))
  raise "wrong head #{name}" unless data.dig("sides", "candidate", "head") == HEAD && data.dig("sides", "base", "head") == BASE
  raise "dirty #{name}" if data.fetch("sides").values.any? { _1.fetch("dirty") }
  raise "different Ruby #{name}" unless data["sides"].values.map { _1["description"] }.uniq.size == 1
  puts "#{name}: exact head/base, clean trees, one Ruby pin"
end

%w[QCK1-exact QCK1-exact-master QCK1-inlist].each do |name|
  totals = {}
  IO.popen(["tar", "-tJf", "#{BODY}/#{name}/callgrind-dumps.tar.xz"]) do |io|
    io.each_line do |entry|
      entry = entry.strip
      next unless entry.include?("-interp-") && entry.end_with?(".callgrind")
      text, status = Open3.capture2("tar", "-xOJf", "#{BODY}/#{name}/callgrind-dumps.tar.xz", entry)
      raise "tar failed" unless status.success?
      totals[File.basename(entry)] = Integer(text.match(/^totals: (\d+)/)[1])
    end
  end
  cases = totals.keys.grep(/-base-n0/).map { _1.sub(/-base-n0.callgrind$/, "") }
  cases.each do |key|
    count = 2000.0
    values = %w[base candidate base2].to_h { |side| [side, (totals.fetch("#{key}-#{side}-n2000.callgrind") - totals.fetch("#{key}-#{side}-n0.callgrind")) / count] }
    mean = (values["base"] + values["base2"]) / 2.0
    puts "#{name} #{key}: #{mean.round} -> #{values['candidate'].round}; AA=#{((values['base2']/values['base']-1)*100).round(4)}%"
  end
end

def median(xs)
  ys = xs.sort
  (ys[(ys.size - 1) / 2] + ys[ys.size / 2]) / 2.0
end

%w[QCK1-wall-yjit QCK1-wall-zjit].each do |name|
  data = JSON.parse(File.read("#{BODY}/#{name}/results.json"))
  data.fetch("wall").each do |label, cell|
    measured = (1..30).map do |round|
      %w[base candidate base2].to_h do |side|
        raw = File.read("#{BODY}/#{name}/raw/wall-r#{round}-#{side}.log")
        sample = JSON.parse(raw.lines.find { _1.start_with?("wall #{label}\t") }.split("\t", 2).last)
        raise "sample mismatch" unless sample == cell["rounds"][round - 1][side]
        raise "wrong windows" unless sample["cpu"].size == 30
        jit = raw.lines.find { _1.start_with?("jit #{label}\t") }
        raise "JIT moved" unless jit && jit.scan(/=(\d+)>(\d+)/).all? { |a,b| a == b }
        [side, Math.log(sample["cpu"].sort[3] / cell["calls"])]
      end
    end
    change = Math.exp(median(measured.flat_map { |r| [r["candidate"]-r["base"], r["candidate"]-r["base2"]] }))-1
    aa = Math.exp(median(measured.map { |r| r["base2"]-r["base"] }))-1
    raise "aggregate mismatch" unless (change-cell["change"]).abs < 1e-12 && (aa-cell["aa"]).abs < 1e-12
    raise "interval failure" unless cell["change_ci"].last < 0 && cell["aa_ci"].first <= 0 && cell["aa_ci"].last >= 0
    %w[change aa].each do |kind|
      rng = Random.new(1)
      samples = Array.new(5000) do
        logs = Array.new(30) { measured[rng.rand(30)] }.flat_map do |r|
          kind == "aa" ? [r["base2"]-r["base"]] : [r["candidate"]-r["base"], r["candidate"]-r["base2"]]
        end
        median(logs)
      end.sort
      ci = samples.values_at(124, 4875).map { Math.exp(_1)-1 }
      raise "CI mismatch" unless ci.zip(cell["#{kind}_ci"]).all? { |a,b| (a-b).abs < 1e-12 }
    end
    puts "#{name} #{label}: change #{(100*change).round(4)}%, AA #{(100*aa).round(4)}%; raw rounds and recomputed CIs match"
  end
end

labels = %w[r13m r13m2 r13qck4].to_h do |label|
  path = File.join(ROOT, "docs/upstream/data/rails-82-leads/labels/#{label}-interpreter.json.gz")
  [label, JSON.parse(Zlib::GzipReader.open(path, &:read))]
end
raise "census wrong head" unless labels["r13qck4"].dig("meta", "rails", "sha") == HEAD
raise "census Ruby pins" unless labels.values.map { _1.dig("meta", "ruby") }.uniq.size == 1
workloads = labels.transform_values { |v| v["runs"].flat_map { |r| r["workloads"].map { |w| [[r["app"], w["workload"]], w["ir_per_op"]] } }.to_h }
raise "different workloads" unless workloads.values.map { _1.keys.sort }.uniq.size == 1
delta = workloads["r13qck4"].to_h { |k,v| [k, 100*(v/workloads["r13m"].fetch(k)-1)] }
aa = workloads["r13m2"].to_h { |k,v| [k, 100*(v/workloads["r13m"].fetch(k)-1)] }
upper = ->(xs) { xs.sort[xs.size/2] }
puts "Census #{delta.size} workloads; median #{upper.call(delta.values)}%, min #{delta.values.min}%, max #{delta.values.max}%"
puts "Census AA median #{upper.call(aa.values)}%, p90 absolute #{aa.values.map(&:abs).sort[(aa.size*0.9).floor]}%"
delta.group_by { |k,v| k.first }.each { |app, rows| puts "Census #{app}: #{upper.call(rows.map(&:last))}%" }
