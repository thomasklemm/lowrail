import csv
import gzip
import json
import math
from pathlib import Path
import random
import re
import statistics
import tarfile

ROOT = Path.cwd()
BODY = ROOT / "bench/upstream/census13r/body"
HEAD = "40e4c9db8fcb00afc252ab554ebaa778efd51180"
BASE = "2e299253f942ab94041cc6f210ac9d33884c210d"

def close(actual, expected):
    assert math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-10), (actual, expected)

def objects(path):
    return {name: float(value) for name, value in re.findall(r"^objects (.+?)(?:\\t|\t)(\S+)$", path.read_text(), re.M)}

body_rows = [(int(a.replace(",", "")), int(b.replace(",", ""))) for a, b in re.findall(
    r"^\| .+ \| ([\d,]+) \| ([\d,]+) \|$", (ROOT / "bench/upstream/pr-queue/items/QCK1.md").read_text(), re.M)]
expected_rows = []
for directory in ("QCK1-exact", "QCK1-exact-master", "QCK1-inlist"):
    path = BODY / directory
    totals = {}
    with tarfile.open(path / "callgrind-dumps.tar.xz") as archive:
        for member in archive:
            if member.isfile() and member.name.endswith(".callgrind"):
                lines = archive.extractfile(member).read().decode().splitlines()
                counts = [int(line.split()[1]) for line in lines if line.startswith("totals:")]
                assert len(counts) == 1, member.name
                totals[Path(member.name).name] = counts[0]
    results = json.loads((path / "results.json").read_text()) if (path / "results.json").exists() else None
    if results:
        assert results["sides"]["base"]["head"] == BASE
        assert results["sides"]["candidate"]["head"] == HEAD
        assert results["sides"]["base"]["description"] == results["sides"]["candidate"]["description"]
        assert not any(side["dirty"] for side in results["sides"].values())
        cells = list(results["instructions"].items())
    else:
        cases = ["where(id: 20 ids), miss", "where(id: 20 ids), hit", "where(id: 100 ids), miss", "where(id: 100 ids), hit"]
        cells = [("interp " + case, None) for case in cases]
        assert HEAD in (path / "HEADS.md").read_text()
    derived = {}
    for key, cell in cells:
        mode, case = key.split(" ", 1)
        slug = re.sub(r"[^A-Za-z0-9]+", "_", case).strip("_")
        candidates = [name for name in totals if re.fullmatch(rf"ir-{mode}-\d+-{slug}-candidate-n2000.callgrind", name)]
        assert len(candidates) == 1, (directory, key, candidates)
        prefix = candidates[0].removesuffix("-candidate-n2000.callgrind")
        values = {side: (totals[f"{prefix}-{side}-n2000.callgrind"] - totals[f"{prefix}-{side}-n0.callgrind"]) / 2000
            for side in ("base", "candidate", "base2")}
        mean_base = (values["base"] + values["base2"]) / 2
        change = values["candidate"] / mean_base - 1
        aa = abs(values["base2"] - values["base"]) / mean_base
        if cell:
            for field, value in (("base", mean_base), ("base1", values["base"]), ("base2", values["base2"]), ("candidate", values["candidate"]), ("change", change), ("aa", aa)):
                close(cell[field], value)
        counts = [objects(path / f"raw/objects-{mode}-{side}.log")[case] for side in ("base", "candidate", "base2")]
        assert len(set(counts)) == 1, (directory, key, counts)
        if cell and "jit" in cell:
            for window in cell["jit"]["windows"]:
                match = re.fullmatch(r"(base2?|candidate) n(\d+)", window["window"])
                raw = (path / f"raw/{prefix}-{match[1]}-n{match[2]}.log").read_text()
                raw_counters = {name: [int(a), int(b)] for name, a, b in re.findall(r"(\w+)=(\d+)>(\d+)", raw)}
                assert raw_counters == window["counters"]
            assert cell["jit"]["flat"] == all(a == b for w in cell["jit"]["windows"] for a, b in w["counters"].values())
        derived[key] = (mean_base, values["candidate"])
        print(f"{directory} {key}: {mean_base:.4f}/{values['candidate']:.4f}, change {change*100:.6f}%, A/A {aa*100:.6f}%, objects {counts[0]}")
    if directory == "QCK1-exact":
        expected_rows.extend(derived[f"interp {case}"] for case in ("find, hit", "find, miss", "where with 3 binds, hit", "where with 3 binds, miss"))
    if directory == "QCK1-inlist":
        expected_rows.extend(derived[f"interp where(id: {n} ids), {state}"] for n in (20, 100) for state in ("hit", "miss"))
assert len(expected_rows) == len(body_rows) == 8
assert all(abs(a - b) < 1 for actual, shown in zip(expected_rows, body_rows) for a, b in zip(actual, shown)), (expected_rows, body_rows)
print("All eight body rows match independent dump-total derivation within one Ir/call; manual IN-list table truncates some fractional counts")

for mode in ("yjit", "zjit"):
    path = BODY / f"QCK1-wall-{mode}"
    result = json.loads((path / "results.json").read_text())
    assert result["sides"]["base"]["head"] == BASE and result["sides"]["candidate"]["head"] == HEAD
    assert result["sides"]["base"]["description"] == result["sides"]["candidate"]["description"]
    process_logs = list((path / "raw").glob("wall-r*-*.log"))
    assert len(process_logs) == 90
    logs = {file.stem.removeprefix("wall-"): file.read_text() for file in process_logs}
    for case, cell in result["wall"].items():
        assert len(cell["rounds"]) == 30 and cell["quantile"] == 0.1
        ratios, aas = [], []
        for index, cohort in enumerate(cell["rounds"], 1):
            estimates = {}
            for side, windows in cohort.items():
                raw = dict(re.findall(r"^wall (.+?)(?:\\t|\t)(\{.*\})$", logs[f"r{index}-{side}"], re.M))
                assert json.loads(raw[case]) == windows
                assert len(windows["cpu"]) == 30 and len(windows["wall"]) == 30
                estimates[side] = math.log(sorted(windows["cpu"])[3] / cell["calls"])
            ratios.append([estimates["candidate"] - estimates["base"], estimates["candidate"] - estimates["base2"]])
            aas.append([estimates["base2"] - estimates["base"]])
        change = math.expm1(statistics.median([x for row in ratios for x in row]))
        aa = math.expm1(statistics.median([row[0] for row in aas]))
        close(change, cell["change"])
        close(aa, cell["aa"])
        for window in cell["jit"]["windows"]:
            raw = logs[window["window"].replace(" ", "-")]
            counters = dict(re.findall(r"^jit (.+?)(?:\\t|\t)(.*)$", raw, re.M))[case]
            assert {name: [int(a), int(b)] for name, a, b in re.findall(r"(\w+)=(\d+)>(\d+)", counters)} == window["counters"]
            assert all(a == b for a, b in window["counters"].values())
        assert len(cell["jit"]["windows"]) == 90
        assert cell["change_ci"][1] < 0 and cell["aa_ci"][0] <= 0 <= cell["aa_ci"][1]
        bootstrap = []
        for rows in (ratios, aas):
            rng = random.Random(2811)
            estimates = sorted(statistics.median([x for _ in range(30) for x in rows[rng.randrange(30)]]) for _ in range(5000))
            bootstrap.append([math.expm1(estimates[124]), math.expm1(estimates[4875])])
        assert bootstrap[0][1] < 0 and bootstrap[1][0] <= 0 <= bootstrap[1][1]
        print(f"wall {mode} {case}: change {change*100:.6f}%, A/A {aa*100:.6f}%; raw samples and JIT counters match; independent bootstrap signs pass")
print("180 raw process logs checked; independent Python RNG confirms CI signs, not original Ruby seeded endpoints")

data = ROOT / "docs/upstream/data/rails-82-leads"
labels = {label: json.loads(gzip.decompress((data / f"labels/{label}-interpreter.json.gz").read_bytes())) for label in ("r13m", "r13m2", "r13qck4")}
maps = {label: {(run["app"], row["workload"]): row["ir_per_op"] for run in obj["runs"] for row in run["workloads"]} for label, obj in labels.items()}
assert len(maps["r13m"]) == 36 and set(maps["r13m"]) == set(maps["r13m2"]) == set(maps["r13qck4"])
assert labels["r13qck4"]["meta"]["rails"]["sha"] == HEAD
assert len({run["ruby"] for obj in labels.values() for run in obj["runs"]}) == 1
table = list(csv.DictReader((data / "per-workload.tsv").open(), delimiter="\t"))
changes, aas = [], []
apps = {}
for row in table:
    key = (row["app"], row["workload"])
    for label in maps:
        assert abs(float(row[label]) - maps[label][key]) <= 0.50001
    delta = (maps["r13qck4"][key] / maps["r13m"][key] - 1) * 100
    aa = (maps["r13m2"][key] / maps["r13m"][key] - 1) * 100
    assert abs(delta - float(row["qck4%"])) < 0.0051 and abs(aa - float(row["aa%"])) < 0.0051
    changes.append(delta)
    aas.append(aa)
    apps.setdefault(key[0], []).append(delta)
upper = lambda xs: sorted(xs)[len(xs) // 2]
print(f"census: {len(changes)} workloads, upper-middle median {upper(changes):.6f}%, min {min(changes):.6f}%, max {max(changes):.6f}%, A/A median {upper(aas):.6f}%")
print("per-app:", {app: upper(values) for app, values in apps.items()})
assert all(abs(delta) < 1 for delta in changes)
print("All census label/TSV cells and none-beyond-1% claim verified")
