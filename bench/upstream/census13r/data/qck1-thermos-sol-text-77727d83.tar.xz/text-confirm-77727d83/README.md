# QCK1 thermos-sol text/evidence confirm

Reviewer/orb: thermos-sol, T-01a21eb9-c0e3-733d-b394-fbdeda571174, 2026-11-28.
Reviewed Lowrail source: 77727d83c9353600b6e8201ebdd9e227d826345d.
Rails base: 2e299253f942ab94041cc6f210ac9d33884c210d.
Rails head: 40e4c9db8fcb00afc252ab554ebaa778efd51180.

`reviewed-QCK1.md` is the queue item before this pass was appended. `provenance.txt`
records the source commit and checksums of the summary files and Callgrind archives.
The full raw process logs are already retained at that Lowrail source commit.

Run `python -u PATH/TO/audit.py` from the Lowrail repository root with the retained
source data present. `audit.txt` is the successful output. This independently
reconstructs instruction cells and census changes, matches timing samples/counters,
and recomputes timing estimates and bootstrap interval signs. The independent
Python RNG does not reproduce the Ruby bootstrap's exact seeded endpoints.

No framework suite, differential probe or fresh timing was run for this text-only
confirm. Their existing exact-head evidence is linked in the QCK1 thermos-sol
review section. Review findings are recorded there and in the item's latest pass.
