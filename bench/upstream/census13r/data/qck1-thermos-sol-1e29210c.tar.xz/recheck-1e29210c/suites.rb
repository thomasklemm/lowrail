require "active_record"
expected = File.join(ENV.fetch("RAILS"), "activerecord")
actual = Gem.loaded_specs.fetch("activerecord").full_gem_path
abort "wrong Active Record: #{actual}, expected #{expected}" unless actual == expected
puts "Active Record source: #{actual}"
puts "cache_sql source: #{ActiveRecord::ConnectionAdapters::AbstractAdapter.instance_method(:cache_sql).source_location.inspect}"
puts "Key defined: #{ActiveRecord::ConnectionAdapters::QueryCache::Store.const_defined?(:Key)}"
ARGV.replace(["--seed", "8181"])
%w[query_cache_test.rb finder_test.rb bind_parameter_test.rb relation_test.rb statement_cache_test.rb asynchronous_queries_test.rb].each { require "cases/#{_1}" }
Dir["test/cases/relation/*_test.rb"].sort.each { require File.expand_path(_1) }
