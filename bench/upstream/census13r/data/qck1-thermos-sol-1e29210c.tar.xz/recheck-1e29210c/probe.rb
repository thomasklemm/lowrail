# frozen_string_literal: true

require "active_record"
require "json"

adapter = ENV.fetch("DB", "sqlite3")
config = { adapter: adapter, database: adapter == "sqlite3" ? ":memory:" : "qck1_probe", query_cache: 3,
  prepared_statements: ENV.fetch("PS", "true") == "true" }
ActiveRecord::Base.establish_connection(config)
ActiveRecord::Base.logger = nil
connection = ActiveRecord::Base.lease_connection
load ENV["KEY_VARIANT"] if ENV["KEY_VARIANT"]
pool = ActiveRecord::Base.connection_pool
pool.enable_query_cache!
events = []
ActiveSupport::Notifications.subscribe("sql.active_record") do |*, payload|
  events << (payload[:cached] ? "cache" : "db") unless payload[:name] == "SCHEMA"
end
sql = adapter == "sqlite3" ? "SELECT CAST(? AS INTEGER) AS value" : "SELECT CAST($1 AS INTEGER) AS value"
text_sql = adapter == "sqlite3" ? "SELECT CAST(? AS TEXT) AS value" : "SELECT CAST($1 AS TEXT) AS value"
qa = ->(n) { ActiveRecord::Relation::QueryAttribute.new("n", n, ActiveRecord::Type::Integer.new) }
query = ->(binds, query_sql = sql, async = false) do
  result = connection.select_all(query_sql, "Probe", binds, async: async)
  result = result.result if result.respond_to?(:result)
  result.rows
end
show = lambda do |label, &block|
  events.clear
  result = begin
    block.call
  rescue => error
    [error.class.name, error.message.lines.first.strip.sub(/ for .*$/, "")]
  end
  puts JSON.generate(label: label, result: result, events: events, size: connection.query_cache.size)
end
clear = -> { connection.clear_query_cache }

show.call("raw scalar hit and distinct") { clear.call; [query.call([11]), query.call([11]), query.call([37])] }
show.call("QA hit and distinct") { clear.call; [query.call([qa.call(11)]), query.call([qa.call(11)]), query.call([qa.call(37)])] }
show.call("no bind mixed") { [connection.select_all("SELECT 71").rows, connection.select_all("SELECT 71").rows, query.call([37])] }
show.call("LRU eviction and promotion") { clear.call; [11, 37, 59, 11, 71, 11, 37].map { query.call([qa.call(_1)]) } }
show.call("raw mutable string") do
  clear.call
  value = +"alpha"
  binds = [value]
  first = query.call(binds, text_sql)
  value.replace("beta")
  [first, query.call(binds, text_sql), query.call(["beta"], text_sql), query.call(["alpha"], text_sql)]
end
show.call("raw mutable bind array") do
  clear.call
  binds = [11]
  first = query.call(binds)
  binds[0] = 37
  [first, query.call(binds), query.call([37]), query.call([11])]
end
class QASubclass < ActiveRecord::Relation::QueryAttribute; end
show.call("QA subclass") do
  clear.call
  [11, 11, 37].map { query.call([QASubclass.new("n", _1, ActiveRecord::Type::Integer.new)]) }
end
class ArraySubclass < Array; end
class StringSubclass < String; end
show.call("array subclass") { clear.call; [11, 11, 37].map { query.call(ArraySubclass[_1]) } }
show.call("string subclass") { clear.call; ["alpha", "alpha", "beta"].map { query.call([StringSubclass.new(_1)], text_sql) } }
show.call("singleton conversions not used") do
  clear.call
  binds = [11]
  def binds.to_ary = raise("unexpected to_ary")
  def binds.to_a = raise("unexpected to_a")
  [query.call(binds), query.call(binds)]
end
module EqualityExtension
  def eql?(other) = super
end
show.call("extended binds") { clear.call; [11, 11, 37].map { query.call([_1].extend(EqualityExtension)) } }
class PrependedBinds < Array
  prepend EqualityExtension
end
show.call("prepended binds subclass") { clear.call; [11, 11, 37].map { query.call(PrependedBinds[_1]) } }
show.call("duck typed raw value rejection") do
  clear.call
  value = Object.new
  def value.method_missing(name, *) = name == :to_int ? 11 : super
  def value.respond_to_missing?(name, *) = name == :to_int || super
  query.call([value])
end
show.call("frozen arguments") { clear.call; [11, 11, 37].map { query.call([_1].freeze, sql.freeze) } }
show.call("Arel sql literal") { clear.call; [11, 11, 37].map { query.call([_1], Arel.sql(sql)) } }
show.call("async hit and empty miss") do
  clear.call
  [query.call([11], sql, true), query.call([11]), query.call([11], sql, true), query.call([37], sql, true)]
end
show.call("uncached") { clear.call; connection.uncached { [query.call([11]), query.call([11])] } }
show.call("version invalidation") do
  clear.call
  [query.call([11]), query.call([11]), pool.query_cache.instance_variable_get(:@version).increment && query.call([11])]
end
class PrivateEqualityArray < Array
  private
    def eql?(other) = super
end
show.call("private eql array subclass") { clear.call; [11, 11].map { query.call(PrivateEqualityArray[_1]) } }
show.call("singleton private eql bind array") do
  clear.call
  make = -> { [11].tap { |a| a.singleton_class.class_eval { private; def eql?(other) = super } } }
  [query.call(make.call), query.call(make.call)]
end
show.call("same-identity eql false") do
  clear.call
  binds = [11]
  def binds.eql?(other) = false
  [query.call(binds), query.call(binds)]
end
show.call("bind hash raises async empty") do
  clear.call
  bind = qa.call(11)
  def bind.hash = raise("hash called")
  query.call([bind], sql, true)
end
show.call("mutating custom serialization") do
  clear.call
  klass = Class.new(ActiveRecord::Type::Integer) do
    attr_accessor :binds
    def serialize(value)
      binds << 37 if binds && binds.length == 1
      super
    end
  end
  type = klass.new
  bind = ActiveRecord::Relation::QueryAttribute.new("n", 11, type)
  binds = [bind]
  type.binds = binds
  query.call(binds)
end
show.call("empty lookup hash count") do
  clear.call
  calls = []
  binds = [11]
  binds.define_singleton_method(:hash) { calls << :hash; super() }
  [query.call(binds, sql, true), calls]
end
class FreshProbe < ActiveRecord::Base
  self.abstract_class = true
end
FreshProbe.establish_connection(config)
fresh = FreshProbe.lease_connection
FreshProbe.connection_pool.enable_query_cache!
show.call("genuinely fresh async hash raises") do
  bind = qa.call(11)
  def bind.hash = raise("unneeded hash called")
  fresh.select_all(sql, "Probe", [bind], async: true).result.rows
end
class PrivateEqualitySQL < String
  private
    def eql?(other) = super
end
show.call("private eql SQL string subclass") do
  clear.call
  [11, 11].map { query.call([_1], PrivateEqualitySQL.new(sql)) }
end
show.call("fiber suspension inside bind hash") do
  clear.call
  bind = qa.call(11)
  fired = false
  bind.define_singleton_method(:hash) do
    unless fired
      fired = true
      Fiber.yield :suspended
    end
    super()
  end
  fiber = Fiber.new { query.call([bind]) }
  [fiber.resume, fiber.resume]
end
show.call("switchman-shaped cache_sql override") do
  clear.call
  connection.singleton_class.prepend(Module.new do
    private
      def cache_sql(sql, name, binds)
        query_cache.compute_if_absent(binds.empty? ? sql : [sql, binds]) { yield }.dup
      end
  end)
  [query.call([11]), query.call([11], sql, true), query.call([11])]
end
require "rails/version"
require_relative "switchman/lib/switchman/active_record/query_cache"
show.call("actual switchman cache_sql override") do
  clear.call
  connection.singleton_class.prepend(Switchman::ActiveRecord::QueryCache)
  def connection.shard = Struct.new(:id).new(11)
  [query.call([11]), query.call([11], sql, true), query.call([11])]
end
