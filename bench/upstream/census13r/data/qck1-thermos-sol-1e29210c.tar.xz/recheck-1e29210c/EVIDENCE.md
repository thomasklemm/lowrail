# QCK1 follow-up on 1e29210c886662fdbf337a2b2e36252171c37eb5

2026-11-27, thermos-sol, T-01a21eb9-c0e3-733d-b394-fbdeda571174. Both rubrics applied personally. Code and corrected prose pass; overall changes verdict remains pending replacement of old-head performance claims. No additional upstream regression test is required for the native Struct equality shape.

Base: 2e299253f942ab94041cc6f210ac9d33884c210d. Ruby: 4.0.10 a704b7cd95, interpreter and YJIT. Rails source checkout `../rails-new` is unmodified. `reviewed.diff` and `pins.txt` identify it. The original review archive holds baseline probe observations and the Switchman module needed by the unchanged probe.rb. This follow-up archive holds new-head observations, logs and bundles; it is not an independent Callgrind or timing cohort.

## Reproduction

From the Lowrail root, scratch is `$PWD/.amp/in/orb-backup/qck1`, with Rails base and new checkouts at rails-base and rails-new. The probe bundle is ../Gemfile (retained here as probe-Gemfile). Run the original probe.rb with RAILS pointing to rails-new, BUNDLE_GEMFILE to that probe bundle, DB=sqlite3/postgresql and PS=true/false. Run prepared-statements-on again with ruby --yjit. Each emits 29 observations. All new-head/base differences are limited to the previously accepted unprefixed private cache_sql override; private Array/String eql?, singleton-private eql? and non-reflexive same-identity bind arrays now match base on both databases and JIT modes. Actual Switchman still has the same existing async miss. Original-probe logs rerun Lowrail's census13r/probe.rb with prepared statements on/off and are byte-identical to retained main outputs.

Allocation worker, run in order base/new/base2, with RAILS and UPSTREAM_BENCH_TREE both set to that checkout, BUNDLE_GEMFILE to the probe bundle:

```
UPSTREAM_BENCH_WARMUP=500 RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000 RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000 mise exec ruby@4.0.10 -- ruby -rbundler/setup script/upstream-bench --worker objects bench/upstream/census13r/qck1_body.rb
```

Base and A/A are identical: find miss 51.999, hit 38; where miss 91, hit 77 objects/call. New: 52.999/39/92/78. Every row adds one object. key-memory-new.txt shows a newly retained ivar-storage reference after first Struct#hash. The previous three-member Struct experiment cached the hash in a field, not an ivar, and was allocation-neutral; this two-member implementation is different. This does not by itself require a source change; updated CPU/timing evidence must justify the tradeoff, and the old “objects unchanged” assertion must not be carried forward.

Suites: from rails-new/activerecord, RAILS points to rails-new and BUNDLE_GEMFILE to rails-new/Gemfile, BUNDLE_WITHOUT=job:storage:cable:rubocop:mdl:doc, ARCONN=sqlite3/postgresql:

```
mise exec ruby@4.0.10 -- ruby -rbundler/setup -Itest /absolute/path/to/qck1/suites.rb
```

The harness validates the loaded Active Record path. New-head SQLite: 1133 runs, 3220 assertions, zero failures/errors, one skip. PostgreSQL 17.12: 1135 runs, 3222 assertions, zero failures/errors, one skip. Same as the retained base controls. Includes query_cache, finder, bind_parameter, relation_test, relation/*, statement_cache, asynchronous_queries; seed 8181.

Maintainability: `bundle exec flog -am FILE` on base/new gives 189.4/192.6 total, new hash 1.2; manual eql? removed. `bundle exec rubocop --config /dev/null --enable-pending-cops --only Metrics --format json FILE` gives the same six existing offenses on both. This intentionally compares default Metrics consistently, not the full Rails style bundle. The first attempted project-config run lacked rubocop-minitest, and a subsequent Metrics/* spelling was rejected; those incomplete outputs are not passing checks. The files named `rubocop-*-default.json` with six offenses are the completed comparison.
