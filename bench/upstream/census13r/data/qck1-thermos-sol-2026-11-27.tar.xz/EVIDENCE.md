# QCK1 thermos-sol evidence, 2026-11-27

Reviewer thread: T-01a21eb9-c0e3-733d-b394-fbdeda571174. Both Thermos rubrics were applied by the reviewer, without delegation. Verdict: changes. Rails source checkouts were not edited; alternate keys were loaded only in the probe/benchmark processes.

## Pins and files

- `rails-base`: rails/rails main 2e299253f942ab94041cc6f210ac9d33884c210d.
- `rails-repo`: thomasklemm/rails e1978ba23b366a27eb627bfda1132e17d6e6a916.
- Measured b41aaa307b912180881a677f4256886722b184c3 and review head have tree 619e7726d09180ff32680cde3722fd3fcf84e76e. The commit message, not source, changed.
- Ruby 4.0.10, revision a704b7cd95, x86_64-linux. This review orb is not a timing orb; no wall-time performance claim was made.
- `pins.txt` records the source revisions, tree identities, environment and extracted dependency versions. `rails-{base,repo}-Gemfile.lock` retain the actual suite bundles; the archive's top-level Gemfile/lock are the separate probe/tool bundle.
- Switchman module source at dc8a54325d0dc21da59ab72f82b7f421dd87645a is retained at the path required by `probe.rb`; the complete gem was not booted. Only the adapter's shard accessor was stubbed.

## Differential probe

Run from the Lowrail repository root, with the two Rails checkouts restored at the paths above (or update paths in the commands). PostgreSQL uses disposable local database `qck1_probe` and the local OS user; no production data or credentials are involved.

```
scratch="$PWD/.amp/in/orb-backup/qck1"
RAILS="$scratch/rails-base" DB=sqlite3 PS=true BUNDLE_GEMFILE="$scratch/Gemfile" mise exec ruby@4.0.10 -- bundle exec ruby "$scratch/probe.rb"
RAILS="$scratch/rails-repo" DB=sqlite3 PS=true BUNDLE_GEMFILE="$scratch/Gemfile" mise exec ruby@4.0.10 -- bundle exec ruby "$scratch/probe.rb"
```

Repeat with DB=postgresql and PS=false. `probe-*-{base,repo}.jsonl` are the raw observations; `probe-yjit-*` repeat prepared-statements-on with Ruby `--yjit`. Compare rows, cache notifications, cache size, exceptions, conversion sentinels and fiber results. The `private eql` and same-identity cases demonstrate the correctness regression. The unprefixed custom cache_sql override loses an async cache hit on head; the actual Switchman override already misses asynchronously on base because it prefixes SQL with the shard ID.

`original-probe-*` are fresh reruns of Lowrail's kept census13r/probe.rb, byte-identical for base/head with prepared statements on/off. Its find_by_sql SQL-array input interpolates values, not raw adapter bind arguments. `standalone-*` and `load-order-*` record successful direct require and require-after-active_record on each tree.

Set KEY_VARIANT to the absolute path to `array_key.rb` or `struct_key.rb` when running head to reproduce the alternative-shape observations. Both use built-in C composite equality. Struct keeps the extra cached hash in a third field. The Array variant allocates hidden ivar storage on first hash and costs an extra object per lookup; it is not allocation-neutral.

## Active Record suites

Use each checkout's own root Gemfile. The harness aborts if the loaded activerecord gem path is not that checkout, then prints cache_sql's source location and whether Key exists. From each checkout's activerecord directory:

```
RAILS=/absolute/path/to/rails-base BUNDLE_GEMFILE=/absolute/path/to/rails-base/Gemfile BUNDLE_WITHOUT=job:storage:cable:rubocop:mdl:doc ARCONN=sqlite3 mise exec ruby@4.0.10 -- ruby -rbundler/setup -Itest /absolute/path/to/qck1/suites.rb
```

Repeat for rails-repo and ARCONN=postgresql. The root-Gemfile suite logs are `own-gemfile-*`. SQLite: 1133 runs, 3220 assertions, zero failures/errors, one skip on each tree. PostgreSQL 17.12: 1135 runs, 3222 assertions, zero failures/errors, one skip on each tree. A failed concurrent PostgreSQL setup hit an unavailable locale in the second test-server slot; that log is retained separately and the successful base run is sequential. Earlier `suite-*` logs used the top-level probe Gemfile with verified source paths; they are not the root-Gemfile counts cited in the review.

## Instructions, objects and shape

`body-recheck`, `stress-data`, `raw-hits-data`, `struct-data` contain complete script/upstream-bench runs, base/A/A/candidate raw windows, commands, Gemfiles/locks, manifests, JSON and tables. Each comparison uses one Ruby pin. Object counts are objects, and Callgrind Ir is instructions, not elapsed time. Every counted benchmark uses the script's fixed heap and N-minus-zero window. Keep commands.sh as a record; its historical absolute paths must be restored or adjusted before replay.

- body-recheck: original qck1_body.rb, warmup 3000, N=2000, interpreter.
- stress-data: stress.rb, warmup 100, N=100, interpreter; distinct-key synchronous misses, empty-cache async misses with short and 1 MiB SQL, and no-bind control.
- raw-hits-data: raw-hits.rb, warmup 500, N=500, interpreter; short raw-bind synchronous/async hits.
- struct-data: body-struct.rb loads struct_key.rb only for candidate, then the kept qck1_body.rb find cases; warmup 500, N=500, interpreter. This is an experiment, not approval of an implemented Rails patch.

Top-level body-array.rb and key-memory.txt retain the allocation experiment; object counts were read through upstream-bench's object worker, not asserted in an upstream test. Flog and RuboCop Metrics JSON/logs retain the before/after maintainability measurements. The six existing Metrics offenses are unchanged.
