Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `raw single bind, hit` | 24 | 24 | 103,696 | 102,934 | −0.7% |
| `raw single bind, async hit` | 23 | 23 | 100,729 | 99,468 | −1.3% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/qck1/raw-hits-data.
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/qck1/rails-base at 2e299253f9
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/qck1/rails-repo at e1978ba23b
- interp raw single bind, hit: instructions −0.7% with A/A 0.09% (base 103,741 / 103,652, candidate 102,934)
- interp raw single bind, async hit: instructions −1.3% with A/A 0.14% (base 100,660 / 100,799, candidate 99,468)
