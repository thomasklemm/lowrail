# frozen_string_literal: true
require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
connection = ActiveRecord::Base.lease_connection
ActiveRecord::Base.connection_pool.enable_query_cache!
sql = "SELECT CAST(? AS INTEGER)".freeze
connection.select_all(sql, "Bench", [11])
UpstreamBench.report("raw single bind, hit") { connection.select_all(sql, "Bench", [11]) }
UpstreamBench.report("raw single bind, async hit") { connection.select_all(sql, "Bench", [11], async: true).result }
