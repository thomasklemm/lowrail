Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `find, miss` | 52 | 52 | 321,203 | 312,445 | −2.7% |
| `find, hit` | 38 | 38 | 244,724 | 235,702 | −3.7% |
| `where with 3 binds, miss` | 91 | 91 | 604,098 | 593,494 | −1.8% |
| `where with 3 binds, hit` | 77 | 77 | 540,957 | 530,108 | −2.0% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/qck1/body-recheck.
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/qck1/rails-base at 2e299253f9
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/qck1/rails-repo at e1978ba23b
- interp find, miss: instructions −2.7% with A/A 0.09% (base 321,340 / 321,067, candidate 312,445)
- interp find, hit: instructions −3.7% with A/A 0.05% (base 244,791 / 244,657, candidate 235,702)
- interp where with 3 binds, miss: instructions −1.8% with A/A 0.01% (base 604,082 / 604,114, candidate 593,494)
- interp where with 3 binds, hit: instructions −2.0% with A/A 0.00% (base 540,953 / 540,961, candidate 530,108)
