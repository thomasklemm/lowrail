# frozen_string_literal: true
require "active_record"

def connection_for(name)
  klass = Object.const_set(name, Class.new(ActiveRecord::Base))
  klass.abstract_class = true
  klass.establish_connection(adapter: "sqlite3", database: ":memory:")
  connection = klass.lease_connection
  klass.connection_pool.enable_query_cache!
  connection
end

raw = connection_for("RawBench")
async = connection_for("AsyncBench")
large = connection_for("LargeBench")
none = connection_for("NoBindBench")
sql = "SELECT CAST(? AS INTEGER)".freeze
long_sql = "#{sql} /*#{"x" * 1_048_576}*/".freeze
value = 0
UpstreamBench.report("raw single bind, distinct keys") { raw.select_all(sql, "Bench", [value += 1]) }
UpstreamBench.report("async empty cache, short SQL") { async.select_all(sql, "Bench", [11], async: true).result }
UpstreamBench.report("async empty cache, 1 MiB SQL") { large.select_all(long_sql, "Bench", [11], async: true).result }
UpstreamBench.report("no bind hit control") { none.select_all("SELECT 11") }
