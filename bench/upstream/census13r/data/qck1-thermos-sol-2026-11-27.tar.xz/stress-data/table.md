Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `raw single bind, distinct keys` | 42 | 42 | 188,957 | 187,550 | −0.7% |
| `async empty cache, short SQL` | 40 | 40 | 167,158 | 168,326 | +0.7% |
| `async empty cache, 1 MiB SQL` | 40 | 40 | 14,096,014 | 14,107,598 | within noise |
| `no bind hit control` | 18 | 18 | 84,098 | 83,919 | within noise |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/qck1/stress-data.
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/qck1/rails-base at 2e299253f9
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/qck1/rails-repo at e1978ba23b
- interp raw single bind, distinct keys: instructions −0.7% with A/A 0.02% (base 188,936 / 188,979, candidate 187,550)
- interp async empty cache, short SQL: instructions +0.7% with A/A 0.00% (base 167,157 / 167,158, candidate 168,326)
- interp async empty cache, 1 MiB SQL: instructions +0.1% with A/A 0.17% (base 14,083,971 / 14,108,057, candidate 14,107,598): inside the A/A, no claim
- interp no bind hit control: instructions −0.2% with A/A 0.55% (base 84,331 / 83,864, candidate 83,919): inside the A/A, no claim
