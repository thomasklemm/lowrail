store = ActiveRecord::ConnectionAdapters::QueryCache::Store
store.send(:remove_const, :Key)
store.const_set(:Key, Class.new(Struct.new(:sql, :binds, :hash)) do
  def initialize(sql, binds)
    super(sql, binds, [sql, binds].hash)
  end
end)
