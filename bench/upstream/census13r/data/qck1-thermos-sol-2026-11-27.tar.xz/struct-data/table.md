Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, before | Objects, after | Instructions, before | Instructions, after | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `find, miss` | 52 | 52 | 321,463 | 313,523 | −2.5% |
| `find, hit` | 38 | 38 | 245,030 | 237,138 | −3.2% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/qck1/struct-data.
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/qck1/rails-base at 2e299253f9
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/qck1/rails-repo at e1978ba23b
- interp find, miss: instructions −2.5% with A/A 0.00% (base 321,456 / 321,470, candidate 313,523)
- interp find, hit: instructions −3.2% with A/A 0.01% (base 245,043 / 245,017, candidate 237,138)
