require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
ActiveRecord::Base.lease_connection
load File.join(__dir__, "struct_key.rb") if ENV.fetch("UPSTREAM_BENCH_TREE").end_with?("rails-repo")
load File.expand_path("../../../../bench/upstream/census13r/qck1_body.rb", __dir__)
UpstreamBench::CASES.delete_if { |name, _| !name.start_with?("find,") }
