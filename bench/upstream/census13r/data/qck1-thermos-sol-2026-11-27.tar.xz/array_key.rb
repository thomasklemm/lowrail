store = ActiveRecord::ConnectionAdapters::QueryCache::Store
store.send(:remove_const, :Key)
store.const_set(:Key, Class.new(Array) do
  def self.new(sql, binds) = self[sql, binds]
  def hash = @hash ||= super
end)
