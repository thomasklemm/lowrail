# QCK1 thermos-sol IN-list delta confirm

Reviewer/orb: thermos-sol, T-01a21eb9-c0e3-733d-b394-fbdeda571174, 2026-11-28.
Requested Lowrail source: 5599216c41eccd3b4d5ee9bd3908097651463a15.
Working source: 4b9f714c0a6bd1e6a20b2e1cd40ac1117ea1d3d8; QCK1 unchanged from requested source.
Rails base: 2e299253f942ab94041cc6f210ac9d33884c210d.
Rails head: 40e4c9db8fcb00afc252ab554ebaa778efd51180; remote branch independently checked.

From the Lowrail repository root, run `python -u PATH/TO/audit.py` and
`mise exec ruby@4.0.10 -- ruby PATH/TO/intervals.rb`. Successful output is in
`audit.txt` and `intervals.txt`. The Python auditor extends the preceding evidence
confirm: it checks 20 instruction cells, the six current body rows, all 360 process
logs (180 original and 180 IN-list), raw JIT counters, 16 timing estimates,
the six-query ranges, 20-versus-100 scaling, and the unchanged census. Its bootstrap
uses an independent Python RNG. The Ruby checker separately reconstructs every
reported interval endpoint with the documented Ruby seed and estimator.

`reviewed-QCK1.md` is the requested item's snapshot. `provenance.txt` pins the
sources; raw runs are already committed, including the IN-list wall runs in 8eda4a26.
This is a retained-data audit, not a fresh benchmark or framework-suite run.

Thomas's acceptance of the mutating-serialize case is recorded, not a claim that
the cache-hit/duplicate-entry difference was fixed. The review verdict and scope
are in the QCK1 thermos-sol section and the queue item's appended pass.
