require "json"

def median(values)
  values = values.sort
  (values[(values.length - 1) / 2] + values[values.length / 2]) / 2.0
end

def interval(rounds)
  random = Random.new(1)
  estimates = Array.new(5000) do
    sample = Array.new(30) { rounds.fetch(random.rand(30)) }.flatten
    median(sample)
  end.sort
  estimates.values_at(124, 4875).map { |value| Math.exp(value) - 1 }
end

count = 0
%w[QCK1-wall-yjit QCK1-wall-zjit QCK1-inlist-wall-yjit QCK1-inlist-wall-zjit].each do |directory|
  result = JSON.parse(File.read("bench/upstream/census13r/body/#{directory}/results.json"))
  result.fetch("wall").each do |name, cell|
    ratios = []
    controls = []
    cell.fetch("rounds").each do |round|
      values = round.transform_values do |windows|
        Math.log(windows.fetch("cpu").sort.fetch(3) / cell.fetch("calls"))
      end
      ratios << [values.fetch("candidate") - values.fetch("base"), values.fetch("candidate") - values.fetch("base2")]
      controls << [values.fetch("base2") - values.fetch("base")]
    end
    change_ci = interval(ratios)
    aa_ci = interval(controls)
    [[change_ci, cell.fetch("change_ci")], [aa_ci, cell.fetch("aa_ci")]].each do |computed, reported|
      raise "interval mismatch: #{directory} #{name}" unless computed.zip(reported).all? { |a, b| (a - b).abs < 1e-12 }
    end
    raise "change interval includes zero" unless change_ci.last < 0
    raise "A/A interval excludes zero" unless aa_ci.first <= 0 && aa_ci.last >= 0
    puts "#{directory} #{name}: all seeded interval endpoints reproduced; change excludes zero, A/A includes zero"
    count += 1
  end
end
raise "wrong cell count" unless count == 16
puts "All 16 timing cells' exact seeded interval endpoints verified"
