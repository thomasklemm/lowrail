#!/bin/bash
set -eu
review=$(realpath "$(dirname "$0")")
source "$review/env.sh"
for side in base head; do
  export BUNDLE_GEMFILE=$(realpath "$review/../$side/Gemfile")
  for prepared in false true; do
    ADAPTER=postgresql PREPARED=$prepared bundle exec ruby "$review/connection_death.rb" > "$review/death-$side-$prepared.log" 2>&1
    echo "death $side $prepared exit=0"
    for adapter in sqlite3 postgresql; do
      ADAPTER=$adapter PREPARED=$prepared bundle exec ruby --yjit "$review/adversarial.rb" > "$review/yjit-$side-$adapter-$prepared.log" 2>&1
      echo "YJIT $side $adapter $prepared exit=0"
    done
  done
done
python3 "$review/check_outputs.py" > "$review/output-validation.log"
