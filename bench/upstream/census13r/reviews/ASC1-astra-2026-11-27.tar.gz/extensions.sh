#!/bin/bash
set -u
review=$(realpath "$(dirname "$0")")
source "$review/env.sh"
export UNIFORM_LIB=/home/user/.local/share/mise/installs/ruby/4.0.10/lib/ruby/gems/4.0.0/gems/uniform_notifier-1.18.1/lib
for extension in bullet goldiloader switchman; do
  for side in base head; do
    export RAILS_TREE=$(realpath "$review/../$side")
    export BUNDLE_GEMFILE="$RAILS_TREE/Gemfile"
    for adapter in sqlite3 postgresql; do
      for prepared in false true; do
        EXTENSION=$extension ADAPTER=$adapter PREPARED=$prepared PROBE_DB="$review/extension.sqlite3" bundle exec ruby "$review/extensions.rb" > "$review/extension-$extension-$side-$adapter-$prepared.log" 2>&1
        echo "$extension $side $adapter $prepared exit=$?"
      done
    done
  done
  for adapter in sqlite3 postgresql; do
    for prepared in false true; do
      diff -u <(sed '/^metrics /d' "$review/extension-$extension-base-$adapter-$prepared.log") <(sed '/^metrics /d' "$review/extension-$extension-head-$adapter-$prepared.log") > "$review/extension-$extension-$adapter-$prepared.diff"
      echo "diff $extension $adapter $prepared exit=$?"
    done
  done
done
