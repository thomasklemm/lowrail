class ReloadEntry < PrimaryRecord
  self.table_name = "entries"
  belongs_to :account, class_name: "ReloadAccount"
end
