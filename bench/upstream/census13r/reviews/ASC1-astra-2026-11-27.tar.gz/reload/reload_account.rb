class ReloadAccount < PrimaryRecord
  self.table_name = "accounts"
  has_many :entries, class_name: "ReloadEntry", foreign_key: :account_id
end
