export PATH=/home/user/.local/share/mise/installs/ruby/4.0.10/bin:$PATH
export GEM_PATH=/home/user/.local/share/mise/installs/ruby/4.0.10/lib/ruby/gems/4.0.0:/home/user/.local/share/mise/installs/ruby/4.0.9/lib/ruby/gems/4.0.0:/home/user/.local/share/mise/installs/ruby/4.0.7/lib/ruby/gems/4.0.0
