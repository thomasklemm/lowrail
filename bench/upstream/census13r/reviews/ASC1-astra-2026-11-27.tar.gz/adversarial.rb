require "json"
require "timeout"
require "active_record"
require "zeitwerk"

ActiveRecord.async_query_executor = :global_thread_pool
ActiveSupport::IsolatedExecutionState.isolation_level = ENV.fetch("ISOLATION", "thread").to_sym
adapter = ENV.fetch("ADAPTER")
prepared = ENV.fetch("PREPARED") == "true"
configs = %w[east east_read west west_read audit].to_h do |name|
  database = adapter == "sqlite3" ? File.join(__dir__, "#{name}.sqlite3") : "asc1_#{name}"
  [name, { adapter: adapter, database: database, prepared_statements: prepared, pool: 4, checkout_timeout: 1 }]
end
ActiveRecord::Migration.verbose = false
configs.each do |name, config|
  ActiveRecord::Base.establish_connection(config)
  ActiveRecord::Schema.define do
    create_table(:accounts, force: true) { |t| t.string :label }
    create_table(:entries, force: true) { |t| t.integer :account_id; t.string :label }
  end
  ActiveRecord::Base.with_connection do |c|
    c.execute("INSERT INTO accounts (id, label) VALUES (1, '#{name}-one'), (7, '#{name}-seven')")
    c.execute("INSERT INTO entries (id, account_id, label) VALUES (2, 1, '#{name}-two'), (5, 1, '#{name}-five'), (9, 7, '#{name}-nine')")
  end
end
ActiveRecord::Base.configurations = { "default_env" => configs }
ActiveRecord::Base.establish_connection(:east)
class PrimaryRecord < ActiveRecord::Base
  self.abstract_class = true
  connects_to shards: { east: { writing: :east, reading: :east_read }, west: { writing: :west, reading: :west_read } }
end
class OtherRecord < ActiveRecord::Base
  self.abstract_class = true
  connects_to database: { writing: :audit, reading: :audit }
end
class Account < PrimaryRecord
  has_many :entries, inverse_of: :account
  has_many :audit_entries, class_name: "AuditEntry", foreign_key: :account_id
  has_one :entry, -> { where(id: 2) }
end
class Entry < PrimaryRecord
  belongs_to :account, inverse_of: :entries
  after_find { Thread.current[:after_find]&.call(self) }
end
class AuditEntry < OtherRecord
  self.table_name = "entries"
  belongs_to :account
end

def pools
  ActiveRecord::Base.connection_handler.connection_pool_list(:all)
end
def release
  pools.each(&:release_connection)
end
def rows(records)
  Array(records).map { |r| [r.class.name, r.id, r.label] }
end
def show(name)
  release
  Thread.current[:events] = []
  result = begin
    yield
  rescue StandardError => e
    [e.class.name, e.message.gsub(/0x[0-9a-f]+/, "ADDRESS")]
  end
  puts JSON.generate([name, result, Thread.current[:events], pools.map { |p| [p.db_config.name, !!p.active_connection?] }.sort])
ensure
  Thread.current[:events] = nil
  Thread.current[:after_find] = nil
  release
end
ActiveSupport::Notifications.subscribe("sql.active_record") do |*, payload|
  if Thread.current[:events] && payload[:name] != "SCHEMA" && payload[:sql].start_with?("SELECT", "UPDATE", "INSERT")
    Thread.current[:events] << [payload[:sql], payload[:binds].map(&:value_for_database), !!payload[:async], !!payload[:cached], payload[:connection].pool.db_config.name]
  end
end

2.times do |round|
  [:east, :west].product([:writing, :reading]).each do |shard, role|
    show("route #{round} #{shard} #{role}") do
      PrimaryRecord.connected_to(role: role, shard: shard) do
        owner = Account.find(1)
        [rows(owner.entries), rows(Entry.find(9).account), rows(owner.audit_entries)]
      end
    end
  end
end
show("nested connected_to during bind") do
  owner = Account.find(1)
  nested = []
  owner.define_singleton_method(:read_attr) do |name|
    PrimaryRecord.connected_to(role: :reading, shard: :west) { nested << rows(Entry.find(9).account) }
    super(name)
  end
  [rows(owner.entries), nested, PrimaryRecord.current_role, PrimaryRecord.current_shard]
end
show("nested connected_to after_find") do
  nested = []
  Thread.current[:after_find] = ->(_) { PrimaryRecord.connected_to(role: :reading, shard: :west) { nested << Account.find(7).label } }
  [rows(Account.find(1).entries), nested, PrimaryRecord.current_shard]
end
show("connected_to_many classes") do
  ActiveRecord::Base.connected_to_many(PrimaryRecord, OtherRecord, role: :reading) do
    rows(Account.find(1).audit_entries)
  end
end
show("prevent writes in owner reader") do
  owner = Account.find(1)
  owner.define_singleton_method(:read_attr) do |name|
    Entry.where(id: 2).update_all(label: "unsafe")
    super(name)
  end
  PrimaryRecord.connected_to(role: :writing, prevent_writes: true) { rows(owner.entries) }
end
show("prevent writes nested recovery") do
  errors = []
  Thread.current[:after_find] = lambda do |_|
    PrimaryRecord.connected_to(role: :writing, prevent_writes: true) do
      Entry.where(id: 2).update_all(label: "unsafe")
    rescue => e
      errors << [e.class.name, e.message]
    end
  end
  [rows(Account.find(1).entries), errors]
end
show("unprepared block") do
  Entry.with_connection { |c| c.unprepared_statement { rows(Account.find(1).entries) } }
end
show("pinned transaction and cross thread") do
  pool = PrimaryRecord.connection_pool
  pool.pin_connection!(true)
  pool.with_connection { |c| c.begin_transaction(joinable: false) }
  Entry.create!(id: 31, account_id: 1, label: "uncommitted")
  result = [rows(Account.find(1).entries), Thread.new { rows(Account.find(1).entries) }.value]
  pool.with_connection { |c| c.rollback_transaction }
  pool.unpin_connection!
  result << rows(Account.find(1).entries)
end
show("parallel threads distinct shards") do
  gates = [Queue.new, Queue.new]
  threads = [:east, :west].each_with_index.map do |shard, i|
    Thread.new do
      PrimaryRecord.connected_to(role: :reading, shard: shard) do
        gates[i] << true
        gates[1 - i].pop
        rows(Account.find(1).entries)
      end
    ensure
      release
    end
  end
  threads.map(&:value)
end
show("suspended fibers inside load") do
  fs = [:east, :west].map do |shard|
    Fiber.new do
      PrimaryRecord.connected_to(role: :writing, shard: shard) do
        owner = Account.find(1)
        paused = false
        owner.define_singleton_method(:read_attr) do |name|
          unless paused
            paused = true
            Fiber.yield([shard, "bind"])
          end
          super(name)
        end
        rows(owner.entries)
      end
    end
  end
  a = fs[0].resume
  b = fs[1].resume
  result = [a, b, fs[1].resume, fs[0].resume]
  raise "fiber did not finish" if fs.any?(&:alive?)
  result
end
[:load_async, :find_target].each do |operation|
  [:east, :west].each do |shard|
    show("#{operation} background #{shard}") do
      tracker = ActiveRecord::Base.asynchronous_queries_tracker
      tracker.start_session
      result = nil
      PrimaryRecord.connected_to(role: :reading, shard: shard) do
        result = if operation == :load_async
          Entry.where(account_id: 1).load_async
        else
          Account.find(1).association(:entries).send(:find_target, async: true)
        end
        nil
      end
      future = operation == :load_async ? result.instance_variable_get(:@future_result) : result
      Timeout.timeout(5) { Thread.pass while future.pending? } if future
      records = operation == :load_async ? result.to_a : result.value
      rows(records)
    ensure
      tracker.finalize_session(true)
    end
  end
end
[:disconnect, :pool_disconnect, :error, :bad_sql].each do |action|
  show("mid-bind #{action}") do
    owner = Account.find(1)
    owner.define_singleton_method(:read_attr) do |name|
      case action
      when :disconnect then Entry.with_connection(&:disconnect!)
      when :pool_disconnect then Entry.connection_pool.disconnect!
      when :error then raise ActiveRecord::ConnectionNotEstablished, "injected bind failure"
      when :bad_sql then Entry.with_connection { |c| c.execute("SELECT * FROM no_such_table_asc1") }
      end
      super(name)
    end
    rows(owner.entries)
  end
  show("recovery #{action}") { rows(Account.find(1).entries) }
end
show("disconnect after SQL before callbacks") do
  Thread.current[:after_find] = ->(_) { PrimaryRecord.with_connection(&:disconnect!) }
  rows(Account.find(1).entries)
end

show("forwarding find_target prepend") do
  owner = Account.find(1)
  association = owner.association(:entries)
  association.singleton_class.prepend(Module.new do
    def find_target(...)
      PrimaryRecord.connected_to(role: :reading, shard: :west) { super }
    end
  end)
  rows(owner.entries)
end
show("forwarding scope cache prepend") do
  owner = Account.find(1)
  reflection = Account.reflect_on_association(:entries)
  reflection.singleton_class.prepend(Module.new do
    def association_scope_cache(...)
      super
    end
  end)
  rows(owner.entries)
end
show("with_connection prepend permanent checkout suppression") do
  patch = Module.new do
    def with_connection(prevent_permanent_checkout: false, &block)
      super(prevent_permanent_checkout: true, &block)
    end
  end
  Entry.singleton_class.prepend(patch)
  rows(Account.find(1).entries)
ensure
  patch.send(:remove_method, :with_connection)
end
show("with_connection role wrapper") do
  patch = Module.new do
    def with_connection(...)
      PrimaryRecord.connected_to(role: :reading, shard: :west) { super }
    end
  end
  Entry.singleton_class.prepend(patch)
  rows(Account.find(1).entries)
ensure
  patch.send(:remove_method, :with_connection)
end
show("old arity nodoc cache override") do
  reflection = Account.reflect_on_association(:entries)
  patch = Module.new do
    def association_scope_cache(klass, routes, &block)
      super
    end
  end
  reflection.singleton_class.prepend(patch)
  rows(Account.find(1).entries)
ensure
  patch.send(:remove_method, :association_scope_cache)
end
show("cache error release") do
  reflection = Account.reflect_on_association(:entries)
  patch = Module.new do
    def association_scope_cache(...)
      raise ActiveRecord::ConnectionNotEstablished, "injected cache failure"
    end
  end
  reflection.singleton_class.prepend(patch)
  rows(Account.find(1).entries)
ensure
  patch.send(:remove_method, :association_scope_cache)
end
show("cache error recovery") { rows(Account.find(1).entries) }

loader = Zeitwerk::Loader.new
loader.push_dir(File.join(__dir__, "reload"))
loader.enable_reloading
loader.setup
show("zeitwerk initial") { rows(ReloadAccount.find(1).entries) }
loader.reload
show("zeitwerk reloaded") { rows(ReloadAccount.find(7).entries) }
show("final leaked leases") { pools.map { |p| [p.db_config.name, p.stat[:busy]] }.sort }
