import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent
def load(path):
    return {a[0]: a for line in path.read_text().splitlines() if line.startswith('[') for a in [json.loads(line)]}
def entries(prefix):
    return [["Entry", 2, prefix + "-two"], ["Entry", 5, prefix + "-five"]]

for adapter in ("sqlite3", "postgresql"):
    for prepared in ("false", "true"):
        for isolation in ("thread", "fiber"):
            a = load(root / f"probe-base-{adapter}-{prepared}-{isolation}.log")
            b = load(root / f"probe-head-{adapter}-{prepared}-{isolation}.log")
            assert len(a) == len(b) == 40
            differences = [k for k in a if a[k] != b[k]]
            assert differences == ["old arity nodoc cache override"], differences
            assert a[differences[0]][1] == entries("east")
            assert b[differences[0]][1] == ["ArgumentError", "wrong number of arguments (given 3, expected 2)"]
            for data in (a, b):
                for round in (0, 1):
                    for shard in ("east", "west"):
                        for role in ("writing", "reading"):
                            prefix = shard + ("_read" if role == "reading" else "")
                            assert data[f"route {round} {shard} {role}"][1] == [entries(prefix), [["Account", 7, prefix + "-seven"]], [["AuditEntry", 2, "audit-two"], ["AuditEntry", 5, "audit-five"]]]
                for kind in ("load_async", "find_target"):
                    for shard in ("east", "west"):
                        row = data[f"{kind} background {shard}"]
                        assert row[1] == entries(shard + "_read")
                        assert any(sql[2] for sql in row[2]), row
                assert data["prevent writes in owner reader"][1][0] == "ActiveRecord::ReadOnlyError"
                pinned = data["pinned transaction and cross thread"][1]
                assert pinned == [entries("east") + [["Entry", 31, "uncommitted"]]] * 2 + [entries("east")]
                assert data["suspended fibers inside load"][1] == [["east", "bind"], ["west", "bind"], entries("west"), entries("east")]
                assert data["parallel threads distinct shards"][1] == [entries("east_read"), entries("west_read")]
                assert data["zeitwerk reloaded"][1] == [["ReloadEntry", 9, "east-nine"]]
                assert all(count == 0 for name, count in data["final leaked leases"][1])
            print(adapter, prepared, isolation, "40 observations: 39 identical; only legacy nodoc arity differs; independent expected records, background async, isolation and cleanup assertions passed")

for prepared in ("false", "true"):
    a = load(root / f"death-base-{prepared}.log")
    b = load(root / f"death-head-{prepared}.log")
    keys = [k for k in a if k.startswith(("server terminated", "pool exhausted"))]
    for k in keys:
        left = re.sub(r"waited [0-9.]+ seconds", "waited ELAPSED seconds", json.dumps(a[k]))
        right = re.sub(r"waited [0-9.]+ seconds", "waited ELAPSED seconds", json.dumps(b[k]))
        assert left == right
    assert a["server terminated during bind"][1] == entries("east")
    assert a["pool exhausted on load"][1][0] == "ActiveRecord::ConnectionTimeoutError"
    assert a["pool exhausted recovery"][1] == entries("east")
    print("postgresql", prepared, "backend termination/reconnect and exhausted-pool recovery match; elapsed timeout duration alone normalized")

for adapter in ("sqlite3", "postgresql"):
    for prepared in ("false", "true"):
        for side in ("base", "head"):
            actual = load(root / f"yjit-{side}-{adapter}-{prepared}.log")
            expected = load(root / f"probe-{side}-{adapter}-{prepared}-thread.log")
            assert actual == expected, (side, adapter, prepared)
        print("YJIT", adapter, prepared, "all 40 observations equal the independently validated interpreter observations on each revision")
