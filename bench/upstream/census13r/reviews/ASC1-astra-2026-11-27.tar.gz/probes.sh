#!/bin/bash
set -u
review=$(realpath "$(dirname "$0")")
source "$review/env.sh"
for side in base head; do
  export RAILS_TREE=$(realpath "$review/../$side")
  export BUNDLE_GEMFILE="$RAILS_TREE/Gemfile"
  for adapter in sqlite3 postgresql; do
    export ADAPTER=$adapter
    for prepared in false true; do
      export PREPARED=$prepared
      for isolation in thread fiber; do
        ISOLATION=$isolation bundle exec ruby "$review/adversarial.rb" > "$review/probe-$side-$adapter-$prepared-$isolation.log" 2>&1
        echo "$side $adapter $prepared $isolation exit=$?"
      done
      PROBE_DB="$review/original.sqlite3" bundle exec ruby "$review/../thermos/async_background.rb" > "$review/original-$side-$adapter-$prepared.log" 2>&1
      echo "original $side $adapter $prepared exit=$?"
    done
  done
done
for adapter in sqlite3 postgresql; do
  for prepared in false true; do
    for isolation in thread fiber; do
      diff -u "$review/probe-base-$adapter-$prepared-$isolation.log" "$review/probe-head-$adapter-$prepared-$isolation.log" > "$review/probe-$adapter-$prepared-$isolation.diff"
      echo "diff $adapter $prepared $isolation exit=$?"
    done
    diff -u <(sed '/^metrics /d' "$review/original-base-$adapter-$prepared.log") <(sed '/^metrics /d' "$review/original-head-$adapter-$prepared.log") > "$review/original-$adapter-$prepared.diff"
    echo "original diff $adapter $prepared exit=$?"
  done
done
