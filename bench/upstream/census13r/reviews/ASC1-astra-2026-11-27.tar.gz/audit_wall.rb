require "json"
root = File.expand_path("../../../../..", __dir__)
def median(values)
  sorted = values.sort
  (sorted[(sorted.size - 1) / 2] + sorted[sorted.size / 2]) / 2.0
end
def interval(rounds)
  random = Random.new(1)
  estimates = 5000.times.map do
    sampled = Array.new(rounds.size) { rounds.fetch(random.rand(rounds.size)) }
    median(sampled.flatten)
  end.sort
  [124, 4875].map { |i| Math.exp(estimates[i]) - 1 }
end
%w[yjit zjit].each do |mode|
  dir = File.join(root, "bench/upstream/census13r/body/ASC1-wall-#{mode}")
  saved = JSON.parse(File.read(File.join(dir, "results.json")))
  saved.fetch("wall").each do |name, cell|
    counts = cell.fetch("rounds").size
    raise "not 30 rounds" unless counts == 30
    changes, controls = [], []
    counts.times do |i|
      times = %w[base candidate base2].to_h do |side|
        text = File.read(File.join(dir, "raw/wall-r#{i + 1}-#{side}.log"))
        raw = JSON.parse(text.lines.find { _1.start_with?("wall #{name}\t") }.split("\t", 2).last)
        raise "raw/summary drift" unless raw == cell.fetch("rounds")[i][side]
        jit = text.lines.find { _1.start_with?("jit #{name}\t") }
        pairs = jit.scan(/=([0-9]+)>([0-9]+)/)
        raise "JIT moved" unless !pairs.empty? && pairs.all? { |a,b| a == b }
        windows = raw.fetch("cpu").sort
        raise "not 30 windows" unless windows.size == 30
        [side, Math.log(windows.fetch(3) / cell.fetch("calls"))]
      end
      changes << [times["candidate"] - times["base"], times["candidate"] - times["base2"]]
      controls << [times["base2"] - times["base"]]
    end
    values = { "change" => Math.exp(median(changes.flatten)) - 1, "aa" => Math.exp(median(controls.flatten)) - 1,
      "change_ci" => interval(changes), "aa_ci" => interval(controls) }
    values.each { |k,v| raise "summary mismatch #{k}" unless v == cell.fetch(k) }
    raise "control median > 0.5%" unless values["aa"].abs <= 0.005
    raise "control excludes zero" unless values["aa_ci"][0] <= 0 && values["aa_ci"][1] >= 0
    raise "change includes zero" unless values["change_ci"][1] < 0
    puts JSON.generate([mode, name, values.transform_values { |v| Array(v).map { _1 * 100 } }])
  end
  puts "#{mode}: all raw windows, six intervals, medians and JIT-flat flags verified"
end
