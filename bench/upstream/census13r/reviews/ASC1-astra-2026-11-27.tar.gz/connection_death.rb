load File.join(__dir__, "adversarial.rb")
require "pg"
show("server terminated during bind") do
  owner = Account.find(1)
  terminated = false
  owner.define_singleton_method(:read_attr) do |name|
    unless terminated
      terminated = true
      PrimaryRecord.with_connection do |c|
        killer = PG.connect(dbname: "asc1_east")
        killer.exec_params("SELECT pg_terminate_backend($1)", [c.raw_connection.backend_pid])
        killer.close
      end
    end
    super(name)
  end
  rows(owner.entries)
end
show("server terminated recovery") { rows(Account.find(1).entries) }
show("pool exhausted on load") do
  owner = Account.find(1)
  pool = Entry.connection_pool
  held = Array.new(pool.max_connections) { pool.checkout }
  Thread.new do
    Thread.current.report_on_exception = false
    rows(owner.entries)
  end.value
ensure
  held&.each { pool.checkin(_1) }
end
show("pool exhausted recovery") { rows(Account.find(1).entries) }
