#!/bin/bash
set -u
review=$(realpath "$(dirname "$0")")
source "$review/env.sh"
for side in base head; do
  export RAILS_TREE=$(realpath "$review/../$side")
  export BUNDLE_GEMFILE="$RAILS_TREE/Gemfile"
  for adapter in sqlite3 postgresql; do
    export ARCONN=$adapter
    for group in associations connections; do
      (
        cd "$RAILS_TREE/activerecord"
        if [[ $group == associations ]]; then
          files=(test/cases/associations/*_test.rb test/cases/{association_route,associations,reflection,statement_cache,finder,strict_loading,query_cache}_test.rb)
        else
          files=(test/cases/{connection_handling,connection_management,connection_pool,transactions,asynchronous_queries,multiple_db,fixtures}_test.rb test/cases/connection_adapters/{adapter_leasing,connection_handlers_sharding_db,connection_swapping_nested,connection_handlers_multi_db,connection_handlers_multi_pool_config}_test.rb)
        fi
        ruby -v
        git rev-parse HEAD
        echo "BUNDLE_GEMFILE=$BUNDLE_GEMFILE"
        bundle exec ruby -Itest -I../railties/lib -e 'require "active_record"; %w[activerecord activemodel activesupport].each { |g| p = Gem.loaded_specs.fetch(g).full_gem_path; puts "LOADED #{g}: #{p}"; abort "wrong tree" unless p.start_with?(ENV.fetch("RAILS_TREE") + "/") }; ARGV.each { |f| require File.expand_path(f) }; ARGV.replace(["--seed", "1127"])' "${files[@]}"
      ) > "$review/suite-$side-$adapter-$group.log" 2>&1
      echo "$side $adapter $group exit=$?"
      tail -6 "$review/suite-$side-$adapter-$group.log"
    done
  done
done
