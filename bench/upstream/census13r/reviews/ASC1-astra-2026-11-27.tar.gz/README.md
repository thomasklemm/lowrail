# ASC1 Astra evidence, 2026-11-27

Reviewer orb: T-01a21ee0-bd69-7357-bcd6-6a80c2744ee2. Base:
2e299253f942ab94041cc6f210ac9d33884c210d. Head:
ed1b28c5b94530e1c8b06d14dfca0ee93d5c07ba. Self-performed; no other agents.

This archive contains sources and output, not the Rails checkouts or databases.
Restore it to `.amp/in/orb-backup/asc1/review`; create detached sibling worktrees
`base` and `head` at those revisions. Extract the existing
`ASC1-thermos-sol-2026-11-27.tar.gz` archive to sibling `thermos`: its `probe.rb`
and `async_background.rb` are deliberately reused and rerun, not new independent
probes. `adversarial.rb` and `connection_death.rb` are this pass's new probes.

`env.sh` records the Ruby 4.0.10 executable and installed gem search paths. Every
test and probe uses the selected Rails worktree's own `Gemfile` through
`BUNDLE_GEMFILE`, not this archive's copy. `Gemfile` and `Gemfile.lock` here are
copies for provenance; the Rails worktrees had no tracked changes. `bundle.log`
retains the install. Tested dependencies are sqlite3 2.5.0 / SQLite 3.47.2,
pg 1.6.3 / PostgreSQL 17.12. The older dependency versions come from the branch's
lockfile; no claim to have tested the newest adapter releases is made here.

## Commands run

* `bash .../review/suites.sh`: selected association, route, reflection, statement
  cache, query cache, finder and strict-loading files; connection handling,
  leasing, transactions, async, multi-database, shard and fixture files. Eight
  logs assert the actual loaded component paths and print each exact SHA and
  BUNDLE_GEMFILE. Seed 1127.
* `bash .../review/fixtures.sh`: separate `test_fixtures_test.rb` on both adapters
  and revisions, seed 1127. It supplements `fixtures_test.rb` above.
* `bash .../review/probes.sh`: new 40-observation probe for every combination of
  base/head, SQLite/PostgreSQL, prepared on/off, thread/fiber isolation. Original
  exactness and background-async probes are also rerun for both adapters and
  preparation settings.
* `python3 .../review/check_outputs.py`: compares every new-probe observation,
  asserts independently specified asymmetric records, backend selection,
  uncommitted pinned-row visibility and rollback, real async notification flags,
  fiber/thread isolation, reloaded class results and empty final leases.
* `bash .../review/extensions.sh`: real Bullet 8.3.1 enabled with an active request,
  Goldiloader 6.0.1 enabled, and the actual Switchman 4.3.9 reflection modules
  loaded in isolation. This last check is not a full supported Switchman boot:
  its declared dependencies exclude Rails 8.2, and its existing owner/routes
  mismatch already fails on base. Gem sources are included. Metadata was fetched
  afresh from Rubygems and GitHub in `currency/`; default-branch files are pinned
  by the corresponding `*-main.json` SHAs.
* For both sides and preparation settings, with their own Gemfiles:
  `ADAPTER=postgresql PREPARED=true bundle exec ruby .../review/connection_death.rb`
  (also `PREPARED=false`). Terminates this disposable test's PostgreSQL backend
  during bind evaluation, then checks recovery; exhausts the pool and checks
  timeout and recovery. The backend-termination call targets only `asc1_east`.
* YJIT: `ADAPTER=sqlite3 PREPARED=true bundle exec ruby --yjit .../review/adversarial.rb`,
  also PostgreSQL, both preparation settings, and both sides. Logs are `yjit-*`.
* `python3 .../review/audit_evidence.py`: reruns the detailed review's raw
  interpreter/census audit, adjusted only for the extraction directory.
* `ruby .../review/audit_wall.rb`: independently reads the 180 raw process logs,
  checks every saved CPU/wall window against the results files, all JIT-flat
  counter pairs, and reproduces the six change/control medians and twelve 95%
  intervals with the tool's seeded whole-round bootstrap convention. No timing
  benchmark was rerun by this review.

PostgreSQL was local and disposable, started with `pg_ctlcluster 17 main start`.
The test user is a local superuser, and `en_US.UTF-8` was generated for the Rails
test database helper. Probes need disposable databases `asc1_probe`, `asc1_east`,
`asc1_east_read`, `asc1_west`, `asc1_west_read`, `asc1_audit`. They recreate their
own tables. Never point these probes at shared or valuable databases.

## Differences and normalization

The only changed observation among the new probe's 40 is the intentionally old
two-argument nodoc cache override: successful records on base, ArgumentError on
head. Forwarding the new argument fixes that consumer. The separate released
Switchman method fails with NoMethodError on base (Array lacks
connection_class_for_self) and ArgumentError on head. Its existing version cap
is correct; a future Rails 8.2 port needs both route and connection changes.

Original and extension comparisons remove only explicitly labeled `metrics`
lines; those raw lines prove the intended saved lookup/checkout. Other values,
SQL, bind values, exceptions and lease state are compared. The backend-death
comparison normalizes only the elapsed duration inside ConnectionTimeoutError
(1.000 versus 1.001 seconds), not its configured timeout or exception class.

`setup-attempts/` retains earlier new-probe/YJIT runs that returned a Relation
from `connected_to`, which forces it to load at block exit. Records matched but
one load_async case therefore ran in the foreground; those logs are not used
to claim real background execution. The final harness assigns the result and
returns nil from the block, waits for completion, and asserts async:true.
`initial-probe.log` also retains an earlier harness with an invalid model-level
unprepared_statement call and a fiber that yielded twice. These were harness
errors, corrected before the final matrix; no Rails fix was made.

`reviewed-item.md` is the input item at Lowrail e8eff78d, including the corrected
f8198175 median/95% interval wording. `rails-change.patch` and `provenance.log`
identify the exact commit/message and confirm library-tree equality with both
historically measured candidate SHAs.

## Limits

No full Rails framework suite, MySQL, oldest-supported-adapter matrix, new
performance cohort, or new Ruby-master execution was run. The installed Ruby
4.0.10 lacks ZJIT (`zjit-availability.log`); the existing pinned-master ZJIT
cohort was audited instead. Local YJIT and interpreter probes test behavior,
not throughput. This bounded released-extension inventory does not certify
every third-party override. No upstream branch or post was changed.
