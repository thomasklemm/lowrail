---
id: ASC1
repo: rails/rails
kind: perf
area: Active Record, associations, connection lookup
reviewer:
branch: thomasklemm/association-load-one-connection-lookup
head: "ed1b28c5b94530e1c8b06d14dfca0ee93d5c07ba"
base: main
built_on: "2e299253f9"
introduced_by:
depends_on: []
tracker: []
stacked_on:
alternative_of:
evidence: [docs/upstream/data/rails-82-leads, bench/upstream/census13r/body/ASC1, bench/upstream/census13r/body/ASC1-wall-yjit, bench/upstream/census13r/body/ASC1-wall-zjit, bench/upstream/census13r/body/ASC1-ips, bench/upstream/census13r/data/probe, bench/upstream/census13r/reviews/ASC1-thermos-sol-2026-11-27.tar.gz, bench/upstream/census13r/reviews/ASC1-thermos-sol-timing-text-2026-11-27.tar.gz]
impact: "Every association load through the statement cache (belongs_to, has_one, has_many, through, polymorphic; every Rails app) resolved the model's connection pool once more than needed: association_scope_cache took the connection in its own with_connection block, then find_target took it again to run the statement (find_by_sql takes it a third time); the change saves one pool lookup per load and, without an existing lease, one checkout (thermos-sol probe: direct loads 3 to 2 lookups, through 4 to 3). The split dates from fa048105d1 (2024-05, with_connection replacing lease_connection); reflection.rb's signature changed again in 7249a66350 (unreleased, #59120). Census, Rails main 2e299253f9, Ruby 4.0.10, 4 apps / 36 workloads, interpreted Ir per request: median -0.26%, max -0.91%; per app medians blog +0.16%, casa -0.26%, react-starter-kit -0.40%, redprints-cfp -0.39% (docs/upstream/data/rails-82-leads/per-workload.tsv), A/A median -0.03%, p90 |d| 0.32%. Exact head, script/upstream-bench, Ruby 4.0.10, interpreter: belongs_to load -3.1%, has_one -3.0%, has_many (3 rows) -2.4% (A/A <= 0.06%), objects unchanged; YJIT cells not JIT-flat, no claim. Connection-lookup lead of the Rails 8.2 round (census 12: 0.81% mean, 68/71; this round 0.75%, 33/36): measured commit 23fe1f4b6b (fork ref thomasklemm/asc1-measured-23fe1f4b6b) has activerecord/lib tree fc7f875b3d, identical to the head. Lifetime: runs on Ruby master and Rails main."
rank: 1
risky: true
state: built
pr:
note: "2026-11-27 (coordinator): applied thermos-sol text-confirm must-fix (a7f5cc8a): A/A clause now names the medians and their 95% intervals. 2026-11-27 (coordinator): thermos-sol approved ed1b28c5b9 (c33c47d2). Added the JIT timing sentence from the a1.xxlarge wall cohorts (ASC1-wall-yjit, ASC1-wall-zjit: belongs_to -3.5%/-1.9%, has_one -2.8%/-3.2%, has_many -2.2%/-1.7%; A/A medians -0.5% to +0.2%, all intervals contain 0, all change intervals exclude 0, JIT-flat in 90 processes); benchmark-ips YJIT was inside its A/A (2.6% to 9.4%) and is not cited. Measured lib tree identical to the head. Needs thermos-sol text confirm and Astra. 2026-11-27 (new helper rule, DECISIONS 0734f6de): the shared helper is association_scope_cache, whose only caller is find_target; it now takes the caller's connection instead of leasing its own, so no caller gets a fast path and no check is copied. The shared pool lookup (Base.connection_pool) itself has no exact cheaper shape short of per-context caching that connected_to would have to invalidate; its parts are small method calls (JIT territory). The third lookup in StatementCache#execute via find_by_sql stays: bullet and goldiloader override find_by_sql. Earlier: 2026-11-27 (thermos-sol text finding on 703f89d6f6): title, body and commit said once per load and two checkouts to one, but find_by_sql adds a third with_connection (warm direct loads 3 to 2 lookups, through 4 to 3); retitled and reworded to one lookup and one checkout fewer, commit message only (ed1b28c5b9). Earlier: 2026-11-27 (thermos-sol finding on 2b46f50bda): association_route_test.rb called association_scope_cache with two arguments; fixed by wrapping both cache checks in with_connection and passing its connection (703f89d6f6, lib unchanged, so the body runs on 23fe1f4b6b still measure this head). The earlier suite run here had loaded main's activerecord through main's Gemfile and is void; rerun with the branch Gemfile: activerecord SQLite 10,485 runs, 37,491 assertions, 0 failures, 4 errors, 52 skips; the 4 errors are sqlite_rake_test needing the sqlite3 CLI, which fails the same on main. Earlier: 2026-11-27 (Rails 8.2 leads round, docs/upstream/rails-82-leads-2026-11-27.md): built and measured; risky because connection handling (critical per DECISIONS), so Astra runs adversarially after thermos-sol. Differential probe (bench/upstream/census13r/probe.rb, data/probe): identical records and SQL with prepared statements on and off, unleased and leased, async, through, polymorphic, strict_loading; only difference one checkout fewer per unleased load. Wall time (benchmark-ips YJIT, --wall YJIT and master ZJIT) runs on an a1.xxlarge orb. Ownership hits: #59212 (bruno-costanzo, skip building the scope on the statement-cache path) changes find_target above these lines, a different concern; git merge-tree with its head is clean. #55002 and #58804 are strict-loading fixes elsewhere in the file. No open PR changes association_scope_cache."
ownership: {date: 2026-11-27, checked: ["open PRs naming find_target, association_scope_cache that change activerecord/lib/active_record/associations/association.rb, activerecord/lib/active_record/reflection.rb"], hits: ["names find_target, changes its file (6 open PRs name it): rails/rails#59212 (PR, open, bruno-costanzo): Don't build the association scope when the reader uses the statement cache","names find_target, changes its file (6 open PRs name it): rails/rails#55002 (PR, open, dewski): Enforce strict loading violations for associations where joins are disabled","names find_target, changes its file (6 open PRs name it): rails/rails#58804 (PR, open, drsharp): Fix has_one_attached/has_many_attached strict_loading raising on attach"]}
passes:
  - reviewer: thermos-sol
    head: "ed1b28c5b94530e1c8b06d14dfca0ee93d5c07ba"
    orb: T-01a21eb9-b7bd-74a9-b7cc-38834c572ca0
    date: 2026-11-27
    verdict: approve
    summary: "Both rubrics self-performed, no delegation; L0. Route-test arity and overbroad lookup/checkout claims fixed and rechecked. Independent SQLite/PostgreSQL suites and exactness/background-async probes pass; released override inventory checked. Worst tested 1,000-row load: -0.0367% interpreter instructions, A/A 0.0054%, objects unchanged; raw evidence archived. Present title/body/commit approved; later benchmark-ips text needs a short confirm. Details: docs/upstream/rails-82-leads-2026-11-27.md, ASC1 thermos-sol."
  - reviewer: thermos-sol
    head: "ed1b28c5b94530e1c8b06d14dfca0ee93d5c07ba"
    orb: T-01a21eb9-b7bd-74a9-b7cc-38834c572ca0
    date: 2026-11-27
    verdict: changes
    summary: "Body-text confirm at Lowrail a469f402 only; code approval unchanged. Timing ranges and interval signs match all six cells from the raw logs, 90 JIT-flat processes per Ruby. One must-fix: ±0.5% describes A/A median differences, not variation or interval bounds (YJIT has_one A/A 95% CI -3.4945% to +2.2526%). Name the median differences explicitly, or cut the A/A clause. No timing rerun or Rails change needed. Details: docs/upstream/rails-82-leads-2026-11-27.md, ASC1 thermos-sol."
  - reviewer: thermos-sol
    head: "ed1b28c5b94530e1c8b06d14dfca0ee93d5c07ba"
    orb: T-01a21eb9-b7bd-74a9-b7cc-38834c572ca0
    date: 2026-11-27
    verdict: approve
    summary: "Text confirm on the body at Lowrail f819817549bc5836880d3ff3c8a95359720889fe. The sole body change is the exact requested median/95% interval clarification; both timing cohorts are unchanged since the raw-log audit. Corrected claims match all six cells. No remaining text must-fix; original code/security/maintainability approval stands. Details: docs/upstream/rails-82-leads-2026-11-27.md, ASC1 thermos-sol."
---

# Reuse the connection for cached association statements

While profiling a few Rails apps, association loads through the statement cache turned out to resolve the model's connection pool once more than needed. `Association#find_target` fetches the cached statement inside one `with_connection` block and runs it in another, so the pool's specification name, role, shard and lease are looked up again, and without an existing lease a connection is checked out and back in once more.

This fetches the statement inside the block that runs it, so both steps use the same connection. Records and SQL are unchanged; each load does one pool lookup fewer and, without an existing lease, one checkout fewer.

Callgrind instructions per load, Ruby 4.0.10, no JIT, objects unchanged:

| | main | this change |
|---|---:|---:|
| belongs_to | 512,155 | 496,346 |
| has_one | 546,596 | 530,339 |
| has_many, 3 rows | 666,752 | 650,905 |

Timed as thread CPU time per load over 30 rounds, the three loads take 2.2% to 3.5% less with YJIT on Ruby 4.0.10 and 1.7% to 3.2% less with ZJIT on Ruby master. Each change's 95% interval excludes zero; the main-against-main median differences are within ±0.5%, with 95% intervals that include zero.
