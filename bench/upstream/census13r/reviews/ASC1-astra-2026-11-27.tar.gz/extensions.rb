require "active_record"
case ENV.fetch("EXTENSION")
when "bullet"
  $LOAD_PATH.unshift(File.join(__dir__, "gems/bullet-8.3.1/lib"))
  $LOAD_PATH.unshift(ENV.fetch("UNIFORM_LIB"))
  require "bullet"
  Bullet.enable = true
  Bullet.start_request
when "goldiloader"
  $LOAD_PATH.unshift(File.join(__dir__, "gems/goldiloader-6.0.1/lib"))
  require "goldiloader"
end
load File.join(__dir__, "../thermos/probe.rb")
if ENV.fetch("EXTENSION") == "switchman"
  require File.join(__dir__, "gems/switchman-4.3.9/lib/switchman/active_record/reflection")
  reflection = Author.reflect_on_association(:posts)
  reflection.singleton_class.prepend(Switchman::ActiveRecord::Reflection::AbstractReflection)
  reflection.singleton_class.prepend(Switchman::ActiveRecord::Reflection::AssociationScopeCache)
  begin
    puts JSON.generate(["released Switchman override", Author.find(1).posts.map(&:id)])
  rescue => error
    puts JSON.generate(["released Switchman override", error.class.name, error.message])
  end
end
Bullet.end_request if ENV.fetch("EXTENSION") == "bullet"
