#!/bin/bash
set -u
review=$(realpath "$(dirname "$0")")
source "$review/env.sh"
for side in base head; do
  export RAILS_TREE=$(realpath "$review/../$side")
  export BUNDLE_GEMFILE="$RAILS_TREE/Gemfile"
  for adapter in sqlite3 postgresql; do
    (
      cd "$RAILS_TREE/activerecord"
      ARCONN=$adapter bundle exec ruby -Itest -I../railties/lib test/cases/test_fixtures_test.rb --seed 1127
    ) > "$review/fixtures-$side-$adapter.log" 2>&1
    echo "$side $adapter exit=$?"
    tail -7 "$review/fixtures-$side-$adapter.log"
  done
done
