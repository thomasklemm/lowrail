import json
import math
import random
import re
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parents[4]
for mode in ("yjit", "zjit"):
    directory = root / "bench/upstream/census13r/body" / f"ASC1-wall-{mode}"
    result = json.loads((directory / "results.json").read_text())
    cases = result["wall"]
    parsed = {}
    for round_number in range(1, 31):
        for side in ("base", "base2", "candidate"):
            text = (directory / "raw" / f"wall-r{round_number}-{side}.log").read_text()
            rows = {}
            jit = {}
            for line in text.splitlines():
                name, value = line.split("\t", 1)
                if name.startswith("wall "):
                    rows[name.removeprefix("wall ")] = json.loads(value)
                elif name.startswith("jit "):
                    counters = re.findall(r"(\w+)=(\d+)>(\d+)", value)
                    assert len(counters) == (3 if mode == "yjit" else 4)
                    assert all(before == after == "0" for _, before, after in counters)
                    jit[name.removeprefix("jit ")] = True
            assert rows.keys() == jit.keys() == cases.keys()
            parsed[round_number, side] = rows
    print(mode, "90 raw processes, every case/window JIT-flat")
    for name, cell in cases.items():
        changes = []
        controls = []
        for round_number, recorded in enumerate(cell["rounds"], 1):
            selected = {}
            for side in ("base", "base2", "candidate"):
                samples = parsed[round_number, side][name]
                assert samples == recorded[side]
                assert len(samples["cpu"]) == len(samples["wall"]) == cell["windows"] == 30
                selected[side] = sorted(samples["cpu"])[3] / cell["calls"]
            changes.append([math.log(selected["candidate"] / selected[side]) for side in ("base", "base2")])
            controls.append([math.log(selected["base2"] / selected["base"])])
        change = math.expm1(median([value for row in changes for value in row]))
        aa = math.expm1(median([value for row in controls for value in row]))
        assert abs(change - cell["change"]) < 1e-12
        assert abs(aa - cell["aa"]) < 1e-12
        assert cell["change_ci"][1] < 0
        assert cell["aa_ci"][0] <= 0 <= cell["aa_ci"][1]
        assert cell["claim"] and cell["jit"]["flat"]
        assert len(cell["jit"]["windows"]) == 90
        for values in (changes, controls):
            rng = random.Random(1127)
            boot = sorted(median([v for _ in range(30) for v in values[rng.randrange(30)]]) for _ in range(5000))
            interval = [math.expm1(boot[124]), math.expm1(boot[4875])]
            assert interval[1] < 0 if values is changes else interval[0] <= 0 <= interval[1]
        print(f"{name}: delta {change * 100:.4f}%, 95% CI {cell['change_ci'][0] * 100:.4f}% to {cell['change_ci'][1] * 100:.4f}%; A/A median {aa * 100:.4f}%, 95% CI {cell['aa_ci'][0] * 100:.4f}% to {cell['aa_ci'][1] * 100:.4f}%")
print("Raw records match all six summary cells; independently bootstrapped interval signs agree.")
