import csv
import gzip
import json
import math
import re
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parents[4]
data = root / "docs/upstream/data/rails-82-leads"
labels = {}
for name in ("r13m", "r13m2", "r13asc"):
    label = json.load(gzip.open(data / "labels" / f"{name}-interpreter.json.gz"))
    labels[name] = {(run["app"], w["workload"]): w["ir_per_op"] for run in label["runs"] for w in run["workloads"]}
    print(name, "Ruby", label["meta"]["ruby"], "Rails", label["meta"]["rails"]["sha"], "workloads", len(labels[name]))
rows = list(csv.DictReader(open(data / "per-workload.tsv"), delimiter="\t"))
for row in rows:
    key = row["app"], row["workload"]
    for label in labels:
        assert abs(labels[label][key] - int(row[label])) <= 0.5, (key, label)
print("All 108 label/TSV instruction cells agree after rounding")
for name in ("r13m2", "r13asc"):
    delta = {key: 100 * (value / labels["r13m"][key] - 1) for key, value in labels[name].items()}
    for app in ("ALL", *sorted({key[0] for key in delta})):
        values = sorted(v for key, v in delta.items() if app == "ALL" or key[0] == app)
        print(name, app, "n", len(values), "upper-median %.4f%%" % values[len(values)//2], "conventional-median %.4f%%" % median(values), "min %.4f%%" % min(values), "max %.4f%%" % max(values))
    print(name, "p90 abs %.4f%%" % sorted(map(abs, delta.values()))[math.ceil(len(delta)*0.9)-1])

bench = root / "bench/upstream/census13r/body/ASC1"
summary = json.load(open(bench / "results.json"))
for i, name in enumerate(("belongs_to load", "has_one load", "has_many load"), 1):
    values = {}
    for side in ("base", "base2", "candidate"):
        counts = []
        for n in (0, 2000):
            path = bench / "raw" / f"ir-interp-{i}-{name.replace(' ', '_')}-{side}-n{n}.valgrind.log"
            counts.append(int(re.search(r"Collected\s*:\s*(\d+)", path.read_text()).group(1)))
        values[side] = (counts[1] - counts[0]) / 2000
        expected = summary["instructions"][f"interp {name}"]["base1" if side == "base" else side]
        assert values[side] == expected, (name, side, values[side], expected)
    print(name, "raw-derived", values)
print("Historical interpreter table independently recomputed from retained Valgrind counts")
