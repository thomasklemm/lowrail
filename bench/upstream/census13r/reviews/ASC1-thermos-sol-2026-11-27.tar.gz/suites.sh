#!/usr/bin/env bash
set -u
review=$(realpath "$(dirname "$0")")
export PATH=/home/user/.local/share/mise/installs/ruby/4.0.10/bin:$PATH
export BUNDLE_GEMFILE="$review/Gemfile"
for side in base head; do
  export RAILS_TREE="$review/rails-$side"
  for adapter in sqlite3 postgresql; do
    export ARCONN=$adapter
    for group in associations connections; do
      log="$review/$side-$adapter-$group.log"
      (
        cd "$RAILS_TREE/activerecord"
        if [[ $group == associations ]]; then
          files=(test/cases/associations/*_test.rb test/cases/{associations,reflection,statement_cache,finder,strict_loading,query_cache}_test.rb)
        else
          files=(test/cases/{connection_handling,connection_management,connection_pool,transactions,asynchronous_queries,multiple_db}_test.rb test/cases/connection_adapters/{adapter_leasing,connection_handlers_sharding_db,connection_swapping_nested,connection_handlers_multi_db,connection_handlers_multi_pool_config}_test.rb)
        fi
        printf 'Ruby: '; ruby -v
        printf 'Head: '; git rev-parse HEAD
        printf 'Files: %s\n' "${files[*]}"
        bundle exec ruby -Itest -I../railties/lib -e 'ARGV.each { |f| require File.expand_path(f) }; ARGV.replace(["--seed", "1127"])' "${files[@]}"
      ) > "$log" 2>&1
      status=$?
      printf '%s %s %s exit=%s\n' "$side" "$adapter" "$group" "$status" | tee -a "$review/suites-summary.log"
      tail -10 "$log"
    done
  done
done
