require "timeout"
load File.join(__dir__, "probe.rb")

main_thread = Thread.current
completed = Queue.new
subscriber = ActiveSupport::Notifications.subscribe("sql.active_record") do |*, payload|
  if payload[:name] == "Post Load" && Thread.current != main_thread
    completed << [payload[:async], payload[:sql]]
  end
end
owner = Author.find(1)
ActiveRecord::Base.release_connection
tracker = ActiveRecord::Base.asynchronous_queries_tracker
tracker.start_session
association = owner.association(:posts)
association.async_load_target
event = Timeout.timeout(5) { completed.pop }
raise "not background" unless event.first
result = association.target.map { [_1.class.name, _1.id, _1.title] }
raise "wrong records" unless result == [["Post", 1, "alpha"], ["SpecialPost", 2, "beta"]]
puts JSON.generate(["confirmed background", event, result, !!ActiveRecord::Base.connection_pool.active_connection?])
tracker.finalize_session(true)
ActiveSupport::Notifications.unsubscribe(subscriber)
