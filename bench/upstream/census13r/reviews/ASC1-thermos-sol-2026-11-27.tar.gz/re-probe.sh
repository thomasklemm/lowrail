#!/usr/bin/env bash
set -eu
review=$(realpath "$(dirname "$0")")
export PATH=/home/user/.local/share/mise/installs/ruby/4.0.10/bin:$PATH
export BUNDLE_GEMFILE="$review/Gemfile"
for side in base current; do
  export RAILS_TREE="$review/rails-$side"
  for adapter in sqlite3 postgresql; do
    export ADAPTER=$adapter
    for prepared in false true; do
      export PREPARED=$prepared PROBE_DB="$review/current-$side-$prepared.sqlite3"
      bundle exec ruby "$review/probe.rb" > "$review/current-probe-$side-$adapter-$prepared.log" 2>&1
      bundle exec ruby "$review/async_background.rb" > "$review/background-$side-$adapter-$prepared.log" 2>&1
      printf 'probe/background %s %s %s: passed\n' "$side" "$adapter" "$prepared"
      if [[ $adapter == sqlite3 ]]; then
        bundle exec ruby -I"$review/goldiloader-6.0.1/lib" -rgoldiloader "$review/probe.rb" > "$review/goldiloader-$side-$prepared.log" 2>&1
      fi
    done
  done
done
for adapter in sqlite3 postgresql; do
  for prepared in false true; do
    diff -u <(sed '/^metrics /d' "$review/current-probe-base-$adapter-$prepared.log") <(sed '/^metrics /d' "$review/current-probe-current-$adapter-$prepared.log") > "$review/current-probe-$adapter-$prepared.diff"
    diff -u <(sed '/^metrics /d' "$review/background-base-$adapter-$prepared.log") <(sed '/^metrics /d' "$review/background-current-$adapter-$prepared.log") > "$review/background-$adapter-$prepared.diff"
    printf 'probe/background %s %s: identical\n' "$adapter" "$prepared"
  done
done
for prepared in false true; do
  diff -u <(sed '/^metrics /d' "$review/goldiloader-base-$prepared.log") <(sed '/^metrics /d' "$review/goldiloader-current-$prepared.log") > "$review/goldiloader-$prepared.diff"
  printf 'goldiloader %s: identical\n' "$prepared"
done
