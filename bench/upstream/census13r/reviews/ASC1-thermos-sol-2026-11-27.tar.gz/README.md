# ASC1 thermos-sol review evidence

Review date: 2026-11-27. Orb/thread: T-01a21eb9-b7bd-74a9-b7cc-38834c572ca0.

Base: 2e299253f942ab94041cc6f210ac9d33884c210d. Final reviewed head: ed1b28c5b94530e1c8b06d14dfca0ee93d5c07ba.

The independent benchmark uses 2b46f50bda446b9d84c3c86ac2f90bec4b7df6db, which has byte-identical activerecord/lib to the final head. The current suites/probes use 703f89d6f6cc002b7f2169c95887d54b07482fbc, whose whole tree equals the final head. `provenance.log` records all library-tree and changed-file blob IDs. These are detached worktrees, not changes to the fork branch.

Restore this archive into `.amp/in/orb-backup/asc1-review` relative to Lowrail. Create detached worktrees named `rails-base`, `rails-head`, `rails-current` there at the three SHAs above. The worktrees and installed Ruby/Valgrind are not duplicated in the archive. Ruby is 4.0.10 (a704b7cd95), pg gem 1.7.0, sqlite3 gem 2.10.2. PostgreSQL 17.12 runs locally, with the test helper's databases and a disposable database named `asc1_probe`; no remote database was used.

## Executed checks

* `bash .amp/in/orb-backup/asc1-review/current-checks.sh`: both suites/groups and original independent probes on base/current. Logs print selected SHA and assert all three loaded component paths. `current-checks.log` and individual `current-*-associations.log` / `current-*-connections.log` are the final suite results.
* `bash .amp/in/orb-backup/asc1-review/re-probe.sh`: final probes, explicit background-query confirmation, and Goldiloader 6.0.1, including frozen string/subclass keys. `re-probe.log` has decisive results; `current-probe-*`, `background-*`, `goldiloader-*` retain actual results and zero-length matching diffs. Counters alone are removed for the diffs; records, SQL, exception messages, conversion effects and lease state remain.
* `python3 .amp/in/orb-backup/asc1-review/audit_evidence.py`: historical body numbers recomputed directly from Valgrind logs, and every compressed census label's instruction cell checked against the TSV. `audit-evidence.log` records the results. The source evidence already lives in Lowrail; it is not duplicated here.
* `script/upstream-bench --out .amp/in/orb-backup/asc1-review/bench --base .amp/in/orb-backup/asc1-review/rails-base --candidate .amp/in/orb-backup/asc1-review/rails-head --gems activesupport,activemodel,activerecord --with sqlite3 --ruby 4.0.10 --valgrind .amp/in/orb-backup/asc1-review/valgrind-brk512 --modes interp --warmup 300 -n 200 --names main,ASC1 .amp/in/orb-backup/asc1-review/worst.rb`: controlled independent micro/worst-input run. `bench/commands.sh` preserves each exact subprocess command, heap settings and Ruby paths; raw counts and A/A are in `bench/raw` and `bench/results.json`. `worst.rb` loads Lowrail's existing `bench/upstream/census13r/asc1_body.rb` then adds cold-cache and 1,000-row cases. `bench/valgrind.json` pins the patched Valgrind.
* Flog: `bundle exec flog -a` on the two production files and route tests, with `RAILS_TREE`/`BUNDLE_GEMFILE` as in the scripts. RuboCop: `bundle exec rubocop --config rubocop.yml --format json` on the same files. Zero thresholds are deliberate measurement settings, not lint failures. `metrics-*` contains full outputs.

## Retained history and boundaries

`base-*` / `head-*` suite logs are the initial 2b46 library-head suites; `head-sqlite-route.log` contains the reproduced stale-arity failure, and `base-sqlite-route.log` its clean control. They are not the final route test result. Earlier probes are retained alongside the final ones, but final `current-probe-*` logs are authoritative. `setup-attempts` contains harness/dependency/locale failures, including an incorrect wait for deferred async instrumentation on both base and head, not hidden branch failures.

The public gem archives, Rubygems metadata and code-search results retain the bounded released-extension inventory. `gems-summary.tsv` records versions, downloads and release dates. Goldiloader source is also unpacked for the runtime check. The similarly named current `stagehand` SDK is unrelated to the old Active Record extension found by search.

No wall time, throughput, MySQL, oldest-adapter matrix, full framework-suite result, or not-JIT-flat speed claim is established by this review. No new upstream post or branch push was made. This archive is supporting evidence; the verdict and limitations are in Lowrail's `docs/upstream/rails-82-leads-2026-11-27.md`, section `ASC1 thermos-sol`.

## Completed worst-input run

The controlled interpreter run finished at 2026-11-27T21:13:03Z. Base/candidate instructions per load and A/A spread:

| Input | Base mean | Candidate | Change | A/A |
| --- | ---: | ---: | ---: | ---: |
| belongs_to | 516904.9025 | 501080.480 | -3.0614% | 0.0546% |
| has_one | 551491.5200 | 535888.820 | -2.8292% | 0.0974% |
| has_many, 3 rows | 673113.0550 | 657179.475 | -2.3671% | 0.1007% |
| cold-cache belongs_to | 934976.0325 | 920077.370 | -1.5935% | 0.0251% |
| has_many, 1000 rows | 63939085.755 | 63915612.425 | -0.0367% | 0.0054% |

Every object count is unchanged; the largest case allocates 9088.144 objects/load. This is the slowest tested case, not a finite global worst over unbounded cardinality and database latency. `bench/results.json` retains unrounded values; `bench/raw` retains all N=0/N=200 counts. No inference about wall time is made.
