# frozen_string_literal: true

load File.expand_path("../../../../bench/upstream/census13r/asc1_body.rb", __dir__)

post = Post.first
bulk = Author.create!(name: "bulk")
Post.insert_all!(Array.new(1000) { |i| { author_id: bulk.id, title: "p#{i}" } })

UpstreamBench.report("belongs_to cold cache") do
  Post.reflect_on_association(:author).clear_association_scope_cache
  post.association(:author).reset
  post.author
end
UpstreamBench.report("has_many 1000 rows") { bulk.posts.reset; bulk.posts.to_a }
