Objects and Callgrind instructions per call, Ruby 4.0.10, no JIT

| | Objects, main | Objects, asc1 | Instructions, main | Instructions, asc1 | Change |
| --- | ---: | ---: | ---: | ---: | ---: |
| `belongs_to load` | 94 | 94 | 516,905 | 501,080 | −3.1% |
| `has_one load` | 94 | 94 | 551,492 | 535,889 | −2.8% |
| `has_many load` | 114 | 114 | 673,113 | 657,179 | −2.4% |
| `belongs_to cold cache` | 194 | 194 | 934,976 | 920,077 | −1.6% |
| `has_many 1000 rows` | 9088.1 | 9088.1 | 63,939,086 | 63,915,612 | −0.0% |

Record (not for the body): Callgrind and benchmark-ips cells take base = mean of two base runs, A/A = their spread. Raw output and commands in /home/user/workspace/repo/.amp/in/orb-backup/asc1-review/bench.
- base: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/asc1-review/rails-base at 2e299253f9
- candidate: ruby 4.0.10 (2026-11-19 revision a704b7cd95) +PRISM [x86_64-linux], /home/user/workspace/repo/.amp/in/orb-backup/asc1-review/rails-head at 2b46f50bda
- interp belongs_to load: instructions −3.1% with A/A 0.05% (base 516,764 / 517,046, candidate 501,080)
- interp has_one load: instructions −2.8% with A/A 0.10% (base 551,223 / 551,760, candidate 535,889)
- interp has_many load: instructions −2.4% with A/A 0.10% (base 672,774 / 673,452, candidate 657,179)
- interp belongs_to cold cache: instructions −1.6% with A/A 0.03% (base 935,093 / 934,859, candidate 920,077)
- interp has_many 1000 rows: instructions −0.0% with A/A 0.01% (base 63,940,809 / 63,937,362, candidate 63,915,612)
