# frozen_string_literal: true

require "json"
require "active_record"

ActiveRecord.async_query_executor = :global_thread_pool
config = if ENV.fetch("ADAPTER") == "postgresql"
  { adapter: "postgresql", database: "asc1_probe" }
else
  { adapter: "sqlite3", database: ENV.fetch("PROBE_DB") }
end
ActiveRecord::Base.establish_connection(**config, prepared_statements: ENV.fetch("PREPARED") == "true", pool: 1, checkout_timeout: 1)
ActiveRecord::Migration.verbose = false
ActiveRecord::Schema.define do
  create_table(:authors, force: true) { |t| t.string :name }
  create_table(:posts, force: true) { |t| t.integer :author_id; t.string :title; t.string :type }
  create_table(:profiles, force: true) { |t| t.integer :author_id; t.string :bio }
  create_table(:tags, force: true) { |t| t.integer :post_id; t.string :name }
  create_table(:comments, force: true) { |t| t.integer :commentable_id; t.string :commentable_type }
end

class ApplicationRecord < ActiveRecord::Base
  primary_abstract_class
end
class Author < ApplicationRecord
  has_many :posts, inverse_of: :author
  has_many :filtered_posts, -> { where(title: "alpha") }, class_name: "Post"
  has_one :profile
  has_many :tags, through: :posts
  has_many :comments, as: :commentable
end
class Post < ApplicationRecord
  belongs_to :author, inverse_of: :posts
  has_many :tags
  after_find { raise "after_find failure" if Thread.current[:raise_after_find] }
end
class SpecialPost < Post; end
class Profile < ApplicationRecord
  belongs_to :author
end
class Tag < ApplicationRecord
  belongs_to :post
end
class Comment < ApplicationRecord
  belongs_to :commentable, polymorphic: true
end
class IntegerLike
  def to_i
    (Thread.current[:conversions] ||= []) << "to_i"
    1
  end
end
class OddString < String
  def to_i(...)
    (Thread.current[:conversions] ||= []) << "string to_i"
    super
  end
end
class MissingInteger
  def respond_to_missing?(name, include_private = false)
    name == :to_i || super
  end

  def method_missing(name, ...)
    return super unless name == :to_i
    (Thread.current[:conversions] ||= []) << "missing to_i"
    1
  end
end
class OddArray < Array; end
class OddHash < Hash; end

owner = Author.create!(id: 1, name: "one")
empty = Author.create!(id: 2, name: "empty")
post = Post.create!(id: 1, author: owner, title: "alpha")
SpecialPost.create!(id: 2, author: owner, title: "beta")
Profile.create!(author: owner, bio: "bio")
Tag.create!(post: post, name: "tag")
comment = Comment.create!(commentable: owner)

pool = ActiveRecord::Base.connection_pool
events = []
ActiveSupport::Notifications.subscribe("sql.active_record") do |*, payload|
  if Thread.current[:observe] && payload[:name] != "SCHEMA"
    events << [payload[:sql], payload[:binds].map(&:value_for_database), !!payload[:cached], !!payload[:async]]
  end
end
ActiveRecord::Base.singleton_class.prepend(Module.new do
  def connection_pool
    Thread.current[:metrics][:pool] += 1 if Thread.current[:observe]
    super
  end
end)
pool.singleton_class.prepend(Module.new do
  def checkout(...)
    Thread.current[:metrics][:checkout] += 1 if Thread.current[:observe]
    super
  end
end)

normalize = lambda do |result|
  case result
  when ActiveRecord::Base then [result.class.name, result.attributes]
  when Array then result.map { normalize.call(_1) }
  else result
  end
end
observe = lambda do |name, &block|
  Thread.current[:metrics] = Hash.new(0)
  Thread.current[:conversions] = []
  events.clear
  Thread.current[:observe] = true
  result = begin
    normalize.call(block.call)
  rescue => e
    [e.class.name, e.message.gsub(/0x[0-9a-f]+/, "ADDRESS")]
  ensure
    Thread.current[:observe] = false
  end
  puts JSON.generate([name, { result: result, sql: events.dup, leased: !!pool.active_connection?, conversions: Thread.current[:conversions] }])
  puts "metrics #{name} #{JSON.generate(Thread.current[:metrics])}"
end

[:posts, :profile, :tags, :comments, :filtered_posts].each do |name|
  owner.association(name).reset
  owner.public_send(name).then { |r| r.respond_to?(:to_a) ? r.to_a : r }
end
post.reload_author
comment.reload_commentable
[:unleased, :leased, :outer_block].each do |mode|
  run = lambda do
    [:posts, :profile, :tags, :comments, :filtered_posts].each do |name|
      owner.association(name).reset
      observe.call("#{mode} #{name}") do
        result = owner.public_send(name)
        result.respond_to?(:to_a) ? result.to_a : result
      end
    end
    post.association(:author).reset
    observe.call("#{mode} belongs_to") { post.author }
    comment.association(:commentable).reset
    observe.call("#{mode} polymorphic") { comment.commentable }
  end
  ActiveRecord::Base.release_connection
  case mode
  when :unleased then run.call
  when :leased then ActiveRecord::Base.lease_connection; run.call
  when :outer_block then ActiveRecord::Base.with_connection { run.call }
  end
end
ActiveRecord::Base.release_connection
observe.call("empty") { empty.posts.to_a }
observe.call("nil key") { Post.new.author }
observe.call("missing target") { Post.new(author_id: 999).author }
observe.call("strict loading") { Author.find(1).tap(&:strict_loading!).posts.to_a }
observe.call("frozen owner and key") { Post.new(author_id: +"1").freeze.author }
observe.call("frozen result") { post.reload_author.freeze }

[1, +"1", OddString.new("1"), IntegerLike.new, MissingInteger.new, OddArray.new([1]), OddHash.new.merge(k: 1), 1 << 100, "1".freeze, OddString.new("1").freeze].each_with_index do |value, index|
  observe.call("key conversion #{index} #{value.class}") { Post.new(author_id: value).author }
end

[:singleton, :extend, :prepend].each do |kind|
  copy = post.dup
  patch = Module.new do
    def read_attr(name)
      (Thread.current[:conversions] ||= []) << "read_attr #{name}"
      super
    end
  end
  case kind
  when :singleton then copy.define_singleton_method(:read_attr, patch.instance_method(:read_attr))
  when :extend then copy.extend(patch)
  when :prepend then copy.singleton_class.prepend(patch)
  end
  observe.call("owner #{kind}") { copy.author }
end
private_owner = post.dup
private_owner.singleton_class.class_eval { private :read_attr }
observe.call("private reader") { private_owner.author }

pool.enable_query_cache!
2.times do |i|
  owner.association(:posts).reset
  observe.call("query cache #{i}") { owner.posts.to_a }
end
pool.disable_query_cache!
observe.call("after_find exception") do
  Thread.current[:raise_after_find] = true
  owner.posts.reload.to_a
ensure
  Thread.current[:raise_after_find] = false
end
observe.call("connection after exception") { owner.posts.reload.to_a }
observe.call("transaction rollback") do
  Author.transaction do
    Post.create!(id: 3, author_id: 1, title: "rolled back")
    result = owner.posts.reload.map(&:title)
    puts JSON.generate(["inside transaction", result])
    raise ActiveRecord::Rollback
  end
  owner.posts.reload.map(&:title)
end
observe.call("async load") do
  tracker = ActiveRecord::Base.asynchronous_queries_tracker
  tracker.start_session
  association = owner.association(:posts)
  association.reset
  association.async_load_target
  association.target
ensure
  tracker.finalize_session(true)
end
observe.call("thread pool one") { Thread.new { Author.find(1).posts.map(&:id) }.value }
ActiveRecord::Base.release_connection
observe.call("fiber suspension") do
  copy = post.dup
  copy.define_singleton_method(:read_attr) { |name| Fiber.yield("paused #{name}"); super(name) }
  fiber = Fiber.new { copy.author.name }
  values = []
  values << fiber.resume while fiber.alive?
  values
end
observe.call("reload schema and cache") do
  Post.reset_column_information
  owner.posts.reload.to_a
end
ActiveRecord::Base.release_connection
