#!/usr/bin/env bash
set -u
review=$(realpath "$(dirname "$0")")
export PATH=/home/user/.local/share/mise/installs/ruby/4.0.10/bin:$PATH
export BUNDLE_GEMFILE="$review/Gemfile"
for side in base current; do
  export RAILS_TREE="$review/rails-$side"
  for adapter in sqlite3 postgresql; do
    export ARCONN=$adapter
    for group in associations connections; do
      log="$review/current-$side-$adapter-$group.log"
      (
        cd "$RAILS_TREE/activerecord"
        if [[ $group == associations ]]; then
          files=(test/cases/associations/*_test.rb test/cases/{association_route,associations,reflection,statement_cache,finder,strict_loading,query_cache}_test.rb)
        else
          files=(test/cases/{connection_handling,connection_management,connection_pool,transactions,asynchronous_queries,multiple_db}_test.rb test/cases/connection_adapters/{adapter_leasing,connection_handlers_sharding_db,connection_swapping_nested,connection_handlers_multi_db,connection_handlers_multi_pool_config}_test.rb)
        fi
        ruby -v
        git rev-parse HEAD
        printf 'Files: %s\n' "${files[*]}"
        bundle exec ruby -Itest -I../railties/lib -e 'require "active_record"; %w[activerecord activemodel activesupport].each { |g| path = Gem.loaded_specs.fetch(g).full_gem_path; puts "LOADED #{g}: #{path}"; abort "wrong tree" unless path.start_with?(ENV.fetch("RAILS_TREE") + "/") }; ARGV.each { |f| require File.expand_path(f) }; ARGV.replace(["--seed", "1127"])' "${files[@]}"
      ) > "$log" 2>&1
      status=$?
      printf '%s %s %s exit=%s\n' "$side" "$adapter" "$group" "$status" | tee -a "$review/current-suites-summary.log"
      tail -6 "$log"
    done
    for prepared in false true; do
      ADAPTER=$adapter PREPARED=$prepared PROBE_DB="$review/current-$side-$prepared.sqlite3" bundle exec ruby "$review/probe.rb" > "$review/current-probe-$side-$adapter-$prepared.log" 2>&1
      printf 'probe %s %s %s exit=%s\n' "$side" "$adapter" "$prepared" "$?"
    done
  done
done
for adapter in sqlite3 postgresql; do
  for prepared in false true; do
    diff -u <(sed '/^metrics /d' "$review/current-probe-base-$adapter-$prepared.log") <(sed '/^metrics /d' "$review/current-probe-current-$adapter-$prepared.log") > "$review/current-probe-$adapter-$prepared.diff"
    printf 'diff %s %s exit=%s\n' "$adapter" "$prepared" "$?"
  done
done
