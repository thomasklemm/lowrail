require "active_record"
require "json"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.transaction do
  1000.times do |i|
    c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, "noidx" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id")))
    c.execute %(CREATE INDEX "idx_#{i}" ON "t#{i}" ("parent_id"))
  end
end
tables = 1000.times.map { "t#{_1}" }
adapter = ActiveRecord::ConnectionAdapters::SQLite3Adapter
names = %i[table_structures fetch_foreign_keys]
names.each { |name| adapter.alias_method :"#{name}_head", name }
base_source = File.read(File.expand_path("rails-base/activerecord/lib/active_record/connection_adapters/sqlite3_adapter.rb", __dir__))
{ table_structures: "arel_visitor", fetch_foreign_keys: "build_foreign_keys" }.each do |name, following|
  source = "        def #{name}" + base_source.split("        def #{name}", 2).last.split("        def #{following}", 2).first
  adapter.class_eval(source.sub("def #{name}", "def #{name}_base"))
end
variants = %w[main head main2]
results = variants.to_h { [_1, { columns: [], foreign_keys: [] }] }
clock = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
12.times do |round|
  variants.rotate(round % 3).each do |variant|
    implementation = variant == "head" ? "head" : "base"
    names.each { |name| adapter.alias_method name, :"#{name}_#{implementation}" }
    raise unless c.columns("t501").map(&:name) == %w[id name parent_id noidx]
    raise unless c.foreign_keys("t501").map(&:name) == ["fk_t501"]
    %i[columns foreign_keys].each do |reader|
      GC.start
      start = clock.call
      tables.each { c.public_send(reader, _1) }
      results[variant][reader] << clock.call - start
    end
  end
end
puts JSON.pretty_generate(sqlite: SQLite3::SQLITE_VERSION, results: results)
