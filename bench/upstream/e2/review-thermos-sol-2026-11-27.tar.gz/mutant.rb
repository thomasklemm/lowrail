require "active_record"
require "active_record/connection_adapters/sqlite3_adapter"

mod = ActiveRecord::ConnectionAdapters::SQLite3::SchemaStatements
file, line = mod.instance_method(:by_stored_name).source_location
source = File.readlines(file)[(line - 1)..].join.split("          def fetch_indexes", 2).first
case ENV.fetch("MUTANT")
when "unicode"
  source = source.gsub("downcase(:ascii)", "downcase")
when "main_first"
  source = source.sub("ORDER BY temporary", "ORDER BY temporary DESC")
end
mod.module_eval(source, file, line)
require File.expand_path("rails-head/activerecord/test/cases/adapters/sqlite3/sqlite3_adapter_test.rb", __dir__)
