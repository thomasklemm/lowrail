#!/usr/bin/env bash
set -euo pipefail
dir=/home/user/workspace/repo/.amp/in/orb-backup/e2-review
out="$dir/review-bench.jsonl"
: > "$out"
for round in 1 2 3 4 5 6; do
  order=(main head main2)
  case $((round % 3)) in
    1) order=(head main2 main) ;;
    2) order=(main2 main head) ;;
  esac
  for label in "${order[@]}"; do
    tree=base
    [ "$label" != head ] || tree=head
    result=$(bash "$dir/run" "$tree" taskset -c 1 ruby "$dir/bench.rb")
    printf '{"round":%s,"tree":"%s","r":%s}\n' "$round" "$label" "$result" >> "$out"
  done
done
bash "$dir/run" head ruby "$dir/summary.rb" "$out"
