require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.execute 'CREATE TABLE "Widgets" ("id" integer PRIMARY KEY AUTOINCREMENT, "number" integer, "calculated" integer GENERATED ALWAYS AS (number + 7) STORED)'
c.execute 'CREATE INDEX widget_expression ON "Widgets" (number + 1) WHERE number > 3'
%w[Widgets widgets WIDGETS].each do |name|
  cols = c.columns(name)
  raise unless cols.first.auto_increment? && cols.last.virtual_stored?
  index = c.indexes(name).first
  raise index.inspect unless index.columns == "number + 1" && index.where == "number > 3"
end
c.execute 'CREATE TABLE "Composite" ("second" integer, "first" integer, "ref_first" integer, "ref_second" integer, PRIMARY KEY (first, second), CONSTRAINT "composite_fk" FOREIGN KEY ("ref_first", "ref_second") REFERENCES "Composite" ("first", "second") DEFERRABLE INITIALLY DEFERRED)'
%w[Composite composite COMPOSITE].each do |name|
  raise unless c.primary_keys(name) == %w[first second]
  fk = c.foreign_keys(name).first
  expected = [%w[ref_first ref_second], %w[first second], name]
  actual = [fk.column, fk.primary_key, fk.from_table]
  raise actual.inspect unless actual == expected
end
c.execute 'CREATE TABLE "Deferred" ("reference" integer, CONSTRAINT "deferred_fk" FOREIGN KEY ("reference") REFERENCES "Widgets" ("id") DEFERRABLE INITIALLY DEFERRED)'
%w[Deferred deferred DEFERRED].each do |name|
  fk = c.foreign_keys(name).first
  raise unless [fk.name, fk.deferrable] == ["deferred_fk", :deferred]
end
puts "SQLite #{SQLite3::SQLITE_VERSION}: generated/autoincrement, expression/partial indexes and composite/deferred FKs pass"
