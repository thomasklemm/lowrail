from pathlib import Path
import hashlib
import json
import re
import statistics

root = Path(__file__).resolve().parent
raw = root / "e2r"
source = (raw / "inproc_fk2.rb").read_text()

def method(text, name):
    match = re.search(r"^( +)def " + name + r"\(tables\)\n", text, re.M)
    end = text.index("\n" + match[1] + "end\n", match.end())
    return text[match.start():end].splitlines()

for variant, tree in [("main", "e2-base"), ("head", "e2-head-2")]:
    adapter = (root.parent / tree / "activerecord/lib/active_record/connection_adapters/sqlite3_adapter.rb").read_text()
    for name in ["table_structures", "fetch_foreign_keys"]:
        copied = method(source, name + "_" + variant)
        normalized = [line.strip().replace("_" + variant + "(", "(").replace("#{CTE}", "#{MASTER_CTE}") for line in copied]
        expected = [line.strip() for line in method(adapter, name) if not line.strip().startswith("# ")]
        assert normalized == expected, (variant, name, normalized, expected)
        print(f"{variant} {name}: copied body matches actual tree after name/CTE/indent/comment normalization")

for filename in ["e2r-fk2-zjit.json", "e2r-fk2-409.json"]:
    data = json.loads((raw / filename).read_text())
    variants = data["variants"]
    base = statistics.median(variants["main"]["times"])
    print(filename, data["ruby"])
    for label, v in variants.items():
        median = statistics.median(v["times"])
        assert median == v["median_s"]
        print(f"  {label}: {median:.9f}s {(median/base-1)*100:+.3f}%; n={len(v['times'])}; alloc={v['alloc_per_call']}; GC={v['gc_runs']}")
    print("  JIT snapshots:", [k for k in data if "zjit" in k])

for filename, key in [("e2r-fk2-proc-zjit.jsonl", "times"), ("e2r-fk2-trees.jsonl", "times"), ("e2r-zjit-fk3.jsonl", "fks_only")]:
    data = [json.loads(line) for line in (raw / filename).read_text().splitlines()]
    assert len(data) == 18
    print(filename)
    base = None
    for label in ["main", "head", "main2"]:
        rows = [r for r in data if r["tree"] == label]
        assert sorted(r["round"] for r in rows) == list(range(1, 7))
        assert all("42a644f6e0" in r["r"]["ruby"] and "+ZJIT" in r["r"]["ruby"] for r in rows)
        assert all(len(r["r"][key]) == 5 for r in rows)
        median = statistics.median(statistics.median(r["r"][key]) for r in rows)
        if base is None:
            base = median
        print(f"  {label}: {median:.9f}s {(median/base-1)*100:+.3f}%; processes={len(rows)}")

body = (raw / "body-2.md").read_bytes()
print("body:", len(body), hashlib.sha256(body).hexdigest())
