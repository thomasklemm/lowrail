# In one process on the head tree: alternate main's and head's fetch_foreign_keys (each over head's table_structures),
# timing 1,000 single foreign_keys calls. Also times head's with main's order but the stored-name fetch.
require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.transaction do
  1000.times { |i| c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, "noidx" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id"))) }
end
tables = 1000.times.map { "t#{_1}" }
A = ActiveRecord::ConnectionAdapters::SQLite3Adapter
CTE = ActiveRecord::ConnectionAdapters::SQLite3::SchemaStatements::MASTER_CTE
A.define_method(:fetch_foreign_keys_head, A.instance_method(:fetch_foreign_keys))
A.define_method(:fetch_foreign_keys_main) do |tables|
  return {} if tables.empty?
  fk_infos = query_all(<<~SQL).group_by { |row| row["table_name"] }
    #{CTE}
    SELECT m.name AS table_name, fk.id, fk.seq, fk."table", fk."from", fk."to", fk.on_update, fk.on_delete
    FROM master m
    JOIN pragma_foreign_key_list(m.name) fk
    WHERE m.type = 'table'
      AND m.name IN (#{quoted_table_names(tables)})
  SQL
  structures = table_structures(tables)
  tables.index_with do |table_name|
    create_table_sql, structure = structures[table_name] || [nil, []]
    column_strings = split_table_structure_sql(create_table_sql, structure.map { |column| column["name"] })
    build_foreign_keys(table_name, fk_infos.fetch(table_name, []), column_strings)
  end
end
variants = %w[main head main2 head2]
times = variants.to_h { [_1, []] }
clock = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
3.times { %w[main head].each { |v| A.alias_method :fetch_foreign_keys, :"fetch_foreign_keys_#{v}"; tables.each { c.foreign_keys(_1) } } }
15.times do |round|
  variants.rotate(round % 4).each do |v|
    A.alias_method :fetch_foreign_keys, :"fetch_foreign_keys_#{v.delete_suffix("2")}"
    t = clock.(); tables.each { c.foreign_keys(_1) }; times[v] << clock.() - t
  end
end
med = ->(a) { a.sort[a.size / 2] }
puts RUBY_DESCRIPTION
variants.each { |v| puts format("%-6s %.4f s  %+.1f%%", v, med.(times[v]), (med.(times[v]) / med.(times["main"]) - 1) * 100) }
