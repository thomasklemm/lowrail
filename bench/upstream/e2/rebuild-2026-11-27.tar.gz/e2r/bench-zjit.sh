#!/bin/bash
# bench-zjit.sh OUT ROUNDS: as bench.sh, on the pinned Ruby master build with --zjit.
out=$1; rounds=${2:-5}; : > $out
R=/home/user/workspace/ruby-master/install/bin
for r in $(seq $rounds); do
  order=(main head main2); case $((r % 3)) in 1) order=(head main2 main);; 2) order=(main2 main head);; esac
  for tree in "${order[@]}"; do
    dir=/home/user/workspace/rails-main; [ $tree = head ] && dir=/home/user/workspace/rails-e2
    res=$(cd $dir && taskset -c 1 env PATH=$R:$PATH BUNDLE_GEMFILE=/home/user/workspace/e2-master/Gemfile $R/bundle exec $R/ruby --zjit -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib /home/user/workspace/repo/.amp/in/orb-backup/e2r/bench.rb)
    echo "{\"round\":$r,\"tree\":\"$tree\",\"r\":$res}" >> $out
  done
done
