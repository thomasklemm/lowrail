# ruby paired-sum.rb FILE.jsonl: per warmup and tree, median over processes of the timed-window median, and per timed
# window index the median over rounds; plus allocations, GC and ZJIT deltas in timed windows.
require "json"
rows = File.readlines(ARGV[0]).map { JSON.parse(_1) }
med = ->(a) { s = a.sort; s.size.odd? ? s[s.size / 2] : (s[s.size / 2 - 1] + s[s.size / 2]) / 2.0 }
[1, 3].each do |w|
  base = nil
  puts "warmup #{w}:"
  %w[main head main2].each do |t|
    rs = rows.select { _1["warmup"] == w && _1["tree"] == t }
    timed = rs.map { |r| r["r"]["windows"].select { _1["phase"] == "timed" } }
    per = timed.map { |ws| med.(ws.map { _1["s"] }) }
    m = med.(per); base ||= m
    byw = timed.transpose.map { |col| med.(col.map { _1["s"] }) }
    warm = rs.map { |r| r["r"]["windows"].select { _1["phase"] == "warmup" }.map { _1["s"] } }.transpose.map { med.(_1) }
    all = timed.flatten
    zc = all.sum { _1["zjit"]["compiled_iseq_count"].to_i }
    puts format("  %-5s %.4f %+.2f%% n=%d [%s] windows %s warmups %s | alloc/call %.1f gc/win %.1f (major %d) gc_ms/win %.1f | timed compiled_iseq %d side_exit/win %d",
      t, m, (m / base - 1) * 100, rs.size, per.map { format("%.3f", _1) }.join(" "), byw.map { format("%.3f", _1) }.join(" "),
      warm.map { format("%.3f", _1) }.join(" "), med.(all.map { _1["alloc"] }) / 1000.0, all.sum { _1["gc"] } / all.size.to_f,
      all.sum { _1["major"] }, all.sum { _1["gc_ms"] } / all.size.to_f, zc, med.(all.map { _1["zjit"]["side_exit_count"].to_i }))
  end
end
