#!/bin/bash
# irbench.sh RUBY OPS [RUBYFLAGS]: per-call Ir for main, head, main again. RUBY=409 (bundle, mise 4.0.9) or master.
which=$1; ops=$2; flags=$3
for op in $ops; do
  for tree in main head main2; do
    dir=/home/user/workspace/rails-main; [ $tree = head ] && dir=/home/user/workspace/rails-e2
    for calls in 0 400; do
      cd $dir
      if [ $which = master ]; then
        R=/home/user/workspace/ruby-master/install/bin
        out=$(OP=$op CALLS=$calls PATH=$R:$PATH BUNDLE_GEMFILE=/home/user/workspace/e2-master/Gemfile $R/bundle exec valgrind --tool=cachegrind --cache-sim=no --smc-check=all --cachegrind-out-file=/dev/null $R/ruby $flags -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib /home/user/workspace/repo/.amp/in/orb-backup/e2r/irbench.rb 2>&1)
      else
        out=$(OP=$op CALLS=$calls BUNDLE_GEMFILE=/home/user/workspace/rails-e2/Gemfile BUNDLE_WITHOUT="doc:mdl:job:cable:storage" mise exec ruby@4.0.9 -- bundle exec valgrind --tool=cachegrind --cache-sim=no --cachegrind-out-file=/dev/null ruby -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib /home/user/workspace/repo/.amp/in/orb-backup/e2r/irbench.rb 2>&1)
      fi
      echo "$(echo "$out" | grep -oE 'I +refs: +[0-9,]+' | tr -dc 0-9) $op $tree $calls"
    done
  done
done
