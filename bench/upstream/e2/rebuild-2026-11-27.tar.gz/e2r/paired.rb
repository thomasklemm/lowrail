# The paired 1-vs-3-warmup check (E2, 2026-11-27, decided in advance: one cohort, no reruns).
# Public foreign_keys on the tree it runs in (main or head), the bench.rb fixture, WARMUP warmup windows then 5 timed
# windows, every window kept: wall time, objects allocated, GC count/minor/major, GC time (ms), ZJIT stat deltas.
require "active_record"
require "json"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.transaction do
  1000.times do |i|
    c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, "noidx" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id")))
    c.execute %(CREATE INDEX "index_t#{i}_on_parent_id" ON "t#{i}" ("parent_id"))
  end
  100.times { |i| c.execute %(CREATE TABLE "u#{i}" ("id" integer PRIMARY KEY, "value" integer)) }
end
tables = 1000.times.map { "t#{_1}" }
raise unless c.foreign_keys("t500").map(&:name) == ["fk_t500"]
zjit = defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?
zstats = -> { zjit ? RubyVM::ZJIT.stats.select { |_, v| v.is_a?(Integer) } : {} }
snap = -> { s = GC.stat; { a: s[:total_allocated_objects], gc: s[:count], minor: s[:minor_gc_count], major: s[:major_gc_count], gct: s[:time], z: zstats.() } }
clock = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
warmup = Integer(ENV.fetch("WARMUP"))
GC.start
windows = (warmup + 5).times.map do |i|
  s0 = snap.(); t0 = clock.()
  tables.each { c.foreign_keys(_1) }
  t = clock.() - t0; s1 = snap.()
  zd = s1[:z].to_h { |k, v| [k, v - s0[:z].fetch(k, 0)] }.reject { |_, v| v.zero? }
  { phase: i < warmup ? "warmup" : "timed", s: t, alloc: s1[:a] - s0[:a], gc: s1[:gc] - s0[:gc], minor: s1[:minor] - s0[:minor],
    major: s1[:major] - s0[:major], gc_ms: s1[:gct] - s0[:gct],
    zjit: zd.slice(*%w[compiled_iseq_count compiled_side_exit_count side_exit_count invalidation_time_ns compile_time_ns
                       dynamic_send_count compiled_block_count].map(&:to_sym), *%w[compiled_iseq_count compiled_side_exit_count side_exit_count invalidation_time_ns compile_time_ns dynamic_send_count]),
    zjit_changed: zd.keys.size }
end
puts JSON.generate(ruby: RUBY_DESCRIPTION, zjit: zjit, sqlite: c.database_version.to_s, warmup: warmup, windows: windows)
