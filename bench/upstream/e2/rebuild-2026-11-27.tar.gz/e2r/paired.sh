#!/bin/bash
# paired.sh OUT: 6 rounds × warmup {1,3} × tree {main, head, main2} rotated, fresh ZJIT processes with --zjit-stats=quiet.
out=$1; : > $out
R=/home/user/workspace/ruby-master/install/bin
for r in 1 2 3 4 5 6; do
  for w in 1 3; do
    order=(main head main2); case $(((r + w) % 3)) in 1) order=(head main2 main);; 2) order=(main2 main head);; esac
    for v in "${order[@]}"; do
      dir=/home/user/workspace/rails-main; [ $v = head ] && dir=/home/user/workspace/rails-e2
      res=$(cd $dir && taskset -c 1 env PATH=$R:$PATH BUNDLE_GEMFILE=/home/user/workspace/e2-master/Gemfile WARMUP=$w $R/bundle exec $R/ruby --zjit --zjit-stats=quiet -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib /home/user/workspace/repo/.amp/in/orb-backup/e2r/paired.rb)
      echo "{\"round\":$r,\"warmup\":$w,\"tree\":\"$v\",\"r\":$res}" >> $out
    done
  done
done
