# Instruction counts per call: run under cachegrind with CALLS=0 and CALLS=n, subtract, divide by n.
# OP=fks|columns|indexes. 200 tables, GC disabled after setup and a warmup pass.
require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.transaction do
  200.times { |i| c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id"))); c.execute %(CREATE INDEX "i#{i}" ON "t#{i}" ("parent_id")) }
end
tables = 200.times.map { "t#{_1}" }
op = { "fks" => :foreign_keys, "columns" => :columns, "indexes" => :indexes }.fetch(ENV.fetch("OP"))
tables.each { c.public_send(op, _1) }
GC.start; GC.disable
Integer(ENV.fetch("CALLS")).times { |i| c.public_send(op, tables[i % 200]) }
