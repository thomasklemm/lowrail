# frozen_string_literal: true

# Runs probe.rb (the E2 public-reader probe) as a test, for script/min-versions.
require "minitest/autorun"

class E2ProbeTest < Minitest::Test
  def test_probe
    skip "SQLite only" unless ENV.fetch("ARCONN", "sqlite3") == "sqlite3"
    out, = capture_io { load File.join(__dir__, "probe.rb") }
    puts out.lines.grep(/FAIL|SQLite|failures/)
    assert_includes out, "0 failures (final)"
  end
end
