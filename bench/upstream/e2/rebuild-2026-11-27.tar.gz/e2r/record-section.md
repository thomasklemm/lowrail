### Rebuilt on main after #59668, 2026-11-27

Opus thread `T-01a21c93-5404-7479-ba90-5ecfbe32de7a`. #59668 merged as rafaelfranca's head `90c9862850` (range-diff identical to our
`29079a50ff`; he only rebased it onto `53f224023d`, merge `33efc59003`). #59671 is rebuilt as one commit on Rails main `088fc0cf61`:
first `4aaec2eb76f652dae2827f2d4c5c66d9e44ca73c` (tree `8bab596208`, reviewed by thermos-sol and Astra below: changes, text and evidence only),
then after their fixes `d29055285a3f3e241a0b66e3e995bcab93bc8bc5` (tree `9fbdb72dccda9de4a1f2ad7d24eeb115a4761103`), both written with
`script/commit` (Thomas author and committer, no trailers, SSH-signed; author date `1795778141`). The amend deletes the two-line
comment above `by_stored_name` and rewrites the commit message (opener "Each reader first queries the names as given", the
catalog lookup and retry described exactly, the known boundary named); runtime code is unchanged.

**Variant: lazy fallback.** Each reader first runs main's own query, unchanged apart from indexes, for the names as given. Only names
it does not find go through a new private `by_stored_name`: one catalog query (`sqlite_master` and `sqlite_temp_master` names,
temporary last), resolved in Ruby with `downcase(:ascii)`, and the reader's query again under the stored names. `indexes` uses
`LEFT JOIN pragma_index_list ... ON i.name NOT GLOB 'sqlite_*'` with `m.type IN ('table', 'view')`, so tables without indexes and views
count as found and skip the fallback. `foreign_keys` reads `table_structures` first and queries FKs under the stored name it returned.
No COLLATE NOCASE, `lower()`, `LIKE` or `pragma_table_list`; no qualified pragma, so no view is expanded that main would not expand.
Diff: 3 files, +97/−29 (tests +44/−3: three new tests, the `indexes` log expectation).

**Queries** (`count.rb`): exact names columns/pk/indexes/fks/checks 1/1/2/2/1, the same as main (a view: 1/1/1/2/1, the same);
a name in another ASCII case 3/3/4/4/3; constant in the number of tables.

**Known boundary, left as on main and 8-1-stable.** A permanent table asked by its exact spelling while a temporary table of another
ASCII case hides it: the unqualified pragmas describe the temporary table, but the CREATE statement (collation, check constraints,
FK names) is the permanent one's. Two fixes in the first query were exact (`v2.diff`: `m.name IN (temp names) OR NOT EXISTS
(pragma_table_info(m.name, 'temp'))`; `v3.diff`: the same behind an uncorrelated "any temporary table" EXISTS) but cost +5.9% and
+7.0% on 1,000 single `columns` calls in wall time, and v3 +8.3% in one process; the cost is compiling the longer statement on every call.
Not lowered for that reason.

**Cost** (`bench.rb`/`bench.sh`/`summary.rb`, Ruby 4.0.9, sqlite3 gem's SQLite 3.47.2, `taskset -c 1`, 1,000 tables each with a NOCASE
column, an index and a named FK, plus 100 tables without indexes; six rounds, order rotated, five repetitions after a warmup; median of
per-round medians, seconds):

| Benchmark | main | head | main again (A/A) |
| --- | --- | --- | --- |
| 3 × (columns, indexes, foreign_keys) batched | 0.561 | 0.577 (+2.9%) | 0.579 (+3.3%) |
| 1,000 × `columns(t)` | 0.550 | 0.540 (−1.8%) | 0.539 (−1.9%) |
| 1,000 × `indexes(t)` | 0.682 | 0.683 (+0.1%) | 0.680 (−0.4%) |
| 10 × 100 × `indexes(u)`, no indexes | 0.371 | 0.369 (−0.5%) | 0.358 (−3.5%) |
| 1,000 × `foreign_keys(t)` | 0.855 | 0.879 (+2.8%) | 0.845 (−1.2%) |

Every head value except single `foreign_keys` (+2.8% against −1.2%) is inside the A/A spread (up to ±3.5%); see the FK investigation below. One-process A/B of `table_structures` (`inproc.rb`, 15 rotated rounds of 1,000
single `columns`): main 0.4004 s, this variant −1.0%, v3 +8.3%, main again +0.2%.

**Tests.** Adapter directory, seed 41231, sqlite3 gem 2.x with SQLite 3.47.2: head 238 runs/630 assertions, main 235/618, both 0F 0E 0S.
`rake sqlite3:test:ractor` on head (CI=1, SEED=41231): 9,722 runs/34,905 assertions, 0F 0E 24S (a first run without the `pg` gem had the one
known `ConnectionHandlersMultiDbTest` LoadError). Probe (`probe.rb`, 59 checks incl. overridden NOCASE/lower/upper/like/glob, `%`, quotes,
attached and broken views, temp-first by other case): head 0 failures; main 27. Mutants on the new tests: Unicode `downcase` 1F, permanent
before temporary 1F, no fallback 3E. RuboCop: 3 files, no offenses; `git diff --check` clean.

`script/min-versions --only sqlite --sqlite 3.37.0,3.39.4,3.40.0,3.54.1`, base `088fc0cf61`, head `4aaec2eb76`, the 15 adapter files plus
`bench/upstream/min-versions/sqlite_schema_readers_test.rb` and the probe as a test (`min-versions.json`):

| SQLite | Base | Head |
| --- | --- | --- |
| 3.35.5 (floor) | helper crash (`pragma_table_list`); standalone 7 runs, 1F (probe) | same crash; standalone 7 runs, 0F |
| 3.37.0 | 235/615, 1S; probe 1F | 238/627, 0F 0E 1S; standalone 0F |
| 3.39.4 | 235/615, 1S; probe 1F | 238/627, 0F 0E 1S; standalone 0F |
| 3.40.0 | 235/618; probe 1F | 238/630, 0F 0E 0S; standalone 0F |
| 3.44.2 (middle) | 235/618; probe 1F | 238/630, 0F 0E 0S; standalone 0F |
| 3.54.1 (no FTS5) | 235/608, 4E fts5; probe 1F | 238/620, 4E fts5; standalone 0F |

No new failure in head anywhere. Scripts and results: `.amp/in/orb-backup/e2r/` in this thread's orb.

**Reviewer fixes applied in `d29055285a`.** Both reviews asked for the same three text changes and one missing measurement.
The body is thermos-sol's exact 84-word replacement (`body-2.md`, SHA-256 `e1f902b72a7d2284ce3ef7fb5fe16d6de289ca0d727be35d3ba0508a2e3144fb`):
no numbers, unchanged query count instead of "same queries", and the inherited CREATE-metadata boundary in one sentence. Astra's
replacement says the same in other words; thermos-sol's was taken because its boundary sentence names the mixed result.

**Ruby master × ZJIT** (pinned weekly build `42a644f6e00b9d21f65015d085553ab40e23faab`, `--enable-zjit --enable-yjit`, run with
`--zjit`, `RubyVM::ZJIT.enabled?` true in every process; sqlite3 gem's SQLite 3.54.1; same `bench.rb`, six rotated rounds, `bench-zjit.sh`):

| Benchmark | main | head | main again (A/A) |
| --- | --- | --- | --- |
| 3 × (columns, indexes, foreign_keys) batched | 0.480 | 0.468 (−2.3%) | 0.468 (−2.3%) |
| 1,000 × `columns(t)` | 0.436 | 0.427 (−2.2%) | 0.437 (+0.2%) |
| 1,000 × `indexes(t)` | 0.596 | 0.583 (−2.3%) | 0.575 (−3.6%) |
| 10 × 100 × `indexes(u)`, no indexes | 0.314 | 0.319 (+1.6%) | 0.297 (−5.7%) |
| 1,000 × `foreign_keys(t)` | 0.698 | 0.755 (+8.1%) | 0.688 (−1.4%) |

Single `foreign_keys` was outside its A/A, so it was investigated, not rerun until green. An FK-only process cohort
(`bench-zjit-fk.sh`, six rounds) gave head +4.4% against A/A +2.1%. In one process alternating main's and head's
`fetch_foreign_keys` (`inproc_fk.rb`, 15 rounds) head was −0.6% and +0.9% against A/A +1.3% under ZJIT, and +3.6% and +0.1% against
A/A +1.8% on 4.0.9. Instruction counts (`irbench.rb`/`irbench.sh`, cachegrind `--cache-sim=no`, 200 tables, GC disabled after a warmup,
(Ir at 400 calls − Ir at 0) / 400, `ir.txt`):

| Call | Ruby | main Ir | head | main again |
| --- | --- | --- | --- | --- |
| `foreign_keys(t)` | 4.0.9 | 2,232,237 | +0.44% | +0.15% |
| `columns(t)` | 4.0.9 | 1,581,721 | +0.27% | −0.01% |
| `indexes(t)` | 4.0.9 | 1,782,165 | −0.52% | −0.07% |
| `foreign_keys(t)` | master × ZJIT | 1,988,926 | +0.51% | +0.25% |

So head's FK path executes about 10,000 more instructions per call (≈0.3% beyond A/A: `index_with`, `uniq` and the stored-name
fetch), and the larger process-level wall-time differences are not instruction work. No ZJIT loss beyond that. The 4.0.9 summary's
scalar FK +2.8% against A/A −1.2% is likewise not "within A/A"; it matches thermos-sol's +4.7% process result and the same Ir.

Raw data, scripts and logs: `bench/upstream/e2/rebuild-2026-11-27.tar.gz` (the `.amp/in/orb-backup/e2r/` folder of this thread).
