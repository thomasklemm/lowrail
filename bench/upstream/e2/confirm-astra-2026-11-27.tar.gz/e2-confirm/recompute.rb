require "json"
root = ARGV.fetch(0)
median = ->(a) { s = a.sort; (s[(s.size - 1) / 2] + s[s.size / 2]) / 2.0 }
primary = File.readlines("#{root}/bench-zjit.jsonl").map { JSON.parse(_1) }
raise unless primary.size == 18 && primary.all? { |r| r["r"]["zjit"] && r["r"]["ruby"].include?("42a644f6e0") && r["r"]["sqlite"] == "3.54.1" }
puts "18/18 primary processes: pinned 42a644f6e0, ZJIT enabled, SQLite 3.54.1"
fk = File.readlines("#{root}/bench-zjit-fk.jsonl").map { JSON.parse(_1) }
times = fk.group_by { _1["tree"] }.transform_values { |rows| median.call(rows.map { median.call(_1["r"]["fks_only"]) }) }
puts "FK-only, averaged-middle median: #{times.inspect}"
puts "Deltas, %: #{times.transform_values { (_1 / times["main"] - 1) * 100 }.inspect}"
fk.group_by { _1["round"] }.each do |round, rows|
  v = rows.to_h { [_1["tree"], median.call(_1["r"]["fks_only"])] }
  puts "Round #{round}: #{v.inspect}; head > main: #{v["head"] > v["main"]}"
end
%w[409 zjit].each do |ruby|
  rows = File.readlines("#{root}/e2r-ir-#{ruby}.txt").map(&:split)
  puts "Instruction subtraction, #{ruby}:"
  rows.group_by { |x| [x[1], x[2]] }.each do |key, values|
    calls = values.to_h { |x| [x[3].to_i, x[0].to_i] }
    puts "#{key.join(' ')}: #{(calls.fetch(400) - calls.fetch(0)) / 400.0}"
  end
end
