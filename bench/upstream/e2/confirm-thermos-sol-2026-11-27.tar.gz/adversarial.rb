require "active_record"
require "json"

$checks = 0
$failures = []
def assert(label, expected)
  actual = yield
  $checks += 1
  $failures << [label, expected, actual] unless expected == actual
end

def connect
  ActiveRecord::Base.remove_connection
  ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
  ActiveRecord::Base.lease_connection
end

def overrides(c)
  cmp = Object.new
  def cmp.compare(a, b) = a.downcase <=> b.downcase
  c.raw_connection.collation("NOCASE", cmp)
  %w[lower like].each do |name|
    c.raw_connection.define_function(name) { raise "application #{name} invoked" }
  end
end

def check_readers(c, names, label)
  names.each do |name|
    columns = c.select_rows("PRAGMA table_xinfo(#{c.quote(name)})")
    assert("#{label} #{name} columns", columns.map { _1[1] }) { c.columns(name).map(&:name) }
    assert("#{label} #{name} primary_keys", columns.select { _1[5] > 0 }.sort_by { _1[5] }.map { _1[1] }) { c.primary_keys(name) }
    indexes = c.select_rows("PRAGMA index_list(#{c.quote(name)})").map { _1[1] }.reject { _1.start_with?("sqlite_") }.sort
    assert("#{label} #{name} indexes", indexes) { c.indexes(name).map(&:name).sort }
    fk = c.select_rows("PRAGMA foreign_key_list(#{c.quote(name)})").map { [_1[2], _1[3], _1[4]] }.sort
    assert("#{label} #{name} foreign_keys", fk) { c.foreign_keys(name).map { [_1.to_table, _1.column, _1.primary_key] }.sort }
    assert("#{label} #{name} FK input keys", [name] * fk.size) { c.foreign_keys(name).map(&:from_table) }
  end
  assert("#{label} batched keys", names.uniq) { c.columns(names).keys }
  assert("#{label} batched results", names.uniq.to_h { [_1, c.columns(_1).map(&:name)] }) { c.columns(names).transform_values { _1.map(&:name) } }
end

[false, true].each do |override|
  ["Widgets", "A%B", "A_B", "Ärger", "it's", 'A"B', "A.B", "A B"].each do |stored|
    c = connect
    c.execute %(CREATE TABLE #{c.quote_column_name(stored)} ("id" integer PRIMARY KEY, "reference" integer, "label" text COLLATE "NOCASE", CONSTRAINT owner_check CHECK (id > 0), CONSTRAINT "owner_fk" FOREIGN KEY ("reference") REFERENCES "target" ("id")))
    c.execute %(CREATE INDEX owner_index ON #{c.quote_column_name(stored)} ("reference") WHERE reference > 0)
    c.execute 'CREATE TABLE "AXB" (wrong integer)' unless stored == "Widgets"
    overrides(c) if override
    names = [stored, stored.swapcase.tr("ä", "Ä"), stored.upcase].uniq
    check_readers(c, names, "ordinary override=#{override}")
    names.each do |name|
      assert("#{stored} check #{name}", ["owner_check"]) { c.check_constraints(name).map(&:name) }
      assert("#{stored} collation #{name}", "NOCASE") { c.columns(name).last.collation }
      if ["Widgets", "A_B"].include?(stored)
        assert("#{stored} index predicate #{name}", ["reference > 0"]) { c.indexes(name).map(&:where) }
      end
      assert("#{stored} named FK #{name}", ["owner_fk"]) { c.foreign_keys(name).map(&:name) }
    end
  end

  %w[table view broken].product(%w[table view broken]).each do |main_type, temp_type|
    c = connect
    c.execute "CREATE TABLE main_source (main_id integer PRIMARY KEY, main_value integer)"
    c.execute "CREATE TABLE temp_source (temp_id integer PRIMARY KEY, temp_value integer)"
    c.execute case main_type
    when "table" then 'CREATE TABLE "Widgets" (main_id integer PRIMARY KEY, main_value integer)'
    when "view" then 'CREATE VIEW "Widgets" AS SELECT * FROM main_source'
    else 'CREATE VIEW "Widgets" AS SELECT * FROM missing_main'
    end
    c.execute case temp_type
    when "table" then 'CREATE TEMP TABLE "widgets" (temp_id integer PRIMARY KEY, temp_value integer)'
    when "view" then 'CREATE TEMP VIEW "widgets" AS SELECT * FROM temp_source'
    else 'CREATE TEMP VIEW "widgets" AS SELECT * FROM missing_temp'
    end
    overrides(c) if override
    %w[Widgets widgets WIDGETS].each do |name|
      if temp_type == "broken"
        %i[columns primary_keys foreign_keys check_constraints].each do |reader|
          assert("broken temp #{main_type} #{name} #{reader}", "ActiveRecord::StatementInvalid") do
            begin; c.public_send(reader, name); "no error"; rescue => e; e.class.name; end
          end
        end
        assert("broken temp indexes #{name}", []) { c.indexes(name) }
      else
        check_readers(c, [name], "shadow #{main_type}/#{temp_type}/#{override}")
      end
    end
  end

  c = connect
  c.execute "ATTACH DATABASE ':memory:' AS aux"
  c.execute "CREATE VIEW aux.Broken AS SELECT * FROM absent"
  c.execute "CREATE TABLE aux.OnlyAttached (id integer PRIMARY KEY)"
  c.execute "CREATE VIEW Broken AS SELECT * FROM absent_main"
  c.execute "CREATE TEMP TABLE broken (temp_id integer)"
  c.execute 'CREATE TABLE "Ärger" (upper_id integer)'
  c.execute 'CREATE TEMP TABLE "ärger" (lower_id integer)'
  overrides(c) if override
  check_readers(c, %w[ÄRGER ärger BROKEN Broken], "attached and Unicode #{override}")
  %w[onlyattached OnlyAttached DOES_NOT_EXIST main.Ärger aux.OnlyAttached].each do |name|
    %i[columns primary_keys].each do |reader|
      assert("unsupported #{reader} #{name}", "ActiveRecord::StatementInvalid") do
        begin; c.public_send(reader, name); "no error"; rescue => e; e.class.name; end
      end
    end
    %i[indexes foreign_keys check_constraints].each do |reader|
      assert("unsupported #{reader} #{name}", []) { c.public_send(reader, name) }
    end
  end
  %i[columns primary_keys indexes foreign_keys check_constraints].each do |reader|
    assert("empty #{reader}", {}) { c.public_send(reader, []) }
  end
end

puts JSON.pretty_generate(sqlite: SQLite3::SQLITE_VERSION, checks: $checks, failures: $failures)
abort "adversarial failures" unless $failures.empty?
