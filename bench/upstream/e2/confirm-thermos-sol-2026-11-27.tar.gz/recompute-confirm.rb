require "json"

dir = File.join(__dir__, "confirm-data/e2r")
median = ->(values) do
  values = values.sort
  (values[(values.size - 1) / 2] + values[values.size / 2]) / 2.0
end

%w[bench-zjit.jsonl bench-zjit-fk.jsonl].each do |name|
  rows = File.readlines(File.join(dir, name)).map { JSON.parse(_1) }
  abort "wrong cohort size" unless rows.size == 18
  abort "missing round" unless rows.group_by { _1["round"] }.values.all? { |round| round.map { _1["tree"] }.sort == %w[head main main2] }
  key = name.include?("-fk") ? "fks_only" : "single_fks"
  groups = rows.group_by { _1["tree"] }
  medians = groups.transform_values { |group| median.call(group.map { median.call(_1["r"][key]) }) }
  upper = groups.transform_values { |group| group.map { median.call(_1["r"][key]) }.sort[group.size / 2] }
  puts "#{name}: 18 rows, six complete rounds"
  puts "Runtimes: #{rows.map { _1["r"].values_at("ruby", "zjit", "sqlite") }.uniq.inspect}"
  [[:median, medians], [:upper_middle, upper]].each do |rule, values|
    puts "#{rule}: #{values.inspect}"
    puts "Head: #{100 * (values.fetch("head") / values.fetch("main") - 1)}%, A/A: #{100 * (values.fetch("main2") / values.fetch("main") - 1)}%"
  end
end

%w[e2r-ir-409.txt e2r-ir-zjit.txt].each do |name|
  File.readlines(File.join(dir, name)).map(&:split).group_by { _1[1] }.each do |op, rows|
    ir = rows.group_by { _1[2] }.transform_values do |group|
      calls = group.to_h { [_1[3].to_i, _1[0].to_i] }
      (calls.fetch(400) - calls.fetch(0)) / 400.0
    end
    puts "#{name} #{op}: #{ir.inspect}"
    puts "Head: #{100 * (ir.fetch("head") / ir.fetch("main") - 1)}%, A/A: #{100 * (ir.fetch("main2") / ir.fetch("main") - 1)}%"
  end
end
