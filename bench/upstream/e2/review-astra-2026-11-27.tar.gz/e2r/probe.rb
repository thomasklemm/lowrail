# Usage (from a Rails checkout): bundle exec ruby -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib probe.rb
require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
C = ActiveRecord::Base.lease_connection
$fail = 0
def check(label, expected)
  actual = begin; yield; rescue => e; "#{e.class}"; end
  ok = actual == expected
  $fail += 1 unless ok
  puts "#{ok ? "ok  " : "FAIL"} #{label}: #{actual.inspect}#{" (expected #{expected.inspect})" unless ok}"
end
def fresh
  C.execute "DETACH DATABASE aux" rescue nil
  (C.query_values("SELECT name FROM sqlite_temp_master WHERE type='view'")).each { C.execute %(DROP VIEW temp."#{_1}") }
  (C.query_values("SELECT name FROM sqlite_temp_master WHERE type='table'")).each { C.execute %(DROP TABLE temp."#{_1}") }
  (C.query_values("SELECT name FROM sqlite_master WHERE type='view'")).each { C.execute %(DROP VIEW main."#{_1}") }
  (C.query_values("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")).each { C.execute %(DROP TABLE main."#{_1}") }
end
puts "SQLite #{C.database_version}"

fresh
C.execute 'CREATE TABLE "Widgets" ("id" integer PRIMARY KEY, "number" integer, "label" text COLLATE "NOCASE", CONSTRAINT w_check CHECK (number > 0), CONSTRAINT "w_fk" FOREIGN KEY ("number") REFERENCES "Widgets" ("id"))'
C.execute 'CREATE INDEX idx_w ON "Widgets" (number)'
C.execute 'CREATE TABLE plain (id integer PRIMARY KEY)'
C.execute 'CREATE VIEW "WidgetsView" AS SELECT id FROM "Widgets"'
%w[Widgets widgets WIDGETS].each do |n|
  check("columns #{n}", %w[id number label]) { C.columns(n).map(&:name) }
  check("collation #{n}", "NOCASE") { C.columns(n).last.collation }
  check("pk #{n}", "id") { C.primary_key(n) }
  check("indexes #{n}", %w[idx_w]) { C.indexes(n).map(&:name) }
  check("index table #{n}", [n]) { C.indexes(n).map(&:table) }
  check("fks #{n}", [["number", "Widgets", "w_fk"]]) { C.foreign_keys(n).map { [_1.column, _1.to_table, _1.name] } }
  check("checks #{n}", %w[w_check]) { C.check_constraints(n).map(&:name) }
end
check("view other case", %w[id]) { C.columns("widgetsview").map(&:name) }
check("indexes on view other case", []) { C.indexes("widgetsview") }
check("plain no indexes", []) { C.indexes("plain") }
check("plain other case no indexes", []) { C.indexes("PLAIN") }
check("missing columns raises", "ActiveRecord::StatementInvalid") { C.columns("nope") }
check("missing indexes", []) { C.indexes("nope") }
check("missing fks", []) { C.foreign_keys("nope") }
check("batch", { "Widgets" => 3, "widgets" => 3, "plain" => 1, "PLAIN" => 1 }) { C.columns(%w[Widgets widgets plain PLAIN]).transform_values(&:size) }
check("batch indexes", { "Widgets" => 1, "widgets" => 1, "plain" => 0, "PLAIN" => 0, "nope" => 0 }) { C.indexes(%w[Widgets widgets plain PLAIN nope]).transform_values(&:size) }

fresh
C.execute 'CREATE TABLE "Ärger" (id integer PRIMARY KEY, upper integer)'
check("non-ascii ascii fold", %w[id upper]) { C.columns("ÄRGER").map(&:name) }
check("non-ascii not folded", "ActiveRecord::StatementInvalid") { C.columns("ärger") }
check("non-ascii indexes not folded", []) { C.indexes("ärger") }

fresh
C.execute 'CREATE TABLE "Widgets" (id integer PRIMARY KEY, permanent integer)'
C.execute 'CREATE INDEX perm_idx ON "Widgets" (permanent)'
C.execute 'CREATE TEMP TABLE "WIDGETS" ("temp_id" integer PRIMARY KEY, "temporary" text COLLATE "NOCASE", CONSTRAINT "t_fk" FOREIGN KEY ("temporary") REFERENCES "targets" ("id"))'
C.execute 'CREATE INDEX temp.temp_idx ON "WIDGETS" (temporary)'
check("temp first by other case: columns", %w[temp_id temporary]) { C.columns("widgets").map(&:name) }
check("temp first: collation", "NOCASE") { C.columns("widgets").last.collation }
check("temp first: indexes", %w[temp_idx]) { C.indexes("widgets").map(&:name) }
check("temp first: fks", [["temporary", "targets", "t_fk"]]) { C.foreign_keys("widgets").map { [_1.column, _1.to_table, _1.name] } }
check("temp exact", %w[temp_id temporary]) { C.columns("WIDGETS").map(&:name) }

fresh
C.execute "CREATE VIEW Widgets AS SELECT * FROM missing"
C.execute "CREATE TEMP TABLE widgets (id integer PRIMARY KEY, temporary integer)"
check("broken main view hidden by temp other case, third spelling", %w[id temporary]) { C.columns("WIDGETS").map(&:name) }
check("same, fks", []) { C.foreign_keys("WIDGETS") }
check("same, indexes", []) { C.indexes("WIDGETS") }

fresh
C.execute "ATTACH DATABASE ':memory:' AS aux"
C.execute "CREATE VIEW aux.attached AS SELECT * FROM missing"
C.execute "CREATE TABLE aux.Other (id integer)"
check("attached broken view fks", []) { C.foreign_keys("attached") }
check("attached broken view checks", []) { C.check_constraints("attached") }
check("attached broken view other case fks", []) { C.foreign_keys("ATTACHED") }
check("attached table not found", "ActiveRecord::StatementInvalid") { C.columns("other") }
check("attached table indexes", []) { C.indexes("OTHER") }

fresh
C.execute "CREATE TEMP VIEW broken AS SELECT * FROM missing"
check("broken temp view indexes", []) { C.indexes("broken") }
check("broken temp view indexes other case", []) { C.indexes("BROKEN") }

fresh
C.execute %(CREATE TABLE "it's" (id integer))
check("quote other case", %w[id]) { C.columns("IT'S").map(&:name) }
C.execute 'CREATE TABLE "a%b" (id integer)'
C.execute 'CREATE TABLE "axb" (other integer)'
check("percent other case", %w[id]) { C.columns("A%B").map(&:name) }

# Redefined functions/collations must not matter.
fresh
cmp = Object.new
def cmp.compare(a, b) = a.downcase <=> b.downcase
C.raw_connection.collation("NOCASE", cmp)
%w[lower upper like glob].each { |f| C.raw_connection.define_function(f) { raise "#{f} called" } rescue nil }
C.execute 'CREATE TABLE "Ärger" (id integer PRIMARY KEY, upper integer)'
C.execute 'CREATE TEMP TABLE "ärger" (id integer PRIMARY KEY, lower integer)'
C.execute 'CREATE TABLE "Widgets" (id integer PRIMARY KEY)'
check("override: non-ascii distinct", { "Ärger" => %w[id upper], "ärger" => %w[id lower] }) { C.columns(%w[Ärger ärger]).transform_values { _1.map(&:name) } }
check("override: other case", %w[id]) { C.columns("widgets").map(&:name) }
puts "#{$fail} failures"

# Exact spelling of a main object hidden by a temporary one of another ASCII case.
fresh
C.execute "CREATE VIEW Widgets AS SELECT * FROM missing"
C.execute "CREATE TEMP TABLE widgets (id integer PRIMARY KEY, temporary integer)"
check("broken main view hidden, exact main spelling: columns", %w[id temporary]) { C.columns("Widgets").map(&:name) }
check("same, fks", []) { C.foreign_keys("Widgets") }
check("same, checks", []) { C.check_constraints("Widgets") }
fresh
C.execute 'CREATE TABLE "Widgets" ("id" integer PRIMARY KEY, "permanent" integer, CONSTRAINT p_check CHECK (permanent > 0))'
C.execute 'CREATE TEMP TABLE "widgets" ("temp_id" integer PRIMARY KEY, "temporary" text COLLATE "NOCASE", CONSTRAINT t_check CHECK (temp_id > 0))'
check("hidden main table, exact main spelling: columns", %w[temp_id temporary]) { C.columns("Widgets").map(&:name) }
# As on main and 8-1-stable: the pragmas describe the temporary table, the CREATE statement is the permanent one's.
check("same: collation (as main)", nil) { C.columns("Widgets").last.collation }
check("same: checks (as main)", %w[p_check]) { C.check_constraints("Widgets").map(&:name) }
check("same: other spelling reads the temporary CREATE", %w[t_check]) { C.check_constraints("WIDGETS").map(&:name) }
puts "#{$fail} failures (final)"
