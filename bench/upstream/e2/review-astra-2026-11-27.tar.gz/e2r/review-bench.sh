#!/usr/bin/env bash
set -euo pipefail
root=/home/user/workspace/repo/.amp/in/orb-backup
out="$root/e2r/review-bench.jsonl"
: > "$out"
for round in 1 2 3; do
  case "$round" in
    1) order=(head main2 main);;
    2) order=(main2 main head);;
    3) order=(main head main2);;
  esac
  for tree in "${order[@]}"; do
    dir="$root/e2-base"
    [ "$tree" != head ] || dir="$root/e2-head"
    result=$(RUBYLIB="$dir/activerecord/lib:$dir/activesupport/lib:$dir/activemodel/lib" taskset -c 1 mise exec ruby@4.0.9 -- ruby "$root/e2r/bench.rb")
    printf '{"round":%s,"tree":"%s","r":%s}\n' "$round" "$tree" "$result" >> "$out"
  done
done
mise exec ruby@4.0.9 -- ruby "$root/e2r/summary.rb" "$out"
