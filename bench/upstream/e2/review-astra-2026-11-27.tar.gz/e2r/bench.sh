#!/bin/bash
# bench.sh OUT ROUNDS: interleaves main, head, main again (A/A) per round.
out=$1; rounds=${2:-5}; : > $out
export BUNDLE_WITHOUT="doc:mdl:job:cable:storage:db"
for r in $(seq $rounds); do
  order=(main head main2); case $((r % 3)) in 1) order=(head main2 main);; 2) order=(main2 main head);; esac
  for tree in "${order[@]}"; do
    dir=/home/user/workspace/rails-main; [ $tree = head ] && dir=/home/user/workspace/rails-e2
    res=$(cd $dir && taskset -c 1 env BUNDLE_GEMFILE=/home/user/workspace/rails-e2/Gemfile mise exec ruby@4.0.9 -- bundle exec ruby -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib /home/user/workspace/repo/.amp/in/orb-backup/e2r/bench.rb)
    echo "{\"round\":$r,\"tree\":\"$tree\",\"r\":$res}" >> $out
  done
done
