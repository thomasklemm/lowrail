require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.execute 'CREATE TABLE "Widgets" (id integer PRIMARY KEY, name text)'
class Widget < ActiveRecord::Base
  self.table_name = "widgets"
end
Widget.create!(name: "sprocket")
raise unless Widget.where(name: "sprocket").pluck(:name) == ["sprocket"]
raise unless c.columns([:widgets, "Widgets"]).keys == %w[widgets Widgets]
puts "Model create/query and mixed Symbol/String batch pass"
