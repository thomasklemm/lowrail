# Queries per reader call.
require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
C = ActiveRecord::Base.lease_connection
C.execute 'CREATE TABLE "Widgets" (id integer PRIMARY KEY, number integer, FOREIGN KEY (number) REFERENCES "Widgets"(id))'
C.execute 'CREATE INDEX idx ON "Widgets" (number)'
C.execute 'CREATE TABLE "Gadgets" (id integer PRIMARY KEY)'
C.execute 'CREATE VIEW "V" AS SELECT 1 AS x'
def count
  n = 0
  sub = ActiveSupport::Notifications.subscribe("sql.active_record") { n += 1 }
  yield
  n
ensure
  ActiveSupport::Notifications.unsubscribe(sub)
end
def row(label, names)
  r = %i[columns primary_keys indexes foreign_keys check_constraints].map { |m| count { C.public_send(m, names) } }
  puts "#{label}: #{r.join(", ")}"
end
row "exact [Widgets, Gadgets]", %w[Widgets Gadgets]
row "exact view [V]", %w[V]
row "[widgets, Gadgets]", %w[widgets Gadgets]
C.execute 'CREATE TEMP TABLE "gadgets" (id integer PRIMARY KEY)'
row "exact [Widgets, Gadgets], temp gadgets", %w[Widgets Gadgets]
