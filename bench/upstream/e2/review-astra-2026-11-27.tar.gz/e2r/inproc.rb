# In one process on the head tree: alternate main's, v1's and v3's table_structures SQL and time 1,000 single columns calls.
require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.transaction do
  1000.times { |i| c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, "noidx" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id"))) }
end
tables = 1000.times.map { "t#{_1}" }
A = ActiveRecord::ConnectionAdapters::SQLite3Adapter
v3 = A.instance_method(:table_structures)
A.define_method(:table_structures_main) do |tables|
  fields = ["name", "type", "notnull", "dflt_value", "pk", "hidden"]
  query_all(<<~SQL).group_by { |row| row["table_name"] }
    #{ActiveRecord::ConnectionAdapters::SQLite3::SchemaStatements::MASTER_CTE}
    SELECT m.name AS table_name, CASE WHEN m.type = 'table' THEN m.sql END AS create_table_sql,
           #{fields.map { |field| "t.#{quote_column_name(field)}" }.join(", ")}
    FROM master m
    JOIN pragma_table_xinfo(m.name) t
    WHERE m.type IN ('table', 'view')
      AND m.name IN (#{quoted_table_names(tables)})
    ORDER BY m.name, t.cid
  SQL
    .transform_values { |group| [group.first["create_table_sql"], group.map { |row| row.except("table_name", "create_table_sql") }] }
end
A.define_method(:table_structures_v1) do |tables|
  fields = ["name", "type", "notnull", "dflt_value", "pk", "hidden"]
  by_stored_name(tables) do |names|
    query_all(<<~SQL).group_by { |row| row["table_name"] }
      #{ActiveRecord::ConnectionAdapters::SQLite3::SchemaStatements::MASTER_CTE}
      SELECT m.name AS table_name, CASE WHEN m.type = 'table' THEN m.sql END AS create_table_sql,
             #{fields.map { |field| "t.#{quote_column_name(field)}" }.join(", ")}
      FROM master m
      JOIN pragma_table_xinfo(m.name) t
      WHERE m.type IN ('table', 'view')
        AND m.name IN (#{quoted_table_names(names)})
      ORDER BY m.name, t.cid
    SQL
      .to_h { |name, group| [name, [group.first["create_table_sql"], group.map { |row| row.except("table_name", "create_table_sql") }, name]] }
  end
end
A.define_method(:table_structures_v3, v3)
variants = %w[main v1 v3 main2]
times = variants.to_h { [_1, []] }
clock = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
15.times do |round|
  variants.rotate(round % 4).each do |v|
    A.alias_method :table_structures, :"table_structures_#{v.delete_suffix("2")}"
    t = clock.(); tables.each { c.columns(_1) }; times[v] << clock.() - t
  end
end
med = ->(a) { a.sort[a.size / 2] }
variants.each { |v| puts format("%-6s %.4f s  %+.1f%%", v, med.(times[v]), (med.(times[v]) / med.(times["main"]) - 1) * 100) }
