require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
checks = 0
assert = ->(want, got, context) { checks += 1; raise "#{context}: #{got.inspect} != #{want.inspect}" unless want == got }
puts "#{RUBY_DESCRIPTION}; SQLite #{c.database_version}"
%i[columns primary_keys indexes foreign_keys check_constraints].each { assert.call({}, c.public_send(_1, []), "empty #{_1}") }
cmp = Object.new
def cmp.compare(a, b) = a.downcase <=> b.downcase
c.raw_connection.collation("NOCASE", cmp)
%w[lower upper like].each { |fn| c.raw_connection.define_function(fn) { raise "unexpected #{fn}" } }
c.execute "ATTACH DATABASE ':memory:' AS aux"
c.execute "CREATE VIEW aux.unrelated AS SELECT * FROM missing"
c.execute "CREATE VIEW main.unrelated_main AS SELECT * FROM missing"
c.execute "CREATE TEMP VIEW unrelated_temp AS SELECT * FROM missing"
[["Widgets", "WIDGETS", "wIdGeTs"], ["a%b", "A%B", "a%B"], ["a_b", "A_B", "a_B"], ["Ärger", "ÄRGER", "ÄrGeR"], ["O'Brien", "O'BRIEN", "o'bRiEn"]].each do |main, temp, requested|
  qm, qt = c.quote_table_name(main), c.quote_table_name(temp)
  c.execute "CREATE TABLE main.#{qm} (main_id integer PRIMARY KEY, permanent text)"
  c.execute %(CREATE TEMP TABLE #{qt} ("temp_id" integer PRIMARY KEY, "temporary" text COLLATE "NOCASE", "ref" integer, CONSTRAINT tc CHECK (ref > 0), CONSTRAINT "tf" FOREIGN KEY ("ref") REFERENCES "target" ("id") DEFERRABLE INITIALLY DEFERRED))
  c.execute "CREATE INDEX temp.ti ON #{qt}(ref) WHERE ref > 1"
  raw_columns = c.query_values("SELECT name FROM pragma_table_xinfo(#{c.quote(requested)})")
  assert.call(%w[temp_id temporary ref], raw_columns, "SQLite owner")
  names = [requested, temp, requested]
  assert.call(names.uniq.to_h { [_1, raw_columns] }, c.columns(names).transform_values { _1.map(&:name) }, "batch cols")
  assert.call("NOCASE", c.columns(requested)[1].collation, "temp create")
  assert.call(["temp_id"], c.primary_keys(requested), "pk")
  assert.call([["ti", ["ref"], requested]], c.indexes(requested).map { [_1.name, _1.columns, _1.table] }, "index")
  assert.call("ref > 1", c.indexes(requested).first.where, "partial index") if main == "Widgets"
  assert.call([["tf", "target", "ref", :deferred]], c.foreign_keys(requested).map { [_1.name, _1.to_table, _1.column, _1.deferrable] }, "fk")
  assert.call(["tc"], c.check_constraints(requested).map(&:name), "check")
  assert.call(names.uniq, c.foreign_keys(names).keys, "fk keys")
  c.execute "DROP TABLE temp.#{qt}"
  c.execute "DROP TABLE main.#{qm}"
end
c.execute "CREATE TABLE main.Ärger (upper integer)"
c.execute "CREATE TEMP TABLE ärger (lower integer)"
assert.call(["upper"], c.columns("ÄRGER").map(&:name), "Unicode upper independent")
assert.call(["lower"], c.columns("äRGER").map(&:name), "Unicode lower independent")
c.execute "CREATE TABLE main.Widgets (id integer)"
c.execute "CREATE INDEX main.wi ON Widgets(id)"
c.execute "CREATE TEMP VIEW widgets AS SELECT * FROM absent"
%w[widgets WIDGETS Widgets].each do |n|
  assert.call([], c.indexes(n), "broken hiding view indexes")
  begin
    c.columns(n)
    raise "broken view should raise"
  rescue ActiveRecord::StatementInvalid
    checks += 1
  end
end
c.execute "CREATE TABLE aux.OnlyAttached (id integer)"
c.execute "CREATE INDEX aux.ai ON OnlyAttached(id)"
%w[OnlyAttached ONLYATTACHED unrelated UNRELATED].each do |n|
  assert.call([], c.indexes(n), "attached indexes")
  assert.call([], c.foreign_keys(n), "attached fk")
  assert.call([], c.check_constraints(n), "attached check")
end
c.execute 'CREATE TABLE main.NoIndex (id integer PRIMARY KEY)'
assert.call([], c.indexes("NOINDEX"), "no index sentinel")
c.execute 'CREATE VIEW main.HealthyView AS SELECT 1 AS one'
assert.call(["one"], c.columns("HEALTHYVIEW").map(&:name), "view columns")
assert.call([], c.indexes("HEALTHYVIEW"), "view indexes")
puts "#{checks} checks passed"
