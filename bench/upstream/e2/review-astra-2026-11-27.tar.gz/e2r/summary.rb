# ruby summary.rb FILE.jsonl: medians of each tree's per-round medians, relative to "main".
require "json"
rows = File.readlines(ARGV[0]).map { JSON.parse(_1) }
med = ->(a) { s = a.sort; s.size.odd? ? s[s.size / 2] : (s[s.size / 2 - 1] + s[s.size / 2]) / 2 }
keys = %w[trio single_columns single_indexes single_indexes_plain single_fks]
trees = rows.map { _1["tree"] }.uniq.sort_by { _1 == "main" ? 0 : 1 }
base = {}
trees.each do |tree|
  rs = rows.select { _1["tree"] == tree }
  line = keys.map do |k|
    m = med.(rs.map { med.(_1["r"][k]) })
    base[k] ||= m if tree == "main"
    rounds = rs.map { format("%.3f", med.(_1["r"][k])) }.join(" ")
    "#{k} #{format("%.3f", m)} (#{format("%+.1f%%", (m / base[k] - 1) * 100)}) [#{rounds}]"
  end
  puts "#{tree} (#{rs.size} rounds, SQLite #{rs.first["r"]["sqlite"]}):", *line.map { "  " + _1 }
end
