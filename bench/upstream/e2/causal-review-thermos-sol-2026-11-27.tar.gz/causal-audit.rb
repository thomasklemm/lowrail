require "json"
require "prism"

dir = File.join(__dir__, "causal-data/e2r")
def definitions(path)
  nodes = [Prism.parse_file(path).value]
  result = {}
  until nodes.empty?
    node = nodes.shift
    result[node.name] = node.location.slice if node.is_a?(Prism::DefNode)
    nodes.concat(node.compact_child_nodes)
  end
  result
end

copies = definitions(File.join(dir, "inproc_fk2.rb"))
normalize = ->(source) do
  source.gsub(/\b(table_structures|fetch_foreign_keys)_(main|head)\b/, '\1')
    .gsub(/\bCTE\b/, "MASTER_CTE")
    .lines.map(&:strip).reject { _1.empty? || _1.match?(/^#(?!\{)/) }.join("\n")
end
%w[main head].each do |variant|
  tree = variant == "main" ? "rails-base" : "rails-confirm"
  actual = definitions(File.join(__dir__, tree, "activerecord/lib/active_record/connection_adapters/sqlite3_adapter.rb"))
  %i[table_structures fetch_foreign_keys].each do |name|
    abort "copy differs: #{variant} #{name}" unless normalize.call(copies.fetch(:"#{name}_#{variant}")) == normalize.call(actual.fetch(name))
    puts "#{variant} #{name}: source matches apart from names/constant reference/formatting/comments"
  end
end

median = ->(values) do
  s = values.sort
  (s[(s.size - 1) / 2] + s[s.size / 2]) / 2.0
end
%w[e2r-fk2-zjit.json e2r-fk2-409.json].each do |name|
  data = JSON.parse(File.read(File.join(dir, name)))
  variants = data.fetch("variants")
  abort "window count" unless variants.values.all? { _1.fetch("times").size == 15 }
  values = variants.transform_values { median.call(_1.fetch("times")) }
  puts "#{name}: #{data.values_at('ruby', 'zjit', 'sqlite').inspect}"
  variants.each do |v, stats|
    abort "wrong median" unless values.fetch(v) == stats.fetch("median_s")
    puts "  #{v}: #{values[v]}, #{100 * (values[v] / values['main'] - 1)}%, alloc/call #{stats['alloc_per_call']}, GC runs #{stats['gc_runs']}"
  end
  puts "  JIT final counters: #{data['zjit_stats'].inspect}"
end

%w[e2r-fk2-proc-zjit.jsonl e2r-fk2-trees.jsonl e2r-zjit-fk3.jsonl].each do |name|
  rows = File.readlines(File.join(dir, name)).map { JSON.parse(_1) }
  abort "cohort size" unless rows.size == 18
  abort "rounds incomplete" unless rows.group_by { _1.fetch('round') }.values.all? { _1.map { |row| row.fetch('tree') }.sort == %w[head main main2] }
  key = name.include?("fk3") ? "fks_only" : "times"
  values = rows.group_by { _1.fetch("tree") }.transform_values do |group|
    abort "window count" unless group.all? { _1.fetch('r').fetch(key).size == 5 }
    median.call(group.map { median.call(_1.fetch('r').fetch(key)) })
  end
  puts "#{name}: #{rows.map { _1.fetch('r').values_at('ruby', 'zjit', 'sqlite') }.uniq.inspect}"
  values.each { |v, value| puts "  #{v}: #{value}, #{100 * (value / values['main'] - 1)}%" }
end
