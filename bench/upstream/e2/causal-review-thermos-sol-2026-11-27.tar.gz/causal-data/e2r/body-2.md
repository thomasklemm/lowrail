The batched SQLite schema readers from #58498 require exact table names: `columns("widgets")` raises `StatementInvalid` for a table created as `Widgets`, and its indexes and foreign keys come back empty.

Missing names are now looked up ignoring ASCII case, with temporary tables and views taking precedence. Names such as `Ärger` and `ärger` remain distinct. Reading a permanent table's exact spelling still mixes its CREATE statement with temporary columns if a differently cased temporary table hides it.

Ransack 6.1.2 [disables this case pending a Rails fix](https://github.com/activerecord-hackery/ransack/blob/2700b29d2f2515f616c0e7e93d71671e7d9e84d2/spec/ransack/active_record/context_spec.rb#L93-L112).
