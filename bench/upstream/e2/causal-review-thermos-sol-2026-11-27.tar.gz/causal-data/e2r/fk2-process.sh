#!/bin/bash
# fk2-process.sh OUT ROUNDS RUBY(master|409): fresh processes on the head tree calling main's or head's complete
# fetch_foreign_keys/table_structures (inproc_fk2.rb VARIANT=...), rotated main/head/main2.
out=$1; rounds=$2; which=$3; : > $out
R=/home/user/workspace/ruby-master/install/bin
cd /home/user/workspace/rails-e2
for r in $(seq $rounds); do
  order=(main head main2); case $((r % 3)) in 1) order=(head main2 main);; 2) order=(main2 main head);; esac
  for v in "${order[@]}"; do
    if [ $which = master ]; then
      res=$(taskset -c 1 env PATH=$R:$PATH BUNDLE_GEMFILE=/home/user/workspace/e2-master/Gemfile VARIANT=${v%2} $R/bundle exec $R/ruby --zjit -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib /home/user/workspace/repo/.amp/in/orb-backup/e2r/inproc_fk2.rb)
    else
      res=$(BUNDLE_WITHOUT="doc:mdl:job:cable:storage" VARIANT=${v%2} taskset -c 1 mise exec ruby@4.0.9 -- bundle exec ruby -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib /home/user/workspace/repo/.amp/in/orb-backup/e2r/inproc_fk2.rb)
    fi
    echo "{\"round\":$r,\"tree\":\"$v\",\"r\":$res}" >> $out
  done
done
