# ruby bench.rb  (run from a Rails tree with its component libs on -I). Prints JSON timings.
require "active_record"
require "json"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
N = 1000
c.transaction do
  N.times do |i|
    c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, "noidx" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id")))
    c.execute %(CREATE INDEX "index_t#{i}_on_parent_id" ON "t#{i}" ("parent_id"))
  end
  100.times { |i| c.execute %(CREATE TABLE "u#{i}" ("id" integer PRIMARY KEY, "value" integer)) } # no indexes, no FKs
end
tables = N.times.map { "t#{_1}" }
plain = 100.times.map { "u#{_1}" }
raise unless c.columns("t500").map(&:name) == %w[id name parent_id noidx] && c.columns("t500")[1].collation == "NOCASE"
raise unless c.indexes("t500").map(&:columns) == [%w[parent_id]] && c.foreign_keys("t500").map(&:name) == ["fk_t500"]
raise unless c.indexes(plain).values.all?(&:empty?) && c.columns(tables).size == N

clock = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
time = ->(&blk) { Integer(ENV.fetch("WARMUP", "1")).times { blk.call }; 5.times.map { t = clock.(); blk.call; clock.() - t } }
GC.start
(puts(JSON.generate(fks_only: time.() { tables.each { c.foreign_keys(_1) } }, sqlite: c.database_version.to_s, ruby: RUBY_DESCRIPTION)); exit) if ENV["FK_ONLY"]
puts JSON.generate(
  trio: time.() { 3.times { c.columns(tables); c.indexes(tables); c.foreign_keys(tables) } },
  single_columns: time.() { tables.each { c.columns(_1) } },
  single_indexes: time.() { tables.each { c.indexes(_1) } },
  single_indexes_plain: time.() { 10.times { plain.each { c.indexes(_1) } } },
  single_fks: time.() { tables.each { c.foreign_keys(_1) } },
  sqlite: c.database_version.to_s,
  ruby: RUBY_DESCRIPTION,
  zjit: defined?(RubyVM::ZJIT) && RubyVM::ZJIT.respond_to?(:enabled?) ? RubyVM::ZJIT.enabled? : nil,
)
