#!/bin/bash
# fk2-trees.sh OUT ROUNDS: main's complete copies (VARIANT=main) in fresh ZJIT processes on the main tree ("main", "main2")
# and on the head tree ("head"): the same executed FK code, different trees.
out=$1; rounds=$2; : > $out
R=/home/user/workspace/ruby-master/install/bin
for r in $(seq $rounds); do
  order=(main head main2); case $((r % 3)) in 1) order=(head main2 main);; 2) order=(main2 main head);; esac
  for v in "${order[@]}"; do
    dir=/home/user/workspace/rails-main; [ $v = head ] && dir=/home/user/workspace/rails-e2
    res=$(cd $dir && taskset -c 1 env PATH=$R:$PATH BUNDLE_GEMFILE=/home/user/workspace/e2-master/Gemfile VARIANT=main $R/bundle exec $R/ruby --zjit -Iactiverecord/lib -Iactivesupport/lib -Iactivemodel/lib /home/user/workspace/repo/.amp/in/orb-backup/e2r/inproc_fk2.rb)
    echo "{\"round\":$r,\"tree\":\"$v\",\"r\":$res}" >> $out
  done
done
