# ruby sum-times.rb FILE.jsonl KEY: average-middle median of per-process medians per tree, relative to main.
require "json"
rows = File.readlines(ARGV[0]).map { JSON.parse(_1) }
key = ARGV[1] || "times"
med = ->(a) { s = a.sort; s.size.odd? ? s[s.size / 2] : (s[s.size / 2 - 1] + s[s.size / 2]) / 2 }
base = nil
%w[main head main2].each do |t|
  rs = rows.select { _1["tree"] == t }
  per = rs.map { med.(_1["r"][key]) }
  m = med.(per); base ||= m
  puts format("%-5s %.4f %+.2f%% [%s]", t, m, (m / base - 1) * 100, per.map { format("%.3f", _1) }.join(" "))
end
