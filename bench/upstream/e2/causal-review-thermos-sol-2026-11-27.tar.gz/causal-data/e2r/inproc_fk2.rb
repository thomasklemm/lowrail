# One process, the bench.rb fixture (1,000 FK tables + 100 plain). Complete main and head implementations of
# fetch_foreign_keys and table_structures (head's also with by_stored_name), each under its own name, no aliasing.
# Rounds rotate the order; per variant: time of 1,000 single calls, objects allocated per call, GC runs.
require "active_record"
require "json"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
c = ActiveRecord::Base.lease_connection
c.transaction do
  1000.times do |i|
    c.execute %(CREATE TABLE "t#{i}" ("id" integer PRIMARY KEY, "name" text COLLATE "NOCASE", "parent_id" integer, "noidx" integer, CONSTRAINT "fk_t#{i}" FOREIGN KEY ("parent_id") REFERENCES "t#{i}" ("id")))
    c.execute %(CREATE INDEX "index_t#{i}_on_parent_id" ON "t#{i}" ("parent_id"))
  end
  100.times { |i| c.execute %(CREATE TABLE "u#{i}" ("id" integer PRIMARY KEY, "value" integer)) }
end
tables = 1000.times.map { "t#{_1}" }
A = ActiveRecord::ConnectionAdapters::SQLite3Adapter
CTE = ActiveRecord::ConnectionAdapters::SQLite3::SchemaStatements::MASTER_CTE
raise "head tree expected" unless A.private_method_defined?(:by_stored_name) || ENV["VARIANT"] == "main"

A.class_eval do
  # main 088fc0cf61, verbatim apart from the names.
  def table_structures_main(tables)
    return {} if tables.empty?

    fields = ["name", "type", "notnull", "dflt_value", "pk"]
    fields << "hidden" if supports_virtual_columns?

    query_all(<<~SQL).group_by { |row| row["table_name"] }
      #{CTE}
      SELECT m.name AS table_name, CASE WHEN m.type = 'table' THEN m.sql END AS create_table_sql,
             #{fields.map { |field| "t.#{quote_column_name(field)}" }.join(", ")}
      FROM master m
      JOIN pragma_#{table_info_pragma}(m.name) t
      WHERE m.type IN ('table', 'view')
        AND m.name IN (#{quoted_table_names(tables)})
      ORDER BY m.name, t.cid
    SQL
      .transform_values do |group|
        [group.first["create_table_sql"], group.map { |row| row.except("table_name", "create_table_sql") }]
      end
  end

  def fetch_foreign_keys_main(tables)
    return {} if tables.empty?

    fk_infos = query_all(<<~SQL).group_by { |row| row["table_name"] }
      #{CTE}
      SELECT m.name AS table_name, fk.id, fk.seq, fk."table", fk."from", fk."to", fk.on_update, fk.on_delete
      FROM master m
      JOIN pragma_foreign_key_list(m.name) fk
      WHERE m.type = 'table'
        AND m.name IN (#{quoted_table_names(tables)})
    SQL

    structures = table_structures_main(tables)

    tables.index_with do |table_name|
      create_table_sql, structure = structures[table_name] || [nil, []]
      column_strings = split_table_structure_sql(create_table_sql, structure.map { |column| column["name"] })

      build_foreign_keys(table_name, fk_infos.fetch(table_name, []), column_strings)
    end
  end

  # head d29055285a, verbatim apart from the names.
  def table_structures_head(tables)
    return {} if tables.empty?

    fields = ["name", "type", "notnull", "dflt_value", "pk"]
    fields << "hidden" if supports_virtual_columns?

    by_stored_name(tables) do |names|
      query_all(<<~SQL).group_by { |row| row["table_name"] }
        #{CTE}
        SELECT m.name AS table_name, CASE WHEN m.type = 'table' THEN m.sql END AS create_table_sql,
               #{fields.map { |field| "t.#{quote_column_name(field)}" }.join(", ")}
        FROM master m
        JOIN pragma_#{table_info_pragma}(m.name) t
        WHERE m.type IN ('table', 'view')
          AND m.name IN (#{quoted_table_names(names)})
        ORDER BY m.name, t.cid
      SQL
        .to_h do |name, group|
          [name, [group.first["create_table_sql"], group.map { |row| row.except("table_name", "create_table_sql") }, name]]
        end
    end
  end

  def fetch_foreign_keys_head(tables)
    return {} if tables.empty?

    structures = table_structures_head(tables)
    stored = tables.index_with { |table| structures.dig(table, 2) || table }

    fk_infos = query_all(<<~SQL).group_by { |row| row["table_name"] }
      #{CTE}
      SELECT m.name AS table_name, fk.id, fk.seq, fk."table", fk."from", fk."to", fk.on_update, fk.on_delete
      FROM master m
      JOIN pragma_foreign_key_list(m.name) fk
      WHERE m.type = 'table'
        AND m.name IN (#{quoted_table_names(stored.values.uniq)})
    SQL

    tables.index_with do |table_name|
      create_table_sql, structure = structures[table_name] || [nil, []]
      column_strings = split_table_structure_sql(create_table_sql, structure.map { |column| column["name"] })

      build_foreign_keys(table_name, fk_infos.fetch(stored[table_name], []), column_strings)
    end
  end
end

# The copies must agree with each other and with the public reader.
tables.first(50).each do |t|
  m = c.send(:fetch_foreign_keys_main, [t])[t].map { [_1.from_table, _1.to_table, _1.options] }
  h = ENV["VARIANT"] == "main" ? m : c.send(:fetch_foreign_keys_head, [t])[t].map { [_1.from_table, _1.to_table, _1.options] }
  raise "differ on #{t}" unless m == h && h == c.foreign_keys(t).map { [_1.from_table, _1.to_table, _1.options] } && h.first[2][:name] == "fk_#{t}"
end

if (only = ENV["VARIANT"])
  m = { "main" => :fetch_foreign_keys_main, "head" => :fetch_foreign_keys_head }.fetch(only)
  clock = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
  3.times { tables.each { |t| c.send(m, [t]) } }
  times = 5.times.map { t0 = clock.(); tables.each { |t| c.send(m, [t]) }; clock.() - t0 }
  puts JSON.generate(times: times, gc: GC.count, ruby: RUBY_DESCRIPTION, zjit: defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?)
  exit
end
variants = %w[main head main2 head2]
meth = { "main" => :fetch_foreign_keys_main, "head" => :fetch_foreign_keys_head }
stats = variants.to_h { [_1, { time: [], alloc: [], gc: [] }] }
clock = -> { Process.clock_gettime(Process::CLOCK_MONOTONIC) }
run = ->(m) { tables.each { |t| c.send(m, [t]) } }
3.times { %w[main head].each { run.(meth[_1]) } } # matched warmup
zjit_before = (RubyVM::ZJIT.stats rescue nil) if defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?
15.times do |round|
  variants.rotate(round % 4).each do |v|
    m = meth[v.delete_suffix("2")]
    a0 = GC.stat(:total_allocated_objects); g0 = GC.count; t0 = clock.()
    run.(m)
    stats[v][:time] << clock.() - t0
    stats[v][:alloc] << (GC.stat(:total_allocated_objects) - a0) / 1000.0
    stats[v][:gc] << GC.count - g0
  end
end
med = ->(a) { s = a.sort; s.size.odd? ? s[s.size / 2] : (s[s.size / 2 - 1] + s[s.size / 2]) / 2 }
zjit = defined?(RubyVM::ZJIT) && RubyVM::ZJIT.enabled?
out = { ruby: RUBY_DESCRIPTION, zjit: zjit, sqlite: c.database_version.to_s,
        variants: stats.transform_values { |s| { median_s: med.(s[:time]), alloc_per_call: med.(s[:alloc]), gc_runs: s[:gc].sum, times: s[:time] } } }
if zjit && RubyVM::ZJIT.respond_to?(:stats) && (st = (RubyVM::ZJIT.stats rescue nil))
  out[:zjit_stats] = st.select { |k, _| k.to_s.match?(/compiled_iseq_count|invalidation|side_exit_count|compile_error|dynamic_send_count\z/) }
end
puts JSON.generate(out)
base = out[:variants]["main"][:median_s]
out[:variants].each { |v, s| warn format("%-6s %.4f s %+.2f%%  alloc/call %.1f  gc %d", v, s[:median_s], (s[:median_s] / base - 1) * 100, s[:alloc_per_call], s[:gc_runs]) }
