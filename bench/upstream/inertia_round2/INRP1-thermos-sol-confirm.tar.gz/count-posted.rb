require 'benchmark/ips'

cases = {}
reporter = Object.new
reporter.define_singleton_method(:report) { |name, &call| cases[name] = call }
Benchmark.define_singleton_method(:ips) { |&suite| suite.call(reporter) }
load File.expand_path(ARGV.fetch(0))
require 'json'

results = cases.map do |name, call|
  3_000.times { call.call }
  resolved = call.call
  GC.start
  GC.disable
  windows = [1_000, 2_000].map do |n|
    before = GC.stat(:total_allocated_objects)
    n.times { call.call }
    [n, GC.stat(:total_allocated_objects) - before]
  end
  GC.enable
  {
    name: name,
    objects_per_resolve: (windows[1][1] - windows[0][1]) / 1_000.0,
    windows: windows,
    resolved: resolved,
  }
end
puts JSON.pretty_generate({
  ruby: RUBY_DESCRIPTION,
  rails: Rails.version,
  inertia: Gem.loaded_specs.fetch('inertia_rails').full_gem_path,
  yjit: RubyVM::YJIT.enabled?,
  script: File.expand_path(ARGV.fetch(0)),
  results: results,
})
