## Summary

The props resolver asks each prop type it reaches whether it is deferred, merges, is a once prop (and fresh), is live or rescues errors, through `Object#try`, and each `try` call allocates an Array for its arguments. Since #442 only prop types are asked, so `respond_to?` followed by the call gives the same answers, including for prop types that don't define a flag, such as `OptionalProp`, which has no `deferred?`.

Pages with deferred, merge or optional props save the most. Resolving a dashboard's props with Ruby 4.0 and YJIT, with the script below:

| | master | this PR |
| --- | ---: | ---: |
| Iterations per second (benchmark-ips) | 44.1k | 54.0k |
| Objects per resolve | 118 | 90 |

<details>
<summary>Benchmark</summary>

Run with `ruby --yjit bench.rb` in an inertia-rails checkout.

```ruby
require "bundler/inline"
gemfile do
  source "https://rubygems.org"
  gem "rails"
  gem "inertia_rails", path: "."
  gem "benchmark-ips"
end
require "rails"
require "action_controller/railtie"
require "inertia_rails"

rows = Array.new(10) { |i| { id: i, name: "Contact #{i}" } }
evaluator = InertiaRails::PropEvaluator.new(Object.new)
props = -> {
  {
    errors: InertiaRails.always { {} },
    stats: { users: 1200, revenue: 34_500, orders: 87 },
    recent: InertiaRails.merge { rows },
    activity: InertiaRails.defer { rows },
    chart: InertiaRails.defer(group: "charts") { [1, 2, 3] },
    archived: InertiaRails.optional { [] },
  }
}

Benchmark.ips do |x|
  x.report("dashboard props") { InertiaRails::PropsResolver.new(props.(), evaluator: evaluator).resolve }
end
```

</details>

## Test plan

The existing specs cover each flag on the built-in prop types, including the ones that don't define it. The resolved props and metadata are the same as on master.

## Checklist

- [ ] Tests added or updated
- [x] `CHANGELOG.md` updated (for user-facing changes)
