# INRP1 Astra review — 2026-11-27

Verdict: **nits** on `0362ffcb1fea17ce393c40b39efa940d28a1c875`. No code blocker found. Two small body corrections recommended below. No upstream writes, pushes, commits, tracked-file edits, delegated agents, or other threads were started.

Reviewed the item from fetched Lowrail origin/main, the current posted body, and both revisions of the linked Thermos artifact. F1–F5 are resolved. Thermos's last nit concerned automatic versus explicit errors sharing; origin/main contains the correction. None of those findings remains open for the PR.

## Body corrections

1. Put `# frozen_string_literal: true` at the start of the posted Ruby benchmark, before `require "bundler/inline"`. This matches the archived script used for the table. The current posted code allocates its `"charts"` string on every resolve: measured 119 → 91 objects instead of 118 → 90. The archived script and the posted script compiled with frozen string literals both give 118 → 90. Base/base2 allocation runs match exactly. This is a one-object reproduction nit, not a defect in the archived figures or the 28-object saving. No code-head change or remeasurement of the old table is needed to add this missing directive.

Exact replacement at the beginning of the benchmark:

```ruby
# frozen_string_literal: true

require "bundler/inline"
```

2. Replace “Pages with deferred, merge or optional props save the most.” with:

> Pages with more prop types avoid more of these allocations.

The old wording suggests an unsupported ranking of the named types. In otherwise identical one-prop full visits, optional saves 4 objects, deferred 5, merge 7, always 7, and once 8. Plain data saves none. These are diagnostic counts, not suggested additions to the body. The replacement preserves the intended explanation without ranking types.

## Behavior and limits

Both trees ran on Ruby 4.0.10 / Rails 8.1.4.1, a pair covered by the upstream Ruby 4.0 / Rails 8.1 CI cell, with identical Gemfile.lock contents. The builder's `pp_diff.rb` gives 4,000 byte-identical lines. My independent harness gives 10,894 matching non-dispatch-override cases, including results, metadata, predicate/response traces and exception classes/messages (object addresses normalized; backtraces intentionally excluded). It exercises public/private/protected and missing flags, advertised/unadvertised method_missing, inherited methods, singleton methods, extend/prepend including super, Forwardable, SimpleDelegator, DelegateClass, stateful flags and respond_to?, method removal, frozen receivers/results, fibers yielding in flags, mutable returned hashes, collection subclasses, combined flags, built-in props/options, rescued and unrescued failures, and full/only/except/reset/except_once/scroll-intent visits. Constructor failures are kept as failures, not counted as successful resolution coverage.

The only differences in the additional 26 interception tests are deliberate overrides of `try` or `public_send` themselves: 15 differing traces, 8 of which change output. A custom BaseProp whose `deferred?` is true but whose overridden dispatch returns false for that flag sends `p: 19` on master and omits it with deferred metadata on head. This was reproduced through a controller XHR action on both trees, each status 200 (`dispatch-http-*.jsonl`). An app can deliberately hit this boundary; it is not impossible. No such actual consumer or documented dispatch-hook contract was found in the target's lib/docs/specs. It is distinct from defining, hiding, delegating or mutating the flags, which matched. I do not recommend a dispatch-identity guard for hypothetical interception users. The body's reference to standard `Object#try` is the relevant scope; this review does not certify arbitrary redefinitions of it or `public_send`.

Error paths covered predicate exceptions, lying respond_to? with absent/private predicates, invalid expiry/cache/live/merge options, block failures and serialization failures. Existing private flag errors match in class and message. Standalone `require "inertia_rails"` fails identically with `NameError: uninitialized constant InertiaRails::ActiveSupport`; requiring Rails first succeeds on both. There are no changed requires, implicit conversions, result ownership, configuration reads or shared state in the diff. The nil-versus-false difference of missing-flag expressions stays within truthiness checks, not returned props/metadata. No thread stress or full Ruby/Rails matrix was rerun; no new concurrency mechanism exists here.

## Executed checks

On each tree, sequentially to avoid their fixed SSR port collisions:

- `bundle exec rspec --tag '~type:generator' --seed 1729`: 1,218 examples, 0 failures.
- `bundle exec rake test`: 64 runs, 110 assertions, 0 failures/errors/skips.
- `bundle exec rubocop`: 214 files, no offenses.
- The exact posted `ruby --yjit ../posted-bench.rb` runs successfully on base, head and a base repeat. These executions are smoke/reproduction checks, not a replacement nine-round pinned-core timing cohort.
- Allocation comparisons used 10,000 resolves after warmup on the same Ruby/Rails pair. Both base captures agree. A direct flag probe allocated 10,000 Arrays for 10,000 standard try calls and zero for guarded direct calls. All raw outputs are archived with this review.
- Exact-head GitHub check-runs API: all nine jobs success, including the advisory Rails-main cell. Head and base were checked again at the end; master remains `5102d8dba738493c51575162666288e6b38057aa` and the PR remains draft.

## Sentence-by-sentence audit

| Current text | Finding/evidence |
| --- | --- |
| Title: Ask prop types for their flags without try | Exactly describes the substitutions. |
| Resolver asks the six listed flags through Object#try; each call allocates an Array | Diff and active_support/core_ext/object/try.rb checked. The per-call Array effect was measured, including A/A controls. |
| Since #442 only prop types are asked | Read #442's changed files and current value_kind/resolve_prop_type. Plain objects that answer flags remain data. |
| Guarded calls give the same answers, including OptionalProp without deferred? | Standard Object#try uses respond_to? followed by public_send. Visibility, missing-method and stateful probes match. OptionalProp lacks deferred?. Custom overrides of the dispatch machinery are the boundary above. |
| Pages with deferred, merge or optional props save the most | Optional wording nit: use the replacement above rather than rank types. |
| Dashboard props, Ruby 4.0 and YJIT, script below | Workload and version/mode match the archived run. The posted script omitted the archive's frozen-string directive; correct it as above. |
| Table: 44.1k → 54.0k i/s | Reparsed all 27 raw rounds. Best base/base2 43,971 and 44,146, their mean 44,058.5; candidate 54,042. Thus +22.6596%, A/A 0.3972%. Correct rounding. |
| Table: 118 → 90 objects | Reparsed the raw objects logs: 117.999 → 89.999 in interpreter and YJIT with identical A/A. Correct for the archived frozen script; new same-pin reproduction confirms the missing directive issue. |
| Run with ruby --yjit bench.rb in a checkout | Executed exact posted code on both trees successfully. |
| Existing specs cover flags on built-in prop types, including absent flags | Read resolver and prop specs, and ran full suites on both trees. This no longer claims every custom protocol boundary is covered. No new spec is needed merely to assert an allocation optimization. |
| Resolved props and metadata are the same as master | Confirmed by builder differential and independent flag/visit probes; qualification about custom dispatch interception above. |
| Tests added unchecked; CHANGELOG checked | Accurate for the diff. |

The remaining commit message and CHANGELOG claims are accurate for standard Object#try, with no stale universal render or per-type count claims. Thomas is author and committer; there are no trailers. No new source comments, wrappers, dependencies, helpers or permanent tests are introduced. PR template headings/checklist match the target repository, so they are not findings.

`audit.py` reparsed the kept raw objects, benchmark-ips rounds and Callgrind trailing totals for INRP1-resolver, INRP1-resolver-ips, INRP1 and INRP1-ips; every aggregate matches results.json. The resolver evidence is on the exact reviewed head, Ruby 4.0.9, not the review's new Ruby 4.0.10. Its interpreter/YJIT instruction changes are −13.8423%/−24.0637%, and all 33 resolver YJIT windows are flat. Whole-action evidence is historical on the original head: 451 → 423 YJIT objects and +3.1426% i/s with 1.5042% A/A, not newly rerun proof on this head. The final amendment only restores custom stateful flag evaluation order; it does not change the built-in dashboard workload. The rejected loaded cohort and application profile were not rerun, and no app-wide speed claim is made.

## Readability and relevance

L0: each condition checks that its flag exists, then asks it; the original evaluation order remains. Guards serve missing flags on real built-in types, or preserve custom once props without fresh?. No additional guard is warranted. Flog grows because the branch previously hidden in try becomes explicit, not because a new semantic branch was introduced: resolve_prop_type 12.7→14.2, collect_deferred_metadata 8.6→10.3, collect_merge_metadata 33.6→35.1, collect_live_metadata 2.6→4.0, collect_once_metadata 7.5→9.0, waits_for_partial_reload? 5.2→7.0, excluded_by_once_cache? 8.7→11.7. Diagnostic RuboCop Metrics (normally disabled by this repo) retains the same offense identities: collect_merge_metadata ABC 29.95→31.29 and cyclomatic 14→15, length unchanged; class length 238→239. Normal project RuboCop is green on both.

The posted body cites no third-party application. Live GitHub/RubyGems API snapshots: inertiajs/inertia-rails has 1,251 stars, is not archived, and was last pushed 2026-11-26 09:37:25 UTC. inertia_rails has 2,760,506 total downloads in the first live read; the retained later API snapshot gives the exact subsequently observed count. Latest release is 3.24.0, published 2026-11-26 08:57:56 UTC, matching current master. This is the maintained Rails adapter for Inertia, not an abandoned version or obscure app-specific hot spot. The simple change removes real allocation/dispatch work from feature-using pages and is worth a maintainer's time. Its isolated resolver gain must not be presented as a 22.7% whole-request improvement, and plain pages with no prop types do not benefit.

## Pass entry

```yaml
- {reviewer: astra, head: "0362ffcb1fea17ce393c40b39efa940d28a1c875", date: 2026-11-27, orb: T-01a21d34-2642-7263-916b-f103367b92cc, verdict: nits, open: "No code blocker; prior Thermos findings resolved. Two body nits: restore the benchmark's frozen_string_literal directive (posted 119/91 versus archived 118/90 objects), and replace the unsupported prop-type ranking with 'Pages with more prop types avoid more of these allocations.' Custom try/public_send interception changes behavior, but no documented hook or actual consumer was found; flag overrides/delegation/stateful visits match. Both trees pass RSpec/Minitest/RuboCop on Ruby 4.0.10/Rails 8.1.4.1; 4000 builder and 10894 non-interception adversarial cases match."}
```
