require "bundler/inline"
gemfile do
  source "https://rubygems.org"
  gem "rails"
  gem "inertia_rails", path: "."
  gem "benchmark-ips"
end
require "rails"
require "action_controller/railtie"
require "inertia_rails"

rows = Array.new(10) { |i| { id: i, name: "Contact #{i}" } }
evaluator = InertiaRails::PropEvaluator.new(Object.new)
props = -> {
  {
    errors: InertiaRails.always { {} },
    stats: { users: 1200, revenue: 34_500, orders: 87 },
    recent: InertiaRails.merge { rows },
    activity: InertiaRails.defer { rows },
    chart: InertiaRails.defer(group: "charts") { [1, 2, 3] },
    archived: InertiaRails.optional { [] },
  }
}

Benchmark.ips do |x|
  x.report("dashboard props") { InertiaRails::PropsResolver.new(props.(), evaluator: evaluator).resolve }
end
