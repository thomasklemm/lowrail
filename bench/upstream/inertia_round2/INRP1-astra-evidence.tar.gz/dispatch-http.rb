require ENV.fetch('APP')
class DispatchProp < InertiaRails::BaseProp
  def deferred? = true
  def group = 'default'
end
%i[try public_send].each do |dispatch|
  prop = DispatchProp.new { 19 }
  prop.define_singleton_method(dispatch) do |name, *args, &block|
    name == :deferred? ? false : super(name, *args, &block)
  end
  ContactsController.define_method(:probe) { render inertia: 'Probe', props: { p: prop } }
  env = Rack::MockRequest.env_for('/probe', InertiaBench::XHR.merge(InertiaBench::FIXED))
  env['rack.session'] = ActionController::TestSession.new
  env['action_dispatch.request.path_parameters'] = { controller: 'contacts', action: 'probe' }
  status, _, body = ContactsController.action(:probe).call(env)
  text = +''
  body.each { |s| text << s }
  body.close if body.respond_to?(:close)
  parsed = JSON.parse(text)
  puts JSON.generate(dispatch: dispatch, status: status, p: parsed['props']['p'], deferred: parsed['deferredProps'])
end
