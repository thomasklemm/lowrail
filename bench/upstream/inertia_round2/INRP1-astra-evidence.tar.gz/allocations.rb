require 'rails'
require 'action_controller/railtie'
require 'inertia_rails'
require 'objspace'
evaluator = InertiaRails::PropEvaluator.new(Object.new)
rows = Array.new(10) { |i| { id: i, name: "Contact #{i}" } }
cases = {
  plain: -> { { p: 19 } },
  always: -> { { p: InertiaRails.always { 19 } } },
  optional: -> { { p: InertiaRails.optional { 19 } } },
  deferred: -> { { p: InertiaRails.defer { 19 } } },
  once: -> { { p: InertiaRails.once { 19 } } },
  merge: -> { { p: InertiaRails.merge { [19] } } },
  dashboard: lambda do
    {
      errors: InertiaRails.always { {} }, stats: { users: 1200, revenue: 34_500, orders: 87 },
      recent: InertiaRails.merge { rows }, activity: InertiaRails.defer { rows },
      chart: InertiaRails.defer(group: 'charts') { [1, 2, 3] }, archived: InertiaRails.optional { [] },
    }
  end,
}
puts JSON.generate(ruby: RUBY_DESCRIPTION, rails: Rails.version)
cases.each do |name, factory|
  1000.times { InertiaRails::PropsResolver.new(factory.call, evaluator: evaluator).resolve }
  GC.start
  GC.disable
  before = GC.stat(:total_allocated_objects)
  10000.times { InertiaRails::PropsResolver.new(factory.call, evaluator: evaluator).resolve }
  after = GC.stat(:total_allocated_objects)
  GC.enable
  puts JSON.generate(name: name, iterations: 10000, objects: after - before)
end
prop = InertiaRails.always { 19 }
prop.define_singleton_method(:flag?) { false }
[:try, :direct].each do |mode|
  1000.times { mode == :try ? prop.try(:flag?) : (prop.respond_to?(:flag?) && prop.flag?) }
  GC.start
  GC.disable
  before = ObjectSpace.count_objects
  10000.times { mode == :try ? prop.try(:flag?) : (prop.respond_to?(:flag?) && prop.flag?) }
  after = ObjectSpace.count_objects
  GC.enable
  puts JSON.generate(mode: mode, arrays: after[:T_ARRAY] - before[:T_ARRAY])
end
