require ENV.fetch('APP')
require 'delegate'
require 'forwardable'
Time.singleton_class.prepend(Module.new { def now(*) = at(1_800_000_000) })
FLAGS = %i[deferred? merge? once? fresh? live? rescue?].freeze
VISITS = {
  full: {}, only: { component: true, only: ['p'] },
  other: { component: true, only: ['other'] },
  except: { component: true, except: ['p'] },
  except_other: { component: true, except: ['other'] },
  reset: { component: true, only: ['p'], reset: ['p'] },
  except_once_path: { except_once: ['p'] }, except_once_key: { except_once: ['key'] },
  partial_once: { component: true, only: ['p'], except_once: ['key'] },
  append: { component: true, only: ['p'], scroll_intent: 'append' },
  prepend: { component: true, only: ['p'], scroll_intent: 'prepend' },
  reset_full: { reset: ['p'] }, nested: { component: true, only: ['p.data.id'] },
}.freeze

class ProbeProp < InertiaRails::BaseProp
  attr_reader :trace, :counts
  def initialize(trace, failure: false)
    @trace, @counts, @failure = trace, Hash.new(0), failure
    super() { { data: [{ id: 19, value: 'result' }] } }
  end
  def inspect = '#<ProbeProp>'
  def group = 'group'
  def once_key = 'key'
  def expires_at = 123
  def live_metadata = { listeners: ['stream'] }
  def deep_merge? = false
  def appends_at_root? = true
  def prepends_at_root? = false
  def match_on = ['id']
  def call(controller, **)
    @trace << [:call, @counts.dup]
    raise ArgumentError, 'block failure' if @failure
    super.merge(counts: @counts.dup)
  end
end

def custom(trace, flag, mode, value, failure: false)
  prop = ProbeProp.new(trace, failure: failure)
  prop.define_singleton_method(:once?) { true } if flag == :fresh?
  if flag
    dispatch = proc do
      counts[flag] += 1
      trace << [flag, counts[flag]]
      case mode
      when :raising then raise ArgumentError, "predicate failure #{flag}"
      when :stateful then counts[flag].odd? ? value : !value
      when :remove
        singleton_class.remove_method(flag)
        value
      when :fiber
        Fiber.yield([:flag_yield, flag])
        value
      else value
      end
    end
    case mode
    when :missing, :missing_unadvertised
      prop.define_singleton_method(:respond_to_missing?) { |name, priv = false| (mode == :missing && name == flag) || super(name, priv) }
      prop.define_singleton_method(:method_missing) do |name, *args|
        name == flag ? instance_exec(&dispatch) : super(name, *args)
      end
    when :prepend, :extend
      mod = Module.new { define_method(flag, &dispatch) }
      mode == :prepend ? prop.singleton_class.prepend(mod) : prop.extend(mod)
    when :forward
      target = Object.new
      target.define_singleton_method(flag) { trace << [:delegated, flag]; value }
      prop.instance_variable_set(:@target, target)
      prop.singleton_class.extend(Forwardable)
      prop.singleton_class.def_delegator(:@target, flag)
    else
      prop.define_singleton_method(flag, &dispatch)
      prop.singleton_class.send(mode, flag) if %i[private protected].include?(mode)
    end
  end
  prop.define_singleton_method(:respond_to?) do |name, *args|
    trace << [:respond_to, name, args] if FLAGS.include?(name)
    super(name, *args)
  end
  prop.freeze if mode == :frozen
  prop
end

def normalized_error(error)
  text = error.respond_to?(:original_message) ? error.original_message : error.message
  [error.class.name, text.gsub(/0x[0-9a-f]+/, '0xADDR')]
end

def run_case(name, visit_name, visit, factory, layout = :plain)
  trace = []
  out = begin
    InertiaRails.cache_store.clear
    prop = factory.call(trace)
    props = case layout
            when :frozen then { p: prop, other: 27 }.freeze
            when :array then { p: [prop, { second: prop }, 'text'] }
            when :dotted then { 'p.data' => prop, 'p.other' => -> { 27 } }
            else { p: prop, other: 27 }
            end
    evaluator = InertiaRails::PropEvaluator.new(Object.new)
    fiber = Fiber.new { InertiaRails::PropsResolver.new(props, evaluator: evaluator, visit: visit).resolve }
    result = fiber.resume
    while fiber.alive?
      trace << result
      result = fiber.resume
    end
    [:ok, result.as_json]
  rescue StandardError => error
    [:error, normalized_error(error)]
  end
  puts JSON.generate([name, visit_name, layout, out, trace])
end

factories = { 'absent' => ->(t) { custom(t, nil, nil, nil) } }
FLAGS.each do |flag|
  [false, nil, true, 'truthy'].each do |value|
    %i[public private protected missing missing_unadvertised prepend extend forward frozen stateful remove raising fiber].each do |mode|
      factories["#{flag}/#{value.inspect}/#{mode}"] = ->(t) { custom(t, flag, mode, value) }
    end
  end
end
factories['once_missing_fresh'] = ->(t) { custom(t, :once?, :public, true) }
factories['once_stateful_fresh'] = lambda do |t|
  p = custom(t, :fresh?, :stateful, false)
  p.define_singleton_method(:once?) { trace << [:once]; true }
  p
end
factories['rescued_block_error'] = ->(t) { custom(t, :rescue?, :public, true, failure: true) }
factories['unrescued_block_error'] = ->(t) { custom(t, :rescue?, :public, false, failure: true) }
factories['respond_true_private'] = lambda do |t|
  p = custom(t, :deferred?, :private, true)
  p.define_singleton_method(:respond_to?) { |name, *a| name == :deferred? || super(name, *a) }
  p
end
factories['respond_true_missing'] = lambda do |t|
  p = custom(t, nil, nil, nil)
  p.define_singleton_method(:respond_to?) { |name, *a| name == :deferred? || super(name, *a) }
  p
end
factories['respond_hides_public'] = lambda do |t|
  p = custom(t, :deferred?, :public, true)
  p.define_singleton_method(:respond_to?) { |name, *a| name == :deferred? ? false : super(name, *a) }
  p
end
factories['simple_delegator'] = ->(t) { SimpleDelegator.new(custom(t, :once?, :public, true)) }
class TypedDelegator < DelegateClass(ProbeProp); end
factories['typed_delegator'] = ->(t) { TypedDelegator.new(custom(t, :once?, :public, true)) }

options = {
  always: [{}, { live: 'room' }],
  optional: [{}, { once: true }, { fresh: true, once: true }, { live: ['room', 'other'], throttle: 0.2.seconds }, { cache: 'optional' }, { cache: { key: 'optional', expires_in: 60 } }],
  defer: [{}, { group: 'charts' }, { rescue: true }, { rescue: false }, { once: true, key: 'key', expires_in: 60 }, { once: true, expires_in: 2.minutes }, { once: true, expires_in: 'invalid' }, { once: true, fresh: true }, { live: 'room', throttle: 20 }, { merge: true }, { deep_merge: true }, { merge: true, append: 'data', match_on: 'id' }, { cache: 'deferred' }, { cache: { key: 'deferred', expires_in: 60 } }, { cache: {} }],
  merge: [{}, { append: true }, { append: false }, { prepend: true }, { prepend: false }, { append: 'data', match_on: 'id' }, { prepend: ['data', 'other'] }, { append: { data: 'id' }, prepend: { other: nil } }, { deep_merge: true }, { once: true, fresh: true }, { once: true, key: 'key' }, { live: 'room' }, { throttle: 20 }, { deep_merge: true, merge: true }],
  once: [{}, { fresh: true }, { key: 'key', expires_in: 30 }, { expires_in: 1.minute }, { expires_in: 'bad' }, { live: 'room' }],
  cache: [{ key: 'cache' }, { key: ['cache', 2], expires_in: 60 }],
  live: [{}, { streams: ['room', 'other'], throttle: 100 }, { streams: ['room'], throttle: 0.1.seconds }],
  deep_merge: [{}, { match_on: ['data.id', 'other.code'] }],
  lazy: [{}],
}
options.each do |type, variants|
  variants.each_with_index do |opts, index|
    [false, true].each do |failure|
      factories["builtin/#{type}/#{index}/#{failure}"] = lambda do |trace|
        block = -> { trace << [:block]; raise ArgumentError, 'builtin block failure' if failure; { data: [{ id: 19 }], other: [31] } }
        kwargs = Marshal.load(Marshal.dump(opts))
        if type == :cache
          InertiaRails.cache(kwargs.delete(:key), **kwargs, &block)
        else
          InertiaRails.public_send(type, **kwargs, &block)
        end
      end
    end
  end
end
[false, true].product([nil, 'group'], [nil, 'data']).each_with_index do |(defer, group, wrapper), i|
  factories["builtin/scroll/#{i}"] = lambda do |trace|
    InertiaRails.scroll({ page_name: 'page', previous_page: 2, next_page: 4, current_page: 3 }, defer: defer, group: group, wrapper: wrapper) do
      trace << [:block]
      { data: [{ id: 19 }] }
    end
  end
end
factories.each do |name, factory|
  VISITS.each { |visit_name, visit| run_case(name, visit_name, visit, factory) }
end
%i[frozen array dotted].each do |layout|
  factories.select { |name, _| name.start_with?('builtin/') || name == 'absent' }.each do |name, factory|
    VISITS.each { |visit_name, visit| run_case(name, visit_name, visit, factory, layout) }
  end
end

if ENV['DISPATCH_OVERRIDES']
  %i[try public_send].each do |method|
    factory = lambda do |trace|
      p = custom(trace, nil, nil, nil)
      p.define_singleton_method(:deferred?) { true }
      p.define_singleton_method(method) do |name, *a, &b|
        name == :deferred? ? false : super(name, *a, &b)
      end
      p
    end
    VISITS.each { |visit_name, visit| run_case("override/#{method}", visit_name, visit, factory) }
  end
end
