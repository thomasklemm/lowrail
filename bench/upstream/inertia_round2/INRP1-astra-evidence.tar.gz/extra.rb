require_relative 'adversarial'

class InheritedFlags < ProbeProp
  FLAGS.each do |flag|
    define_method(flag) { trace << [:inherited, flag]; false }
  end
end
class InheritedChild < InheritedFlags; end
class ObservedHash < Hash
  attr_accessor :trace
  %i[each each_value map to_a to_hash merge []=].each do |method|
    define_method(method) do |*a, &b|
      trace << [:hash, method] if trace
      super(*a, &b)
    end
  end
end
class ObservedArray < Array
  attr_accessor :trace
  %i[each each_with_index map to_a to_ary include?].each do |method|
    define_method(method) do |*a, &b|
      trace << [:array, method] if trace
      super(*a, &b)
    end
  end
end
class ObservedString < String
  attr_accessor :trace
  %i[to_s to_sym include? gsub!].each do |method|
    define_method(method) do |*a, &b|
      trace << [:string, method] if trace
      super(*a, &b)
    end
  end
end
extra = {
  'inherited' => ->(t) { InheritedChild.new(t) },
  'prepended_super' => lambda do |t|
    prop = InheritedChild.new(t)
    mod = Module.new do
      FLAGS.each { |flag| define_method(flag) { trace << [:prepended, flag]; super() } }
    end
    prop.singleton_class.prepend(mod)
    prop
  end,
  'stateful_respond_to' => lambda do |t|
    prop = InheritedChild.new(t)
    counts = Hash.new(0)
    prop.define_singleton_method(:respond_to?) do |name, *a|
      if FLAGS.include?(name)
        counts[name] += 1
        t << [:respond_to, name, counts[name]]
        counts[name].odd? && super(name, *a)
      else
        super(name, *a)
      end
    end
    prop
  end,
  'freeze_mid_predicate' => lambda do |t|
    prop = InheritedChild.new(t)
    prop.define_singleton_method(:deferred?) { t << [:freeze]; freeze; false }
    prop
  end,
  'mutating_return_hash' => lambda do |t|
    data = { a: 1 }
    data[:b] = -> { t << [:mutation]; data[:a] = 19; 31 }
    InertiaRails.always { data }
  end,
  'subclass_returns' => lambda do |t|
    key = ObservedString.new('data')
    key.trace = t
    list = ObservedArray.new([InertiaRails.once { 31 }, 19])
    list.trace = t
    hash = ObservedHash.new
    hash.trace = t
    hash[key] = list
    InertiaRails.always { hash }
  end,
  'frozen_return' => ->(_t) { InertiaRails.always { { data: [19, 31].freeze }.freeze } },
  'rescued_as_json' => lambda do |t|
    broken = Object.new
    broken.define_singleton_method(:as_json) { |*| t << [:as_json]; raise ArgumentError, 'json failure' }
    InertiaRails.defer(rescue: true, live: 'room') { broken }
  end,
  'dotted_wrapper' => ->(t) { -> { t << [:closure]; { inner: InertiaRails.once { 19 } } } },
}
64.times do |mask|
  extra["combined/#{mask}"] = lambda do |t|
    prop = ProbeProp.new(t)
    FLAGS.each_with_index do |flag, i|
      prop.define_singleton_method(flag) do
        t << [:combined, flag]
        mask[i] == 1
      end
    end
    prop
  end
end
extra.each do |name, factory|
  VISITS.each do |visit_name, visit|
    run_case(name, visit_name, visit, factory, name == 'dotted_wrapper' ? :dotted : :plain)
  end
end
