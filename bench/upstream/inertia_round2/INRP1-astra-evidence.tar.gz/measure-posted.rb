require 'benchmark/ips'
require 'json'
module Benchmark
  def self.ips(*)
    yield Object.new.tap { |reporter|
      def reporter.report(label, &work)
        3000.times(&work)
        GC.start
        GC.disable
        first = GC.stat(:total_allocated_objects)
        10000.times(&work)
        last = GC.stat(:total_allocated_objects)
        GC.enable
        puts JSON.generate(label: label, ruby: RUBY_DESCRIPTION, rails: Rails.version,
                           iterations: 10000, objects: last - first)
      end
    }
  end
end
