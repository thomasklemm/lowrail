import json, pathlib, re, statistics
root = pathlib.Path(__file__).resolve().parents[4]
body = root / 'bench/upstream/inertia_round2/body'
out = {}
for name in ['INRP1-resolver', 'INRP1-resolver-ips', 'INRP1', 'INRP1-ips']:
    directory = body / name
    data = json.loads((directory / 'results.json').read_text())
    observed = {'heads': data['sides'], 'objects': {}, 'instructions': {}, 'ips': {}}
    for key, result in data['objects'].items():
        mode, label = key.split(' ', 1)
        vals = {}
        for side in ['base', 'candidate', 'base2']:
            log = (directory / 'raw' / f'objects-{mode}-{side}.log').read_text()
            vals[side] = float(re.search(r'objects ' + re.escape(label) + r'\s+([\d.]+)', log)[1])
        assert vals['candidate'] == result['candidate']
        assert (vals['base'] + vals['base2']) / 2 == result['base']
        observed['objects'][key] = vals
    for key, result in data['instructions'].items():
        mode, label = key.split(' ', 1)
        vals = {}
        for side in ['base', 'candidate', 'base2']:
            totals = []
            for n in [0, data['n']]:
                matches = list((directory / 'raw').glob(f'ir-{mode}-*-{label.replace(" ", "_")}-{side}-n{n}.callgrind'))
                assert len(matches) == 1
                log = matches[0].read_text()
                totals.append(int(re.search(r'^totals: (\d+)', log, re.M)[1]))
            vals[side] = (totals[1] - totals[0]) / data['n']
        assert abs(vals['candidate'] - result['candidate']) < 1e-6
        assert abs((vals['base'] + vals['base2']) / 2 - result['base']) < 1e-6
        observed['instructions'][key] = vals
    for label, result in data['ips'].items():
        vals = {}
        for side in ['base', 'candidate', 'base2']:
            rates = []
            for f in sorted((directory / 'raw').glob(f'ips-r*-{side}.log')):
                text = f.read_text()
                hit = re.search(re.escape(label) + r'\s+([\d.]+)([kM]?) \(.*?i/s', text)
                rates.append(float(hit[1]) * {'': 1, 'k': 1000, 'M': 1000000}[hit[2]])
            vals[side] = max(rates)
        assert vals['candidate'] == result['candidate']
        assert (vals['base'] + vals['base2']) / 2 == result['base']
        observed['ips'][label] = vals
    windows = []
    for f in (directory / 'raw').glob('*.log'):
        for line in f.read_text().splitlines():
            if line.startswith('jit '):
                counters = re.findall(r'(\w+)=(\d+)>(\d+)', line)
                assert counters and all(a == b for _, a, b in counters), (str(f), line)
                windows.append({'file': f.name, 'line': line})
    observed['flat_windows'] = len(windows)
    out[name] = observed
print(json.dumps(out, indent=2))
