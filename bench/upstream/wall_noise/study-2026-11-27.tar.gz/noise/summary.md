| file | label | processes | windows × calls | sd of process means, observed / window noise only | A/A pair sd: median / p10 / min | JIT moved (windows) |
| --- | --- | ---: | --- | --- | --- | ---: |
| round1.jsonl | z-base | 32 | 20 × 200 | 3.38% / 1.61% | 4.49% / 2.85% / 1.60% | 0 |
| round1.jsonl | z-noaslr | 32 | 20 × 200 | 2.99% / 1.50% | 4.30% / 1.62% / 0.90% | 0 |
| round1.jsonl | z-heap-gcoff | 32 | 20 × 200 | 2.35% / 0.91% | 3.55% / 1.93% / 1.14% | 0 |
| round1.jsonl | z-core0 | 32 | 20 × 200 | 3.69% / 1.05% | 2.42% / 1.74% / 2.51% | 0 |
| round1.jsonl | z-nopin | 32 | 20 × 200 | 2.71% / 1.21% | 3.77% / 1.73% / 1.50% | 0 |
| round1.jsonl | z-execmem | 32 | 20 × 200 | 4.24% / 1.29% | 6.24% / 3.95% / 2.98% | 0 |
| round1.jsonl | interp | 32 | 20 × 200 | 3.07% / 1.06% | 3.73% / 1.97% / 1.44% | 0 |
| round1.jsonl | y-base | 32 | 20 × 200 | 5.16% / 1.94% | 6.99% / 3.70% / 3.42% | 57 |
| round1-large.jsonl | z-base | 32 | 20 × 200 | 3.09% / 1.44% | 4.24% / 2.97% / 3.01% | 0 |
| round1-large.jsonl | z-noaslr | 32 | 20 × 200 | 2.64% / 1.25% | 3.44% / 1.49% / 1.41% | 0 |
| round1-large.jsonl | z-heap-gcoff | 32 | 20 × 200 | 3.89% / 1.59% | 2.75% / 1.64% / 1.41% | 0 |
| round1-large.jsonl | z-nopin | 32 | 20 × 200 | 4.97% / 2.03% | 5.15% / 3.03% / 3.17% | 0 |
| round1-large.jsonl | interp | 32 | 20 × 200 | 5.37% / 1.96% | 5.37% / 3.66% / 2.18% | 0 |
| round1-large.jsonl | y-base | 32 | 20 × 200 | 4.01% / 1.73% | 3.32% / 2.22% / 2.36% | 67 |
| round2.jsonl | z-fixrand | 32 | 20 × 200 | 4.33% / 1.69% | 2.85% / 1.10% / 1.15% | 0 |
| round2.jsonl | z-det | 32 | 20 × 200 | 2.45% / 1.28% | 2.65% / 1.42% / 1.26% | 0 |
| round3.jsonl | z-sibload | 16 | 20 × 200 | 2.78% / 1.52% | 3.89% / 2.85% / 2.15% | 0 |
| round3.jsonl | z-base2 | 16 | 20 × 200 | 3.52% / 1.08% | 3.86% / 2.83% / 1.50% | 0 |
| round4.jsonl | z-short-gcoff | 32 | 80 × 50 | 3.41% / 0.76% | 2.28% / 2.70% / 2.89% | 0 |
| round4.jsonl | z-short | 32 | 80 × 50 | 3.22% / 0.82% | 3.49% / 1.77% / 1.05% | 0 |
| round5.jsonl | y-gcoff | 32 | 20 × 200 | 2.35% / 1.31% | 2.18% / 1.56% / 1.21% | 0 |
| round5.jsonl | y-short-gcoff | 32 | 80 × 50 | 3.92% / 0.86% | 3.68% / 3.60% / 2.23% | 0 |
| round6.jsonl | z-ref | 32 | 20 × 200 | 3.21% / 1.36% | 5.06% / 3.62% / 3.54% | 0 |
