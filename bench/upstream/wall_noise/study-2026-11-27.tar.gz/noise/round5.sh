#!/usr/bin/env bash
# Round 5: YJIT on 4.0.10 with GC off per window and the fixed heap, 20x200 and 80x50 windows.
set -euo pipefail
cd "$(dirname "$0")"
D=$(mise where ruby@4.0.9)/bin/ruby
out=${1:-$PWD/round5.jsonl}
M=$HOME/w/ruby-master/bin/ruby
HEAP="RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000 RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000"
export WARM=3 WINDOWS=80 CALLS=50
P=16
run() { local l=$1 r=$2; shift 2; echo "$(date +%T) $l"; RUBY=$r $D drive.rb "$out" $l "$@" 2>&1 | tail -3; }
Y=$(mise where ruby@4.0.10)/bin/ruby
WINDOWS=20 CALLS=200 EXTRA_ENV="$HEAP GCMODE=off" run y-gcoff $Y $P main:--yjit main:--yjit -- taskset -c 1
EXTRA_ENV="$HEAP GCMODE=off" run y-short-gcoff $Y $P main:--yjit main:--yjit -- taskset -c 1
echo DONE
