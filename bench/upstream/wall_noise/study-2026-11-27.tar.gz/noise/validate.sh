#!/usr/bin/env bash
# Validation cohorts for upstream-bench --wall, one at a time: A/A, planted ~1%, E2 head; ZJIT on master, YJIT on 4.0.10.
set -uo pipefail
cd ~/workspace/repo
B=bench/upstream/wall_noise
M=$HOME/w/ruby-master/bin/ruby
common=(--gems activesupport,activemodel,activerecord --with sqlite3 --modes "" --wall 30)
go() { local name=$1 cand=$2 ruby=$3 mode=$4; echo "$(date +%T) $name"
  mise exec ruby@4.0.10 -- script/upstream-bench --out $B/$name --base ~/w/rails-main --candidate $cand --ruby $ruby \
    --wall-mode $mode --names main,${name#*-} "${common[@]}" $B/e2_fk.rb > /tmp/$name.out 2>&1; echo "  exit $?"; }
go zjit-aa ~/w/rails-aa $M zjit
go yjit-aa ~/w/rails-aa 4.0.10 yjit
go zjit-plant ~/w/rails-plant $M zjit
go zjit-e2 ~/w/rails-e2 $M zjit
go yjit-plant ~/w/rails-plant 4.0.10 yjit
go yjit-e2 ~/w/rails-e2 4.0.10 yjit
echo DONE
