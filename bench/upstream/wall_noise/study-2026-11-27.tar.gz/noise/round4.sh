#!/usr/bin/env bash
# Round 4: window length. 80 windows of 50 calls, GC off per window with the fixed heap, and with GC on.
set -euo pipefail
cd "$(dirname "$0")"
D=$(mise where ruby@4.0.9)/bin/ruby
out=${1:-$PWD/round4.jsonl}
M=$HOME/w/ruby-master/bin/ruby
HEAP="RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000 RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000"
export WARM=3 WINDOWS=80 CALLS=50
P=16
run() { local l=$1 r=$2; shift 2; echo "$(date +%T) $l"; RUBY=$r $D drive.rb "$out" $l "$@" 2>&1 | tail -3; }
EXTRA_ENV="$HEAP GCMODE=off" run z-short-gcoff $M $P main:--zjit main:--zjit -- taskset -c 1
run z-short $M $P main:--zjit main:--zjit -- taskset -c 1
echo DONE
