# refan.rb FILE LABEL: does timing a fixed reference workload next to each window track the host's speed?
# Correlation of log window time with log reference time (within processes and across process medians), and the
# A/A pair sd of the p10 and median estimators raw and divided by the reference.
require "json"
rows = File.readlines(ARGV[0]).map { JSON.parse(_1) }.select { _1["label"] == ARGV[1] }
med = ->(a) { s = a.sort; n = s.size; n.odd? ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0 }
q = ->(a, p) { s = a.sort; s[((s.size - 1) * p).round] }
corr = ->(x, y) { mx = x.sum / x.size; my = y.sum / y.size; x.zip(y).sum { (_1 - mx) * (_2 - my) } / Math.sqrt(x.sum { (_1 - mx)**2 } * y.sum { (_1 - my)**2 }) }
sd = ->(x) { m = x.sum / x.size; Math.sqrt(x.sum { (_1 - m)**2 } / (x.size - 1)) }
%w[ref_loop ref_sort].each do |ref|
  w = rows.flat_map { _1["r"]["windows"] }
  printf "%s: window corr %.2f; process-median corr %.2f\n", ref, corr.(w.map { Math.log(_1["cpu"]) }, w.map { Math.log(_1[ref]) }),
    corr.(rows.map { |r| Math.log(med.(r["r"]["windows"].map { _1["cpu"] })) }, rows.map { |r| Math.log(med.(r["r"]["windows"].map { _1[ref] })) })
end
{ "raw" => ->(x) { x["cpu"] }, "/ref_loop" => ->(x) { x["cpu"] / x["ref_loop"] }, "/ref_sort" => ->(x) { x["cpu"] / x["ref_sort"] } }.each do |name, f|
  { "median" => ->(a) { med.(a) }, "p10" => ->(a) { q.(a, 0.1) } }.each do |en, e|
    pairs = rows.group_by { _1["pair"] }.values.select { _1.size == 2 }.map do |p|
      a, b = %w[A B].map { |arm| e.(p.find { _1["arm"] == arm }["r"]["windows"].map(&f)) }
      Math.log(b / a)
    end
    printf "  %-10s %-6s sd(pair) %.2f%%\n", name, en, sd.(pairs) * 100
  end
end
