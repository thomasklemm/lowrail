#!/usr/bin/env bash
# Release build of ruby master 42a644f6e0 with YJIT and ZJIT into ~/w/ruby-master (baseruby mise 4.0.9).
set -euo pipefail
export PATH="$HOME/.local/share/mise/installs/ruby/4.0.9/bin:$HOME/.cargo/bin:$PATH"
cd ~/w/ruby-src; [ -x configure ] || ./autogen.sh
b=~/w/build-master; rm -rf "$b"; mkdir -p "$b"; cd "$b"
~/w/ruby-src/configure --prefix=$HOME/w/ruby-master --enable-yjit --enable-zjit --disable-install-doc > configure.log 2>&1
make -j2 > make.log 2>&1
make install > install.log 2>&1
~/w/ruby-master/bin/ruby --zjit -v
