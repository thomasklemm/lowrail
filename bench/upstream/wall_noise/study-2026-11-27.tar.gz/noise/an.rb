# an.rb FILE.jsonl [LABEL...]: per label, per-process estimators and B/A over ABBA pairs with bootstrap 95% CIs.
require "json"
rows = File.readlines(ARGV[0]).map { JSON.parse(_1) }
labels = ARGV.drop(1)
labels = rows.map { _1["label"] }.uniq if labels.empty?
med = ->(a) { s = a.sort; n = s.size; n.odd? ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0 }
q = ->(a, p) { s = a.sort; s[((s.size - 1) * p).round] }
rng = Random.new(1)
boot = ->(xs, &stat) { b = 2000.times.map { stat.(Array.new(xs.size) { xs[rng.rand(xs.size)] }) }; [q.(b, 0.025), q.(b, 0.975)] }
pct = ->(x) { format("%+.2f%%", x * 100) }
labels.each do |label|
  rs = rows.select { _1["label"] == label }
  next if rs.empty?
  ests = { "median" => ->(w) { med.(w) }, "min" => ->(w) { w.min }, "p10" => ->(w) { q.(w, 0.1) }, "p25" => ->(w) { q.(w, 0.25) } }
  puts "== #{label}: #{rs.size} processes, #{rs.first["r"]["windows"].size} windows, #{rs.first["r"]["ruby"][0, 40]}"
  win = rs.flat_map { _1["r"]["windows"] }
  printf "  per window: steal ticks %d of %d windows >0, nvcsw mean %.1f, gc/window %.2f, jit moved in %d windows\n",
    win.count { _1["steal"] > 0 }, win.size, win.sum { _1["nvcsw"] } / win.size.to_f, win.sum { _1["gc"] } / win.size.to_f,
    win.count { _1["jit"].first(4).any?(&:nonzero?) }
  %w[wall cpu].each do |metric|
    within = rs.map { w = _1["r"]["windows"].map { |x| x[metric] }; (q.(w, 0.75) - q.(w, 0.25)) / med.(w) }
    ests.each do |en, e|
      per = rs.map { |r| [r["pair"], r["arm"], e.(r["r"]["windows"].map { _1[metric] })] }
      a = per.select { _1[1] == "A" }.map(&:last); b = per.select { _1[1] == "B" }.map(&:last)
      cv = ->(x) { m = x.sum / x.size; Math.sqrt(x.sum { (_1 - m)**2 } / (x.size - 1)) / m }
      pairs = per.group_by(&:first).values.select { _1.size == 2 }.map { |p| p.find { _1[1] == "B" }[2] / p.find { _1[1] == "A" }[2] }
      lr = pairs.map { Math.log(_1) }
      mr = Math.exp(med.(lr)); lo, hi = boot.(lr) { |s| med.(s) }.map { Math.exp(_1) }
      gm = ->(x) { Math.exp(x.sum { Math.log(_1) } / x.size) }
      ratio = gm.(b) / gm.(a)
      blo, bhi = boot.(lr) { |s| s.sum / s.size }.map { Math.exp(_1) }
      printf "  %-4s %-6s A %.4f B %.4f | between-proc CV A %.2f%% B %.2f%% | within IQR/med %.2f%% | B/A median-of-pairs %s [%s, %s]  mean-of-pairs %s [%s, %s]  range %s..%s sd(pair) %.2f%%\n",
        metric, en, med.(a), med.(b), cv.(a) * 100, cv.(b) * 100, med.(within) * 100, pct.(mr - 1), pct.(lo - 1), pct.(hi - 1),
        pct.(ratio - 1), pct.(blo - 1), pct.(bhi - 1), pct.(pairs.min - 1), pct.(pairs.max - 1), Math.sqrt(lr.sum { (_1 - lr.sum / lr.size)**2 } / (lr.size - 1)) * 100
    end
  end
end
