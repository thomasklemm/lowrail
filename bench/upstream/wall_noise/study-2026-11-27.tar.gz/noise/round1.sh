#!/usr/bin/env bash
# Round 1: A/A (main vs main) per variable, one variable changed at a time against z-base. 16 ABBA pairs each.
set -euo pipefail
cd "$(dirname "$0")"
D=$(mise where ruby@4.0.9)/bin/ruby
out=${1:-$HOME/workspace/repo/.amp/in/orb-backup/noise/round1.jsonl}
M=$HOME/w/ruby-master/bin/ruby
Y=$(mise where ruby@4.0.10)/bin/ruby
HEAP="RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000 RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000"
export WARM=3 WINDOWS=20 CALLS=200
P=16
run() { local l=$1 r=$2; shift 2; echo "$(date +%T) $l"; RUBY=$r $D drive.rb "$out" $l "$@" 2>&1 | tail -3; }
for cfg in ${CONFIGS:-z-base z-noaslr z-heap-gcoff z-core0 z-nopin z-execmem interp y-base}; do
  case $cfg in
    z-base) run $cfg $M $P main:--zjit main:--zjit -- taskset -c 1 ;;
    z-noaslr) run $cfg $M $P main:--zjit main:--zjit -- setarch -R taskset -c 1 ;;
    z-heap-gcoff) EXTRA_ENV="$HEAP GCMODE=off" run $cfg $M $P main:--zjit main:--zjit -- taskset -c 1 ;;
    z-core0) run $cfg $M $P main:--zjit main:--zjit -- taskset -c 0 ;;
    z-nopin) run $cfg $M $P main:--zjit main:--zjit ;;
    z-execmem) run $cfg $M $P "main:--zjit --zjit-exec-mem-size=512 --zjit-mem-size=1024" "main:--zjit --zjit-exec-mem-size=512 --zjit-mem-size=1024" -- taskset -c 1 ;;
    interp) run $cfg $M $P main: main: -- taskset -c 1 ;;
    y-base) run $cfg $Y $P main:--yjit main:--yjit -- taskset -c 1 ;;
  esac
done
echo DONE
