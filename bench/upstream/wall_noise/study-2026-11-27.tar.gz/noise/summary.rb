# summary.rb FILE... : one row per label: processes, windows per process, observed sd of process means of log CPU
# time versus the sd that window noise alone would give, and the A/A pair sd of the median, p10 and min estimators.
require "json"
med = ->(a) { s = a.sort; n = s.size; n.odd? ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0 }
q = ->(a, p) { s = a.sort; s[((s.size - 1) * p).round] }
sd = ->(x) { m = x.sum / x.size; Math.sqrt(x.sum { (_1 - m)**2 } / (x.size - 1)) }
puts "| file | label | processes | windows × calls | sd of process means, observed / window noise only | A/A pair sd: median / p10 / min | JIT moved (windows) |"
puts "| --- | --- | ---: | --- | --- | --- | ---: |"
ARGV.each do |file|
  rows = File.readlines(file).map { JSON.parse(_1) }
  rows.group_by { _1["label"] }.each do |label, rs|
    next if rs.size < 4
    ws = rs.map { |r| r["r"]["windows"].map { Math.log(_1["cpu"]) } }
    means = ws.map { _1.sum / _1.size }
    within = ws.sum { |w| m = w.sum / w.size; w.sum { (_1 - m)**2 } } / (ws.sum(&:size) - ws.size)
    est = ->(e) do
      pairs = rs.group_by { _1["pair"] }.values.select { _1.size == 2 }.map { |p| %w[B A].map { |a| e.(p.find { _1["arm"] == a }["r"]["windows"].map { _1["cpu"] }) } }
      format("%.2f%%", sd.(pairs.map { Math.log(_1 / _2) }) * 100)
    end
    moved = rs.sum { |r| r["r"]["windows"].count { _1["jit"].first(4).any?(&:nonzero?) } }
    calls = rs.first["env"]["CALLS"] || (label.include?("short") ? 50 : 200)
    puts "| #{File.basename(file)} | #{label} | #{rs.size} | #{ws.first.size} × #{calls} | #{format("%.2f%% / %.2f%%", sd.(means) * 100, Math.sqrt(within / ws.first.size) * 100)} | " \
      "#{[->(w) { med.(w) }, ->(w) { q.(w, 0.1) }, ->(w) { w.min }].map { est.(_1) }.join(" / ")} | #{moved} |"
  end
end
