#!/usr/bin/env bash
# Round 2: hash seed, all deterministic knobs together, and two long processes for the time scale of slow periods.
set -euo pipefail
cd "$(dirname "$0")"
D=$(mise where ruby@4.0.9)/bin/ruby
out=${1:-$PWD/round2.jsonl}
M=$HOME/w/ruby-master/bin/ruby
HEAP="RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000 RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000"
export WARM=3 WINDOWS=20 CALLS=200
P=16
run() { local l=$1 r=$2; shift 2; echo "$(date +%T) $l"; RUBY=$r $D drive.rb "$out" $l "$@" 2>&1 | tail -3; }
for cfg in ${CONFIGS:-z-fixrand z-det z-long}; do
  case $cfg in
    z-fixrand) EXTRA_ENV="LD_PRELOAD=$HOME/w/fixrand.so" run $cfg $M $P main:--zjit main:--zjit -- taskset -c 1 ;;
    z-det) EXTRA_ENV="LD_PRELOAD=$HOME/w/fixrand.so $HEAP GCMODE=off" run $cfg $M $P main:--zjit main:--zjit -- setarch -R taskset -c 1 ;;
    z-long) WINDOWS=300 run $cfg $M 1 main:--zjit main:--zjit -- taskset -c 1 ;;
  esac
done
echo DONE
