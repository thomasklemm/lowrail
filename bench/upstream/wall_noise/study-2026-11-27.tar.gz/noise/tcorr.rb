# tcorr.rb FILE LABEL: is the noise tied to time or to the process? Lag-1 autocorrelation of window times within a
# process, correlation of consecutive processes' medians and mins (in run order), and the share of the variance of
# window times explained by the process (one-way ANOVA on log time).
require "json"
rows = File.readlines(ARGV[0]).map { JSON.parse(_1) }.select { _1["label"] == ARGV[1] }.sort_by { _1["at"] }
med = ->(a) { s = a.sort; n = s.size; n.odd? ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0 }
corr = ->(x, y) { mx = x.sum / x.size; my = y.sum / y.size; sxy = x.zip(y).sum { (_1 - mx) * (_2 - my) }; sxy / Math.sqrt(x.sum { (_1 - mx)**2 } * y.sum { (_1 - my)**2 }) }
ws = rows.map { |r| r["r"]["windows"].map { Math.log(_1["cpu"]) } }
lag = ws.flat_map { |w| w.each_cons(2).to_a }
printf "lag-1 window autocorrelation: %.2f\n", corr.(lag.map(&:first), lag.map(&:last))
meds = ws.map { med.(_1) }; mins = ws.map(&:min)
printf "consecutive processes: median corr %.2f, min corr %.2f\n", corr.(meds[0..-2], meds[1..]), corr.(mins[0..-2], mins[1..])
all = ws.flatten; gm = all.sum / all.size
between = ws.sum { |w| w.size * (w.sum / w.size - gm)**2 }
total = all.sum { (_1 - gm)**2 }
printf "process share of window variance: %.0f%%\n", between / total * 100
# Expected process-mean spread from window noise alone, versus observed.
within = ws.sum { |w| m = w.sum / w.size; w.sum { (_1 - m)**2 } } / (all.size - ws.size)
printf "sd of process means: observed %.2f%%, from window noise alone %.2f%%\n", Math.sqrt(ws.map { _1.sum / _1.size }.then { |m| mm = m.sum / m.size; m.sum { (_1 - mm)**2 } / (m.size - 1) }) * 100, Math.sqrt(within / ws.first.size) * 100
