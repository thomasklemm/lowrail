# estsim.rb [V1_RESULTS_JSON]: false-claim rate at 30 rounds of three round estimators on identical-code synthetic
# rounds (iid log noise: exponential scale .05, and normal sd .05), and power for a planted +1% with the noise sd
# measured in the real A/A; with a results.json from the v1 run, the interval widths each gives on the real rounds.
require "json"
def median(xs) = (s = xs.sort; n = s.size; n.odd? ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0)
def ci(xs, boots, &stat)
  rng = Random.new(1)
  b = Array.new(boots) { stat.(Array.new(xs.size) { xs[rng.rand(xs.size)] }) }.sort
  [b[(boots * 0.025).floor], b[(boots * 0.975).ceil - 1]]
end
mean = ->(x) { x.sum / x.size }
ests = {
  "median of c-mean(b)" => [->(r) { [r[0] - (r[1] + r[2]) / 2] }, ->(x) { median(x) }],
  "mean of c-mean(b)" => [->(r) { [r[0] - (r[1] + r[2]) / 2] }, mean],
  "pooled median of c-b1, c-b2" => [->(r) { [r[0] - r[1], r[0] - r[2]] }, ->(x) { median(x) }],
}
claim = ->(rounds, (per, stat)) do
  # resample rounds, keep a round's values together
  vals = rounds.map(&per)
  lo, hi = ci(vals, 1000) { |s| stat.(s.flatten) }
  lo > 0 || hi < 0
end
rng = Random.new(11)
noise = { "exp .05" => -> { -0.05 * Math.log(1 - rng.rand) }, "normal .05" => -> { 0.05 * Math.sqrt(-2 * Math.log(1 - rng.rand)) * Math.cos(2 * Math::PI * rng.rand) } }
noise.each do |nn, f|
  ests.each do |en, e|
    hits = 400.times.count { claim.(Array.new(30) { [f.(), f.(), f.()] }, e) }
    printf "%-10s %-30s false claims %3d/400\n", nn, en, hits
  end
end
if ARGV[0]
  cell = JSON.parse(File.read(ARGV[0]))["wall"].values.first
  q = cell["quantile"]
  est = cell["rounds"].map { |r| %w[candidate base base2].map { |k| w = r[k]["cpu"].sort; Math.log(w[((w.size - 1) * q).round]) } }
  ests.each do |en, (per, stat)|
    lo, hi = ci(est.map(&per), 5000) { |s| stat.(s.flatten) }
    printf "real A/A rounds, %-30s %+.2f%% [%+.2f%%, %+.2f%%]\n", en, stat.(est.flat_map(&per)) * 100, lo * 100, hi * 100
  end
end
