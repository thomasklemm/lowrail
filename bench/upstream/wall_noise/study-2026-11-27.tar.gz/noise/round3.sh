#!/usr/bin/env bash
# Round 3: the SMT sibling. z-sibload runs a busy loop pinned to vCPU 0 (the sibling of the measured vCPU 1) throughout.
set -euo pipefail
cd "$(dirname "$0")"
D=$(mise where ruby@4.0.9)/bin/ruby
out=${1:-$PWD/round3.jsonl}
M=$HOME/w/ruby-master/bin/ruby
export WARM=3 WINDOWS=20 CALLS=200
run() { local l=$1 r=$2; shift 2; echo "$(date +%T) $l"; RUBY=$r $D drive.rb "$out" $l "$@" 2>&1 | tail -3; }
taskset -c 0 sh -c 'while :; do :; done' & busy=$!
run z-sibload $M 8 main:--zjit main:--zjit -- taskset -c 1
kill $busy
run z-base2 $M 8 main:--zjit main:--zjit -- taskset -c 1
echo DONE
