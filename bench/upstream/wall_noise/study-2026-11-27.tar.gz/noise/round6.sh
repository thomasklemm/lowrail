#!/usr/bin/env bash
# Round 6: reference workloads timed next to every window (REF=1), GC off with the fixed heap; 16 pairs and two long processes.
set -euo pipefail
cd "$(dirname "$0")"
D=$(mise where ruby@4.0.9)/bin/ruby
out=${1:-$PWD/round6.jsonl}
M=$HOME/w/ruby-master/bin/ruby
HEAP="RUBY_GC_HEAP_0_INIT_SLOTS=1000000 RUBY_GC_HEAP_1_INIT_SLOTS=250000 RUBY_GC_HEAP_2_INIT_SLOTS=100000 RUBY_GC_HEAP_3_INIT_SLOTS=20000 RUBY_GC_HEAP_4_INIT_SLOTS=10000"
export WARM=3 WINDOWS=20 CALLS=200
run() { local l=$1 r=$2; shift 2; echo "$(date +%T) $l"; RUBY=$r $D drive.rb "$out" $l "$@" 2>&1 | tail -3; }
EXTRA_ENV="$HEAP GCMODE=off REF=1" run z-ref $M 16 main:--zjit main:--zjit -- taskset -c 1
WINDOWS=300 EXTRA_ENV="$HEAP GCMODE=off REF=1" run z-long-ref $M 1 main:--zjit main:--zjit -- taskset -c 1
echo DONE
