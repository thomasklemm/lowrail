$VERBOSE = nil
Warning[:experimental] = false

def check(name, expected)
  actual = yield
  raise "#{name}: #{actual.inspect} != #{expected.inspect}" unless actual == expected
  puts "#{name}: #{actual.inspect}"
end

module BoundaryWrites
  def put(v) = (@slot = v)
  def read = @slot
  def rhs = (@slot = yield)
  def block_put(host, v)
    host.bounce(v) { |x| @slot = x }
  end
end
class BoundaryObject
  include BoundaryWrites
end
class BlockHost
  def bounce(v) = yield(v)
end

[0, 1, 2, 3, 6, 12, 30, 126].each do |padding|
  check("frozen id after profile #{padding}", [FrozenError, 799, true]) do
    o = Class.new(BoundaryObject).new.extend(Module.new)
    padding.times { |i| o.instance_variable_set(:"@p#{i}", i + 31) }
    800.times { |i| raise unless o.put(i) == i }
    o.freeze
    100.times { begin; o.put(:wrong); rescue FrozenError; end }
    before = o.instance_variables.map { |iv| [iv, o.instance_variable_get(iv)] }
    raise 'object_id assigned before probe' if RubyVM::Shape.of(o).has_object_id?
    id = o.object_id
    GC.verify_compaction_references(expand_heap: true, toward: :empty)
    error = begin; o.put(:wrong); rescue FrozenError => e; e.class; end
    raise unless before == o.instance_variables.map { |iv| [iv, o.instance_variable_get(iv)] }
    [error, o.read, o.object_id == id]
  end
end

check('reembed at suspended RHS', [:robject, :extended_or_rdata, :robject, 913, 40]) do
  capacity = (GC::INTERNAL_CONSTANTS.fetch(:RVALUE_SIZE) - GC::INTERNAL_CONSTANTS.fetch(:RBASIC_SIZE)) / 8
  klass = Class.new do
    include BoundaryWrites
    class_eval("def initialize; @slot = 1; #{(capacity - 1).times.map { |i| "@v#{i} = #{40 + i}" }.join('; ')}; end")
  end
  o = klass.new.extend(Module.new)
  first = RubyVM::Shape.of(o).layout
  o.instance_variable_set(:@overflow, 99)
  second = RubyVM::Shape.of(o).layout
  800.times { |i| o.rhs { i } }
  f = Fiber.new { o.rhs { Fiber.yield; 913 } }
  f.resume
  o.remove_instance_variable(:@overflow)
  third = RubyVM::Shape.of(o).layout
  raise unless f.resume == 913
  [first, second, third, o.read, o.instance_variable_get(:@v0)]
end

check('inlined block captured self', [799, nil, FrozenError, 799]) do
  o = BoundaryObject.new.extend(Module.new)
  host = BlockHost.new
  800.times { |i| raise unless o.block_put(host, i) == i }
  before = [o.read, host.instance_variable_get(:@slot)]
  o.freeze
  o.object_id
  error = begin; o.block_put(host, :wrong); rescue FrozenError => e; e.class; end
  before + [error, o.read]
end

check('inlined block shared shapes', [879600, nil]) do
  host = BlockHost.new
  klass = Class.new(BoundaryObject)
  objects = 800.times.map { |i| i.even? ? klass.new : klass.new.extend(Module.new) }
  objects.each_with_index { |o, i| raise unless o.block_put(host, i * 3 - 99) == i * 3 - 99 }
  [objects.sum(&:read), host.instance_variable_get(:@slot)]
end

check('layout families freeze after profile', [799, 799, 799, 799, 799]) do
  [BoundaryObject.new, Class.new, Module.new, Time.at(0), Struct.new(:payload).new(:untouched)].map do |o|
    o.extend(BoundaryWrites)
    12.times { |i| o.instance_variable_set(:"@family#{i}", i) }
    800.times { |i| raise unless o.put(i) == i }
    o.freeze
    o.object_id
    error = begin; o.put(:wrong); rescue FrozenError => e; e.class; end
    raise unless error == FrozenError
    raise unless o.instance_variable_get(:@family11) == 11
    raise unless o.payload == :untouched if o.is_a?(Struct)
    o.read
  end
end

check('thread mutates suspended writer', [FrozenError, 799]) do
  o = BoundaryObject.new.extend(Module.new)
  800.times { |i| o.rhs { i } }
  ready, resume = Queue.new, Queue.new
  thread = Thread.new do
    begin
      o.rhs { ready << true; resume.pop; :wrong }
    rescue FrozenError => e
      e.class
    end
  end
  ready.pop
  o.freeze
  o.object_id
  resume << true
  [thread.value, o.read]
end

check('parallel thread shape transitions', [599, 10599, 20599, 30599]) do
  4.times.map do |n|
    Thread.new do
      o = BoundaryObject.new.extend(Module.new)
      600.times do |i|
        o.instance_variable_set(:"@t#{i % 13}", i)
        raise unless o.put(10000 * n + i) == 10000 * n + i
        Thread.pass if i % 17 == 0
      end
      o.read
    end
  end.map(&:value)
end

class BoundaryRactorClass
  extend BoundaryWrites
end
800.times { |i| BoundaryRactorClass.put(i) }
check('Ractor class write isolation', [Ractor::IsolationError, 799]) do
  r = Ractor.new do
    begin; BoundaryRactorClass.put(:wrong); rescue Ractor::IsolationError => e; e.class; end
  end
  [r.value, BoundaryRactorClass.read]
end

check('parallel Ractor local extended writes', [599, 10599, 20599]) do
  3.times.map do |n|
    Ractor.new(n) do |index|
      o = BoundaryObject.new.extend(BoundaryWrites)
      600.times do |i|
        o.instance_variable_set(:"@r#{i % 11}", i)
        raise unless o.put(10000 * index + i) == 10000 * index + i
      end
      o.read
    end
  end.map(&:value)
end

check('frozen object id exhausts shape tree', [true, FrozenError, 799, :sentinel]) do
  o = Class.new(BoundaryObject).new.extend(Module.new)
  o.instance_variable_set(:@unique_final_exhaust_prefix, :sentinel)
  800.times { |i| o.put(i) }
  o.freeze
  raise if RubyVM::Shape.of(o).complex? || RubyVM::Shape.of(o).has_object_id?
  RubyVM::Shape.exhaust_shapes
  o.object_id
  error = begin; o.put(:wrong); rescue FrozenError => e; e.class; end
  [RubyVM::Shape.of(o).complex?, error, o.read, o.instance_variable_get(:@unique_final_exhaust_prefix)]
end

if RubyVM::ZJIT.enabled?
  s = RubyVM::ZJIT.stats
  STDERR.puts "JIT instructions=#{s[:zjit_insn_count]} inlined blocks=#{s[:inline_block_count]} inlined block calls=#{s[:inline_block_optimized_send_count]}"
  raise unless s.fetch(:zjit_insn_count) > 0
end
