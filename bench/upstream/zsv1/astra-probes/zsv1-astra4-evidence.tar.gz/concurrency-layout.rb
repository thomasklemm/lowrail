Warning[:experimental] = false
module CrossWriter
  def put(v) = (@f2 = v)
end
ordinary = Object.new.extend(CrossWriter)
large_class = Class.new
large_class.class_eval("def initialize; #{8.times.map { |i| "@f#{i}=#{i}" }.join(';')}; end")
large = large_class.new.extend(CrossWriter)
record = Struct.new(:payload).new(:untouched).extend(CrossWriter)
time = Time.at(12345).extend(CrossWriter)
[ordinary, large, record, time].each do |o|
  12.times { |i| o.instance_variable_set(:"@f#{i}", i) }
end
raise unless RubyVM::Shape.of(ordinary).id == RubyVM::Shape.of(record).id
raise unless RubyVM::Shape.of(large).id == RubyVM::Shape.of(time).id
1000.times { |i| ordinary.put(i); large.put(i) }
RubyVM::ZJIT.reset_stats! if RubyVM::ZJIT.enabled?
[record, time].each do |o|
  500.times { |i| raise unless o.put(i) == i }
  raise unless o.instance_variable_get(:@f2) == 499 && o.instance_variable_get(:@f11) == 11
end
raise unless record.payload == :untouched && time.to_i == 12345
if RubyVM::ZJIT.enabled?
  s = RubyVM::ZJIT.stats
  STDERR.puts "shared Struct/Time writes: generic=#{s[:dynamic_setivar_count]}, compiled instructions=#{s[:zjit_insn_count]}"
  raise unless s[:dynamic_setivar_count] == 0 && s[:zjit_insn_count] >= 1000
end
puts 'T_OBJECT/T_STRUCT/T_DATA shared shape: stored=499, neighboring ivars and native payloads unchanged'

module ParallelWriter
  def put(v) = (@slot = v)
  def read = @slot
end
class ParallelObject
  include ParallelWriter
end
warm = ParallelObject.new.extend(Module.new)
1000.times { |i| warm.put(i) }
RubyVM::ZJIT.reset_stats! if RubyVM::ZJIT.enabled?
values = 4.times.map do |n|
  Thread.new do
    o = ParallelObject.new.extend(ParallelWriter)
    1000.times { |i| raise unless o.put(n * 10000 + i) == n * 10000 + i }
    o.read
  end
end.map(&:value)
raise unless values == [999, 10999, 20999, 30999]
puts "thread writes: #{values.inspect}"
if RubyVM::ZJIT.enabled?
  s = RubyVM::ZJIT.stats
  STDERR.puts "threads: store fields=#{s[:store_field_count]}, compiled instructions=#{s[:zjit_insn_count]}"
  raise unless s[:store_field_count] >= 3900
  RubyVM::ZJIT.reset_stats!
end
values = 3.times.map do |n|
  Ractor.new(n) do |index|
    o = ParallelObject.new.extend(ParallelWriter)
    1000.times { |i| raise unless o.put(index * 10000 + i) == index * 10000 + i }
    o.read
  end
end.map(&:value)
raise unless values == [999, 10999, 20999]
puts "Ractor writes: #{values.inspect}"
if RubyVM::ZJIT.enabled?
  s = RubyVM::ZJIT.stats
  STDERR.puts "Ractors: store fields=#{s[:store_field_count]}, compiled instructions=#{s[:zjit_insn_count]}"
  raise unless s[:store_field_count] >= 2900
end
