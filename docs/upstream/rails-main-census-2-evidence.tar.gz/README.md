# U2 retained evidence

See Lowrail docs/upstream/rails-main-census-2.md for admission decisions,
pins, all measured ratios and limitations. This archive is not a new
whole-request census or a fixed-heap Lowrail speed benchmark.

## Contents

- assets-cohort and coder-cohort: all 108 raw fresh-process workers per
  candidate, worker stderr, combined all.json, and 27/12-cell summary.json.
  A/B/draft order is the six permutations twice, sequential modes per
  triplet. No rejected case or A/A control is discarded.
- asset-map.patch: the one published two-line allocation-only candidate.
  fork-commit.txt records author, committer and parent. No upstream PR here.
- coder-rejected.patch: Range removal rejected for flat ZJIT regressions.
  coder-nonflat.json preserves the known nonflat first-case diagnostics.
- intent-reset-rejected.patch and intent-return-alias.txt: the rejected
  empty-queue guard and executed ownership counterexample.
- asset-*.json: base/draft byte/encoding/safety/headers/nonces/ownership
  snapshots. Exact-head receipts were repeated after pull --rebase.
- controls-*.json: direct Coder, public cache and ownership snapshots.
  Direct Coder uses 7.1 envelope; public stores in this control script keep
  standalone AS's 7.0 default. Controls are bounded, not exhaustive.
- cache-*.json: sorted per-test identity/assertion/outcome receipts,
  including two off-only controls at each seed. Different source hashes
  and working directories are expected in draft receipt metadata.
- cache-lead.rb/json: separate synthetic C2-shaped 7.1-format store probe,
  read and hit fetch. Counts only <internal:marshal> objects, not all
  allocations. Uses installed Dalli 5.0.6, not C2's 5.1.0. No app re-run.
- receipt.rb: the Minitest reporter used for cache per-test receipts.
- *.log: original test, lint, build, setup and cohort output, including
  unsuccessful setup/smoke checks. Failures/skips are not relabeled green.
- contribution-policy: scoped copies of the four checked Rails policy
  files at the pinned main. No AI-contribution prohibition found there.
- duplicate-recheck.txt, upstream-search.json-stream and nearby-open-pr-
  diffs.json-stream: bounded public GitHub searches/diffs. They are not
  proof of universal absence of overlap.
- MANIFEST.sha256: file checksums, excluding this manifest itself.

## Reproduction entry points

Use Ruby 4.0.7 for suites and snapshots. Install the pinned Rails root
Gemfile.lock bundle, e.g. BUNDLE_ONLY=default:test:rubocop:cable:db. Cache
checks need real loopback Redis :6379 and Memcached :11211. Test servers
must be disposable: Rails' own cache suites clear server data.

Public retained scripts are under Lowrail bench/upstream/:

    ruby census_2_controls.rb RAILS_CHECKOUT > controls.json
    ruby preload_links.rb RAILS_CHECKOUT snapshot > assets.json
    ruby cache-lead.rb CLEAN_RAILS_CHECKOUT > cache-lead.json

Use different checkouts for main and each patch and compare output.
The Rails suite commands run from the component directory:

    BUNDLE_ONLY=default:test:rubocop:cable:db PARALLEL_WORKERS=1 MT_CPU=1 SEED=41231 bundle exec rake test

For only AS's cache suites, select TEST='test/cache/**/*_test.rb'. To
collect per-test receipts, load this archive's receipt.rb with ruby -r,
and set RECEIPT to a new JSON path. The retained raw receipts, not total
counts alone, determine equality.

Exact-head lint runs from the Rails root:

    BUNDLE_ONLY=default:test:rubocop:cable:db bundle exec rubocop --config .rubocop.yml actionview/lib/action_view/helpers/asset_tag_helper.rb

The --config flag is necessary when additionally checking the external
Lowrail scripts, otherwise RuboCop discovers unrelated default rules.

Timing uses stock Ruby master 5f2bc22560e9063fb8dec736afbf378251cad3ec
built with both YJIT and ZJIT (configuration/build/install logs retained).
Do not run builds/tests/other performance work alongside either cohort.
Use a new output path: the orchestrator refuses to replace a cohort.

    RUBY_MASTER=/absolute/master/ruby ruby census_2_pairs.rb CLEAN_RAILS DRAFT_RAILS NEW_OUTPUT
    CENSUS_TOPIC=assets RUBY_MASTER=/absolute/master/ruby ruby census_2_pairs.rb CLEAN_RAILS DRAFT_RAILS NEW_ASSET_OUTPUT

All raw runtime source hashes are in workers. The published map! source
hash agrees with all asset draft workers. The rejected coder source was
restored, not committed. No timing cohort was rerun after its result.
