# frozen_string_literal: true
require "objspace"
require "json"
require "tmpdir"
root = ARGV.fetch(0)
$LOAD_PATH.unshift "#{root}/activesupport/lib"
require "active_support"
require "active_support/cache"
require "dalli"

ActiveSupport::Cache.format_version = 7.1
rows = []
Dir.mktmpdir("u2-lead") do |dir|
  stores = {
    memory: ActiveSupport::Cache::MemoryStore.new,
    file: ActiveSupport::Cache::FileStore.new(dir),
    redis: ActiveSupport::Cache::RedisCacheStore.new(url: "redis://127.0.0.1:6379/9", namespace: "u2-lead"),
    memcache: ActiveSupport::Cache::MemCacheStore.new("127.0.0.1:11211", namespace: "u2-lead", pool: false),
    memcache_fastpath_control: ActiveSupport::Cache::MemCacheStore.new("127.0.0.1:11211", namespace: "u2-lead-fast", pool: false, string_fastpath: true)
  }
  stores.each do |store_name, store|
    v1, v2, v3, v4 = %w[v1 v2 v3 v4].map { _1.encode(Encoding::US_ASCII) }
    { home_shape: [nil, v1, v2], what_shape: [v3], repo_shape: [nil, nil, nil, v4] }.each do |shape, versions|
      versions.each_with_index { |version, index| store.write("entry-#{index}", "<p>entry-#{index}</p>", version: version) }
      %i[read fetch].each do |operation|
        read = lambda do
          versions.each_with_index.map do |version, index|
            if operation == :read
              store.read("entry-#{index}", version: version)
            else
              store.fetch("entry-#{index}", version: version) { raise "miss" }
            end
          end
        end
        10.times { read.call }
        ObjectSpace.trace_object_allocations_start
        GC.start
        GC.disable
        generation = GC.count
        result = read.call
        objects = Hash.new(0)
        ObjectSpace.each_object do |object|
          next unless ObjectSpace.allocation_generation(object) == generation
          next unless ObjectSpace.allocation_sourcefile(object) == "<internal:marshal>"
          objects[object.class.name] += 1
        end
        GC.enable
        ObjectSpace.trace_object_allocations_stop
        ObjectSpace.trace_object_allocations_clear
        expected = versions.each_index.map { "<p>entry-#{_1}</p>" }
        raise "values differ" unless result == expected
        rows << { store: store_name, operation: operation, shape: shape, marshal_objects: objects }
      end
      versions.each_index { store.delete("entry-#{_1}") }
    end
  end
end
puts JSON.pretty_generate(ruby: RUBY_DESCRIPTION, dalli: Dalli::VERSION,
  cache_format_version: ActiveSupport::Cache.format_version, synthetic: true, rows: rows)
