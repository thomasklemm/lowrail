require "minitest"
require "json"
require "digest"
class CensusReceipt < Minitest::AbstractReporter
  def initialize
    @rows = []
  end
  def record(result)
    @rows << { name: "#{result.class_name}##{result.name}", code: result.result_code,
      assertions: result.assertions, failures: result.failures.map { [_1.class.name, _1.message] } }
  end
  def report
    File.write(ENV.fetch("RECEIPT"), JSON.pretty_generate({ ruby: RUBY_DESCRIPTION,
      mt_cpu: ENV["MT_CPU"], seed: ENV["SEED"], cwd: Dir.pwd,
      source: Dir["../{activesupport,activerecord}/lib/**/*.rb"].sort.to_h { [_1, Digest::SHA256.file(_1).hexdigest] },
      rows: @rows.sort_by { _1[:name] } }))
  end
end
Minitest.extensions << "census_receipt"
def Minitest.plugin_census_receipt_init(options)
  reporter << CensusReceipt.new
end
