CPU top 30 (census 8) with census 7 allocation rank
| CPU | site | apps | Ir/op | % Ir | obj/op (c8) | c7 alloc rank |
|---:|---|---:|---:|---:|---:|---:|
| 1 | `activesupport/lib/active_support/inflector/methods.rb:437` | 15 | 725357 | 1.21 | 11.81 | 93 |
| 2 | `activesupport/lib/active_support/core_ext/enumerable.rb:317` | 20 | 519289 | 0.87 | 369.45 | 1 |
| 3 | `activerecord/lib/active_record/relation/query_methods.rb:193` | 20 | 501767 | 0.84 | 0 | - |
| 4 | `activerecord/lib/active_record/querying.rb:99` | 20 | 369420 | 0.62 | 9.45 | 123 |
| 5 | `activemodel/lib/active_model/attribute_set.rb:225` | 20 | 323690 | 0.54 | 51.07 | 15 |
| 6 | `activemodel/lib/active_model/indexed_row.rb:172` | 19 | 284076 | 0.47 | 0 | - |
| 7 | `activesupport/lib/active_support/isolated_execution_state.rb:32` | 20 | 275197 | 0.46 | 0 | - |
| 8 | `activesupport/lib/active_support/core_ext/erb/util.rb:160` | 19 | 261185 | 0.44 | 0 | - |
| 9 | `activerecord/lib/active_record/result.rb:121` | 20 | 256506 | 0.43 | 0 | - |
| 10 | `activemodel/lib/active_model/attribute_set.rb:92` | 20 | 227717 | 0.38 | 0 | - |
| 11 | `activerecord/lib/arel/collectors/plain_string.rb:15` | 20 | 219220 | 0.37 | 0 | - |
| 12 | `actionview/lib/action_view/buffers.rb:47` | 16 | 219190 | 0.37 | 0 | - |
| 13 | `activerecord/lib/active_record/connection_adapters/postgresql/database_statements.rb:256` | 12 | 209168 | 0.35 | 187.8 | 2 |
| 14 | `activemodel/lib/active_model/attribute_set.rb:249` | 20 | 204888 | 0.34 | 0 | - |
| 15 | `activesupport/lib/active_support/core_ext/erb/util.rb:16` | 18 | 177423 | 0.30 | 2.68 | 330 |
| 16 | `activemodel/lib/active_model/indexed_row.rb:174` | 19 | 160472 | 0.27 | 0 | - |
| 17 | `activerecord/lib/arel/table.rb:91` | 20 | 152500 | 0.25 | 114.07 | 3 |
| 18 | `activerecord/lib/arel/visitors/visitor.rb:37` | 20 | 152386 | 0.25 | 0 | - |
| 19 | `activerecord/lib/active_record/relation/predicate_builder.rb:251` | 20 | 144431 | 0.24 | 0 | - |
| 20 | `activerecord/lib/active_record/relation/merger.rb:65` | 20 | 140796 | 0.24 | 0 | - |
| 21 | `activemodel/lib/active_model/attribute_set.rb:226` | 20 | 140557 | 0.23 | 0 | - |
| 22 | `activemodel/lib/active_model/attribute_set.rb:258` | 19 | 140394 | 0.23 | 0 | - |
| 23 | `activesupport/lib/active_support/ordered_options.rb:108` | 20 | 136961 | 0.23 | 0 | - |
| 24 | `actionview/lib/action_view/helpers/asset_url_helper.rb:194` | 17 | 136003 | 0.23 | 0 | - |
| 25 | `activerecord/lib/active_record/connection_adapters/abstract/query_cache.rb:90` | 20 | 135750 | 0.23 | 0 | - |
| 26 | `activerecord/lib/arel/visitors/visitor.rb:35` | 20 | 134866 | 0.23 | 0 | - |
| 27 | `activesupport/lib/active_support/weak_key_map.rb:39` | 20 | 133735 | 0.22 | 0 | - |
| 28 | `activerecord/lib/active_record/type/hash_lookup_type_map.rb:67` | 12 | 133383 | 0.22 | 0 | - |
| 29 | `activerecord/lib/active_record/relation/merger.rb:64` | 20 | 131090 | 0.22 | 0 | - |
| 30 | `activesupport/lib/active_support/core_ext/string/output_safety.rb:245` | 19 | 126407 | 0.21 | 107.42 | 4 |

Census 7 allocation top 30 with census 8 CPU rank
| c7 | site | apps (c7) | obj/op (c7) | CPU rank | Ir/op | % Ir |
|---:|---|---:|---:|---:|---:|---:|
| 1 | `activesupport/lib/active_support/core_ext/enumerable.rb:317` | 20 | 370.08 | 2 | 519289 | 0.87 |
| 2 | `activerecord/lib/active_record/connection_adapters/postgresql/database_statements.rb:256` | 12 | 183.31 | 13 | 209168 | 0.35 |
| 3 | `activerecord/lib/arel/table.rb:91` | 20 | 114.14 | 17 | 152500 | 0.25 |
| 4 | `activesupport/lib/active_support/core_ext/string/output_safety.rb:245` | 19 | 101.7 | 30 | 126407 | 0.21 |
| 5 | `activerecord/lib/active_record/relation/where_clause.rb:32` | 20 | 96.32 | 87 | 63503 | 0.11 |
| 6 | `activerecord/lib/active_record/connection_adapters/postgresql/database_statements.rb:228` | 12 | 89.23 | 45 | 103930 | 0.17 |
| 7 | `activemodel/lib/active_model/attribute.rb:10` | 20 | 79.35 | 188 | 36184 | 0.06 |
| 8 | `activerecord/lib/active_record/relation/delegation.rb:140` | 20 | 66.63 | 33 | 116867 | 0.20 |
| 9 | `activerecord/lib/active_record/relation.rb:80` | 20 | 62.92 | - | - | - |
| 10 | `activemodel/lib/active_model/type/string.rb:40` | 20 | 61.79 | 57 | 89017 | 0.15 |
| 11 | `activemodel/lib/active_model/attribute_set/builder.rb:20` | 20 | 60.83 | 235 | 28750 | 0.05 |
| 12 | `activerecord/lib/active_record/relation/predicate_builder.rb:146` | 20 | 55.65 | 66 | 82066 | 0.14 |
| 13 | `activesupport/lib/active_support/core_ext/string/output_safety.rb:73` | 19 | 53.79 | 51 | 98271 | 0.16 |
| 14 | `activerecord/lib/active_record/associations.rb:62` | 20 | 52.66 | 226 | 29923 | 0.05 |
| 15 | `activemodel/lib/active_model/attribute_set.rb:225` | 20 | 51.08 | 5 | 323690 | 0.54 |
| 16 | `activerecord/lib/active_record/relation.rb:101` | 20 | 49.88 | - | - | - |
| 17 | `actionview/lib/action_view/helpers/tag_helper.rb:1545` | 19 | 43.35 | 373 | 17994 | 0.03 |
| 18 | `activerecord/lib/active_record/result.rb:196` | 20 | 41.08 | 166 | 38874 | 0.06 |
| 19 | `activesupport/lib/active_support/notifications/fanout.rb:379` | 20 | 39.98 | 2199 | 1798 | 0.00 |
| 20 | `activesupport/lib/active_support/core_ext/object/deep_dup.rb:18` | 18 | 39.47 | 69 | 79631 | 0.13 |
| 21 | `activerecord/lib/active_record/associations/preloader/branch.rb:28` | 15 | 32.06 | 183 | 36698 | 0.06 |
| 22 | `activerecord/lib/arel/nodes/select_statement.rb:11` | 20 | 31.96 | 533 | 12845 | 0.02 |
| 23 | `activesupport/lib/active_support/core_ext/time/calculations.rb:173` | 20 | 31.54 | 100 | 58747 | 0.10 |
| 24 | `activesupport/lib/active_support/notifications/fanout.rb:378` | 20 | 31.08 | 240 | 28414 | 0.05 |
| 25 | `activesupport/lib/active_support/notifications/fanout.rb:381` | 20 | 31.08 | - | - | - |
| 26 | `activerecord/lib/active_record/relation/query_methods.rb:1989` | 20 | 30.8 | - | - | - |
| 27 | `activemodel/lib/active_model/indexed_row.rb:124` | 20 | 30.66 | 148 | 43038 | 0.07 |
| 28 | `activemodel/lib/active_model/indexed_row.rb:97` | 20 | 30.66 | 203 | 33018 | 0.06 |
| 29 | `activerecord/lib/active_record/persistence.rb:278` | 20 | 30.41 | 307 | 22390 | 0.04 |
| 30 | `activerecord/lib/arel/predications.rb:18` | 20 | 27.79 | 480 | 14134 | 0.02 |

In both top 30: 5
