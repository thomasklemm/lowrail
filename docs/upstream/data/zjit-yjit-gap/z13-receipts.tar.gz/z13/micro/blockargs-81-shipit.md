send_fallback_send_block_arg_not_nil per iteration: 207915 (forward 198800, symbol 9061, other 54)

| ISEQ | per iteration | kind | block-argument calls in the ISEQ |
|---|---:|---|---|
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb:39` | 67566 | forward | `fetch_value(&block) line 39` |
| `mon_synchronize@monitor.rb:147` | 35340 | forward | `synchronize(&b) line 147` |
| `synchronize@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb:96` | 23172 | forward | `synchronize(&block) line 96` |
| `fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb:42` | 13719 | forward | `value(&block) line 43` |
| `iterate_guarding_exceptions@activesupport-8.1.2/lib/active_support/notifications/fanout.rb:21` | 13081 | forward | `each(&block) line 24` |
| `with_connection@activerecord-8.1.2/lib/active_record/connection_handling.rb:313` | 7326 | forward | `with_connection(&block) line 313` |
| `fetch_attribute@activerecord-8.1.2/lib/arel.rb:71` | 4715 | forward | `fetch_attribute(&block) line 72` |
| `build_from_hash@activerecord-8.1.2/lib/active_record/relation/predicate_builder.rb:24` | 4441 | forward | `expand_from_hash(&block) line 25` |
| `each@activesupport-8.1.2/lib/active_support/notifications/fanout.rb:124` | 4403 | forward | `iterate_guarding_exceptions(&block) line 124` |
| `block (2 levels) in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb:92` | 3749 | forward | `instantiate_instance_of(&block) line 92` |
| `instantiate_instance_of@activerecord-8.1.2/lib/active_record/persistence.rb:311` | 2951 | forward | `init_with_attributes(&block) line 313` |
| `block in association_scope_cache@activerecord-8.1.2/lib/active_record/reflection.rb:550` | 2424 | forward | `cached_find_by_statement(&block) line 550` |
| `execute@activerecord-8.1.2/lib/active_record/statement_cache.rb:150` | 2424 | forward | `async_find_by_sql(&block) line 154`, `find_by_sql(&block) line 156` |
| `find_by_sql@activerecord-8.1.2/lib/active_record/querying.rb:51` | 2424 | forward | `_load_from_sql(&block) line 55` |
| `find_target@activerecord-8.1.2/lib/active_record/associations/singular_association.rb:48` | 2424 | symbol | `then(&:first) line 50`, `then(&:first) line 55` |
| `log@activerecord-8.1.2/lib/active_record/connection_adapters/abstract_adapter.rb:1205` | 1970 | forward | `instrument(&block) line 1206` |
| `initialize@activerecord-8.1.2/lib/active_record/result.rb:107` | 1970 | symbol | `each(&:-@) line 110` |
| `can_use_fast_cache_version?@activerecord-8.1.2/lib/active_record/integration.rb:179` | 1434 | symbol | `with_connection(&:default_timezone) line 184` |
| `scoping@activerecord-8.1.2/lib/active_record/relation.rb:552` | 1377 | forward | `_scoping(&block) line 558` |
| `serializable?@activemodel-8.1.2/lib/active_model/attribute.rb:63` | 1375 | forward | `serializable?(&block) line 63` |
| `instantiate_records@activerecord-8.1.2/lib/active_record/relation.rb:1480` | 1074 | forward | `instantiate(&block) line 1482`, `_load_from_sql(&block) line 1486` |
| `instantiate@activerecord-8.1.2/lib/active_record/persistence.rb:100` | 1058 | forward | `instantiate_instance_of(&block) line 102` |
| `block (2 levels) in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb:89` | 964 | forward | `instantiate(&block) line 89` |
| `instrument@active_model_serializers-0.9.13/lib/active_model/serializable.rb:57` | 800 | forward | `instrument(&block) line 58` |
| `url@shipit-engine-0.45.0/lib/shipit/github_app.rb:136` | 787 | symbol | `map(&:to_s) line 137` |
| `to_param@activesupport-8.1.2/lib/active_support/core_ext/object/to_query.rb:49` | 664 | symbol | `collect(&:to_param) line 49` |
| `initialize@shipit-engine-0.45.0/app/models/shipit/status/group.rb:25` | 595 | symbol | `uniq(&:context) line 27`, `map(&:context) line 28`, `sort_by!(&:context) line 31` |
| `link_to@actionview-8.1.2/lib/action_view/helpers/url_helper.rb:198` | 449 | forward | `content_tag(&block) line 207` |
| `block in render@actionview-8.1.2/lib/action_view/template.rb:273` | 354 | forward | `_run(&block) line 281`, `_run(&block) line 284` |
| `instrument_render_template@actionview-8.1.2/lib/action_view/template.rb:583` | 354 | forward | `instrument(&block) line 583` |
| `expanded_version@activesupport-8.1.2/lib/active_support/cache.rb:1060` | 307 | symbol | `tap(&:compact!) line 1061` |
| `instrument@activesupport-8.1.2/lib/active_support/cache.rb:1066` | 264 | forward | `_instrument(&block) line 1067` |
| `call@activerecord-8.1.2/lib/active_record/associations/preloader/batch.rb:13` | 254 | symbol | `flat_map(&:branches) line 13`, `flat_map(&:runnable_loaders) line 15`, `map(&:table_name) line 20`, `each(&:run) line 28`, `partition(&:done?) line 31`, `flat_map(&:children) line 33` |
| `instrument_fragment_cache@actionpack-8.1.2/lib/abstract_controller/caching/fragments.rb:145` | 202 | forward | `instrument(&block) line 145` |
| `block in cache@actionview-8.1.2/lib/action_view/helpers/cache_helper.rb:179` | 202 | forward | `fragment_for(&block) line 180` |
| `block in call@activerecord-8.1.2/lib/active_record/associations/preloader/batch.rb:21` | 127 | symbol | `map(&:klass) line 21` |
| `content_for@actionview-8.1.2/lib/action_view/helpers/capture_helper.rb:172` | 106 | forward | `capture(&block) line 176` |
| `instantiate@activerecord-8.1.2/lib/active_record/associations/join_dependency/join_part.rb:65` | 94 | forward | `instantiate(&block) line 66` |
| `block in each@activerecord-8.1.2/lib/active_record/associations/join_dependency/join_part.rb:33` | 94 | forward | `each(&block) line 33` |
| `references_eager_loaded_tables?@activerecord-8.1.2/lib/active_record/relation.rb:1499` | 77 | symbol | `map!(&:downcase) line 1510`, `map(&:to_s) line 1512` |
