send_fallback_send_block_arg_not_nil per iteration: 119999 (forward 109986, symbol 10013)

| ISEQ | per iteration | kind | block-argument calls in the ISEQ |
|---|---:|---|---|
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb:39` | 35550 | forward | `fetch_value(&block) line 39` |
| `iterate_guarding_exceptions@activesupport-8.1.1/lib/active_support/notifications/fanout.rb:21` | 21948 | forward | `each(&block) line 24` |
| `mon_synchronize@monitor.rb:147` | 19970 | forward | `synchronize(&b) line 147` |
| `each@activesupport-8.1.1/lib/active_support/notifications/fanout.rb:124` | 9974 | forward | `iterate_guarding_exceptions(&block) line 124` |
| `instrument_render_template@actionview-8.1.1/lib/action_view/template.rb:583` | 5287 | forward | `instrument(&block) line 583` |
| `block in render@actionview-8.1.1/lib/action_view/template.rb:273` | 5287 | forward | `_run(&block) line 281`, `_run(&block) line 284` |
| `synchronize@activerecord-8.1.1/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb:96` | 4000 | forward | `synchronize(&block) line 96` |
| `with_connection@activerecord-8.1.1/lib/active_record/connection_handling.rb:313` | 3970 | forward | `with_connection(&block) line 313` |
| `block in call@rack-3.1.17/lib/rack/tempfile_reaper.rb:27` | 2000 | symbol | `each(&:close!) line 27` |
| `initialize@activerecord-8.1.1/lib/active_record/result.rb:107` | 2000 | symbol | `each(&:-@) line 110` |
| `clear_all@activesupport-8.1.1/lib/active_support/current_attributes.rb:158` | 2000 | symbol | `each(&:reset) line 159` |
| `each@actionpack-8.1.1/lib/action_dispatch/middleware/stack.rb:82` | 2000 | forward | `each(&block) line 82` |
| `log@activerecord-8.1.1/lib/active_record/connection_adapters/abstract_adapter.rb:1200` | 2000 | forward | `instrument(&block) line 1201` |
| `[]=@activesupport-8.1.1/lib/active_support/execution_context.rb:70` | 2000 | symbol | `each(&:call) line 71` |
| `run@activerecord-8.1.1/lib/active_record/asynchronous_queries_tracker.rb:37` | 2000 | symbol | `tap(&:start_session) line 37` |
| `build_rendered_collection@jbuilder-2.13.0/lib/jbuilder/collection_renderer.rb:28` | 13 | symbol | `map(&:body) line 28` |
