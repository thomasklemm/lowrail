send_fallback_send_block_arg_not_nil per iteration: 94975 (forward 90913, symbol 3604, mixed 458)

| ISEQ | per iteration | kind | block-argument calls in the ISEQ |
|---|---:|---|---|
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb:39` | 58391 | forward | `fetch_value(&block) line 39` |
| `mon_synchronize@monitor.rb:147` | 6503 | forward | `synchronize(&b) line 147` |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb:42` | 5596 | forward | `value(&block) line 43` |
| `iterate_guarding_exceptions@activesupport-8.1.1/lib/active_support/notifications/fanout.rb:21` | 4023 | forward | `each(&block) line 24` |
| `synchronize@activerecord-8.1.1/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb:96` | 2988 | forward | `synchronize(&block) line 96` |
| `with_connection@activerecord-8.1.1/lib/active_record/connection_handling.rb:313` | 1527 | forward | `with_connection(&block) line 313` |
| `each@activesupport-8.1.1/lib/active_support/notifications/fanout.rb:124` | 1481 | forward | `iterate_guarding_exceptions(&block) line 124` |
| `instantiate_instance_of@activerecord-8.1.1/lib/active_record/persistence.rb:311` | 1267 | forward | `init_with_attributes(&block) line 313` |
| `block (2 levels) in _load_from_sql@activerecord-8.1.1/lib/active_record/querying.rb:92` | 1267 | forward | `instantiate_instance_of(&block) line 92` |
| `build_from_hash@activerecord-8.1.1/lib/active_record/relation/predicate_builder.rb:24` | 1162 | forward | `expand_from_hash(&block) line 25` |
| `log@activerecord-8.1.1/lib/active_record/connection_adapters/abstract_adapter.rb:1200` | 1030 | forward | `instrument(&block) line 1201` |
| `initialize@activerecord-8.1.1/lib/active_record/result.rb:107` | 1030 | symbol | `each(&:-@) line 110` |
| `serializable?@activemodel-8.1.1/lib/active_model/attribute.rb:63` | 796 | forward | `serializable?(&block) line 63` |
| `instrument_render_template@actionview-8.1.1/lib/action_view/template.rb:583` | 690 | forward | `instrument(&block) line 583` |
| `block in render@actionview-8.1.1/lib/action_view/template.rb:273` | 690 | forward | `_run(&block) line 281`, `_run(&block) line 284` |
| `fetch_attribute@activerecord-8.1.1/lib/arel.rb:71` | 455 | forward | `fetch_attribute(&block) line 72` |
| `call@activerecord-8.1.1/lib/active_record/associations/preloader/batch.rb:13` | 446 | symbol | `flat_map(&:branches) line 13`, `flat_map(&:runnable_loaders) line 15`, `map(&:table_name) line 20`, `each(&:run) line 28`, `partition(&:done?) line 31`, `flat_map(&:children) line 33` |
| `load@activerecord-8.1.1/lib/active_record/relation.rb:1200` | 396 | forward | `exec_queries(&block) line 1201` |
| `defaults_hash@activerecord-typedstore-1.6.0/lib/active_record/typed_store/typed_hash.rb:16` | 359 | symbol | `select(&:has_default?) line 16` |
| `block in exec_queries@activerecord-8.1.1/lib/active_record/relation.rb:1429` | 334 | mixed | `instantiate_records(&block) line 1437`, `each(&:readonly!) line 1440` |
| `instrument@activesupport-8.1.1/lib/active_support/cache.rb:1066` | 262 | forward | `_instrument(&block) line 1067` |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set.rb:51` | 249 | forward | `value(&block) line 51` |
| `execute@activerecord-8.1.1/lib/active_record/statement_cache.rb:150` | 247 | forward | `async_find_by_sql(&block) line 154`, `find_by_sql(&block) line 156` |
| `block in call@activerecord-8.1.1/lib/active_record/associations/preloader/batch.rb:21` | 233 | symbol | `map(&:klass) line 21` |
| `scoping@activerecord-8.1.1/lib/active_record/relation.rb:552` | 215 | forward | `_scoping(&block) line 558` |
| `find_by_sql@activerecord-8.1.1/lib/active_record/querying.rb:51` | 212 | forward | `_load_from_sql(&block) line 55` |
| `references_eager_loaded_tables?@activerecord-8.1.1/lib/active_record/relation.rb:1499` | 210 | symbol | `map!(&:downcase) line 1510`, `map(&:to_s) line 1512` |
| `field_id@actionview-8.1.1/lib/action_view/helpers/form_tag_helper.rb:102` | 172 | symbol | `tap(&:compact!) line 110` |
| `instantiate_records@activerecord-8.1.1/lib/active_record/relation.rb:1480` | 168 | forward | `instantiate(&block) line 1482`, `_load_from_sql(&block) line 1486` |
| `messages_for@activemodel-8.1.1/lib/active_model/errors.rb:442` | 135 | symbol | `map(&:message) line 442` |
| `cache_votes@benchmarks/lobsters/app/models/stories_paginator.rb:30` | 126 | symbol | `map(&:id) line 31`, `map(&:story_id) line 33`, `map(&:id) line 34`, `map(&:story_id) line 35`, `map(&:id) line 36` |
| `uncached@activerecord-8.1.1/lib/active_record/query_cache.rb:34` | 124 | forward | `disable_query_cache(&block) line 35` |
| `in_batches@activerecord-8.1.1/lib/active_record/relation/batches.rb:259` | 124 | mixed | `map(&:to_s) line 260`, `batch_on_loaded_relation(&block) line 279`, `batch_on_unloaded_relation(&block) line 289` |
| `skip_query_cache_if_necessary@activerecord-8.1.1/lib/active_record/relation.rb:1491` | 124 | forward | `uncached(&block) line 1492` |
| `each@actionpack-8.1.1/lib/action_dispatch/http/response.rb:92` | 114 | forward | `each(&block) line 93` |
| `run@activerecord-8.1.1/lib/active_record/asynchronous_queries_tracker.rb:37` | 114 | symbol | `tap(&:start_session) line 37` |
| `block in call@rack-2.2.19/lib/rack/tempfile_reaper.rb:17` | 114 | symbol | `each(&:close!) line 17` |
| `each_chunk@actionpack-8.1.1/lib/action_dispatch/http/response.rb:181` | 114 | forward | `each(&block) line 181` |
| `each@actionpack-8.1.1/lib/action_dispatch/http/response.rb:158` | 114 | forward | `each_chunk(&block) line 163` |
| `parse_http_accept_header@rack-2.2.19/lib/rack/request.rb:575` | 114 | symbol | `each(&:strip!) line 575` |
