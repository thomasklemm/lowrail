send_fallback_send_block_arg_not_nil per iteration: 92610 (forward 82623, symbol 9987)

| ISEQ | per iteration | kind | block-argument calls in the ISEQ |
|---|---:|---|---|
| `mon_synchronize@monitor.rb:147` | 21970 | forward | `synchronize(&b) line 147` |
| `iterate_guarding_exceptions@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications/fanout.rb:22` | 18000 | forward | `each(&block) line 25` |
| `store_if_absent@/home/user/w/rails-vb1/activesupport/lib/active_support/ractors.rb:207` | 15426 | forward | `store_if_absent(&block) line 207` |
| `each@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications/fanout.rb:200` | 6000 | forward | `iterate_guarding_exceptions(&block) line 200` |
| `block in render@/home/user/w/rails-vb1/actionview/lib/action_view/template.rb:338` | 5287 | forward | `_run(&block) line 346`, `_run(&block) line 349` |
| `instrument@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications.rb:269` | 4000 | forward | `instrument(&block) line 271` |
| `synchronize@/home/user/w/rails-vb1/activerecord/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb:99` | 4000 | forward | `synchronize(&block) line 99` |
| `with_connection@/home/user/w/rails-vb1/activerecord/lib/active_record/connection_handling.rb:361` | 3970 | forward | `with_connection(&block) line 361` |
| `[]=@/home/user/w/rails-vb1/activesupport/lib/active_support/execution_context.rb:79` | 2000 | symbol | `each(&:call) line 80` |
| `run@/home/user/w/rails-vb1/activerecord/lib/active_record/asynchronous_queries_tracker.rb:37` | 2000 | symbol | `tap(&:start_session) line 37` |
| `each@/home/user/w/rails-vb1/actionpack/lib/action_dispatch/middleware/stack.rb:81` | 2000 | forward | `each(&block) line 81` |
| `block in call@rack-3.1.17/lib/rack/tempfile_reaper.rb:27` | 2000 | symbol | `each(&:close!) line 27` |
| `append_sec_fetch_site_to_vary_header@/home/user/w/rails-vb1/actionpack/lib/action_controller/metal/request_forgery_protection.rb:571` | 1987 | symbol | `reject(&:blank?) line 576`, `map(&:strip) line 576` |
| `_set_vary_header@/home/user/w/rails-vb1/actionpack/lib/action_controller/metal/rendering.rb:230` | 1987 | symbol | `reject(&:blank?) line 231`, `map(&:strip) line 231` |
| `cached_find_by_statement@/home/user/w/rails-vb1/activerecord/lib/active_record/core.rb:455` | 1970 | forward | `cached_find_by_statement(&block) line 455` |
| `build_rendered_collection@jbuilder-2.13.0/lib/jbuilder/collection_renderer.rb:28` | 13 | symbol | `map(&:body) line 28` |
