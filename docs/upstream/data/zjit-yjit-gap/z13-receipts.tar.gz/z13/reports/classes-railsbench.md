Gap +157.9 M Ir per iteration. Price per extra send/yield 273 Ir (167.6 M over 613635), per extra ivar read 41 Ir (7.9 M over 194888). Interpreted insns per iteration: ZJIT 7306 in ISEQs without JIT code + 947524 after exits at 48.7 Ir; YJIT 945762 + 755760 at 45.5 Ir.

| class | M Ir | share of gap |
|---|---:|---:|
| codegen quality in compiled code (JIT code without the entry trampoline) | +78.7 | 50% |
| missing specialization: blocks | +59.8 | 38% |
| fallbacks: polymorphic, megamorphic, unprofiled | +54.1 | 34% |
| missing specialization: protected, send, other method types | +26.9 | 17% |
| missing specialization: splat, kwargs, forwarding | +21.5 | 14% |
| fallbacks: side exits and frame materialization | +13.6 | 9% |
| missing specialization: ivars | +7.9 | 5% |
| missing specialization: super | +5.2 | 3% |
| code ZJIT does not compile (interpreted ISEQs without JIT code) | +0.4 | 0% |
| everything else (cfunc bodies and runtime, compile, invalidation) | -12.9 | -8% |
| fallbacks: interpreter after side exits | -31.2 | -20% |
| GC, allocation, write barriers | -66.0 | -42% |

| reason | class | extra per iteration | M Ir |
|---|---|---:|---:|
| `send_fallback_invokeblock_polymorphic_miss` | polymorphic, megamorphic, unprofiled | 155660 | +42.5 |
| `send_fallback_invokeblock_not_specialized` | blocks | 111146 | +30.4 |
| `send_fallback_send_block_arg_not_nil` | blocks | 107986 | +29.5 |
| `send_fallback_one_or_more_complex_arg_pass` | splat, kwargs, forwarding | 71565 | +19.5 |
| `send_fallback_send_not_optimized_need_permission` | protected, send, other method types | 54836 | +15.0 |
| `send_fallback_send_not_optimized_method_type_optimized` | protected, send, other method types | 41673 | +11.4 |
| `send_fallback_send_polymorphic_fallback` | polymorphic, megamorphic, unprofiled | 30483 | +8.3 |
| `getivar_fallback_no_profile_missing_ic` | ivars | 194858 | +7.9 |
| `send_fallback_super_complex_args_pass` | super | 13030 | +3.6 |
| `send_fallback_send_polymorphic` | polymorphic, megamorphic, unprofiled | 5961 | +1.6 |
| `send_fallback_sendforward_not_specialized` | splat, kwargs, forwarding | 5217 | +1.4 |
| `send_fallback_super_polymorphic` | polymorphic, megamorphic, unprofiled | 4026 | +1.1 |
| `send_fallback_super_from_block` | super | 4000 | +1.1 |
| `send_fallback_super_call_with_block` | super | 2039 | +0.6 |
| `send_fallback_send_not_optimized_method_type` | protected, send, other method types | 2013 | +0.5 |
| `send_fallback_send_megamorphic` | polymorphic, megamorphic, unprofiled | 2000 | +0.5 |
| `send_fallback_invokesuperforward_not_specialized` | splat, kwargs, forwarding | 2000 | +0.5 |
