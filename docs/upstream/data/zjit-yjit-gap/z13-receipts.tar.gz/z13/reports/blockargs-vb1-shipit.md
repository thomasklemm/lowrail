send_fallback_send_block_arg_not_nil per iteration: 140099 (forward 130421, symbol 8017, mixed 1602, other 54, unknown 5)

| ISEQ | per iteration | kind | block-argument calls in the ISEQ |
|---|---:|---|---|
| `mon_synchronize@monitor.rb:147` | 36609 | forward | `synchronize(&b) line 147` |
| `synchronize@/home/user/w/rails-vb1/activerecord/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb:99` | 23980 | forward | `synchronize(&block) line 99` |
| `iterate_guarding_exceptions@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications/fanout.rb:22` | 13773 | forward | `each(&block) line 25` |
| `with_connection@/home/user/w/rails-vb1/activerecord/lib/active_record/connection_handling.rb:361` | 11066 | forward | `with_connection(&block) line 361` |
| `store_if_absent@/home/user/w/rails-vb1/activesupport/lib/active_support/ractors.rb:207` | 7182 | forward | `store_if_absent(&block) line 207` |
| `each@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications/fanout.rb:200` | 4591 | forward | `iterate_guarding_exceptions(&block) line 200` |
| `block (2 levels) in _load_from_sql@/home/user/w/rails-vb1/activerecord/lib/active_record/querying.rb:118` | 3749 | forward | `instantiate_instance_of(&block) line 118` |
| `each_reference@/home/user/w/rails-vb1/activerecord/lib/active_record/association_route.rb:270` | 3373 | forward | `each(&block) line 270` |
| `each_constraint@/home/user/w/rails-vb1/activerecord/lib/active_record/association_route.rb:274` | 3373 | forward | `each(&block) line 274` |
| `instantiate_instance_of@/home/user/w/rails-vb1/activerecord/lib/active_record/persistence.rb:298` | 2951 | forward | `init_with_attributes(&block) line 299` |
| `instrument@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications.rb:269` | 2621 | forward | `instrument(&block) line 271` |
| `cached_find_by_statement@/home/user/w/rails-vb1/activerecord/lib/active_record/core.rb:455` | 2449 | forward | `cached_find_by_statement(&block) line 455` |
| `execute@/home/user/w/rails-vb1/activerecord/lib/active_record/statement_cache.rb:177` | 2424 | forward | `async_find_by_sql(&block) line 181`, `find_by_sql(&block) line 183` |
| `find_by_sql@/home/user/w/rails-vb1/activerecord/lib/active_record/querying.rb:67` | 2424 | forward | `_load_from_sql(&block) line 71` |
| `block in association_scope_cache@/home/user/w/rails-vb1/activerecord/lib/active_record/reflection.rb:254` | 2424 | forward | `cached_find_by_statement(&block) line 254` |
| `find_target@/home/user/w/rails-vb1/activerecord/lib/active_record/associations/singular_association.rb:45` | 2424 | symbol | `then(&:first) line 47`, `then(&:first) line 52` |
| `can_use_fast_cache_version?@/home/user/w/rails-vb1/activerecord/lib/active_record/integration.rb:203` | 1788 | symbol | `with_connection(&:default_timezone) line 208` |
| `block in exec_queries@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:1477` | 1602 | mixed | `instantiate_records(&block) line 1485`, `each(&:readonly!) line 1488` |
| `scoping@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:560` | 1377 | forward | `_scoping(&block) line 566` |
| `serializable?@/home/user/w/rails-vb1/activemodel/lib/active_model/attribute.rb:80` | 1375 | forward | `serializable?(&block) line 80` |
| `instantiate_records@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:1528` | 1074 | forward | `instantiate(&block) line 1530`, `_load_from_sql(&block) line 1534` |
| `to_param@/home/user/w/rails-vb1/activesupport/lib/active_support/core_ext/object/to_query.rb:57` | 971 | symbol | `collect(&:to_param) line 57` |
| `block (2 levels) in _load_from_sql@/home/user/w/rails-vb1/activerecord/lib/active_record/querying.rb:113` | 964 | forward | `instantiate_instance_of(&block) line 113` |
| `instrument@active_model_serializers-0.9.13/lib/active_model/serializable.rb:57` | 800 | forward | `instrument(&block) line 58` |
| `url@/home/user/w/vendor/shipit-engine-0.45.0/lib/shipit/github_app.rb:136` | 787 | symbol | `map(&:to_s) line 137` |
| `initialize@/home/user/w/vendor/shipit-engine-0.45.0/app/models/shipit/status/group.rb:25` | 595 | symbol | `uniq(&:context) line 27`, `map(&:context) line 28`, `sort_by!(&:context) line 31` |
| `link_to@/home/user/w/rails-vb1/actionview/lib/action_view/helpers/navigation_helper.rb:307` | 449 | forward | `content_tag(&block) line 316` |
| `expanded_version@/home/user/w/rails-vb1/activesupport/lib/active_support/cache.rb:1064` | 307 | symbol | `tap(&:compact!) line 1065` |
| `block in render@/home/user/w/rails-vb1/actionview/lib/action_view/template.rb:338` | 267 | forward | `_run(&block) line 346`, `_run(&block) line 349` |
| `call@/home/user/w/rails-vb1/activerecord/lib/active_record/associations/preloader/batch.rb:13` | 254 | symbol | `flat_map(&:branches) line 13`, `flat_map(&:runnable_loaders) line 15`, `map(&:table_name) line 20`, `each(&:run) line 28`, `partition(&:done?) line 31`, `flat_map(&:children) line 33` |
| `block in cache@/home/user/w/rails-vb1/actionview/lib/action_view/helpers/cache_helper.rb:210` | 202 | forward | `fragment_for(&block) line 211` |
| `instrument_fragment_cache@/home/user/w/rails-vb1/actionpack/lib/abstract_controller/caching/fragments.rb:143` | 202 | forward | `instrument(&block) line 143` |
| `block in call@/home/user/w/rails-vb1/activerecord/lib/active_record/associations/preloader/batch.rb:21` | 127 | symbol | `map(&:klass) line 21` |
| `content_for@/home/user/w/rails-vb1/actionview/lib/action_view/helpers/capture_helper.rb:209` | 106 | forward | `capture(&block) line 213` |
| `block in each@/home/user/w/rails-vb1/activerecord/lib/active_record/associations/join_dependency/join_part.rb:33` | 94 | forward | `each(&block) line 33` |
| `remapper@/home/user/w/rails-vb1/activerecord/lib/active_record/associations/join_dependency.rb:294` | 94 | symbol | `map(&:alias) line 296`, `map(&:name) line 296` |
| `block in expand_from_hash@/home/user/w/rails-vb1/activerecord/lib/active_record/relation/predicate_builder.rb:147` | 94 | forward | `expand_from_hash(&block) line 160`, `associated_table(&block) line 160` |
| `instantiate@/home/user/w/rails-vb1/activerecord/lib/active_record/associations/join_dependency.rb:114` | 94 | symbol | `map(&:alias) line 151`, `map(&:name) line 151` |
| `initialize@/home/user/w/rails-vb1/activemodel/lib/active_model/indexed_row.rb:211` | 94 | symbol | `sort_by!(&:first) line 228`, `map(&:last) line 241` |
| `instantiate@/home/user/w/rails-vb1/activerecord/lib/active_record/persistence.rb:108` | 94 | forward | `init_with_attributes(&block) line 128` |
