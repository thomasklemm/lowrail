send_fallback_send_block_arg_not_nil per iteration: 28159 (forward 25113, symbol 2588, mixed 458)

| ISEQ | per iteration | kind | block-argument calls in the ISEQ |
|---|---:|---|---|
| `mon_synchronize@monitor.rb:147` | 6617 | forward | `synchronize(&b) line 147` |
| `iterate_guarding_exceptions@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications/fanout.rb:22` | 3867 | forward | `each(&block) line 25` |
| `synchronize@/home/user/w/rails-vb1/activerecord/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb:99` | 2988 | forward | `synchronize(&block) line 99` |
| `with_connection@/home/user/w/rails-vb1/activerecord/lib/active_record/connection_handling.rb:361` | 1527 | forward | `with_connection(&block) line 361` |
| `each@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications/fanout.rb:200` | 1289 | forward | `iterate_guarding_exceptions(&block) line 200` |
| `instantiate_instance_of@/home/user/w/rails-vb1/activerecord/lib/active_record/persistence.rb:298` | 1267 | forward | `init_with_attributes(&block) line 299` |
| `block (2 levels) in _load_from_sql@/home/user/w/rails-vb1/activerecord/lib/active_record/querying.rb:118` | 1267 | forward | `instantiate_instance_of(&block) line 118` |
| `store_if_absent@/home/user/w/rails-vb1/activesupport/lib/active_support/ractors.rb:207` | 838 | forward | `store_if_absent(&block) line 207` |
| `serializable?@/home/user/w/rails-vb1/activemodel/lib/active_model/attribute.rb:80` | 796 | forward | `serializable?(&block) line 80` |
| `block in render@/home/user/w/rails-vb1/actionview/lib/action_view/template.rb:338` | 560 | forward | `_run(&block) line 346`, `_run(&block) line 349` |
| `call@/home/user/w/rails-vb1/activerecord/lib/active_record/associations/preloader/batch.rb:13` | 446 | symbol | `flat_map(&:branches) line 13`, `flat_map(&:runnable_loaders) line 15`, `map(&:table_name) line 20`, `each(&:run) line 28`, `partition(&:done?) line 31`, `flat_map(&:children) line 33` |
| `load@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:1242` | 396 | forward | `exec_queries(&block) line 1243` |
| `defaults_hash@activerecord-typedstore-1.6.0/lib/active_record/typed_store/typed_hash.rb:16` | 359 | symbol | `select(&:has_default?) line 16` |
| `block in exec_queries@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:1477` | 334 | mixed | `instantiate_records(&block) line 1485`, `each(&:readonly!) line 1488` |
| `instrument@/home/user/w/rails-vb1/activesupport/lib/active_support/notifications.rb:269` | 259 | forward | `instrument(&block) line 271` |
| `execute@/home/user/w/rails-vb1/activerecord/lib/active_record/statement_cache.rb:177` | 247 | forward | `async_find_by_sql(&block) line 181`, `find_by_sql(&block) line 183` |
| `cached_find_by_statement@/home/user/w/rails-vb1/activerecord/lib/active_record/core.rb:455` | 247 | forward | `cached_find_by_statement(&block) line 455` |
| `fetch_attribute@/home/user/w/rails-vb1/activerecord/lib/arel.rb:80` | 236 | forward | `fetch_attribute(&block) line 81` |
| `fetch_attribute@/home/user/w/rails-vb1/activerecord/lib/arel/nodes/binary.rb:34` | 236 | forward | `fetch_attribute(&) line 35`, `fetch_attribute(&) line 37` |
| `block in call@/home/user/w/rails-vb1/activerecord/lib/active_record/associations/preloader/batch.rb:21` | 233 | symbol | `map(&:klass) line 21` |
| `scoping@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:560` | 215 | forward | `_scoping(&block) line 566` |
| `find_by_sql@/home/user/w/rails-vb1/activerecord/lib/active_record/querying.rb:67` | 212 | forward | `_load_from_sql(&block) line 71` |
| `references_eager_loaded_tables?@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:1547` | 210 | symbol | `map!(&:downcase) line 1558`, `map(&:to_s) line 1560` |
| `field_id@/home/user/w/rails-vb1/actionview/lib/action_view/helpers/form_tag_helper.rb:109` | 172 | symbol | `tap(&:compact!) line 117` |
| `instantiate_records@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:1528` | 168 | forward | `instantiate(&block) line 1530`, `_load_from_sql(&block) line 1534` |
| `each_reference@/home/user/w/rails-vb1/activerecord/lib/active_record/association_route.rb:270` | 158 | forward | `each(&block) line 270` |
| `each_constraint@/home/user/w/rails-vb1/activerecord/lib/active_record/association_route.rb:274` | 158 | forward | `each(&block) line 274` |
| `messages_for@/home/user/w/rails-vb1/activemodel/lib/active_model/errors.rb:519` | 135 | symbol | `map(&:message) line 520` |
| `fetch_value@/home/user/w/rails-vb1/activemodel/lib/active_model/attribute_set.rb:375` | 135 | forward | `value_at(&block) line 378` |
| `each_match@/home/user/w/rails-vb1/activerecord/lib/active_record/association_route.rb:225` | 133 | forward | `each(&block) line 225` |
| `cache_votes@benchmarks/lobsters/app/models/stories_paginator.rb:30` | 126 | symbol | `map(&:id) line 31`, `map(&:story_id) line 33`, `map(&:id) line 34`, `map(&:story_id) line 35`, `map(&:id) line 36` |
| `uncached@/home/user/w/rails-vb1/activerecord/lib/active_record/query_cache.rb:35` | 124 | forward | `disable_query_cache(&block) line 36` |
| `in_batches@/home/user/w/rails-vb1/activerecord/lib/active_record/relation/batches.rb:261` | 124 | mixed | `map(&:to_s) line 272`, `batch_on_loaded_relation(&block) line 281`, `batch_on_unloaded_relation(&block) line 291` |
| `skip_query_cache_if_necessary@/home/user/w/rails-vb1/activerecord/lib/active_record/relation.rb:1539` | 124 | forward | `uncached(&block) line 1540` |
| `each@/home/user/w/rails-vb1/actionpack/lib/action_dispatch/middleware/stack.rb:81` | 114 | forward | `each(&block) line 81` |
| `[]=@/home/user/w/rails-vb1/activesupport/lib/active_support/execution_context.rb:79` | 114 | symbol | `each(&:call) line 80` |
| `each@/home/user/w/rails-vb1/actionpack/lib/action_dispatch/http/response.rb:90` | 114 | forward | `each(&block) line 91` |
| `run@/home/user/w/rails-vb1/activerecord/lib/active_record/asynchronous_queries_tracker.rb:37` | 114 | symbol | `tap(&:start_session) line 37` |
| `block in call@rack-2.2.19/lib/rack/tempfile_reaper.rb:17` | 114 | symbol | `each(&:close!) line 17` |
| `each@/home/user/w/rails-vb1/actionpack/lib/action_dispatch/http/response.rb:157` | 114 | forward | `each_chunk(&block) line 162` |
