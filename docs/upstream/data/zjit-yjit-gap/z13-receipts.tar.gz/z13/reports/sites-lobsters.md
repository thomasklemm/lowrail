Price per extra operation: send/yield 287 Ir (136.1 M over 474455 calls), ivar 79 Ir (21.3 M over 267720 reads)

#### Extra generic operations by ZJIT reason (ZJIT fallbacks not matched by a YJIT generic call at the same ISEQ; per iteration)

| reason | ZJIT count | extra vs YJIT | est. M Ir |
|---|---:|---:|---:|
| `getivar_fallback_no_profile_missing_ic` | 209621 | 193356 | 15.3 |
| `send_fallback_send_polymorphic_fallback` | 272792 | 171350 | 49.2 |
| `send_fallback_send_block_arg_not_nil` | 94975 | 88339 | 25.3 |
| `getivar_fallback_no_side_exits` | 150718 | 71534 | 5.7 |
| `send_fallback_invokeblock_not_specialized` | 66129 | 52163 | 15.0 |
| `send_fallback_invokeblock_polymorphic_miss` | 100695 | 42587 | 12.2 |
| `send_fallback_send_megamorphic` | 109080 | 41285 | 11.8 |
| `send_fallback_one_or_more_complex_arg_pass` | 41663 | 20972 | 6.0 |
| `send_fallback_send_not_optimized_method_type_optimized` | 25646 | 19723 | 5.7 |
| `send_fallback_send_not_optimized_need_permission` | 15959 | 15567 | 4.5 |
| `send_fallback_send_polymorphic` | 10966 | 10133 | 2.9 |
| `send_fallback_sendforward_not_specialized` | 31884 | 4933 | 1.4 |
| `send_fallback_super_polymorphic` | 2661 | 2641 | 0.8 |
| `send_fallback_super_complex_args_pass` | 3227 | 2151 | 0.6 |
| `setivar_fallback_no_side_exits` | 5956 | 1876 | 0.1 |
| `exit_guard_type_failure` | 986 | 986 | – |
| `send_fallback_singleton_class_seen` | 1168 | 827 | 0.2 |
| `send_fallback_send_not_optimized_method_type` | 5794 | 545 | 0.2 |
| `send_fallback_super_call_with_block` | 738 | 491 | 0.1 |
| `exit_patchpoint_method_redefined` | 483 | 483 | – |
| `send_fallback_super_from_block` | 1397 | 384 | 0.1 |
| `getivar_fallback_polymorphic` | 347 | 347 | 0.0 |
| `getivar_fallback_megamorphic` | 322 | 322 | 0.0 |
| `send_fallback_invokesuperforward_not_specialized` | 2474 | 318 | 0.1 |
| `setivar_fallback_complex` | 350 | 285 | 0.0 |
| `send_fallback_super_not_optimized_method_type` | 114 | 45 | 0.0 |
| `exit_guard_shape_failure` | 17 | 17 | – |
| `exit_guard_super_method_entry` | 16 | 16 | – |
| `exit_interrupt` | 1 | 1 | – |
| `getivar_fallback_complex` | 941 | 0 | 0.0 |
| `setivar_fallback_not_t_object` | 5099 | 0 | 0.0 |

#### Top sites (per iteration)

| ISEQ | kind | ZJIT fallbacks | YJIT generic calls | extra | est. M Ir | ZJIT reasons |
|---|---|---:|---:|---:|---:|---|
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | send | 58496 | 0 | 58496 | 16.8 | send_block_arg_not_nil 58391, send_polymorphic_fallback 105 |
| `each@<internal:array>` | yield | 87327 | 50274 | 37053 | 10.6 | invokeblock_polymorphic_miss 87327 |
| `map@<internal:array>` | yield | 39410 | 5655 | 33755 | 9.7 | invokeblock_not_specialized 39410 |
| `<<@activerecord-8.1.1/lib/arel/collectors/composite.rb` | ivar | 28760 | 0 | 28760 | 2.3 | no_profile_missing_ic 28760 |
| `hash@activemodel-8.1.1/lib/active_model/attribute.rb` | ivar | 27717 | 0 | 27717 | 2.2 | no_profile_missing_ic 27717 |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb` | send | 41909 | 18478 | 23431 | 6.7 | send_polymorphic_fallback 41909 |
| `association@activerecord-8.1.1/lib/active_record/associations.rb` | send | 21290 | 1233 | 20057 | 5.8 | send_polymorphic_fallback 21290 |
| `stale_state@activerecord-8.1.1/lib/active_record/associations/belongs_to_association.rb` | ivar | 17024 | 0 | 17024 | 1.4 | no_side_exits 17024 |
| `_app_views_comments__comment_html_erb@benchmarks/lobsters/app/views/comments/_comment.html.erb` | ivar | 16089 | 1572 | 14517 | 1.2 | no_side_exits 15373, no_profile_missing_ic 454, complex 262 |
| `cast@activemodel-8.1.1/lib/active_model/type/value.rb` | send | 13728 | 0 | 13728 | 3.9 | send_polymorphic_fallback 13728 |
| `build_arel@activerecord-8.1.1/lib/active_record/relation/query_methods.rb` | send | 13807 | 2338 | 11469 | 3.3 | send_megamorphic 12438, send_polymorphic_fallback 1356, one_or_more_complex_arg_pass 13 |
| `cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | ivar | 11214 | 0 | 11214 | 0.9 | no_profile_missing_ic 11214 |
| `klass@activerecord-8.1.1/lib/active_record/associations/association.rb` | ivar | 9898 | 0 | 9898 | 0.8 | no_side_exits 5084, no_profile_missing_ic 4814 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | send | 9543 | 0 | 9543 | 2.7 | send_not_optimized_need_permission 9543 |
| `association_key_name@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | ivar | 9342 | 0 | 9342 | 0.7 | no_profile_missing_ic 9342 |
| `association_primary_key@activerecord-8.1.1/lib/active_record/reflection.rb` | ivar | 9058 | 0 | 9058 | 0.7 | no_profile_missing_ic 9058 |
| `type_cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | ivar | 7476 | 0 | 7476 | 0.6 | no_profile_missing_ic 7476 |
| `new!@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | send | 7206 | 0 | 7206 | 2.1 | send_not_optimized_method_type_optimized 7206 |
| `find_minimum_transition@tzinfo-2.0.6/lib/tzinfo/data_sources/transitions_data_timezone_info.rb` | send | 7206 | 0 | 7206 | 2.1 | one_or_more_complex_arg_pass 7206 |
| `loaded?@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | ivar | 7127 | 0 | 7127 | 0.6 | no_profile_missing_ic 7031, polymorphic 96 |
| `query_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/query.rb` | send | 6990 | 0 | 6990 | 2.0 | send_polymorphic_fallback 6990 |
| `associate_records_to_owner@activerecord-8.1.1/lib/active_record/associations/preloader/associat` | ivar | 6828 | 0 | 6828 | 0.5 | no_side_exits 6353, no_profile_missing_ic 475 |
| `block in grouped_records@activerecord-8.1.1/lib/active_record/associations/preloader/branch.rb` | send | 7025 | 448 | 6577 | 1.9 | send_polymorphic_fallback 7025 |
| `mon_synchronize@monitor.rb` | send | 6503 | 0 | 6503 | 1.9 | send_block_arg_not_nil 6503 |
| `polymorphic?@activerecord-8.1.1/lib/active_record/reflection.rb` | ivar | 6470 | 0 | 6470 | 0.5 | no_profile_missing_ic 6430, polymorphic 40 |
| `stale_target?@activerecord-8.1.1/lib/active_record/associations/association.rb` | send | 6452 | 0 | 6452 | 1.9 | send_polymorphic 6352, send_polymorphic_fallback 100 |
| `hash@activerecord-8.1.1/lib/active_record/relation/query_attribute.rb` | ivar | 6342 | 0 | 6342 | 0.5 | no_profile_missing_ic 6342 |
| `downto@<internal:numeric>` | yield | 5792 | 0 | 5792 | 1.7 | invokeblock_not_specialized 5792 |
| `visit@activerecord-8.1.1/lib/arel/visitors/visitor.rb` | send | 13988 | 8259 | 5729 | 1.6 | send_not_optimized_method_type_optimized 9590, send_polymorphic_fallback 4398 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | send | 5596 | 0 | 5596 | 1.6 | send_block_arg_not_nil 5596 |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb` | ivar | 6250 | 1630 | 4620 | 0.4 | no_profile_missing_ic 3342, no_side_exits 2822, no_side_exits 86 |
| `_value_for_database@activemodel-8.1.1/lib/active_model/attribute.rb` | ivar | 4445 | 0 | 4445 | 0.4 | no_profile_missing_ic 4445 |
| `period_for_utc@activesupport-8.1.1/lib/active_support/values/time_zone.rb` | ivar | 4370 | 0 | 4370 | 0.3 | no_profile_missing_ic 4370 |
| `visit@psych-5.2.6/lib/psych/visitors/visitor.rb` | send | 4350 | 3 | 4347 | 1.2 | send_not_optimized_method_type_optimized 4347, send_polymorphic_fallback 3 |
| `accept@psych-5.2.6/lib/psych/visitors/to_ruby.rb` | ivar | 4272 | 0 | 4272 | 0.3 | no_side_exits 4272 |
| `loop@<internal:kernel>` | yield | 4182 | 0 | 4182 | 1.2 | invokeblock_not_specialized 4182 |
| `id@activerecord-8.1.1/lib/active_record/attribute_methods/primary_key.rb` | send | 4081 | 0 | 4081 | 1.2 | send_megamorphic 4081 |
| `value_for@activerecord-8.1.1/lib/active_record/scoping.rb` | send | 5847 | 1788 | 4059 | 1.2 | send_polymorphic_fallback 3336, send_polymorphic 2511 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | ivar | 4040 | 0 | 4040 | 0.3 | no_profile_missing_ic 3756, no_side_exits 284 |
| `nil?@activerecord-8.1.1/lib/active_record/relation/query_attribute.rb` | ivar | 4038 | 0 | 4038 | 0.3 | no_profile_missing_ic 4038 |

