Gap +197.4 M Ir per iteration. Price per extra send/yield 287 Ir (136.1 M over 474455), per extra ivar read 79 Ir (21.3 M over 267720). Interpreted insns per iteration: ZJIT 8503 in ISEQs without JIT code + 360315 after exits at 49.1 Ir; YJIT 235011 + 599229 at 48.4 Ir.

| class | M Ir | share of gap |
|---|---:|---:|
| fallbacks: polymorphic, megamorphic, unprofiled | +77.1 | 39% |
| codegen quality in compiled code (JIT code without the entry trampoline) | +55.9 | 28% |
| missing specialization: blocks | +40.3 | 20% |
| missing specialization: ivars | +21.3 | 11% |
| missing specialization: protected, send, other method types | +10.3 | 5% |
| everything else (cfunc bodies and runtime, compile, invalidation) | +8.6 | 4% |
| missing specialization: splat, kwargs, forwarding | +7.5 | 4% |
| fallbacks: side exits and frame materialization | +4.5 | 2% |
| missing specialization: super | +0.9 | 0% |
| code ZJIT does not compile (interpreted ISEQs without JIT code) | +0.4 | 0% |
| GC, allocation, write barriers | -6.8 | -3% |
| fallbacks: interpreter after side exits | -22.6 | -11% |

| reason | class | extra per iteration | M Ir |
|---|---|---:|---:|
| `send_fallback_send_polymorphic_fallback` | polymorphic, megamorphic, unprofiled | 171350 | +49.2 |
| `send_fallback_send_block_arg_not_nil` | blocks | 88339 | +25.3 |
| `getivar_fallback_no_profile_missing_ic` | ivars | 193356 | +15.3 |
| `send_fallback_invokeblock_not_specialized` | blocks | 52163 | +15.0 |
| `send_fallback_invokeblock_polymorphic_miss` | polymorphic, megamorphic, unprofiled | 42587 | +12.2 |
| `send_fallback_send_megamorphic` | polymorphic, megamorphic, unprofiled | 41285 | +11.8 |
| `send_fallback_one_or_more_complex_arg_pass` | splat, kwargs, forwarding | 20972 | +6.0 |
| `getivar_fallback_no_side_exits` | ivars | 71534 | +5.7 |
| `send_fallback_send_not_optimized_method_type_optimized` | protected, send, other method types | 19723 | +5.7 |
| `send_fallback_send_not_optimized_need_permission` | protected, send, other method types | 15567 | +4.5 |
| `send_fallback_send_polymorphic` | polymorphic, megamorphic, unprofiled | 10133 | +2.9 |
| `send_fallback_sendforward_not_specialized` | splat, kwargs, forwarding | 4933 | +1.4 |
| `send_fallback_super_polymorphic` | polymorphic, megamorphic, unprofiled | 2641 | +0.8 |
| `send_fallback_super_complex_args_pass` | super | 2151 | +0.6 |
| `send_fallback_singleton_class_seen` | polymorphic, megamorphic, unprofiled | 827 | +0.2 |
| `send_fallback_send_not_optimized_method_type` | protected, send, other method types | 545 | +0.2 |
| `setivar_fallback_no_side_exits` | ivars | 1876 | +0.1 |
