Gap +525.6 M Ir per iteration. Price per extra send/yield 341 Ir (406.9 M over 1194786), per extra ivar read 101 Ir (60.3 M over 595037). Interpreted insns per iteration: ZJIT 6275 in ISEQs without JIT code + 627296 after exits at 62.2 Ir; YJIT 172903 + 203170 at 135.8 Ir.

| class | M Ir | share of gap |
|---|---:|---:|
| fallbacks: polymorphic, megamorphic, unprofiled | +267.4 | 51% |
| codegen quality in compiled code (JIT code without the entry trampoline) | +109.0 | 21% |
| missing specialization: blocks | +95.3 | 18% |
| missing specialization: ivars | +60.3 | 11% |
| missing specialization: protected, send, other method types | +24.5 | 5% |
| missing specialization: splat, kwargs, forwarding | +17.4 | 3% |
| fallbacks: side exits and frame materialization | +10.6 | 2% |
| missing specialization: super | +2.3 | 0% |
| code ZJIT does not compile (interpreted ISEQs without JIT code) | +0.4 | 0% |
| fallbacks: interpreter after side exits | -12.1 | -2% |
| everything else (cfunc bodies and runtime, compile, invalidation) | -18.4 | -4% |
| GC, allocation, write barriers | -31.2 | -6% |

| reason | class | extra per iteration | M Ir |
|---|---|---:|---:|
| `send_fallback_send_polymorphic_fallback` | polymorphic, megamorphic, unprofiled | 592212 | +201.7 |
| `send_fallback_send_block_arg_not_nil` | blocks | 195626 | +66.6 |
| `getivar_fallback_no_profile_missing_ic` | ivars | 478538 | +48.5 |
| `send_fallback_invokeblock_polymorphic_miss` | polymorphic, megamorphic, unprofiled | 102534 | +34.9 |
| `send_fallback_invokeblock_not_specialized` | blocks | 84274 | +28.7 |
| `send_fallback_send_megamorphic` | polymorphic, megamorphic, unprofiled | 60529 | +20.6 |
| `send_fallback_send_not_optimized_method_type_optimized` | protected, send, other method types | 40851 | +13.9 |
| `send_fallback_one_or_more_complex_arg_pass` | splat, kwargs, forwarding | 38023 | +12.9 |
| `send_fallback_send_not_optimized_need_permission` | protected, send, other method types | 30462 | +10.4 |
| `getivar_fallback_no_side_exits` | ivars | 94754 | +9.6 |
| `send_fallback_send_polymorphic` | polymorphic, megamorphic, unprofiled | 28039 | +9.5 |
| `send_fallback_sendforward_not_specialized` | splat, kwargs, forwarding | 12204 | +4.2 |
| `setivar_fallback_no_side_exits` | ivars | 18853 | +1.9 |
| `send_fallback_super_complex_args_pass` | super | 4275 | +1.5 |
| `send_fallback_super_call_with_block` | super | 1818 | +0.6 |
| `send_fallback_super_polymorphic` | polymorphic, megamorphic, unprofiled | 1672 | +0.6 |
| `send_fallback_invokesuperforward_not_specialized` | splat, kwargs, forwarding | 857 | +0.3 |
| `getivar_fallback_polymorphic` | ivars | 2702 | +0.3 |
| `send_fallback_super_from_block` | super | 722 | +0.2 |
