| bucket | railsbench | lobsters | shipit |
|---|---:|---:|---:|
| method dispatch (generic send path) | +87.4 (48%) | +88.4 (49%) | +294.5 (48%) |
| JIT code | +57.6 (31%) | +47.1 (26%) | +88.8 (14%) |
| ivar and attr access (generic) | +16.3 (9%) | +39.0 (22%) | +108.1 (17%) |
| GC (marking, sweeping, freeing) | +27.0 (15%) | +8.8 (5%) | +76.7 (12%) |
| block and proc invocation (generic) | +46.4 (25%) | +18.7 (10%) | +38.3 (6%) |
| ZJIT entry trampoline (C→JIT entry) | +29.3 (16%) | +17.3 (10%) | +40.1 (6%) |
| side exits and frame materialization | +14.7 (8%) | +4.9 (3%) | +13.1 (2%) |
| invalidation | +0.0 (0%) | +0.1 (0%) | +0.0 (0%) |
| compile (ZJIT/YJIT compiler, profiling) | -1.9 (-1%) | -9.4 (-5%) | +2.5 (0%) |
| other runtime (cfunc bodies, hash, string, regexp, ...) | -7.8 (-4%) | +5.7 (3%) | -10.3 (-2%) |
| write barriers | -13.0 (-7%) | -3.7 (-2%) | -4.8 (-1%) |
| interpreter (YARV loop and insn helpers) | -29.8 (-16%) | -20.4 (-11%) | -1.0 (-0%) |
| allocation (objects, malloc) | -42.2 (-23%) | -17.3 (-10%) | -27.2 (-4%) |
| **ZJIT − YJIT** | **+183.9** | **+179.1** | **+618.7** |
