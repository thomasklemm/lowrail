Price per extra operation: send/yield 272 Ir (163.2 M over 599632 calls), ivar 57 Ir (16.3 M over 286420 reads)

#### Extra generic operations by ZJIT reason (ZJIT fallbacks not matched by a YJIT generic call at the same ISEQ; per iteration)

| reason | ZJIT count | extra vs YJIT | est. M Ir |
|---|---:|---:|---:|
| `getivar_fallback_no_profile_missing_ic` | 221098 | 218498 | 12.4 |
| `send_fallback_invokeblock_polymorphic_miss` | 211938 | 153650 | 41.8 |
| `send_fallback_send_block_arg_not_nil` | 120000 | 107987 | 29.4 |
| `send_fallback_invokeblock_not_specialized` | 129074 | 105157 | 28.6 |
| `send_fallback_one_or_more_complex_arg_pass` | 104508 | 71565 | 19.5 |
| `getivar_fallback_no_side_exits` | 73922 | 67922 | 3.9 |
| `send_fallback_send_not_optimized_need_permission` | 54836 | 54836 | 14.9 |
| `send_fallback_send_not_optimized_method_type_optimized` | 41673 | 41673 | 11.3 |
| `send_fallback_send_polymorphic_fallback` | 26500 | 26500 | 7.2 |
| `send_fallback_super_complex_args_pass` | 39252 | 13030 | 3.5 |
| `send_fallback_send_polymorphic` | 5961 | 5961 | 1.6 |
| `send_fallback_sendforward_not_specialized` | 75134 | 5217 | 1.4 |
| `send_fallback_super_polymorphic` | 4013 | 4013 | 1.1 |
| `send_fallback_super_from_block` | 6000 | 4000 | 1.1 |
| `exit_unhandled_block_arg` | 2052 | 2052 | – |
| `send_fallback_send_not_optimized_method_type` | 31296 | 2013 | 0.5 |
| `send_fallback_invokesuperforward_not_specialized` | 19970 | 2000 | 0.5 |
| `send_fallback_send_megamorphic` | 189766 | 2000 | 0.5 |
| `send_fallback_send_no_profiles` | 30 | 30 | 0.0 |
| `exit_guard_type_failure` | 0 | 0 | – |
| `setivar_fallback_not_t_object` | 4030 | 0 | 0.0 |
| `send_fallback_super_call_with_block` | 4000 | 0 | 0.0 |
| `send_fallback_super_not_optimized_method_type` | 2000 | 0 | 0.0 |

#### Top sites (per iteration)

| ISEQ | kind | ZJIT fallbacks | YJIT generic calls | extra | est. M Ir | ZJIT reasons |
|---|---|---:|---:|---:|---:|---|
| `each@<internal:array>` | yield | 200651 | 58288 | 142363 | 38.7 | invokeblock_polymorphic_miss 200651 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | send | 41805 | 0 | 41805 | 11.4 | send_not_optimized_need_permission 41805 |
| `fetch_header@rack-3.1.17/lib/rack/request.rb` | send | 41805 | 0 | 41805 | 11.4 | one_or_more_complex_arg_pass 41805 |
| `request@actionpack-8.1.1/lib/action_dispatch/middleware/cookies.rb` | ivar | 35766 | 0 | 35766 | 2.0 | no_profile_missing_ic 35766 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | send | 35550 | 0 | 35550 | 9.7 | send_block_arg_not_nil 35550 |
| `map@<internal:array>` | yield | 41197 | 9300 | 31897 | 8.7 | invokeblock_not_specialized 41197 |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb` | ivar | 28714 | 0 | 28714 | 1.6 | no_profile_missing_ic 28714 |
| `level_override@logger-1.7.0/lib/logger.rb` | ivar | 25961 | 0 | 25961 | 1.5 | no_side_exits 25961 |
| `level@logger-1.7.0/lib/logger.rb` | ivar | 25961 | 0 | 25961 | 1.5 | no_side_exits 25961 |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb` | ivar | 23640 | 0 | 23640 | 1.3 | no_profile_missing_ic 23640 |
| `iterate_guarding_exceptions@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | send | 21948 | 0 | 21948 | 6.0 | send_block_arg_not_nil 21948 |
| `mon_synchronize@monitor.rb` | send | 19971 | 0 | 19971 | 5.4 | send_block_arg_not_nil 19971 |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb` | ivar | 18114 | 0 | 18114 | 1.0 | no_profile_missing_ic 18114 |
| `url_options@actionview-8.1.1/lib/action_view/routing_url_for.rb` | ivar | 18114 | 0 | 18114 | 1.0 | no_profile_missing_ic 18114 |
| `block in each_precompressed_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | yield | 17883 | 0 | 17883 | 4.9 | invokeblock_not_specialized 17883 |
| `select@<internal:array>` | yield | 16014 | 16 | 15998 | 4.4 | invokeblock_not_specialized 16014 |
| `block (2 levels) in search_combinations@actionview-8.1.1/lib/action_view/path_set.rb` | yield | 12078 | 0 | 12078 | 3.3 | invokeblock_not_specialized 12078 |
| `before@activesupport-8.1.1/lib/active_support/execution_wrapper.rb` | send | 12000 | 0 | 12000 | 3.3 | send_not_optimized_method_type_optimized 12000 |
| `tag_stack@activesupport-8.1.1/lib/active_support/tagged_logging.rb` | ivar | 12000 | 0 | 12000 | 0.7 | no_side_exits 12000 |
| `performed?@actionpack-8.1.1/lib/action_controller/metal.rb` | ivar | 11940 | 0 | 11940 | 0.7 | no_profile_missing_ic 11940 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | ivar | 10357 | 0 | 10357 | 0.6 | no_profile_missing_ic 10357 |
| `each@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | send | 9974 | 0 | 9974 | 2.7 | send_block_arg_not_nil 9974 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | send | 9057 | 0 | 9057 | 2.5 | send_polymorphic_fallback 9057 |
| `optimize_routes_generation?@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | send | 9057 | 0 | 9057 | 2.5 | send_not_optimized_method_type_optimized 9057 |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb` | send | 9057 | 0 | 9057 | 2.5 | send_not_optimized_need_permission 9057 |
| `silenced?@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | send | 8013 | 0 | 8013 | 2.2 | send_polymorphic_fallback 8013 |
| `exists?@actionpack-8.1.1/lib/action_dispatch/request/session.rb` | send | 7948 | 0 | 7948 | 2.2 | send_not_optimized_method_type_optimized 7948 |
| `block in id@actionpack-8.1.1/lib/action_dispatch/request/session.rb` | send | 7948 | 0 | 7948 | 2.2 | send_not_optimized_method_type_optimized 7948 |
| `<<@actionview-8.1.1/lib/action_view/buffers.rb` | send | 7340 | 0 | 7340 | 2.0 | send_polymorphic_fallback 7340 |
| `times@<internal:numeric>` | yield | 7071 | 1 | 7070 | 1.9 | invokeblock_not_specialized 7071 |
| `loop@<internal:kernel>` | yield | 6970 | 0 | 6970 | 1.9 | invokeblock_not_specialized 6970 |
| `instrument@activesupport-8.1.1/lib/active_support/notifications/instrumenter.rb` | yield | 5987 | 0 | 5987 | 1.6 | invokeblock_polymorphic_miss 5987 |
| `each_candidate_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | yield | 5974 | 0 | 5974 | 1.6 | invokeblock_not_specialized 5974 |
| `update_with_single_argument@activesupport-8.1.1/lib/active_support/hash_with_indifferent_access` | send | 5970 | 0 | 5970 | 1.6 | one_or_more_complex_arg_pass 5970 |
| `block in each_precompressed_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | send | 5961 | 0 | 5961 | 1.6 | send_polymorphic 5961 |
| `instrument@activesupport-8.1.1/lib/active_support/notifications.rb` | yield | 5300 | 0 | 5300 | 1.4 | invokeblock_polymorphic_miss 5300 |
| `_run@actionview-8.1.1/lib/action_view/base.rb` | send | 5287 | 0 | 5287 | 1.4 | one_or_more_complex_arg_pass 5287 |
| `instrument_render_template@actionview-8.1.1/lib/action_view/template.rb` | send | 5287 | 0 | 5287 | 1.4 | send_block_arg_not_nil 5287 |
| `block in render@actionview-8.1.1/lib/action_view/template.rb` | send | 5287 | 0 | 5287 | 1.4 | send_block_arg_not_nil 5287 |
| `block in each_pool_config@activerecord-8.1.1/lib/active_record/connection_adapters/pool_manager` | send | 4000 | 0 | 4000 | 1.1 | one_or_more_complex_arg_pass 4000 |

