Price per extra operation: send/yield 285 Ir (124.3 M over 436338 calls), ivar 102 Ir (39.0 M over 382805 reads)

#### Extra generic operations by ZJIT reason (ZJIT fallbacks not matched by a YJIT generic call at the same ISEQ; per iteration)

| reason | ZJIT count | extra vs YJIT | est. M Ir |
|---|---:|---:|---:|
| `getivar_fallback_no_profile_missing_ic` | 320309 | 303104 | 30.8 |
| `send_fallback_send_polymorphic_fallback` | 246908 | 147909 | 42.1 |
| `send_fallback_send_block_arg_not_nil` | 95131 | 88213 | 25.1 |
| `getivar_fallback_no_side_exits` | 153654 | 76763 | 7.8 |
| `send_fallback_invokeblock_not_specialized` | 66266 | 53550 | 15.3 |
| `send_fallback_invokeblock_polymorphic_miss` | 100199 | 41888 | 11.9 |
| `send_fallback_send_megamorphic` | 99676 | 30175 | 8.6 |
| `send_fallback_one_or_more_complex_arg_pass` | 41377 | 21328 | 6.1 |
| `send_fallback_send_not_optimized_method_type_optimized` | 25774 | 16413 | 4.7 |
| `send_fallback_send_not_optimized_need_permission` | 15959 | 15567 | 4.4 |
| `send_fallback_send_polymorphic` | 10063 | 9057 | 2.6 |
| `send_fallback_sendforward_not_specialized` | 31883 | 5000 | 1.4 |
| `exit_guard_type_failure` | 2800 | 2800 | – |
| `send_fallback_super_polymorphic` | 2738 | 2677 | 0.8 |
| `send_fallback_super_complex_args_pass` | 3227 | 2178 | 0.6 |
| `setivar_fallback_no_side_exits` | 6061 | 1351 | 0.1 |
| `getivar_fallback_polymorphic` | 1252 | 1252 | 0.1 |
| `send_fallback_singleton_class_seen` | 1168 | 827 | 0.2 |
| `send_fallback_send_not_optimized_method_type` | 5789 | 798 | 0.2 |
| `send_fallback_super_from_block` | 1397 | 384 | 0.1 |
| `exit_patchpoint_method_redefined` | 382 | 382 | – |
| `exit_unhandled_block_arg` | 341 | 341 | – |
| `setivar_fallback_complex` | 332 | 317 | 0.0 |
| `send_fallback_invokesuperforward_not_specialized` | 2474 | 204 | 0.1 |
| `send_fallback_super_call_with_block` | 382 | 155 | 0.0 |
| `setivar_fallback_not_t_object` | 5099 | 19 | 0.0 |
| `send_fallback_super_not_optimized_method_type` | 114 | 13 | 0.0 |
| `exit_no_profile_getivar` | 6 | 6 | – |
| `exit_guard_shape_failure` | 3 | 3 | – |
| `exit_interrupt` | 1 | 1 | – |
| `getivar_fallback_complex` | 937 | 0 | 0.0 |

#### Top sites (per iteration)

| ISEQ | kind | ZJIT fallbacks | YJIT generic calls | extra | est. M Ir | ZJIT reasons |
|---|---|---:|---:|---:|---:|---|
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | send | 58494 | 0 | 58494 | 16.7 | send_block_arg_not_nil 58380, send_polymorphic_fallback 115 |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | ivar | 42063 | 0 | 42063 | 4.3 | no_profile_missing_ic 42063 |
| `each@<internal:array>` | yield | 87327 | 50633 | 36694 | 10.5 | invokeblock_polymorphic_miss 87327 |
| `map@<internal:array>` | yield | 39410 | 5657 | 33753 | 9.6 | invokeblock_not_specialized 39410 |
| `<<@activerecord-8.1.1/lib/arel/collectors/composite.rb` | ivar | 28760 | 0 | 28760 | 2.9 | no_profile_missing_ic 28760 |
| `hash@activemodel-8.1.1/lib/active_model/attribute.rb` | ivar | 27717 | 0 | 27717 | 2.8 | no_profile_missing_ic 27717 |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb` | send | 43560 | 18478 | 25082 | 7.1 | send_polymorphic_fallback 43560 |
| `association@activerecord-8.1.1/lib/active_record/associations.rb` | send | 18698 | 1233 | 17465 | 5.0 | send_polymorphic_fallback 18698 |
| `stale_state@activerecord-8.1.1/lib/active_record/associations/belongs_to_association.rb` | ivar | 17024 | 0 | 17024 | 1.7 | no_side_exits 17024 |
| `_app_views_comments__comment_html_erb@benchmarks/lobsters/app/views/comments/_comment.html.erb` | ivar | 16094 | 0 | 16094 | 1.6 | no_side_exits 15378, no_profile_missing_ic 454, complex 262 |
| `klass@activerecord-8.1.1/lib/active_record/associations/association.rb` | ivar | 16005 | 0 | 16005 | 1.6 | no_profile_missing_ic 16004, polymorphic 1 |
| `cast@activemodel-8.1.1/lib/active_model/type/value.rb` | send | 12087 | 0 | 12087 | 3.4 | send_polymorphic_fallback 12087 |
| `build_arel@activerecord-8.1.1/lib/active_record/relation/query_methods.rb` | send | 13876 | 2338 | 11538 | 3.3 | send_megamorphic 8299, send_polymorphic_fallback 5564, one_or_more_complex_arg_pass 13 |
| `loaded?@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | ivar | 11385 | 0 | 11385 | 1.2 | no_profile_missing_ic 10998, polymorphic 387 |
| `cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | ivar | 11214 | 0 | 11214 | 1.1 | no_profile_missing_ic 11214 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | send | 9543 | 0 | 9543 | 2.7 | send_not_optimized_need_permission 9543 |
| `association_key_name@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | ivar | 9342 | 0 | 9342 | 1.0 | no_profile_missing_ic 9342 |
| `association_primary_key@activerecord-8.1.1/lib/active_record/reflection.rb` | ivar | 9058 | 0 | 9058 | 0.9 | no_profile_missing_ic 9058 |
| `type_cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | ivar | 7476 | 0 | 7476 | 0.8 | no_profile_missing_ic 7476 |
| `new!@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | send | 7334 | 0 | 7334 | 2.1 | send_not_optimized_method_type_optimized 7334 |
| `find_minimum_transition@tzinfo-2.0.6/lib/tzinfo/data_sources/transitions_data_timezone_info.rb` | send | 7334 | 0 | 7334 | 2.1 | one_or_more_complex_arg_pass 7334 |
| `associate_records_to_owner@activerecord-8.1.1/lib/active_record/associations/preloader/associat` | ivar | 6828 | 0 | 6828 | 0.7 | no_profile_missing_ic 6828 |
| `block in grouped_records@activerecord-8.1.1/lib/active_record/associations/preloader/branch.rb` | send | 7025 | 448 | 6577 | 1.9 | send_polymorphic_fallback 7025 |
| `polymorphic?@activerecord-8.1.1/lib/active_record/reflection.rb` | ivar | 6517 | 0 | 6517 | 0.7 | no_profile_missing_ic 6430, polymorphic 87 |
| `mon_synchronize@monitor.rb` | send | 6504 | 0 | 6504 | 1.9 | send_block_arg_not_nil 6504 |
| `stale_target?@activerecord-8.1.1/lib/active_record/associations/association.rb` | send | 6455 | 0 | 6455 | 1.8 | send_polymorphic 6353, send_polymorphic_fallback 102 |
| `hash@activerecord-8.1.1/lib/active_record/relation/query_attribute.rb` | ivar | 6342 | 0 | 6342 | 0.6 | no_profile_missing_ic 6342 |
| `deprecated_associations_api_guard@activerecord-8.1.1/lib/active_record/associations.rb` | ivar | 6255 | 0 | 6255 | 0.6 | no_profile_missing_ic 6255 |
| `downto@<internal:numeric>` | yield | 5940 | 0 | 5940 | 1.7 | invokeblock_not_specialized 5940 |
| `_app_views_layouts_application_html_erb@benchmarks/lobsters/app/views/layouts/application.html.` | ivar | 5665 | 0 | 5665 | 0.6 | no_side_exits 5612, no_side_exits 53 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | send | 5596 | 0 | 5596 | 1.6 | send_block_arg_not_nil 5596 |
| `value@activemodel-8.1.1/lib/active_model/attribute.rb` | ivar | 5086 | 0 | 5086 | 0.5 | no_profile_missing_ic 5086 |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb` | ivar | 6448 | 1630 | 4818 | 0.5 | no_profile_missing_ic 3342, no_side_exits 3014, no_side_exits 92 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | ivar | 4794 | 0 | 4794 | 0.5 | no_side_exits 4073, no_profile_missing_ic 721 |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb` | ivar | 4560 | 0 | 4560 | 0.5 | no_profile_missing_ic 4560 |
| `_value_for_database@activemodel-8.1.1/lib/active_model/attribute.rb` | ivar | 4445 | 0 | 4445 | 0.5 | no_profile_missing_ic 4445 |
| `period_for_utc@activesupport-8.1.1/lib/active_support/values/time_zone.rb` | ivar | 4370 | 0 | 4370 | 0.4 | no_profile_missing_ic 4370 |
| `visit@psych-5.2.6/lib/psych/visitors/visitor.rb` | send | 4347 | 0 | 4347 | 1.2 | send_not_optimized_method_type_optimized 4347 |
| `accept@psych-5.2.6/lib/psych/visitors/to_ruby.rb` | ivar | 4272 | 0 | 4272 | 0.4 | no_profile_missing_ic 4272 |
| `loop@<internal:kernel>` | yield | 4182 | 0 | 4182 | 1.2 | invokeblock_not_specialized 4182 |

