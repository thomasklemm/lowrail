### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 3274.2 | 3277.8 | 3303.1 | 3285.0 | 0.88% |
| YJIT | 3101.5 | 3103.1 | 3113.0 | 3105.9 | 0.37% |
| ZJIT − YJIT | | | | +179.1 (+5.77%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| method dispatch (generic send path) | 453.9 | 365.5 | **+88.4** | 49% | 0.4 |
| JIT code | 332.6 | 268.3 | **+64.4** | 36% | 0.2 |
| ivar and attr access (generic) | 79.1 | 40.2 | **+39.0** | 22% | 0.0 |
| block and proc invocation (generic) | 103.6 | 84.9 | **+18.7** | 10% | 0.0 |
| GC (marking, sweeping, freeing) | 61.0 | 52.2 | **+8.8** | 5% | 24.1 |
| other runtime (cfunc bodies, hash, string, regexp, ...) | 2047.1 | 2041.4 | **+5.7** | 3% | 2.6 |
| side exits and frame materialization | 5.3 | 0.4 | **+4.9** | 3% | 0.0 |
| invalidation | 0.2 | 0.0 | **+0.1** | 0% | 0.0 |
| write barriers | 16.6 | 20.3 | **-3.7** | -2% | 0.0 |
| compile (ZJIT/YJIT compiler, profiling) | 8.0 | 17.4 | **-9.4** | -5% | 1.6 |
| allocation (objects, malloc) | 157.6 | 174.9 | **-17.3** | -10% | 3.7 |
| interpreter (YARV loop and insn helpers) | 20.0 | 40.4 | **-20.4** | -11% | 0.0 |
| total | 3285.0 | 3105.9 | **+179.1** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `<JIT code>` | JIT code | 332.6 | 268.3 | +64.4 |
| `rb_vm_exec` | method dispatch | 71.7 | 40.5 | +31.3 |
| `rb_vm_opt_send_without_block` | method dispatch | 29.7 | 14.3 | +15.4 |
| `rb_shape_get_iv_index` | ivar and attr access | 19.8 | 5.6 | +14.2 |
| `vm_exec_core` | interpreter | 11.9 | 26.1 | -14.2 |
| `rb_ivar_lookup` | ivar and attr access | 19.7 | 6.2 | +13.5 |
| `setup_parameters_complex` | method dispatch | 22.8 | 9.8 | +13.0 |
| `vm_invoke_iseq_block` | block and proc invocation | 15.5 | 2.6 | +12.9 |
| `vm_call_iseq_setup` | method dispatch | 27.7 | 18.3 | +9.3 |
| `rb_vm_send` | method dispatch | 11.7 | 2.5 | +9.1 |
| `yjit_compile` | method dispatch | 0.0 | 7.8 | -7.8 |
| `rb_vm_getinstancevariable` | ivar and attr access | 7.6 | 0.0 | +7.6 |
| `rb_ec_stack_check` | method dispatch | 21.8 | 14.6 | +7.2 |
| `rb_vm_invokeblock` | block and proc invocation | 12.7 | 5.6 | +7.1 |
| `vm_callee_setup_arg` | method dispatch | 24.3 | 17.3 | +6.9 |
| `zjit_materialize_frames` | side exits and frame materialization | 5.3 | 0.0 | +5.2 |
| `rb_ec_newobj_of` | allocation | 14.1 | 19.3 | -5.2 |
| `vm_search_super_method` | method dispatch | 1.3 | 6.0 | -4.7 |
| `CALLER_SETUP_ARG` | method dispatch | 23.9 | 19.3 | +4.7 |
| `vm_lookup_cc` | method dispatch | 9.7 | 5.2 | +4.5 |
| `rb_vm_invokesuper` | method dispatch | 0.8 | 4.8 | -4.0 |
| `gc_mark` | GC | 12.6 | 8.7 | +3.9 |
| `rb_class_allocate_instance` | allocation | 2.6 | 6.5 | -3.9 |
| `rb_gc_writebarrier` | write barriers | 16.1 | 19.7 | -3.6 |
| `rb_shape_get_iv_index_with_hint` | ivar and attr access | 5.4 | 1.9 | +3.5 |
| `vm_search_method_slowpath0` | method dispatch | 7.8 | 4.4 | +3.4 |
| `rb_gc_mark_movable` | GC | 3.1 | 0.0 | +3.0 |
| `search_nonascii` | other runtime | 6.0 | 3.0 | +3.0 |
| `rb_newobj_of` | allocation | 14.5 | 17.4 | -2.9 |
| `vm_yield_with_cfunc` | block and proc invocation | 1.0 | 3.9 | -2.8 |
| `rb_str_concat` | other runtime | 2.8 | 0.0 | +2.8 |
| `<yjit::backend::ir::Assembler>::compile_with_regs` | compile | 0.0 | 2.8 | -2.8 |
| `rb_ec_ary_new_from_values` | allocation | 0.3 | 3.1 | -2.7 |
| `rb_str_buf_append` | other runtime | 3.5 | 0.8 | +2.7 |
| `rb_builtin_ary_at_end` | interpreter | 0.0 | 2.7 | -2.7 |
| `rb_managed_id_table_lookup` | method dispatch | 15.9 | 13.4 | +2.6 |
| `rb_ivar_get_at_no_ractor_check` | ivar and attr access | 0.2 | 2.7 | -2.5 |
| `RCLASS_EXT_WRITABLE` | method dispatch | 6.2 | 8.7 | -2.5 |
| `vm_call0_body` | method dispatch | 21.7 | 24.1 | -2.5 |
| `rb_funcallv_scope.constprop.0` | method dispatch | 12.9 | 15.2 | -2.3 |

### Unclassified (other runtime) differences above 0.5M
  +3.0 search_nonascii
  +2.8 rb_str_concat
  +2.7 rb_str_buf_append
  -1.9 ary_memcpy0
  -1.7 tbl_update.isra.0
  -1.5 rb_obj_is_kind_of
  +1.2 obj_field_set
  -1.0 rb_str_cat
  +0.9 rb_obj_shape_transition_add_ivar
  +0.9 str_modify_keep_cr
  +0.8 rb_string_value
  +0.8 ar_insert_direct.isra.0
  -0.7 rb_mod_eqq
  -0.7 rb_str_modify
  +0.7 rb_enc_from_index
  -0.7 rb_obj_as_string_result
  +0.7 rb_hash_bulk_insert.part.0
  +0.7 get_next_shape_internal

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `entry trampoline` | 17.3 | 0.0 | +17.3 |
| `<unmapped JIT>` | 1.7 | 14.8 | -13.1 |
| `each@<internal:array>` | 13.8 | 8.5 | +5.3 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | 2.5 | 5.0 | -2.5 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 7.5 | 5.0 | +2.4 |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 5.3 | 3.2 | +2.1 |
| `initialize@activesupport-8.1.1/lib/active_support/time_with_zone.rb` | 2.7 | 0.6 | +2.1 |
| `block in perform_query@activerecord-8.1.1/lib/active_record/connection_adapters/sqlite3/database_statements.rb` | 2.6 | 0.8 | +1.7 |
| `[]@activesupport-8.1.1/lib/active_support/isolated_execution_state.rb` | 0.1 | 1.7 | -1.6 |
| `<<@actionview-8.1.1/lib/action_view/buffers.rb` | 3.6 | 2.0 | +1.6 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | 3.0 | 1.5 | +1.5 |
| `for@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | 2.9 | 1.4 | +1.5 |
| `association@activerecord-8.1.1/lib/active_record/associations.rb` | 4.0 | 2.6 | +1.4 |
| `tag_option@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb` | 3.4 | 2.0 | +1.4 |
| `map@<internal:array>` | 4.5 | 3.2 | +1.4 |
| `change@activesupport-8.1.1/lib/active_support/core_ext/time/calculations.rb` | 2.7 | 1.4 | +1.2 |
| `_app_views_layouts_application_html_erb___4068411127899166254_14376@/home/user/w/rbc/lobsters-callgrind-zjit-a` | 1.2 | 0.0 | +1.2 |
| `blank?@activesupport-8.1.1/lib/active_support/core_ext/object/blank.rb` | 0.1 | 1.1 | -1.0 |
| `_app_views_comments__comment_html_erb__1568978641464934163_16232@/home/user/w/rbc/lobsters-callgrind-zjit-a-lo` | 1.0 | 0.0 | +1.0 |
| `query_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/query.rb` | 0.0 | 1.0 | -1.0 |
| `initialize@activerecord-8.1.1/lib/active_record/relation.rb` | 1.7 | 0.8 | +1.0 |
| `visit_Arel_Attributes_Attribute@activerecord-8.1.1/lib/arel/visitors/to_sql.rb` | 1.5 | 0.6 | +0.9 |
| `<<@activerecord-8.1.1/lib/arel/collectors/plain_string.rb` | 0.0 | 0.9 | -0.9 |
| `scalar@psych-5.2.6/lib/psych/tree_builder.rb` | 1.5 | 0.6 | +0.9 |
| `html_escape@activesupport-8.1.1/lib/active_support/core_ext/erb/util.rb` | 0.0 | 0.9 | -0.9 |
| `block in merge!@activerecord-typedstore-1.6.0/lib/active_record/typed_store/typed_hash.rb` | 1.4 | 0.5 | +0.9 |
| `for_time@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | 2.3 | 1.4 | +0.9 |
| `evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 0.0 | 0.9 | -0.9 |
| `fetch@concurrent-ruby-1.3.5/lib/concurrent-ruby/concurrent/map.rb` | 1.8 | 1.0 | +0.8 |
| `new!@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | 0.0 | 0.8 | -0.8 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 332.6)

     31.4   9.4% SendDirect
     29.0   8.7% PushInlineFrame
     21.8   6.6% CondBranchHasType
     21.7   6.5% CCallWithFrame
     20.7   6.2% GuardType
     17.6   5.3% CCallVariadic
     17.3   5.2% entry trampoline
     14.1   4.2% IsBitEqual
     14.0   4.2% PatchPoint
     12.2   3.7% CondBranch
     11.9   3.6% EntryPoint
     11.5   3.5% Return
     10.3   3.1% Test
     10.1   3.0% Send
      8.1   2.4% HashAref
      7.7   2.3% LoadField
      6.6   2.0% Jump
      5.9   1.8% CheckInterrupts
      5.5   1.6% GetIvar
      3.9   1.2% PopInlineFrame
      3.6   1.1% WriteBarrier
      3.5   1.1% ArrayLength
      3.5   1.0% GuardBitEquals
      2.4   0.7% InvokeBlock
      2.3   0.7% GetEP

### JIT code by YJIT codegen symbol (run b, M per iteration; total 268.3)

     35.8  13.3% gen_send_general: jit_guard_known_klass
     32.1  12.0% gen_send_iseq: gen_push_frame
     26.5   9.9% opt_send_without_block
     21.8   8.1% leave
     21.2   7.9% gen_send_iseq
     19.2   7.2% <unmapped JIT>
     12.1   4.5% getinstancevariable
     10.5   3.9% gen_send_cfunc: gen_push_frame
      9.2   3.4% opt_aref
      7.4   2.7% gen_send_cfunc
      6.5   2.4% gen_send_cfunc: known_cfunc_codegen
      6.3   2.3% getlocal_WC_0
      5.7   2.1% setinstancevariable
      5.0   1.8% opt_invokebuiltin_delegate
      4.2   1.6% gen_send_dynamic
      4.0   1.5% setlocal_WC_0
      3.7   1.4% send
      3.3   1.2% invokeblock
      3.2   1.2% gen_send_general
      2.5   1.0% putself
      2.4   0.9% branchunless
      1.9   0.7% invokesuper
      1.9   0.7% branchif
      1.9   0.7% getlocal_WC_1
      1.8   0.7% opt_getconstant_path

### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `<JIT code>` | 1974222 | 0 | 1974222 | 221431.8 | 0.0 |
| `rb_ivar_get` | 352075 | 96514 | 255560 | 48.5 | 14.9 |
| `rb_builtin_ary_at_end` | 0 | 238168 | -238168 | 0.0 | 2.6 |
| `rb_ivar_get_at_no_ractor_check` | 17276 | 226994 | -209718 | 1.9 | 12.7 |
| `rb_gc_writebarrier` | 4596 | 209293 | -204697 | 0.2 | 6.1 |
| `rb_vm_opt_send_without_block` | 402691 | 200393 | 202298 | 6428.4 | 8182.7 |
| `rb_builtin_ary_at` | 0 | 177715 | -177715 | 0.0 | 1.1 |
| `rb_builtin_fixnum_inc` | 0 | 169766 | -169766 | 0.0 | 0.5 |
| `rb_vm_getinstancevariable` | 125021 | 0 | 125021 | 14.3 | 0.0 |
| `rb_vm_send` | 140579 | 31170 | 109409 | 17848.0 | 8004.1 |
| `rb_vm_invokeblock` | 166482 | 72725 | 93756 | 20124.4 | 9588.6 |
| `builtin_inline_class_20` | 0 | 77798 | -77798 | 0.0 | 0.8 |
| `rb_yarv_ary_entry_internal` | 0 | 72098 | -72098 | 0.0 | 1.2 |
| `rb_obj_alloc` | 13720 | 79788 | -66068 | 8.4 | 12.7 |
| `rb_obj_as_string_result` | 0 | 63290 | -63290 | 0.0 | 0.7 |
| `rb_ec_ary_new_from_values` | 5527 | 65346 | -59819 | 2.0 | 18.0 |
| `rb_str_concat` | 58701 | 0 | 58701 | 25.8 | 0.0 |
| `rb_get_symbol_id` | 0 | 57280 | -57280 | 0.0 | 0.7 |
| `rb_jit_str_simple_append` | 28664 | 85819 | -57155 | 4.6 | 20.5 |
| `rb_obj_is_kind_of` | 141440 | 193744 | -52304 | 5.8 | 8.5 |
| `rb_vm_invokesuper` | 7858 | 53087 | -45229 | 20525.7 | 3660.3 |
| `rb_obj_equal` | 0 | 40917 | -40917 | 0.0 | 0.2 |
| `rb_vm_yield_with_cfunc` | 38003 | 3368 | 34635 | 3830.6 | 204.8 |
| `rb_vm_setinstancevariable` | 11423 | 40844 | -29421 | 4.8 | 8.3 |
| `rb_hash_new` | 2735 | 26086 | -23351 | 0.3 | 2.3 |
| `rb_obj_not_equal` | 0 | 23080 | -23080 | 0.0 | 8.2 |
| `erb_escape_html` | 22774 | 0 | 22774 | 5.8 | 0.0 |
| `rb_ivar_set` | 20428 | 0 | 20428 | 6.0 | 0.0 |
| `rb_zjit_defined_ivar` | 17718 | 0 | 17718 | 1.8 | 0.0 |
| `rb_vm_env_write` | 18794 | 2176 | 16618 | 0.2 | 0.1 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | `rb_ivar_get` | 42063 | 0 | 42063 |
| `each@<internal:array>` | `rb_vm_invokeblock` | 87329 | 50633 | 36696 |
| `map@<internal:array>` | `rb_vm_invokeblock` | 39410 | 5657 | 33753 |
| `hash@activemodel-8.1.1/lib/active_model/attribute.rb` | `rb_ivar_get` | 27717 | 0 | 27717 |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb` | `rb_vm_opt_send_without_block` | 43560 | 18478 | 25082 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | `rb_vm_send` | 20696 | 0 | 20696 |
| `association@activerecord-8.1.1/lib/active_record/associations.rb` | `rb_vm_opt_send_without_block` | 18698 | 1233 | 17465 |
| `stale_state@activerecord-8.1.1/lib/active_record/associations/belongs_to_association.rb` | `rb_ivar_get` | 17024 | 0 | 17024 |
| `scalar@psych-5.2.6/lib/psych/tree_builder.rb` | `rb_ivar_set` | 15928 | 0 | 15928 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | `rb_vm_getinstancevariable` | 14763 | 0 | 14763 |
| `association@activerecord-8.1.1/lib/active_record/associations.rb` | `rb_hash_aref` | 12575 | 0 | 12575 |
| `associate_records_to_owner@activerecord-8.1.1/lib/active_record/associations/preloader/association.r` | `rb_ivar_get` | 12322 | 0 | 12322 |
| `build_arel@activerecord-8.1.1/lib/active_record/relation/query_methods.rb` | `rb_vm_opt_send_without_block` | 13876 | 2338 | 11538 |
| `cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | `rb_ivar_get` | 11214 | 0 | 11214 |
| `association@activerecord-8.1.1/lib/active_record/associations.rb` | `rb_vm_getinstancevariable` | 11131 | 0 | 11131 |
| `association_instance_get@activerecord-8.1.1/lib/active_record/associations.rb` | `rb_vm_getinstancevariable` | 10707 | 0 | 10707 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | `rb_vm_opt_send_without_block` | 9543 | 0 | 9543 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | `rb_ivar_get` | 9310 | 0 | 9310 |
| `association_primary_key@activerecord-8.1.1/lib/active_record/reflection.rb` | `rb_ivar_get` | 9058 | 0 | 9058 |
| `visit_Arel_Attributes_Attribute@activerecord-8.1.1/lib/arel/visitors/to_sql.rb` | `rb_ivar_get` | 8696 | 0 | 8696 |
| `retrieve_connection_pool@activerecord-8.1.1/lib/active_record/connection_adapters/abstract/connectio` | `rb_hash_aref` | 8250 | 0 | 8250 |
| `<<@activerecord-8.1.1/lib/arel/collectors/composite.rb` | `rb_ivar_get` | 7912 | 0 | 7912 |
| `_app_views_comments__comment_html_erb__1568978641464934163_16232@/home/user/w/rbc/lobsters-callgrind` | `rb_vm_getinstancevariable` | 7886 | 0 | 7886 |
| `cast@activemodel-8.1.1/lib/active_model/type/helpers/numeric.rb` | `rb_vm_opt_send_without_block` | 7785 | 0 | 7785 |
| `hash@activerecord-8.1.1/lib/active_record/relation/query_attribute.rb` | `rb_ivar_get` | 7664 | 0 | 7664 |
| `set_inverse@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | `rb_ivar_get` | 7639 | 0 | 7639 |
| `type_cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | `rb_ivar_get` | 7476 | 0 | 7476 |
| `for_time@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | `rb_vm_opt_send_without_block` | 7334 | 0 | 7334 |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | `rb_vm_opt_send_without_block` | 7419 | 623 | 6796 |
| `_value_for_database@activemodel-8.1.1/lib/active_model/attribute.rb` | `rb_ivar_get` | 6660 | 0 | 6660 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | `rb_vm_opt_send_without_block` | 6628 | 0 | 6628 |
| `block in grouped_records@activerecord-8.1.1/lib/active_record/associations/preloader/branch.rb` | `rb_vm_opt_send_without_block` | 7025 | 448 | 6577 |
| `downto@<internal:numeric>` | `rb_vm_invokeblock` | 5939 | 0 | 5939 |
| `instance@activerecord-8.1.1/lib/active_record/scoping.rb` | `rb_hash_aref` | 5826 | 0 | 5826 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 8622 | 2874 | 5748 |
| `attribute_types@activemodel-8.1.1/lib/active_model/attribute_registration.rb` | `rb_vm_getinstancevariable` | 5617 | 0 | 5617 |
| `_app_views_layouts_application_html_erb___4068411127899166254_14376@/home/user/w/rbc/lobsters-callgr` | `rb_vm_getinstancevariable` | 5612 | 0 | 5612 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | `rb_vm_send` | 5596 | 0 | 5596 |
| `connected_to_stack@activerecord-8.1.1/lib/active_record/core.rb` | `rb_hash_aref` | 5522 | 0 | 5522 |
| `block (3 levels) in populate_keys_to_load_and_already_loaded_records@activerecord-8.1.1/lib/active_r` | `rb_ivar_get` | 5504 | 0 | 5504 |

