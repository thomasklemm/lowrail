### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 3971.8 | 4049.9 | 3971.7 | 3997.8 | 1.96% |
| YJIT | 3383.5 | 3371.8 | 3381.9 | 3379.1 | 0.35% |
| ZJIT − YJIT | | | | +618.7 (+18.31%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| method dispatch (generic send path) | 995.7 | 701.3 | **+294.5** | 48% | 1.8 |
| JIT code | 702.4 | 573.4 | **+128.9** | 21% | 0.3 |
| ivar and attr access (generic) | 189.0 | 80.9 | **+108.1** | 17% | 0.0 |
| GC (marking, sweeping, freeing) | 297.5 | 220.8 | **+76.7** | 12% | 70.6 |
| block and proc invocation (generic) | 234.8 | 196.5 | **+38.3** | 6% | 0.0 |
| side exits and frame materialization | 13.3 | 0.2 | **+13.1** | 2% | 0.0 |
| compile (ZJIT/YJIT compiler, profiling) | 4.5 | 2.0 | **+2.5** | 0% | 2.2 |
| invalidation | 0.1 | 0.0 | **+0.0** | 0% | 0.0 |
| interpreter (YARV loop and insn helpers) | 44.5 | 45.5 | **-1.0** | -0% | 0.0 |
| write barriers | 36.6 | 41.3 | **-4.8** | -1% | 0.2 |
| other runtime (cfunc bodies, hash, string, regexp, ...) | 1286.3 | 1296.6 | **-10.3** | -2% | 6.6 |
| allocation (objects, malloc) | 193.3 | 220.5 | **-27.2** | -4% | 1.5 |
| total | 3997.8 | 3379.1 | **+618.7** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `<JIT code>` | JIT code | 702.4 | 573.4 | +128.9 |
| `rb_vm_exec` | method dispatch | 160.0 | 76.7 | +83.3 |
| `rb_vm_opt_send_without_block` | method dispatch | 67.1 | 24.4 | +42.6 |
| `rb_ivar_lookup` | ivar and attr access | 55.9 | 15.3 | +40.6 |
| `rb_shape_get_iv_index` | ivar and attr access | 50.1 | 14.3 | +35.8 |
| `gc_mark` | GC | 92.0 | 57.6 | +34.3 |
| `setup_parameters_complex` | method dispatch | 47.7 | 16.2 | +31.5 |
| `vm_invoke_iseq_block` | block and proc invocation | 37.5 | 6.5 | +31.0 |
| `vm_call_iseq_setup` | method dispatch | 54.3 | 31.7 | +22.6 |
| `rb_gc_mark_movable` | GC | 24.7 | 5.3 | +19.4 |
| `rb_ec_stack_check` | method dispatch | 48.0 | 29.5 | +18.6 |
| `vm_lookup_cc` | method dispatch | 28.9 | 10.8 | +18.1 |
| `rb_vm_send` | method dispatch | 22.4 | 5.3 | +17.1 |
| `vm_callee_setup_arg` | method dispatch | 46.6 | 29.7 | +17.0 |
| `rb_vm_getinstancevariable` | ivar and attr access | 16.1 | 0.0 | +16.1 |
| `vm_search_method_slowpath0` | method dispatch | 22.3 | 8.4 | +13.9 |
| `rb_vm_invokeblock` | block and proc invocation | 30.3 | 17.0 | +13.3 |
| `zjit_materialize_frames` | side exits and frame materialization | 13.2 | 0.0 | +13.1 |
| `yjit_compile` | method dispatch | 0.0 | 13.0 | -13.0 |
| `vm_exec_core` | interpreter | 31.6 | 19.4 | +12.3 |
| `CALLER_SETUP_ARG` | method dispatch | 53.4 | 41.8 | +11.6 |
| `vm_yield_with_cfunc` | block and proc invocation | 2.9 | 14.0 | -11.1 |
| `vm_call_iseq_setup_normal_0start_0params_0locals` | method dispatch | 15.4 | 4.9 | +10.6 |
| `rb_managed_id_table_lookup` | method dispatch | 38.7 | 28.2 | +10.4 |
| `rb_shape_get_iv_index_with_hint` | ivar and attr access | 11.4 | 1.6 | +9.9 |
| `vm_call0_body` | method dispatch | 36.2 | 45.9 | -9.7 |
| `gc_marks_rest` | GC | 12.0 | 3.0 | +9.0 |
| `rb_funcallv_scope.constprop.0` | method dispatch | 21.5 | 30.3 | -8.8 |
| `rb_ec_newobj_of` | allocation | 14.4 | 22.8 | -8.4 |
| `RCLASS_EXT_WRITABLE` | method dispatch | 17.4 | 25.4 | -8.0 |
| `rb_ivar_get_at_no_ractor_check` | ivar and attr access | 0.1 | 8.0 | -7.9 |
| `rb_builtin_ary_at_end` | interpreter | 0.0 | 7.3 | -7.3 |
| `rb_class_allocate_instance` | allocation | 6.0 | 13.2 | -7.2 |
| `rb_vm_yield_with_cfunc` | block and proc invocation | 7.3 | 0.2 | +7.2 |
| `vm_call_method_each_type` | method dispatch | 10.3 | 4.0 | +6.3 |
| `gc_continue` | GC | 6.2 | 12.3 | -6.1 |
| `vm_call_ivar` | ivar and attr access | 8.8 | 2.7 | +6.1 |
| `rb_ec_ary_new_from_values` | allocation | 0.8 | 6.5 | -5.7 |
| `vm_call0_cc` | method dispatch | 25.3 | 31.0 | -5.7 |
| `vm_caller_setup_arg_block.constprop.0` | block and proc invocation | 10.2 | 4.7 | +5.5 |

### Unclassified (other runtime) differences above 0.5M
  -3.6 ary_memcpy0
  -2.0 rb_obj_is_kind_of
  +1.8 VM_CF_BLOCK_HANDLER.isra.0
  -1.6 rb_obj_not_equal
  -1.6 rb_struct_initialize_m
  -1.3 tbl_update.isra.0
  -1.1 rb_sym2str
  -1.0 rb_get_symbol_id
  +1.0 push_mark_stack
  -0.8 rb_is_instance_id
  -0.7 rb_obj_equal
  +0.7 RVALUE_PAGE_OLD_UNCOLLECTIBLE_SET.constprop.0
  +0.7 rb_id2sym
  +0.7 rb_check_id
  -0.7 rb_get_alloc_func
  +0.7 ar_insert_direct.isra.0
  -0.6 __memset_avx2_unaligned_erms
  +0.6 __memcpy_avx_unaligned_erms
  +0.6 rb_hash_bulk_insert.part.0
  -0.6 onig_search_gpos
  +0.6 obj_field_set
  -0.5 rb_current_ec
  +0.5 rb_ary_push

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `entry trampoline` | 40.1 | 0.0 | +40.1 |
| `<unmapped JIT>` | 1.8 | 29.7 | -28.0 |
| `each@<internal:array>` | 43.3 | 27.1 | +16.2 |
| `[]@activesupport-8.1.2/lib/active_support/isolated_execution_state.rb` | 0.3 | 6.8 | -6.5 |
| `block in perform_query@activerecord-8.1.2/lib/active_record/connection_adapters/sqlite3/database_statements.rb` | 7.7 | 2.5 | +5.2 |
| `with_connection@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool.rb` | 8.4 | 3.4 | +5.0 |
| `<<@activerecord-8.1.2/lib/arel/collectors/composite.rb` | 0.0 | 4.7 | -4.7 |
| `visit_Arel_Attributes_Attribute@activerecord-8.1.2/lib/arel/visitors/to_sql.rb` | 6.7 | 2.2 | +4.5 |
| `attribute_types@activemodel-8.1.2/lib/active_model/attribute_registration.rb` | 10.0 | 5.6 | +4.4 |
| `block in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb` | 13.8 | 9.8 | +4.1 |
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb` | 1.9 | 5.8 | -3.9 |
| `retrieve_connection_pool@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_handler.` | 6.4 | 2.9 | +3.5 |
| `block in merge@activerecord-8.1.2/lib/active_record/relation/merger.rb` | 10.1 | 6.9 | +3.2 |
| `connection_lease@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool.rb` | 0.0 | 3.1 | -3.1 |
| `block in fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb` | 8.9 | 5.9 | +3.0 |
| `build@activerecord-8.1.2/lib/active_record/relation/predicate_builder.rb` | 3.7 | 0.8 | +3.0 |
| `block in column_types@activerecord-8.1.2/lib/active_record/result.rb` | 8.2 | 5.4 | +2.8 |
| `klass@activerecord-8.1.2/lib/active_record/associations/association.rb` | 1.4 | 4.2 | -2.8 |
| `merge@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | 6.2 | 3.5 | +2.8 |
| `map@<internal:array>` | 9.6 | 6.9 | +2.7 |
| `build_handle@activesupport-8.1.2/lib/active_support/notifications/fanout.rb` | 3.7 | 1.0 | +2.7 |
| `fetch@concurrent-ruby-1.3.6/lib/concurrent-ruby/concurrent/map.rb` | 5.6 | 3.0 | +2.6 |
| `initialize@activerecord-8.1.2/lib/active_record/relation.rb` | 6.7 | 4.1 | +2.6 |
| `<<@activerecord-8.1.2/lib/arel/collectors/plain_string.rb` | 0.1 | 2.7 | -2.6 |
| `block in poll@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb` | 3.2 | 0.6 | +2.6 |
| `connection_pool@activerecord-8.1.2/lib/active_record/connection_handling.rb` | 1.0 | 3.5 | -2.5 |
| `create@activerecord-8.1.2/lib/active_record/relation/delegation.rb` | 4.0 | 1.5 | +2.5 |
| `connected_to_stack@activerecord-8.1.2/lib/active_record/core.rb` | 4.1 | 1.8 | +2.3 |
| `!=@<internal:basic_object>` | 2.3 | 0.0 | +2.3 |
| `type_map@activerecord-8.1.2/lib/active_record/connection_adapters/abstract_adapter.rb` | 0.0 | 2.2 | -2.2 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 702.4)

     67.1   9.6% PushInlineFrame
     59.1   8.4% SendDirect
     56.6   8.1% CondBranchHasType
     40.6   5.8% GuardType
     40.1   5.7% entry trampoline
     35.4   5.0% IsBitEqual
     33.2   4.7% CCallWithFrame
     31.5   4.5% CCallVariadic
     27.9   4.0% PatchPoint
     27.6   3.9% CondBranch
     25.5   3.6% EntryPoint
     24.8   3.5% Return
     20.8   3.0% Send
     20.2   2.9% Test
     17.2   2.4% LoadField
     15.6   2.2% HashAref
     14.6   2.1% Jump
     12.8   1.8% GetIvar
     12.7   1.8% CheckInterrupts
      9.6   1.4% ArrayLength
      9.0   1.3% PopInlineFrame
      8.0   1.1% WriteBarrier
      7.6   1.1% GuardBitEquals
      6.7   1.0% HashAset
      6.5   0.9% ArrayAref

### JIT code by YJIT codegen symbol (run b, M per iteration; total 573.3)

     75.4  13.1% gen_send_iseq: gen_push_frame
     75.3  13.1% gen_send_general: jit_guard_known_klass
     58.3  10.2% opt_send_without_block
     49.3   8.6% gen_send_iseq
     49.2   8.6% leave
     39.9   7.0% <unmapped JIT>
     29.7   5.2% getinstancevariable
     20.2   3.5% gen_send_cfunc: gen_push_frame
     19.8   3.5% opt_aref
     13.9   2.4% gen_send_cfunc
     13.5   2.4% opt_invokebuiltin_delegate
     11.2   1.9% getlocal_WC_0
     11.0   1.9% setinstancevariable
      9.6   1.7% gen_send_cfunc: known_cfunc_codegen
      8.3   1.4% gen_send_dynamic
      8.2   1.4% setlocal_WC_0
      8.2   1.4% send
      8.0   1.4% invokeblock
      6.8   1.2% gen_send_general
      5.8   1.0% putself
      4.4   0.8% opt_aset
      4.2   0.7% branchunless
      3.8   0.7% branchif
      3.5   0.6% getlocal_WC_1
      3.4   0.6% opt_getconstant_path

### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `<JIT code>` | 4243493 | 0 | 4243493 | 352009.5 | 0.0 |
| `rb_ivar_get` | 997017 | 196802 | 800215 | 131.0 | 33.9 |
| `rb_builtin_ary_at_end` | 0 | 659429 | -659429 | 0.0 | 7.3 |
| `rb_ivar_get_at_no_ractor_check` | 10409 | 667781 | -657372 | 1.4 | 35.2 |
| `rb_vm_opt_send_without_block` | 917049 | 341778 | 575271 | 34026.5 | 14519.7 |
| `rb_builtin_ary_at` | 0 | 495532 | -495532 | 0.0 | 3.0 |
| `rb_builtin_fixnum_inc` | 0 | 486188 | -486188 | 0.0 | 1.5 |
| `rb_gc_writebarrier` | 47787 | 477044 | -429257 | 2.0 | 14.9 |
| `rb_vm_getinstancevariable` | 247987 | 0 | 247987 | 27.7 | 0.0 |
| `builtin_inline_class_20` | 0 | 220540 | -220540 | 0.0 | 2.2 |
| `rb_vm_send` | 267623 | 65025 | 202598 | 25820.0 | 3781.7 |
| `rb_get_symbol_id` | 0 | 196645 | -196645 | 0.0 | 2.7 |
| `rb_vm_invokeblock` | 399560 | 225355 | 174205 | 39660.7 | 14366.6 |
| `rb_yarv_ary_entry_internal` | 0 | 171925 | -171925 | 0.0 | 2.7 |
| `rb_obj_alloc` | 27523 | 164246 | -136723 | 8.1 | 64.4 |
| `rb_vm_yield_with_cfunc` | 138794 | 2966 | 135828 | 7805.4 | 220.8 |
| `rb_ec_ary_new_from_values` | 15874 | 140417 | -124544 | 18.1 | 51.9 |
| `rb_obj_is_kind_of` | 180334 | 275526 | -95192 | 7.5 | 10.9 |
| `rb_obj_not_equal` | 0 | 90250 | -90250 | 0.0 | 31.0 |
| `rb_obj_equal` | 0 | 49438 | -49438 | 0.0 | 0.2 |
| `rb_hash_new` | 10244 | 59457 | -49213 | 10.7 | 17.9 |
| `__memcpy_avx_unaligned_erms` | 931961 | 891053 | 40908 | 13.7 | 13.3 |
| `rb_obj_as_string_result` | 0 | 39877 | -39877 | 0.0 | 0.4 |
| `rb_zjit_materialize_frames` | 39833 | 0 | 39833 | 9.7 | 0.0 |
| `rb_vm_env_write` | 37420 | 1376 | 36044 | 0.4 | 0.1 |
| `rb_zjit_defined_ivar` | 32755 | 0 | 32755 | 2.7 | 0.0 |
| `rb_vm_invokesuper` | 14343 | 40059 | -25716 | 38381.7 | 6735.1 |
| `rb_int_equal` | 21431 | 0 | 21431 | 1.2 | 0.0 |
| `rb_yarv_str_eql_internal` | 31873 | 10879 | 20994 | 1.3 | 0.2 |
| `rb_obj_dummy0` | 0 | 19552 | -19552 | 0.0 | 0.0 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `attribute_types@activemodel-8.1.2/lib/active_model/attribute_registration.rb` | `rb_vm_getinstancevariable` | 115960 | 0 | 115960 |
| `block in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb` | `rb_vm_opt_send_without_block` | 114270 | 660 | 113610 |
| `each@<internal:array>` | `rb_vm_invokeblock` | 259465 | 183112 | 76354 |
| `block in fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb` | `rb_ivar_get` | 74636 | 0 | 74636 |
| `map@<internal:array>` | `rb_vm_invokeblock` | 79649 | 10531 | 69118 |
| `hash@activemodel-8.1.2/lib/active_model/type/value.rb` | `rb_vm_opt_send_without_block` | 67904 | 0 | 67904 |
| `retrieve_connection_pool@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connectio` | `rb_hash_aref` | 53724 | 0 | 53724 |
| `visit_Arel_Attributes_Attribute@activerecord-8.1.2/lib/arel/visitors/to_sql.rb` | `rb_ivar_get` | 52002 | 0 | 52002 |
| `hash@activemodel-8.1.2/lib/active_model/attribute.rb` | `rb_ivar_get` | 48408 | 0 | 48408 |
| `==@activemodel-8.1.2/lib/active_model/attribute.rb` | `rb_ivar_get` | 39438 | 0 | 39438 |
| `==@activemodel-8.1.2/lib/active_model/type/value.rb` | `rb_ivar_get` | 39438 | 0 | 39438 |
| `connected_to_stack@activerecord-8.1.2/lib/active_record/core.rb` | `rb_ivar_get` | 35816 | 0 | 35816 |
| `connected_to_stack@activerecord-8.1.2/lib/active_record/core.rb` | `rb_hash_aref` | 35816 | 0 | 35816 |
| `build@activerecord-8.1.2/lib/active_record/relation/predicate_builder.rb` | `rb_ivar_get` | 33336 | 0 | 33336 |
| `stale_state@activerecord-8.1.2/lib/active_record/associations/belongs_to_association.rb` | `rb_ivar_get` | 32848 | 0 | 32848 |
| `hash@activemodel-8.1.2/lib/active_model/type/value.rb` | `rb_ivar_get` | 31731 | 0 | 31731 |
| `hash@activerecord-8.1.2/lib/active_record/relation/query_attribute.rb` | `rb_ivar_get` | 29102 | 0 | 29102 |
| `association@activerecord-8.1.2/lib/active_record/associations.rb` | `rb_vm_opt_send_without_block` | 31735 | 3594 | 28141 |
| `value_for@activerecord-8.1.2/lib/active_record/scoping.rb` | `rb_vm_opt_send_without_block` | 31704 | 3852 | 27852 |
| `instance@activerecord-8.1.2/lib/active_record/scoping.rb` | `rb_ivar_get` | 27307 | 0 | 27307 |
| `instance@activerecord-8.1.2/lib/active_record/scoping.rb` | `rb_hash_aref` | 27307 | 0 | 27307 |
| `mon_synchronize@monitor.rb` | `rb_vm_send` | 23186 | 0 | 23186 |
| `empty?@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | `rb_ivar_get` | 22052 | 0 | 22052 |
| `value_for@activerecord-8.1.2/lib/active_record/scoping.rb` | `rb_hash_aref` | 22420 | 676 | 21744 |
| `current_role@activerecord-8.1.2/lib/active_record/core.rb` | `rb_vm_opt_send_without_block` | 35274 | 14594 | 20680 |
| `current_shard@activerecord-8.1.2/lib/active_record/core.rb` | `rb_vm_opt_send_without_block` | 35274 | 14594 | 20680 |
| `!=@<internal:basic_object>` | `rb_vm_opt_send_without_block` | 18776 | 0 | 18776 |
| `merge@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | `rb_vm_opt_send_without_block` | 18306 | 0 | 18306 |
| `merge@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | `rb_ivar_get` | 18306 | 0 | 18306 |
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb` | `rb_vm_send` | 18013 | 0 | 18013 |
| `merge_clauses@activerecord-8.1.2/lib/active_record/relation/merger.rb` | `rb_vm_opt_send_without_block` | 17479 | 1550 | 15929 |
| `except_predicates@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | `rb_ivar_get` | 14163 | 0 | 14163 |
| `klass@activerecord-8.1.2/lib/active_record/associations/association.rb` | `rb_ivar_get` | 14158 | 0 | 14158 |
| `initialize@activerecord-8.1.2/lib/active_record/relation.rb` | `rb_vm_opt_send_without_block` | 14376 | 738 | 13638 |
| `create@activerecord-8.1.2/lib/active_record/relation/delegation.rb` | `rb_vm_opt_send_without_block` | 13081 | 0 | 13081 |
| `iterate_guarding_exceptions@activesupport-8.1.2/lib/active_support/notifications/fanout.rb` | `rb_vm_send` | 13081 | 0 | 13081 |
| `merge_multi_values@activerecord-8.1.2/lib/active_record/relation/merger.rb` | `rb_vm_opt_send_without_block` | 14023 | 961 | 13062 |
| `set_strict_loading@activerecord-8.1.2/lib/active_record/associations/association.rb` | `rb_ivar_get` | 12669 | 0 | 12669 |
| `violates_strict_loading?@activerecord-8.1.2/lib/active_record/associations/association.rb` | `rb_ivar_get` | 12656 | 0 | 12656 |
| `primary_key@activerecord-8.1.2/lib/active_record/attribute_methods/primary_key.rb` | `rb_vm_getinstancevariable` | 12464 | 0 | 12464 |

