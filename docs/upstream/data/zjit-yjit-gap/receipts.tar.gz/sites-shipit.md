Price per extra operation: send/yield 350 Ir (372.8 M over 1066608 calls), ivar 119 Ir (108.1 M over 909132 reads)

#### Extra generic operations by ZJIT reason (ZJIT fallbacks not matched by a YJIT generic call at the same ISEQ; per iteration)

| reason | ZJIT count | extra vs YJIT | est. M Ir |
|---|---:|---:|---:|
| `getivar_fallback_no_profile_missing_ic` | 836857 | 705796 | 83.9 |
| `send_fallback_send_polymorphic_fallback` | 682001 | 515361 | 180.1 |
| `getivar_fallback_no_side_exits` | 410796 | 201840 | 24.0 |
| `send_fallback_send_block_arg_not_nil` | 201311 | 188838 | 66.0 |
| `send_fallback_invokeblock_polymorphic_miss` | 379587 | 160824 | 56.2 |
| `send_fallback_send_not_optimized_method_type_optimized` | 70380 | 40851 | 14.3 |
| `exit_patchpoint_stable_constant_names` | 38498 | 38498 | – |
| `send_fallback_one_or_more_complex_arg_pass` | 82761 | 37474 | 13.1 |
| `send_fallback_send_not_optimized_need_permission` | 30469 | 30462 | 10.6 |
| `send_fallback_send_megamorphic` | 80978 | 28487 | 10.0 |
| `send_fallback_send_polymorphic` | 30432 | 28252 | 9.9 |
| `send_fallback_invokeblock_not_specialized` | 19944 | 13501 | 4.7 |
| `send_fallback_sendforward_not_specialized` | 100847 | 12039 | 4.2 |
| `send_fallback_super_complex_args_pass` | 7317 | 4275 | 1.5 |
| `send_fallback_super_call_with_block` | 1850 | 1761 | 0.6 |
| `send_fallback_super_polymorphic` | 1682 | 1672 | 0.6 |
| `getivar_fallback_polymorphic` | 1433 | 1433 | 0.2 |
| `exit_guard_type_failure` | 1264 | 1264 | – |
| `send_fallback_send_not_optimized_method_type` | 9304 | 992 | 0.3 |
| `send_fallback_invokesuperforward_not_specialized` | 6736 | 857 | 0.3 |
| `send_fallback_super_from_block` | 2717 | 722 | 0.3 |
| `send_fallback_singleton_class_seen` | 216 | 196 | 0.1 |
| `setivar_fallback_no_side_exits` | 226 | 62 | 0.0 |
| `exit_unhandled_block_arg` | 57 | 57 | – |
| `send_fallback_send_no_profiles` | 57 | 30 | 0.0 |
| `send_fallback_super_not_optimized_method_type` | 777 | 15 | 0.0 |
| `exit_interrupt` | 2 | 2 | – |
| `exit_guard_shape_failure` | 1 | 1 | – |
| `setivar_fallback_not_t_object` | 7566 | 1 | 0.0 |

#### Top sites (per iteration)

| ISEQ | kind | ZJIT fallbacks | YJIT generic calls | extra | est. M Ir | ZJIT reasons |
|---|---|---:|---:|---:|---:|---|
| `block in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb` | send | 114270 | 660 | 113610 | 39.7 | send_polymorphic_fallback 114270 |
| `<<@activerecord-8.1.2/lib/arel/collectors/composite.rb` | ivar | 105476 | 0 | 105476 | 12.5 | no_profile_missing_ic 105476 |
| `each@<internal:array>` | yield | 259463 | 183112 | 76351 | 26.7 | invokeblock_polymorphic_miss 259463 |
| `block in fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb` | ivar | 74310 | 0 | 74310 | 8.8 | no_side_exits 74310 |
| `map@<internal:array>` | yield | 79649 | 10531 | 69118 | 24.2 | invokeblock_polymorphic_miss 79649 |
| `hash@activemodel-8.1.2/lib/active_model/type/value.rb` | send | 67904 | 0 | 67904 | 23.7 | send_polymorphic_fallback 67904 |
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb` | send | 67565 | 0 | 67565 | 23.6 | send_block_arg_not_nil 67565 |
| `klass@activerecord-8.1.2/lib/active_record/associations/association.rb` | ivar | 64455 | 0 | 64455 | 7.7 | no_profile_missing_ic 64455 |
| `hash@activemodel-8.1.2/lib/active_model/attribute.rb` | ivar | 48408 | 0 | 48408 | 5.8 | no_profile_missing_ic 48408 |
| `==@activemodel-8.1.2/lib/active_model/type/value.rb` | ivar | 39438 | 0 | 39438 | 4.7 | no_profile_missing_ic 39438 |
| `==@activemodel-8.1.2/lib/active_model/attribute.rb` | ivar | 39438 | 0 | 39438 | 4.7 | no_profile_missing_ic 39438 |
| `connection_specification_name@activerecord-8.1.2/lib/active_record/connection_handling.rb` | exit | 38466 | 0 | 38466 | – | exit_patchpoint_stable_constant_names 38466 |
| `mon_synchronize@monitor.rb` | send | 35341 | 0 | 35341 | 12.4 | send_block_arg_not_nil 35341 |
| `stale_state@activerecord-8.1.2/lib/active_record/associations/belongs_to_association.rb` | ivar | 32848 | 0 | 32848 | 3.9 | no_side_exits 32848 |
| `hash@activemodel-8.1.2/lib/active_model/type/value.rb` | ivar | 31731 | 0 | 31731 | 3.8 | no_profile_missing_ic 31731 |
| `association@activerecord-8.1.2/lib/active_record/associations.rb` | send | 31735 | 3594 | 28141 | 9.8 | send_megamorphic 24328, send_polymorphic_fallback 7407 |
| `value_for@activerecord-8.1.2/lib/active_record/scoping.rb` | send | 31704 | 3852 | 27852 | 9.7 | send_polymorphic 17942, send_polymorphic_fallback 13762 |
| `synchronize@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool/q` | send | 23172 | 0 | 23172 | 8.1 | send_block_arg_not_nil 23172 |
| `hash@activerecord-8.1.2/lib/active_record/relation/query_attribute.rb` | ivar | 22834 | 0 | 22834 | 2.7 | no_profile_missing_ic 22834 |
| `empty?@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | ivar | 22052 | 0 | 22052 | 2.6 | no_profile_missing_ic 22052 |
| `current_shard@activerecord-8.1.2/lib/active_record/core.rb` | send | 35274 | 14594 | 20680 | 7.2 | send_polymorphic_fallback 35274 |
| `current_role@activerecord-8.1.2/lib/active_record/core.rb` | send | 35274 | 14594 | 20680 | 7.2 | send_polymorphic_fallback 35274 |
| `!=@<internal:basic_object>` | send | 18776 | 0 | 18776 | 6.6 | send_polymorphic_fallback 18776 |
| `each_attributes@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | ivar | 18306 | 0 | 18306 | 2.2 | no_profile_missing_ic 18306 |
| `merge@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | send | 18306 | 0 | 18306 | 6.4 | send_not_optimized_need_permission 18306 |
| `deprecated_associations_api_guard@activerecord-8.1.2/lib/active_record/associations.rb` | ivar | 16202 | 0 | 16202 | 1.9 | no_profile_missing_ic 16202 |
| `merge_clauses@activerecord-8.1.2/lib/active_record/relation/merger.rb` | send | 17479 | 1550 | 15929 | 5.6 | send_polymorphic_fallback 17479 |
| `except_predicates@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | ivar | 14163 | 0 | 14163 | 1.7 | no_profile_missing_ic 14163 |
| `fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb` | send | 13719 | 0 | 13719 | 4.8 | send_block_arg_not_nil 13719 |
| `initialize@activerecord-8.1.2/lib/active_record/relation.rb` | send | 14376 | 738 | 13638 | 4.8 | send_polymorphic_fallback 14376 |
| `iterate_guarding_exceptions@activesupport-8.1.2/lib/active_support/notifications/fanout.rb` | send | 13081 | 0 | 13081 | 4.6 | send_block_arg_not_nil 13081 |
| `merge_multi_values@activerecord-8.1.2/lib/active_record/relation/merger.rb` | send | 14023 | 961 | 13062 | 4.6 | send_polymorphic_fallback 14023 |
| `set_strict_loading@activerecord-8.1.2/lib/active_record/associations/association.rb` | ivar | 12669 | 0 | 12669 | 1.5 | no_profile_missing_ic 12669 |
| `violates_strict_loading?@activerecord-8.1.2/lib/active_record/associations/association.rb` | ivar | 12656 | 0 | 12656 | 1.5 | no_profile_missing_ic 12656 |
| `relation_class_for@activerecord-8.1.2/lib/active_record/relation/delegation.rb` | send | 13081 | 785 | 12296 | 4.3 | send_polymorphic_fallback 13081 |
| `visit@activerecord-8.1.2/lib/arel/visitors/visitor.rb` | send | 44631 | 32583 | 12048 | 4.2 | send_not_optimized_method_type_optimized 27562, send_polymorphic_fallback 17069 |
| `stale_target?@activerecord-8.1.2/lib/active_record/associations/association.rb` | send | 11804 | 0 | 11804 | 4.1 | send_polymorphic 11804 |
| `relation@activerecord-8.1.2/lib/active_record/core.rb` | send | 11060 | 306 | 10754 | 3.8 | one_or_more_complex_arg_pass 10590, send_polymorphic_fallback 470 |
| `polymorphic?@activerecord-8.1.2/lib/active_record/reflection.rb` | ivar | 10420 | 0 | 10420 | 1.2 | no_profile_missing_ic 10420 |
| `default_role@activerecord-8.1.2/lib/active_record/core.rb` | send | 17637 | 7297 | 10340 | 3.6 | send_polymorphic_fallback 17637 |

