### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 4943.3 | 4940.5 | 4945.6 | 4943.2 | 0.10% |
| YJIT | 4762.2 | 4753.2 | 4762.3 | 4759.2 | 0.19% |
| ZJIT − YJIT | | | | +183.9 (+3.87%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| method dispatch (generic send path) | 821.1 | 733.7 | **+87.4** | 48% | 1.2 |
| JIT code | 647.0 | 560.0 | **+87.0** | 47% | 0.0 |
| block and proc invocation (generic) | 219.1 | 172.7 | **+46.4** | 25% | 0.0 |
| GC (marking, sweeping, freeing) | 167.9 | 140.9 | **+27.0** | 15% | 3.9 |
| ivar and attr access (generic) | 65.9 | 49.6 | **+16.3** | 9% | 0.0 |
| side exits and frame materialization | 15.8 | 1.1 | **+14.7** | 8% | 0.0 |
| invalidation | 0.0 | 0.0 | **+0.0** | 0% | 0.0 |
| compile (ZJIT/YJIT compiler, profiling) | 1.1 | 3.0 | **-1.9** | -1% | 4.4 |
| other runtime (cfunc bodies, hash, string, regexp, ...) | 2602.5 | 2610.3 | **-7.8** | -4% | 7.1 |
| write barriers | 41.8 | 54.9 | **-13.0** | -7% | 0.1 |
| interpreter (YARV loop and insn helpers) | 47.4 | 77.2 | **-29.8** | -16% | 0.0 |
| allocation (objects, malloc) | 313.7 | 355.9 | **-42.2** | -23% | 1.5 |
| total | 4943.2 | 4759.2 | **+183.9** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `<JIT code>` | JIT code | 647.0 | 560.0 | +87.0 |
| `rb_vm_exec` | method dispatch | 124.2 | 81.9 | +42.3 |
| `vm_invoke_iseq_block` | block and proc invocation | 33.0 | 6.3 | +26.7 |
| `rb_vm_invokeblock` | block and proc invocation | 26.2 | 6.5 | +19.7 |
| `vm_exec_core` | interpreter | 23.3 | 42.8 | -19.5 |
| `zjit_materialize_frames` | side exits and frame materialization | 15.7 | 0.1 | +15.6 |
| `yjit_compile` | method dispatch | 0.0 | 14.4 | -14.4 |
| `rb_vm_send` | method dispatch | 19.1 | 5.4 | +13.7 |
| `gc_mark` | GC | 16.2 | 2.6 | +13.6 |
| `rb_gc_writebarrier` | write barriers | 39.7 | 52.7 | -13.0 |
| `CALLER_SETUP_ARG` | method dispatch | 45.7 | 32.9 | +12.8 |
| `rb_ivar_lookup` | ivar and attr access | 16.7 | 4.9 | +11.7 |
| `rb_shape_get_iv_index` | ivar and attr access | 13.9 | 2.9 | +11.0 |
| `rb_gc_mark_movable` | GC | 10.8 | 0.0 | +10.8 |
| `vm_call_iseq_setup` | method dispatch | 42.3 | 32.3 | +10.1 |
| `rb_ec_newobj_of` | allocation | 43.3 | 53.3 | -10.0 |
| `rb_ec_stack_check` | method dispatch | 36.1 | 26.8 | +9.3 |
| `setup_parameters_complex` | method dispatch | 47.8 | 39.3 | +8.5 |
| `vm_callee_setup_arg` | method dispatch | 36.8 | 28.5 | +8.3 |
| `rb_class_allocate_instance` | allocation | 4.7 | 12.8 | -8.1 |
| `rb_newobj_of` | allocation | 39.2 | 47.1 | -7.9 |
| `rb_vm_opt_send_without_block` | method dispatch | 24.1 | 16.5 | +7.6 |
| `vm_search_super_method` | method dispatch | 9.1 | 15.3 | -6.2 |
| `rb_ec_ary_new_from_values` | allocation | 0.9 | 7.1 | -6.2 |
| `rb_obj_fields` | ivar and attr access | 11.9 | 18.0 | -6.1 |
| `rb_vm_invokesuper` | method dispatch | 5.4 | 11.2 | -5.8 |
| `rb_ivar_get_at_no_ractor_check` | ivar and attr access | 0.5 | 6.2 | -5.6 |
| `RCLASS_EXT_WRITABLE` | method dispatch | 15.4 | 21.0 | -5.6 |
| `ary_memcpy0` | other runtime | 8.8 | 14.2 | -5.4 |
| `rb_obj_is_kind_of` | other runtime | 10.8 | 16.1 | -5.3 |
| `vm_call0_body` | method dispatch | 40.6 | 45.6 | -5.0 |
| `rb_gc_get_objspace` | allocation | 21.2 | 26.2 | -5.0 |
| `__memset_avx2_unaligned_erms` | other runtime | 83.8 | 78.9 | +4.9 |
| `rb_builtin_ary_at_end` | interpreter | 0.0 | 4.9 | -4.9 |
| `vm_call_method_each_type` | method dispatch | 9.3 | 4.5 | +4.8 |
| `vm_call_method` | method dispatch | 7.9 | 3.4 | +4.5 |
| `rb_funcallv_scope.constprop.0` | method dispatch | 25.7 | 30.2 | -4.5 |
| `rb_zjit_root_mark` | GC | 3.7 | 0.0 | +3.7 |
| `vm_call_symbol` | method dispatch | 8.7 | 5.1 | +3.6 |
| `rb_vm_getinstancevariable` | ivar and attr access | 3.6 | 0.0 | +3.6 |

### Unclassified (other runtime) differences above 0.5M
  -5.4 ary_memcpy0
  -5.3 rb_obj_is_kind_of
  +4.9 __memset_avx2_unaligned_erms
  -2.6 rb_obj_as_string_result
  -2.5 tbl_update.isra.0
  +1.7 rb_str_buf_append
  +1.7 rb_str_concat
  +1.3 ar_insert_direct.isra.0
  -1.2 rb_struct_initialize_m
  +1.2 rb_hash_bulk_insert.part.0
  +0.9 search_nonascii
  -0.9 rb_obj_not_equal
  -0.8 find_table_bin_ind
  -0.8 rb_ary_store
  +0.8 VM_CF_BLOCK_HANDLER.isra.0
  +0.7 coderange_scan
  -0.7 rb_obj_equal
  -0.7 rb_get_alloc_func
  +0.7 find_table_entry_ind
  -0.6 rb_hash_aset
  -0.6 rb_str_cat
  -0.6 rb_current_ec
  +0.6 rb_enc_from_index
  +0.6 rb_vm_method_cfunc_is
  +0.5 str_modify_keep_cr
  +0.5 rb_check_id

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `entry trampoline` | 29.3 | 0.0 | +29.3 |
| `<unmapped JIT>` | 5.5 | 20.9 | -15.4 |
| `each@<internal:array>` | 27.9 | 17.0 | +10.8 |
| `get_header@rack-3.1.17/lib/rack/request.rb` | 0.2 | 10.1 | -9.9 |
| `[]@activesupport-8.1.1/lib/active_support/isolated_execution_state.rb` | 0.0 | 5.1 | -5.1 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | 9.4 | 4.9 | +4.5 |
| `_find_all@actionview-8.1.1/lib/action_view/template/resolver.rb` | 5.6 | 1.2 | +4.4 |
| `build_handle@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | 4.7 | 0.4 | +4.3 |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 8.5 | 5.2 | +3.3 |
| `block in listening?@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | 4.2 | 1.1 | +3.1 |
| `tag_option@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb` | 8.0 | 5.0 | +3.0 |
| `block in try_precompressed_files@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | 3.9 | 0.9 | +3.0 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | 3.8 | 0.8 | +3.0 |
| `block (2 levels) in groups_for@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | 3.7 | 0.8 | +3.0 |
| `block in parameterize_args@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | 3.8 | 1.0 | +2.8 |
| `_app_views_posts_show_html_erb__2283849260234568065_8528@/home/user/w/rbc/railsbench-callgrind-zjit-a-railsben` | 2.7 | 0.0 | +2.7 |
| `instrument@activesupport-8.1.1/lib/active_support/notifications/instrumenter.rb` | 3.0 | 0.3 | +2.7 |
| `session_exists?@rack-session-2.1.1/lib/rack/session/abstract/id.rb` | 3.1 | 0.4 | +2.7 |
| `blank?@activesupport-8.1.1/lib/active_support/core_ext/object/blank.rb` | 0.2 | 2.8 | -2.7 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 6.0 | 3.3 | +2.6 |
| `method_missing@activesupport-8.1.1/lib/active_support/ordered_options.rb` | 5.9 | 3.3 | +2.6 |
| `fetch_header@rack-3.1.17/lib/rack/request.rb` | 0.3 | 2.8 | -2.5 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | 0.0 | 2.3 | -2.3 |
| `file_readable?@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | 0.0 | 2.2 | -2.2 |
| `instrument@activesupport-8.1.1/lib/active_support/notifications.rb` | 3.8 | 1.6 | +2.2 |
| `move@actionpack-8.1.1/lib/action_dispatch/journey/gtg/transition_table.rb` | 4.4 | 2.2 | +2.2 |
| `[]@rack-3.1.17/lib/rack/headers.rb` | 0.6 | 2.7 | -2.1 |
| `[]=@rack-3.1.17/lib/rack/headers.rb` | 0.6 | 2.6 | -2.1 |
| `block in _app_views_posts_index_html_erb___2688544198241802360_8912@/home/user/w/rbc/railsbench-callgrind-zjit` | 2.1 | 0.0 | +2.1 |
| `block in perform_query@activerecord-8.1.1/lib/active_record/connection_adapters/sqlite3/database_statements.rb` | 3.0 | 1.0 | +2.0 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 647.0)

     81.4  12.6% PushInlineFrame
     55.6   8.6% SendDirect
     49.5   7.7% GuardType
     44.6   6.9% CCallWithFrame
     41.1   6.4% CCallVariadic
     31.7   4.9% PatchPoint
     29.3   4.5% entry trampoline
     21.2   3.3% HashAref
     20.7   3.2% EntryPoint
     19.6   3.0% Return
     18.5   2.9% Test
     16.9   2.6% CondBranch
     16.8   2.6% LoadField
     15.7   2.4% CondBranchHasType
     15.5   2.4% IsBitEqual
     10.9   1.7% Jump
     10.9   1.7% PopInlineFrame
     10.7   1.6% Send
     10.3   1.6% CheckInterrupts
      9.1   1.4% GuardBitEquals
      7.8   1.2% WriteBarrier
      7.0   1.1% ArrayLength
      6.1   0.9% HashAset
      6.0   0.9% <unmapped JIT>
      5.9   0.9% GetEP

### JIT code by YJIT codegen symbol (run b, M per iteration; total 560.0)

     72.0  12.9% gen_send_iseq: gen_push_frame
     65.3  11.7% gen_send_general: jit_guard_known_klass
     55.4   9.9% opt_send_without_block
     47.1   8.4% gen_send_iseq
     47.0   8.4% leave
     32.6   5.8% <unmapped JIT>
     24.9   4.4% gen_send_cfunc: gen_push_frame
     23.6   4.2% opt_aref
     22.5   4.0% getinstancevariable
     17.3   3.1% gen_send_cfunc
     14.8   2.6% gen_send_cfunc: known_cfunc_codegen
     13.8   2.5% getlocal_WC_0
     10.8   1.9% setinstancevariable
      8.2   1.5% setlocal_WC_0
      8.1   1.4% send
      8.0   1.4% opt_invokebuiltin_delegate
      6.7   1.2% gen_send_dynamic
      6.7   1.2% invokeblock
      6.5   1.2% opt_aset
      5.5   1.0% invokesuper
      4.8   0.9% putself
      4.8   0.9% opt_getconstant_path
      4.6   0.8% getlocal_WC_1
      4.5   0.8% branchunless
      4.0   0.7% branchif

### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `<JIT code>` | 3432528 | 0 | 3432528 | 210827.4 | 0.0 |
| `rb_gc_writebarrier` | 6000 | 491805 | -485805 | 0.2 | 14.3 |
| `rb_ivar_get_at_no_ractor_check` | 45805 | 515952 | -470147 | 7.2 | 31.1 |
| `rb_builtin_ary_at_end` | 0 | 435855 | -435855 | 0.0 | 4.8 |
| `rb_builtin_ary_at` | 0 | 273154 | -273154 | 0.0 | 1.6 |
| `rb_vm_invokeblock` | 341024 | 84163 | 256861 | 32560.8 | 15985.8 |
| `rb_builtin_fixnum_inc` | 0 | 246045 | -246045 | 0.0 | 0.7 |
| `rb_obj_as_string_result` | 0 | 240013 | -240013 | 0.0 | 2.6 |
| `rb_ivar_get` | 229098 | 0 | 229098 | 29.6 | 0.0 |
| `rb_obj_is_kind_of` | 167423 | 362715 | -195292 | 6.8 | 17.2 |
| `rb_vm_send` | 232418 | 65317 | 167100 | 13781.9 | 5610.6 |
| `rb_yarv_ary_entry_internal` | 0 | 142652 | -142652 | 0.0 | 2.3 |
| `rb_obj_alloc` | 56457 | 194898 | -138441 | 21.8 | 47.7 |
| `rb_ec_ary_new_from_values` | 17085 | 143493 | -126407 | 28.9 | 50.5 |
| `builtin_inline_class_20` | 0 | 125051 | -125051 | 0.0 | 1.3 |
| `rb_vm_opt_send_without_block` | 342165 | 234238 | 107927 | 1287.2 | 1751.0 |
| `rb_vm_env_write` | 129370 | 21973 | 107397 | 1.6 | 1.0 |
| `rb_obj_equal` | 0 | 105053 | -105053 | 0.0 | 0.5 |
| `rb_hash_new` | 13295 | 82628 | -69333 | 24.3 | 23.0 |
| `rb_vm_getinstancevariable` | 65922 | 0 | 65922 | 3.6 | 0.0 |
| `rb_vm_invokesuper` | 55265 | 120465 | -65200 | 18676.2 | 402.9 |
| `rb_obj_not_equal` | 0 | 47974 | -47974 | 0.0 | 18.6 |
| `rb_hash_aref` | 1126118 | 1173844 | -47726 | 285.0 | 313.0 |
| `erb_escape_html` | 42172 | 0 | 42172 | 12.8 | 0.0 |
| `rb_get_symbol_id` | 0 | 41853 | -41853 | 0.0 | 0.2 |
| `rb_str_dup` | 0 | 39579 | -39579 | 0.0 | 15.3 |
| `rb_str_concat` | 34815 | 0 | 34815 | 16.8 | 0.0 |
| `rb_jit_str_simple_append` | 76026 | 110841 | -34815 | 19.4 | 30.3 |
| `rb_zjit_defined_ivar` | 31961 | 0 | 31961 | 2.4 | 0.0 |
| `rb_builtin_ary_first` | 0 | 31236 | -31236 | 0.0 | 0.2 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `each@<internal:array>` | `rb_vm_invokeblock` | 200653 | 58288 | 142365 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 77883 | 25961 | 51922 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | `rb_vm_opt_send_without_block` | 41805 | 0 | 41805 |
| `map@<internal:array>` | `rb_vm_invokeblock` | 41197 | 9300 | 31897 |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb` | `rb_ivar_get` | 28714 | 0 | 28714 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | `rb_ivar_get` | 28471 | 0 | 28471 |
| `level_override@logger-1.7.0/lib/logger.rb` | `rb_vm_getinstancevariable` | 25961 | 0 | 25961 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_getinstancevariable` | 25961 | 0 | 25961 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_hash_aref` | 25961 | 0 | 25961 |
| `local_level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_hash_aref` | 25961 | 0 | 25961 |
| `method_missing@activesupport-8.1.1/lib/active_support/ordered_options.rb` | `rb_hash_aref` | 23922 | 0 | 23922 |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb` | `rb_ivar_get` | 23640 | 0 | 23640 |
| `iterate_guarding_exceptions@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | `rb_vm_send` | 21948 | 0 | 21948 |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb` | `rb_ivar_get` | 18114 | 0 | 18114 |
| `block in each_precompressed_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | `rb_vm_invokeblock` | 17883 | 0 | 17883 |
| `select@<internal:array>` | `rb_vm_invokeblock` | 16031 | 16 | 16015 |
| `raw_host_with_port@actionpack-8.1.1/lib/action_dispatch/http/url.rb` | `rb_hash_aref` | 16000 | 0 | 16000 |
| `block in initialize@rack-3.1.17/lib/rack/response.rb` | `rb_hash_aref` | 15896 | 0 | 15896 |
| `session_exists?@rack-session-2.1.1/lib/rack/session/abstract/id.rb` | `rb_hash_aref` | 15896 | 0 | 15896 |
| `block in parameterize_args@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | `rb_vm_send` | 14140 | 0 | 14140 |
| `instrument@activesupport-8.1.1/lib/active_support/notifications.rb` | `rb_hash_aref` | 13287 | 0 | 13287 |
| `block (2 levels) in search_combinations@actionview-8.1.1/lib/action_view/path_set.rb` | `rb_vm_invokeblock` | 12078 | 0 | 12078 |
| `before@activesupport-8.1.1/lib/active_support/execution_wrapper.rb` | `rb_vm_opt_send_without_block` | 12000 | 0 | 12000 |
| `tag_stack@activesupport-8.1.1/lib/active_support/tagged_logging.rb` | `rb_vm_getinstancevariable` | 12000 | 0 | 12000 |
| `request@actionpack-8.1.1/lib/action_dispatch/middleware/cookies.rb` | `rb_ivar_get` | 11922 | 0 | 11922 |
| `retrieve_connection_pool@activerecord-8.1.1/lib/active_record/connection_adapters/abstract/connectio` | `rb_hash_aref` | 11910 | 0 | 11910 |
| `script_name@rack-3.1.17/lib/rack/request.rb` | `rb_hash_aref` | 10358 | 0 | 10358 |
| `routes@actionpack-8.1.1/lib/action_dispatch/http/request.rb` | `rb_hash_aref` | 10357 | 0 | 10357 |
| `block in initialize@actionpack-8.1.1/lib/action_dispatch/http/response.rb` | `rb_hash_aref` | 10000 | 0 | 10000 |
| `parameters@actionpack-8.1.1/lib/action_dispatch/http/parameters.rb` | `rb_hash_aref` | 9983 | 0 | 9983 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | `rb_vm_opt_send_without_block` | 9057 | 0 | 9057 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | `rb_vm_opt_send_without_block` | 9057 | 0 | 9057 |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb` | `rb_vm_opt_send_without_block` | 9057 | 0 | 9057 |
| `block in listening?@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | `rb_vm_opt_send_without_block` | 8013 | 0 | 8013 |
| `policy_present?@actionpack-8.1.1/lib/action_dispatch/http/content_security_policy.rb` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `perform_query@activerecord-8.1.1/lib/active_record/connection_adapters/sqlite3/database_statements.r` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `cache_control_headers@actionpack-8.1.1/lib/action_dispatch/http/cache.rb` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `recognize@actionpack-8.1.1/lib/action_dispatch/journey/router.rb` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `instrumenter@activesupport-8.1.1/lib/active_support/notifications.rb` | `rb_hash_aref` | 15974 | 7987 | 7987 |
| `scheme@rack-3.1.17/lib/rack/request.rb` | `rb_hash_aref` | 7974 | 0 | 7974 |

