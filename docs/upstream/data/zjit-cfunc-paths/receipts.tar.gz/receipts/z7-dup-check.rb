# Prints observable Kernel#dup behavior; the output must be identical on master and the prototype.
out = []
h = Hash.new { |hh, k| k * 2 }; h[:a] = 1
d = h.dup; out << [d, d.default_proc.call(nil, 3), d.equal?(h), d.frozen?]
ci = {}.compare_by_identity; ci["x"] = 1; out << [ci.dup.compare_by_identity?, ci.dup.size]
a = [1, [2]].freeze; da = a.dup; out << [da, da.frozen?, da[1].equal?(a[1])]
o = Object.new; o.instance_variable_set(:@x, 1); def o.sing = 1
od = o.dup; out << [od.instance_variable_get(:@x), od.respond_to?(:sing), od.singleton_methods]

class SubH < Hash; end
out << [SubH[a: 1].dup.class, SubH[a: 1].dup]

module LoudCopy; def initialize_copy(o) = (super; self[:copied] = true; self); end
class PH < Hash; prepend LoudCopy; end
out << PH[a: 1].dup

class UD; attr_reader :log; def initialize = @log = []; def initialize_dup(o) = (@log = [:dup]; super); end
out << UD.new.dup.log

class IC < Array; def initialize_copy(o) = (super; push(:ic)); end
out << IC[1].dup

module Ref; refine Hash do; def initialize_copy(o) = (super; self[:refined] = true; self); end; end
using Ref
out << { a: 1 }.dup

events = []
tp = TracePoint.new(:c_call) { |t| events << t.method_id if %i[dup initialize_dup initialize_copy].include?(t.method_id) }
tp.enable { [1].dup; {}.dup; Object.new.dup }
out << events

trace_target = []
m = Hash.instance_method(:initialize_copy)
begin
  tp2 = TracePoint.new(:c_call) { |t| trace_target << t.method_id }
  tp2.enable(target: m) { {b: 2}.dup }
rescue ArgumentError => e
  trace_target << e.class
end
out << trace_target

module KC; def initialize_copy(o) = (@redefined = true; super); end
Object.prepend(KC)
x = Object.new.dup; out << x.instance_variable_get(:@redefined)

class Hash; def initialize_copy(o) = (replace(o); store(:redef, 1); self); end
out << { a: 1 }.dup

e = (begin; Class.new(BasicObject) { }.allocate.__send__(:dup) rescue $!.class; end); out << e

class Array; def initialize_dup(o) = (super; push(:idup)); end
out << [1].dup

out.each { p _1 }
