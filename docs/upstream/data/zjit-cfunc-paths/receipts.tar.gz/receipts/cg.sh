#!/bin/bash
# Callgrind Ir per iteration on ruby-bench (ruby_bench_callgrind.rb). Usage: cg.sh RUBY_PREFIX TAG BENCH [ruby flags]
R=$1 TAG=$2 B=$3; shift 3
EXT=${EXT:-/home/user/z7/ext-m3}
cd ~/ruby-bench
HARNESS=ruby_bench_callgrind valgrind --tool=callgrind --instr-atstart=no --smc-check=all-non-file \
  --callgrind-out-file=/home/user/z7/out/cg-$TAG-$B.%p.out $R/bin/ruby -I$EXT "$@" benchmarks/$B/benchmark.rb > ~/z7/out/cg-$TAG-$B.log 2>&1
echo "$TAG $B $?"
