def d(x) = x.dup
class C; def initialize = @a = 1; end
o = C.new.freeze; h = {a: 1}.freeze; a = [1].freeze
r = []
10.times { r = [d(o).frozen?, d(o).instance_variable_get(:@a), d(h).frozen?, d(a).frozen?, (d(o).instance_variable_set(:@b, 2) rescue $!.class)] }
p r
e = Struct.new(:x).new(1).freeze; p (10.times.map { d(e).frozen? }.uniq)
