# Kernel#dup compiled by ZJIT, then the copy hooks change. Output must match master.
def d(x) = x.dup
out = []
h = { a: 1 }; a = [1]; o = Object.new.tap { _1.instance_variable_set(:@v, 1) }
10.times { d(h); d(a); d(o) }   # compiled with --zjit-call-threshold=2
out << [d(h), d(a), d(o).instance_variable_get(:@v)]

module P; def initialize_copy(x) = (super; self[:p] = 1; self); end
Hash.prepend(P)
out << d(h)

module I; def initialize_copy(x) = (super; push(:i)); end
class SubA < Array; end
sa = SubA[1]; 5.times { d(sa) }
SubA.include(I)            # included modules sit above SubA but below Array
out << d(sa)
class SubA; def initialize_copy(x) = (super; push(:sub)); end
out << d(sa)

class Object; def initialize_dup(x) = (@dup_hook = true; super); end
out << d(o).instance_variable_get(:@dup_hook)

events = []
TracePoint.new(:c_call) { |t| events << t.method_id if %i[initialize_dup initialize_copy].include?(t.method_id) }.enable { d([2]) }
out << events

class Array; def initialize_copy(x) = (replace(x); push(:redef)); end
out << d(a)
out.each { p _1 }
