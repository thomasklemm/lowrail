# Observable behavior of Kernel#dup / #initialize_dup. Each line is compared across builds and modes.
$stdout.sync = true
def show(label)
  r = begin; yield; rescue Exception => e; "#{e.class}: #{e.message}"; end
  puts "#{label}: #{r.inspect}"
end
def labels(bt) = bt.map { _1.sub(/^#{Regexp.escape(__FILE__)}/, "F") }.first(6)

# 1 backtraces
class RaiseCopy; def initialize_copy(o) = raise("boom"); end
show("bt user initialize_copy") { begin; RaiseCopy.new.dup; rescue => e; labels(e.backtrace); end }
show("bt allocator undefined") { begin; Encoding::UTF_8.dup; rescue => e; [e.class, e.message, labels(e.backtrace)]; end }
class CallerCopy; def initialize_copy(o) = ($c = caller(0).first(5).map { _1.sub(__FILE__, "F") }); end
show("caller in initialize_copy") { CallerCopy.new.dup; $c }
class LocCopy; def initialize_copy(o) = ($l = caller_locations(1, 3).map { [_1.path.sub(__FILE__, "F"), _1.lineno, _1.label] }); end
show("caller_locations") { LocCopy.new.dup; $l }

# 2 TracePoint
ev = []
tp = TracePoint.new(:call, :c_call, :return, :c_return) do |t|
  ev << [t.event, t.method_id, t.path.sub(__FILE__, "F")] if %i[dup initialize_dup initialize_copy].include?(t.method_id)
end
tp.enable { [1].dup; {}.dup; Object.new.dup }
show("tracepoint") { ev }
ev2 = []
tp2 = TracePoint.new(:c_call) { |t| ev2 << t.method_id if %i[dup initialize_dup initialize_copy].include?(t.method_id) }
tp2.enable { {a: 1}.dup }
show("tracepoint c_call only") { ev2 }
show("tracepoint target") do
  m = Kernel.instance_method(:dup); r = []
  TracePoint.new(:call, :c_call) { |t| r << t.method_id }.enable(target: m) { [1].dup }; r
end

# 3 Method objects
%i[dup initialize_dup].each do |n|
  m = Kernel.instance_method(n)
  show("Method #{n}") { [m.owner, m.arity, m.source_location&.first, m.parameters, Kernel.private_method_defined?(n)] }
end
show("Method dup on obj") { o = Object.new; m = o.method(:dup); [m.owner, m.arity, m.source_location.nil?, m.super_method] }

# 4 refinements (lexical; rb_funcall ignores them)
module RefCopy; refine(Hash) { def initialize_copy(o) = (super; self[:refined] = 1; self) }; refine(Object) { def initialize_dup(o) = (super; @refdup = 1; self) }; end
using RefCopy
show("refined initialize_copy") { {a: 1}.dup }
show("refined initialize_dup") { Object.new.dup.instance_variable_get(:@refdup) }

# 5 special constants, frozen, singleton
show("special") { [1.dup, :s.dup, nil.dup, true.dup, 1.5.dup, (2**70).dup, 2r.dup, 3i.dup, "dyn#{1}".to_sym.dup].map(&:inspect) }
show("frozen") { o = Object.new.tap { _1.instance_variable_set(:@a, 1) }.freeze; d = o.dup; [d.frozen?, d.instance_variable_get(:@a), {a: 1}.freeze.dup.frozen?, [1].freeze.dup.frozen?, "s".freeze.dup.frozen?] }
show("singleton") { o = Object.new; def o.x = 1; o.extend(Comparable); d = o.dup; [d.singleton_methods, d.is_a?(Comparable), d.singleton_class.ancestors[1]] }
show("chilled string") { s = "lit"; d = s.dup; [d.frozen?, (d << "x")] }
show("same object?") { o = Object.new; o.dup.equal?(o) }
show("BasicObject bind_call") { b = BasicObject.new; Kernel.instance_method(:dup).bind_call(b).__id__ != b.__id__ }

# 6 custom allocate, T_DATA, builtins with own copy
class CustomAlloc; def self.allocate = raise("custom allocate"); def initialize = @x = 1; end
show("custom allocate") { CustomAlloc.new.dup.instance_variable_get(:@x) }
show("t_data") { t = Time.at(0, in: "+09:00"); [t.dup == t, t.dup.utc_offset, Random.new(1).dup.rand(100), Set[1, 2].dup, Struct.new(:a).new(1).dup.a, Data.define(:a).new(a: 1).dup.a, [1, 2].each.dup.next, /x/i.dup, (1..2).dup, Object.method(:new).unbind.dup.name] }
show("hash flags") { h = Hash.new(5).compare_by_identity; h["k"] = 1; d = h.dup; [d.default, d.compare_by_identity?, d.size, Hash.new { 7 }.dup.default_proc.call] }
show("array subclass") { c = Class.new(Array); d = c[1, 2].dup; [d.class == c, d] }

# 7 user hooks and odd definitions
class UserDup; attr_reader :log; def initialize = @log = []; def initialize_dup(o) = (@log = [:dup]; super); def initialize_copy(o) = (@log << :copy; super); end
show("user hooks") { UserDup.new.dup.log }
class NoInitDup; undef_method :initialize_dup; end
show("undef initialize_dup") { NoInitDup.new.dup }
class MMDup; undef_method :initialize_dup; def method_missing(n, *a) = ($mm = n); def respond_to_missing?(*) = true; end
show("method_missing") { MMDup.new.dup; $mm }
class PublicDup; public :initialize_dup; end
show("public initialize_dup") { PublicDup.new.dup.class }
class HijackSend; def __send__(*) = :hijacked; def initialize_copy(o) = (@copied = true); end
show("redefined __send__") { $VERBOSE = nil; HijackSend.new.dup.instance_variable_get(:@copied) }
class SuperDup; def dup = super.tap { _1.instance_variable_set(:@via, :super) }; end
show("super into Kernel#dup") { SuperDup.new.dup.instance_variable_get(:@via) }
module PreDup; def dup = [:pre, super.class]; end
class PreDupC; prepend PreDup; end
show("prepend dup") { PreDupC.new.dup }
show("clone unaffected") { o = Object.new; def o.s = 1; o.freeze; c = o.clone; [c.frozen?, c.singleton_methods] }

# 8 Ractor
show("ractor") do
  $VERBOSE = nil
  Ractor.new { [[1, 2].dup, {a: 1}.dup, Object.new.dup.class, Ractor.make_shareable({a: [1]}).dup.frozen?] }.value
end
show("shareable dup") { s = Ractor.make_shareable({a: [1]}); d = s.dup; [Ractor.shareable?(d), d.frozen?, d[:a].frozen?] }
