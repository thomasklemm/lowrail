def d(x) = x.dup
h = {a: 1}
200.times { d(h) }
module Validations; def initialize_dup(o) = super; end
class Search; end
RubyVM::ZJIT.reset_stats!
Search.include(Validations)
1000.times { d(h) }
s = RubyVM::ZJIT.stats
p s.select { |k, v| k.to_s.start_with?("exit_") && v > 0 }.merge(side_exit_count: s[:side_exit_count])
