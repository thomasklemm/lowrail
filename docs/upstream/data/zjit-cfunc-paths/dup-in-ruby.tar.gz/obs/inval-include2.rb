require "active_model"
def d(x) = x.dup
h = {a: 1}
200.times { d(h) }
RubyVM::ZJIT.reset_stats!
class Search; include ActiveModel::Validations; end
1000.times { d(h) }
s = RubyVM::ZJIT.stats
p s.select { |k, v| k.to_s.start_with?("exit_") && v > 0 }.merge(side_exit_count: s[:side_exit_count])
