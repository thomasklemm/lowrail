def d(x) = x.dup
h = {a: 1}
20.times { d(h) }
