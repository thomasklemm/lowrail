#!/bin/bash
# Ir per iteration = (window .2 - window .1) / 3 for each Callgrind run TAG-BENCH
for f in /home/user/z7/out/cg-*-*.*.out.2; do
  base=${f%.2}; a=$(grep -h '^totals:\|^summary:' $base.1 | tail -1 | awk '{print $2}'); b=$(grep -h '^totals:\|^summary:' $f | tail -1 | awk '{print $2}')
  n=$(basename $base .out); echo "$n $(( (b - a) / 3 ))"
done
