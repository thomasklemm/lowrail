#!/bin/bash
# test-all files and ruby/spec kernel/dup on a build dir, three configurations.
B=$1; TAG=$2; cd $B
T='ruby/test_object.rb ruby/test_clone.rb ruby/test_hash.rb ruby/test_array.rb ruby/test_settracefunc.rb ruby/test_refinement.rb ruby/test_backtrace.rb'
make test-all TESTS="$T" > ~/z7/t-$TAG-interp.log 2>&1; echo "interp $?"
make test-all TESTS="$T" RUN_OPTS='--zjit-call-threshold=1' > ~/z7/t-$TAG-zjit1.log 2>&1; echo "zjit1 $?"
Z7_DUP_RUBY=1 make test-all TESTS="$T" > ~/z7/t-$TAG-always.log 2>&1; echo "always $?"
for cfg in "" "--zjit-call-threshold=1"; do make test-spec SPECOPTS="../spec/ruby/core/kernel/dup_spec.rb ../spec/ruby/core/kernel/clone_spec.rb ../spec/ruby/core/kernel/initialize_dup_spec.rb ../spec/ruby/core/kernel/initialize_copy_spec.rb" RUN_OPTS="$cfg" > ~/z7/s-$TAG-${cfg:-interp}.log 2>&1; echo "spec $cfg $?"; done
Z7_DUP_RUBY=1 make test-spec SPECOPTS="../spec/ruby/core/kernel/dup_spec.rb ../spec/ruby/core/kernel/clone_spec.rb ../spec/ruby/core/kernel/initialize_dup_spec.rb ../spec/ruby/core/kernel/initialize_copy_spec.rb" > ~/z7/s-$TAG-always.log 2>&1; echo "spec always $?"
