#!/bin/bash
# Per-call Ir for dup cases: build x mode. Usage: matrix.sh "build:prefix:ext ..." 
C="empty Hash#dup Array#dup Object.new#dup Object#dup String#dup"
for spec in "$@"; do
  IFS=: read tag prefix ext envv <<< "$spec"
  for mode in interp yjit zjit; do
    case $mode in interp) F="";; yjit) F="--yjit";; zjit) F="--zjit";; esac
    res=$(env $envv R=$prefix EXT=$ext TAG=$tag-$mode FLAGS="$F" CASES="$C" ~/z7/micro/run.sh | grep -v '^empty' | tr '\n' ' ')
    echo "$tag $mode $res"
  done
done
