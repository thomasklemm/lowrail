#!/bin/bash
# micro.rb under Callgrind for each case; prints Ir per call net of the empty loop.
R=${R:-/home/user/rubies/m3}; EXT=${EXT:-/home/user/z7/ext-m3}; TAG=${TAG:-master}; FLAGS=${FLAGS---zjit}
case "$FLAGS" in *zjit*) THR=--zjit-call-threshold=2;; *yjit*) THR=--yjit-call-threshold=2;; *) THR=;; esac
out=/home/user/z7/micro/$TAG; mkdir -p $out
cases=${CASES:-"empty Hash#dup Array#dup Object#dup String#dup Regexp#match? String#match? Time#utc? String#length Hash#key?"}
for c in $cases; do
  valgrind --tool=callgrind --instr-atstart=no --smc-check=all-non-file --callgrind-out-file=$out/$c.out \
    $R/bin/ruby -I$EXT $FLAGS $THR /home/user/z7/micro/micro.rb "$c" > $out/$c.log 2>&1 &
done
wait
e=$(grep -h '^totals:\|^summary:' $out/empty.out* | tail -1 | awk '{print $2}')
for c in $cases; do
  t=$(grep -h '^totals:\|^summary:' $out/$c.out* | tail -1 | awk '{print $2}')
  echo "$c $(( (t - e) / 20000 ))"
done
