# Per-call Ir of single C-method call sites under the JIT, via Callgrind client
# requests: window(N calls) - window(N iterations of the empty loop), / N.
require "lowrail_callgrind"
N = 20_000
H = { a: 1, b: 2, c: 3 }; A = [1, 2, 3]; S = "hello world"; RE = /wor/; T = Time.at(0).utc
class Plain; def initialize; @a = 1; @b = 2; end; end
O = Plain.new
CASES = {
  "empty"         => ->(n) { i = 0; while i < n; i += 1; end },
  "Hash#dup"      => ->(n) { i = 0; while i < n; H.dup; i += 1; end },
  "Array#dup"     => ->(n) { i = 0; while i < n; A.dup; i += 1; end },
  "Object#dup"    => ->(n) { i = 0; while i < n; O.dup; i += 1; end },
  "Object.new#dup" => ->(n) { i = 0; e = Object.new; while i < n; e.dup; i += 1; end },
  "String#dup"    => ->(n) { i = 0; while i < n; S.dup; i += 1; end },
  "Regexp#match?" => ->(n) { i = 0; while i < n; RE.match?(S); i += 1; end },
  "String#match?" => ->(n) { i = 0; while i < n; S.match?(RE); i += 1; end },
  "Time#utc?"     => ->(n) { i = 0; while i < n; T.utc?; i += 1; end },
  "String#length" => ->(n) { i = 0; while i < n; S.length; i += 1; end },
  "Hash#key?"     => ->(n) { i = 0; while i < n; H.key?(:b); i += 1; end },
}
name = ARGV.fetch(0)
body = CASES.fetch(name)
50.times { body.(200) }   # profile and compile
GC.disable
LowrailCallgrindBench.start(false); body.(N); LowrailCallgrindBench.finish
