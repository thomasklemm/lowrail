#!/bin/bash
# ZJIT stats per iteration with exit/fallback traces for one build and bench.
R=$1 TAG=$2 B=$3; shift 3
cd ${RB:-/home/user/ruby-bench}
HARNESS=ruby_bench_jit_stats JIT_STATS_JSON=/home/user/z7/out/st-$TAG-$B.json $R/bin/ruby --zjit --zjit-stats-quiet "$@" benchmarks/$B/benchmark.rb > /home/user/z7/out/st-$TAG-$B.log 2>&1
echo "$TAG $B $?"
