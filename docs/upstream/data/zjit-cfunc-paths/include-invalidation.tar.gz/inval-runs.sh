#!/bin/bash
# 18 stats runs in 4 parallel streams (one ruby-bench copy per stream).
run_stream() { local rb=$1; shift; for job in "$@"; do set -- $job; RB=$rb ~/z7/stats3.sh ~/rubies/$1 $2 $3 ${4:+--zjit-max-versions=$4}; done; }
run_stream /home/user/ruby-bench   "dupr2 S lobsters" "dupr2 S16 lobsters 16" "m3 M lobsters" "m3 M16 lobsters 16" "m19583 P16 lobsters 16" &
run_stream /home/user/ruby-bench-b "dupr2 S shipit" "dupr2 S16 shipit 16" "m3 M shipit" "m3 M16 shipit 16" "m19583 P16 shipit 16" &
run_stream /home/user/ruby-bench-c "m19583 P lobsters" "m19583 P shipit" "dupr2 S railsbench" "dupr2 S16 railsbench 16" &
run_stream /home/user/ruby-bench-d "m3 M railsbench" "m3 M16 railsbench 16" "m19583 P railsbench" "m19583 P16 railsbench 16" &
wait
echo ALLDONE
