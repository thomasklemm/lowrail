#!/bin/bash
one() { local rb=$1 tag=$2 b=$3 narrow=$4; rm -f ~/z7/out/inval-$tag-$b.tsv; if [ -n "$narrow" ]; then export Z7_NARROW=1; else unset Z7_NARROW; fi; Z7_INVAL_LOG=/home/user/z7/out/inval-$tag-$b.tsv RB=$rb ~/z7/stats3.sh ~/rubies/narrow $tag $b; }
( one /home/user/ruby-bench N lobsters; one /home/user/ruby-bench NN lobsters 1 ) &
( one /home/user/ruby-bench-b N shipit; one /home/user/ruby-bench-b NN shipit 1 ) &
( one /home/user/ruby-bench-c N railsbench; one /home/user/ruby-bench-c NN railsbench 1 ) &
wait; echo ALLDONE
