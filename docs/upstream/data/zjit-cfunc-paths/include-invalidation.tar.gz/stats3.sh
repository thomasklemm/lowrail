#!/bin/bash
# Like stats2.sh, with the DECISIONS memory flags and OOM recorded for warmup and measurement.
R=$1 TAG=$2 B=$3; shift 3
cd ${RB:-/home/user/ruby-bench}
HARNESS=ruby_bench_jit_stats2 JIT_STATS_JSON=/home/user/z7/out/st3-$TAG-$B.json $R/bin/ruby --zjit --zjit-stats-quiet --zjit-exec-mem-size=512 --zjit-mem-size=1024 "$@" benchmarks/$B/benchmark.rb > /home/user/z7/out/st3-$TAG-$B.log 2>&1
echo "$TAG $B $?"
