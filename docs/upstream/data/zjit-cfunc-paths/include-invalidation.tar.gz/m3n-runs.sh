#!/bin/bash
one() { local rb=$1 tag=$2 b=$3 narrow=$4; rm -f ~/z7/out/inval-$tag-$b.tsv; if [ -n "$narrow" ]; then export Z7_NARROW=1; else unset Z7_NARROW; fi; Z7_INVAL_LOG=/home/user/z7/out/inval-$tag-$b.tsv RB=$rb ~/z7/stats3.sh ~/rubies/m3n $tag $b; }
( one /home/user/ruby-bench-b MN lobsters; one /home/user/ruby-bench-b MNN lobsters 1 ) &
( one /home/user/ruby-bench-c MN shipit; one /home/user/ruby-bench-c MNN shipit 1; one /home/user/ruby-bench-c MN railsbench ) &
wait; echo ALLDONE
