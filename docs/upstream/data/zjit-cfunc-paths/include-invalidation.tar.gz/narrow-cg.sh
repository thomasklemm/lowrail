#!/bin/bash
# Callgrind Ir, same narrow binary, with and without the Z7_NARROW oracle, two runs each.
cg() { local rb=$1 tag=$2 b=$3 narrow=$4; if [ -n "$narrow" ]; then export Z7_NARROW=1; else unset Z7_NARROW; fi; CG_NO_GC=1 EXT=/home/user/z7/ext-dupr2 RB=$rb ~/z7/cg.sh ~/rubies/narrow $tag $b --zjit; }
( for t in N:"" NN:1 N2:"" NN2:1; do cg /home/user/ruby-bench-d ${t%%:*} lobsters ${t#*:}; done ) &
( for t in N:"" NN:1 N2:"" NN2:1; do cg /home/user/ruby-bench ${t%%:*} shipit ${t#*:}; done ) &
wait; echo ALLDONE
