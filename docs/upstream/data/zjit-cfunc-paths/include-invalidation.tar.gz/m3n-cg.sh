#!/bin/bash
cg() { local rb=$1 tag=$2 b=$3 narrow=$4; if [ -n "$narrow" ]; then export Z7_NARROW=1; else unset Z7_NARROW; fi; CG_NO_GC=1 EXT=/home/user/z7/ext-m3 RB=$rb ~/z7/cg.sh ~/rubies/m3n $tag $b --zjit; }
( cg /home/user/ruby-bench-b MN lobsters; cg /home/user/ruby-bench-b MN2 lobsters ) &
( cg /home/user/ruby-bench-c MNN lobsters 1; cg /home/user/ruby-bench-c MNN2 lobsters 1 ) &
wait; echo ALLDONE
