# Variants: does a change on an unrelated class invalidate compiled Hash#dup code?
def d(x) = x.dup
def drive(h, n)
  i = 0
  while i < n
    d(h)
    i += 1
  end
end
h = {a: 1}
class Search; end
class Base; end
class Model < Base; end
class Other < Base; end
module Validations; def initialize_dup(o) = super; end
module Unrelated; def foo = 1; end
Search.new.dup if ENV["WARM"]
5.times { drive(h, 100) }
before = RubyVM::ZJIT.stats[:compiled_iseq_count]
case ENV["V"]
when "none" then nil
when "include" then Search.include(Validations)
when "include_unrelated" then Search.include(Unrelated)
when "include_sub" then Model.include(Validations)
when "define_leaf" then Search.define_method(:initialize_dup) { |o| super(o) }
when "extend" then Object.new.extend(Validations)
end
RubyVM::ZJIT.reset_stats!
5.times { drive(h, 1000) }
s = RubyVM::ZJIT.stats
puts "#{ENV["V"]}#{ENV["WARM"] && "+warm"}: recompiled=#{s[:compiled_iseq_count] > 0} exits=#{s[:exit_patchpoint_method_redefined]}"
