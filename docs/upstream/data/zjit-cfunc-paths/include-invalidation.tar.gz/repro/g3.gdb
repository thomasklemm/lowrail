set pagination off
break rb_method_entry_complement_defined_class if called_id == 3345
commands
silent
printf "== complement src_me=%p dc=%p\n", src_me, defined_class
bt 14
cont
end
break *rb_zjit_cme_invalidate if $rdi == 0x7fffdca50508 || $rdi == 0x7fffdca505f8
commands
silent
printf "== zjit invalidate %p\n", $rdi
bt 14
cont
end
run
