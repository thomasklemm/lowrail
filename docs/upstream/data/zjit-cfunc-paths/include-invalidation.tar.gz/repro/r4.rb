# N unrelated classes each include a module that defines initialize_dup,
# with the Hash#dup site running in between. Prints exits per round.
def d(x) = x.dup
def drive(h, n)
  i = 0
  while i < n
    d(h)
    i += 1
  end
end
h = {a: 1}
5.times { drive(h, 100) }
mod = ENV["UNRELATED"] ? Module.new { def foo = 1 } : Module.new { def initialize_dup(o) = super }
rounds = []
Integer(ENV.fetch("N", "6")).times do |k|
  Class.new.include(mod)
  RubyVM::ZJIT.reset_stats!
  5.times { drive(h, 1000) }
  rounds << RubyVM::ZJIT.stats[:exit_patchpoint_method_redefined]
end
p rounds
