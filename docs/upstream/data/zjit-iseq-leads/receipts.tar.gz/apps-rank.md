apps: 10 (blog, campfire, codetriage, fizzy-mysql, fizzy, lobsters, pingcrm, react-starter-kit, redprints-cfp, writebook)
per-ISEQ sums that differ from the global counter: 0

| # | counter | ISEQ | apps | mean/op | max/op (app) |
|---|---|---|---|---|---|
| 1 | `send_fallback_invokeblock_polymorphic_miss` | `each@<internal:array>:266` | 10 | 924.4 | 1953.5 (lobsters) |
| 2 | `send_fallback_send_polymorphic_fallback` | `!=@<internal:basic_object>:14` | 10 | 281.9 | 847.4 (lobsters) |
| 3 | `send_fallback_invokeblock_polymorphic_miss` | `find@<internal:array>:335` | 10 | 130.9 | 274.5 (fizzy) |
| 4 | `send_fallback_send_polymorphic_fallback` | `_reflections@activerecord/lib/active_record/reflection.rb:13` | 10 | 120.3 | 427.8 (lobsters) |
| 5 | `send_fallback_send_not_optimized_need_permission` | `block in initialize@activesupport/lib/active_support/ordered_options.rb:109` | 10 | 113.9 | 277.8 (lobsters) |
| 6 | `send_fallback_send_not_optimized_method_type_optimized` | `visit@activerecord/lib/arel/visitors/visitor.rb:35` | 10 | 99.7 | 223.3 (fizzy) |
| 7 | `getivar_fallback_no_profile_missing_ic` | `empty?@activerecord/lib/active_record/relation/where_clause.rb:8` | 10 | 91.5 | 231.1 (fizzy) |
| 8 | `send_fallback_sendforward_not_specialized` | `empty?@activerecord/lib/active_record/relation/where_clause.rb:8` | 10 | 91.5 | 231.1 (fizzy) |
| 9 | `getivar_fallback_no_profile_missing_ic` | `klass@activerecord/lib/active_record/associations/association.rb:171` | 10 | 75.3 | 223.5 (lobsters) |
| 10 | `send_fallback_send_block_arg_not_nil` | `mon_synchronize@monitor.rb:147` | 10 | 63.3 | 148.9 (fizzy) |
| 11 | `send_fallback_send_polymorphic_fallback` | `visit@activerecord/lib/arel/visitors/visitor.rb:35` | 10 | 52.4 | 116.8 (fizzy-mysql) |
| 12 | `send_fallback_send_polymorphic_fallback` | `attribute_aliases@activemodel/lib/active_model/attribute_methods.rb:64` | 10 | 50.9 | 122.8 (writebook) |
| 13 | `getivar_fallback_no_profile_missing_ic` | `association_route@activerecord/lib/active_record/reflection.rb:650` | 10 | 43.7 | 123.3 (lobsters) |
| 14 | `send_fallback_send_block_arg_not_nil` | `iterate_guarding_exceptions@activesupport/lib/active_support/notifications/fanout.rb:23` | 10 | 43.1 | 70.1 (writebook) |
| 15 | `getivar_fallback_no_profile_missing_ic` | `polymorphic?@activerecord/lib/active_record/reflection.rb:832` | 10 | 38.1 | 132.8 (lobsters) |
| 16 | `send_fallback_one_or_more_complex_arg_pass` | `resolve_attribute_name@activemodel/lib/active_model/attribute_methods.rb:426` | 10 | 37.9 | 91.3 (fizzy-mysql) |
| 17 | `getivar_fallback_no_profile_missing_ic` | `current_default_association_route?@activerecord/lib/active_record/reflection.rb:902` | 10 | 36.9 | 104.3 (lobsters) |
| 18 | `getivar_fallback_no_side_exits` | `connection_specification_name@activerecord/lib/active_record/connection_handling.rb:368` | 10 | 33.8 | 100.2 (fizzy) |
| 19 | `getivar_fallback_no_profile_missing_ic` | `attribute_aliases@activemodel/lib/active_model/attribute_methods.rb:64` | 10 | 33.5 | 101.3 (lobsters) |
| 20 | `send_fallback_send_block_arg_not_nil` | `synchronize@activerecord/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb:99` | 10 | 31.6 | 78.9 (fizzy) |
| 21 | `send_fallback_one_or_more_complex_arg_pass` | `fetch_header@rack/lib/rack/request.rb:112` | 10 | 30.4 | 70.2 (lobsters) |
| 22 | `send_fallback_send_polymorphic` | `value_for@activerecord/lib/active_record/scoping.rb:121` | 10 | 30.2 | 77.9 (fizzy) |
| 23 | `send_fallback_send_not_optimized_need_permission` | `merge@activerecord/lib/active_record/relation/where_clause.rb:30` | 10 | 27.2 | 70.8 (fizzy-mysql) |
| 24 | `send_fallback_send_block_arg_not_nil` | `each@activesupport/lib/active_support/notifications/fanout.rb:201` | 10 | 27.0 | 67.3 (fizzy) |
| 25 | `getivar_fallback_no_profile_missing_ic` | `deprecated_associations_api_guard@activerecord/lib/active_record/associations.rb:107` | 10 | 24.5 | 114.4 (lobsters) |
| 26 | `getivar_fallback_no_side_exits` | `tag_builder@actionview/lib/action_view/helpers/tag_helper.rb:1888` | 10 | 23.8 | 87.4 (fizzy-mysql) |
| 27 | `getivar_fallback_no_profile_missing_ic` | `columns_hash@activerecord/lib/active_record/model_schema.rb:496` | 10 | 23.5 | 53.9 (lobsters) |
| 28 | `getivar_fallback_no_profile_missing_ic` | `initialize@activerecord/lib/active_record/associations/association.rb:47` | 10 | 23.2 | 99.3 (lobsters) |
| 29 | `getivar_fallback_no_profile_missing_ic` | `value@activemodel/lib/active_model/attribute.rb:53` | 10 | 22.9 | 51.8 (fizzy) |
| 30 | `send_fallback_send_block_arg_not_nil` | `with_connection@activerecord/lib/active_record/connection_handling.rb:361` | 10 | 22.3 | 60.3 (fizzy) |
| 31 | `exit_unhandled_block_arg` | `fetch_or_store@activerecord/lib/active_record/association_route.rb:189` | 10 | 20.9 | 66.7 (campfire) |
| 32 | `send_fallback_sendforward_not_specialized` | `current_transaction@activerecord/lib/active_record/connection_adapters/abstract/database_statements.rb:552` | 10 | 19.9 | 47.1 (fizzy) |
| 33 | `send_fallback_one_or_more_complex_arg_pass` | `relation@activerecord/lib/active_record/core.rb:481` | 10 | 19.8 | 49.0 (fizzy) |
| 34 | `getivar_fallback_no_profile_missing_ic` | `changed_from_assignment?@activemodel/lib/active_model/attribute.rb:187` | 10 | 19.5 | 47.9 (fizzy-mysql) |
| 35 | `getivar_fallback_no_profile_missing_ic` | `_value_for_database@activemodel/lib/active_model/attribute.rb:191` | 10 | 18.9 | 42.8 (fizzy) |
| 36 | `send_fallback_send_block_arg_not_nil` | `store_if_absent@activesupport/lib/active_support/ractors.rb:207` | 10 | 17.3 | 33.4 (campfire) |
| 37 | `send_fallback_send_polymorphic_fallback` | `arel_node?@activerecord/lib/arel.rb:76` | 10 | 17.0 | 51.3 (fizzy) |
| 38 | `getivar_fallback_no_profile_missing_ic` | `original_value@activemodel/lib/active_model/attribute.rb:65` | 10 | 16.3 | 38.6 (fizzy-mysql) |
| 39 | `getivar_fallback_no_profile_missing_ic` | `shuffle_rows@activerecord/lib/active_record/result.rb:171` | 10 | 15.9 | 39.4 (fizzy) |
| 40 | `send_fallback_sendforward_not_specialized` | `enable_lazy_transactions!@activerecord/lib/active_record/connection_adapters/abstract/database_statements.rb:552` | 10 | 15.8 | 39.5 (fizzy) |

Top by summed cost (any breadth):
| # | counter | ISEQ | apps | mean/op over all apps |
|---|---|---|---|---|
| 1 | `send_fallback_invokeblock_polymorphic_miss` | `each@<internal:array>:266` | 10 | 924.4 |
| 2 | `send_fallback_invokeblock_not_specialized` | `map@<internal:array>:284` | 9 | 331.1 |
| 3 | `send_fallback_send_polymorphic_fallback` | `!=@<internal:basic_object>:14` | 10 | 281.9 |
| 4 | `send_fallback_send_polymorphic` | `block in tag_options@actionview/lib/action_view/helpers/tag_helper.rb:1548` | 6 | 204.7 |
| 5 | `send_fallback_singleton_class_seen` | `fetch@activemodel/lib/active_model/indexed_row.rb:172` | 6 | 192.8 |
| 6 | `getivar_fallback_no_profile_missing_ic` | `<<@activerecord/lib/arel/collectors/composite.rb:21` | 8 | 192.2 |
| 7 | `getivar_fallback_no_profile_missing_ic` | `[]@activesupport/lib/active_support/isolated_execution_state.rb:33` | 5 | 184.5 |
| 8 | `send_fallback_invokeblock_polymorphic_miss` | `find@<internal:array>:335` | 10 | 130.9 |
| 9 | `send_fallback_send_polymorphic_fallback` | `_reflections@activerecord/lib/active_record/reflection.rb:13` | 10 | 120.3 |
| 10 | `send_fallback_send_not_optimized_need_permission` | `block in initialize@activesupport/lib/active_support/ordered_options.rb:109` | 10 | 113.9 |
| 11 | `getivar_fallback_no_side_exits` | `association_cache@activerecord/lib/active_record/associations.rb:85` | 7 | 100.1 |
| 12 | `send_fallback_send_not_optimized_method_type_optimized` | `visit@activerecord/lib/arel/visitors/visitor.rb:35` | 10 | 99.7 |
| 13 | `getivar_fallback_no_side_exits` | `schema_loaded?@activerecord/lib/active_record/model_schema.rb:656` | 7 | 97.7 |
| 14 | `getivar_fallback_no_side_exits` | `schema_context@activerecord/lib/active_record/model_schema.rb:215` | 6 | 97.6 |
| 15 | `send_fallback_sendforward_not_specialized` | `empty?@activerecord/lib/active_record/relation/where_clause.rb:8` | 10 | 91.5 |
| 16 | `getivar_fallback_no_profile_missing_ic` | `empty?@activerecord/lib/active_record/relation/where_clause.rb:8` | 10 | 91.5 |
| 17 | `exit_patchpoint_stable_constant_names` | `empty@activerecord/lib/active_record/relation/where_clause.rb:99` | 5 | 80.8 |
| 18 | `getivar_fallback_no_profile_missing_ic` | `klass@activerecord/lib/active_record/associations/association.rb:171` | 10 | 75.3 |
| 19 | `getivar_fallback_no_side_exits` | `_read_attribute!@activerecord/lib/active_record/attribute_methods/read.rb:58` | 7 | 74.9 |
| 20 | `getivar_fallback_no_profile_missing_ic` | `<<@activerecord/lib/arel/collectors/substitute_binds.rb:14` | 3 | 73.4 |
| 21 | `send_fallback_send_polymorphic_fallback` | `schema_context@activerecord/lib/active_record/model_schema.rb:215` | 5 | 71.2 |
| 22 | `setivar_fallback_no_side_exits` | `reset@activerecord/lib/active_record/relation.rb:1256` | 6 | 68.0 |
| 23 | `send_fallback_send_polymorphic_fallback` | `hash@activemodel/lib/active_model/type/value.rb:131` | 7 | 67.3 |
| 24 | `send_fallback_send_megamorphic` | `connection_specification_name@activerecord/lib/active_record/connection_handling.rb:368` | 7 | 66.2 |
| 25 | `send_fallback_send_block_arg_not_nil` | `mon_synchronize@monitor.rb:147` | 10 | 63.3 |
| 26 | `getivar_fallback_no_profile_missing_ic` | `attribute_types@activerecord/lib/active_record/attributes.rb:283` | 4 | 61.6 |
| 27 | `send_fallback_send_polymorphic_fallback` | `association@activerecord/lib/active_record/associations.rb:56` | 6 | 59.6 |
| 28 | `getivar_fallback_no_side_exits` | `_read_attribute@activerecord/lib/active_record/attribute_methods/read.rb:51` | 8 | 56.6 |
| 29 | `send_fallback_send_megamorphic` | `attribute_aliases@activemodel/lib/active_model/attribute_methods.rb:64` | 5 | 56.4 |
| 30 | `send_fallback_send_polymorphic_fallback` | `visit@activerecord/lib/arel/visitors/visitor.rb:35` | 10 | 52.4 |
| 31 | `send_fallback_send_megamorphic` | `build_arel@activerecord/lib/active_record/relation/query_methods.rb:2045` | 4 | 52.2 |
| 32 | `send_fallback_send_polymorphic_fallback` | `attribute_aliases@activemodel/lib/active_model/attribute_methods.rb:64` | 10 | 50.9 |
| 33 | `send_fallback_send_megamorphic` | `association@activerecord/lib/active_record/associations.rb:56` | 3 | 48.3 |
| 34 | `getivar_fallback_no_side_exits` | `table_name@activerecord/lib/active_record/model_schema.rb:290` | 7 | 47.2 |
| 35 | `send_fallback_send_polymorphic_fallback` | `current_role@activerecord/lib/active_record/core.rb:179` | 9 | 47.1 |
| 36 | `getivar_fallback_no_profile_missing_ic` | `hash@activemodel/lib/active_model/attribute.rb:149` | 7 | 46.8 |
| 37 | `send_fallback_send_polymorphic_fallback` | `current_shard@activerecord/lib/active_record/core.rb:199` | 9 | 46.3 |
| 38 | `getivar_fallback_no_profile_missing_ic` | `hash@activemodel/lib/active_model/type/value.rb:131` | 9 | 46.3 |
| 39 | `send_fallback_send_polymorphic_fallback` | `value_for@activerecord/lib/active_record/scoping.rb:121` | 9 | 45.0 |
| 40 | `getivar_fallback_no_profile_missing_ic` | `association_route@activerecord/lib/active_record/reflection.rb:650` | 10 | 43.7 |

Reasons by apps reached (counter summed over ISEQs):
  send_fallback_send_polymorphic_fallback                 apps 10  mean/op over all apps 2589.1
  getivar_fallback_no_profile_missing_ic                  apps 10  mean/op over all apps 2493.2
  getivar_fallback_no_side_exits                          apps 10  mean/op over all apps 1662.3
  send_fallback_send_megamorphic                          apps 10  mean/op over all apps 1183.7
  send_fallback_invokeblock_polymorphic_miss              apps 10  mean/op over all apps 1138.6
  send_fallback_invokeblock_not_specialized               apps 10  mean/op over all apps 530.2
  send_fallback_one_or_more_complex_arg_pass              apps 10  mean/op over all apps 420.7
  send_fallback_send_block_arg_not_nil                    apps 10  mean/op over all apps 334.1
  send_fallback_sendforward_not_specialized               apps 10  mean/op over all apps 330.8
  send_fallback_send_polymorphic                          apps 10  mean/op over all apps 321.3
  send_fallback_send_not_optimized_need_permission        apps 10  mean/op over all apps 187.9
  send_fallback_send_not_optimized_method_type_optimized  apps 10  mean/op over all apps 186.3
  setivar_fallback_no_side_exits                          apps 10  mean/op over all apps 182.1
  exit_guard_type_failure                                 apps 10  mean/op over all apps 77.4
  send_fallback_send_not_optimized_method_type            apps 10  mean/op over all apps 53.2
  setivar_fallback_not_t_object                           apps 10  mean/op over all apps 38.7
  send_fallback_super_complex_args_pass                   apps 10  mean/op over all apps 35.8
  send_fallback_invokesuperforward_not_specialized        apps 10  mean/op over all apps 27.4
  send_fallback_super_polymorphic                         apps 10  mean/op over all apps 25.0
  exit_unhandled_block_arg                                apps 10  mean/op over all apps 22.5
  send_fallback_super_from_block                          apps 10  mean/op over all apps 21.1
  send_fallback_send_no_profiles                          apps 10  mean/op over all apps 17.7
  getivar_fallback_polymorphic                            apps 10  mean/op over all apps 11.6
  send_fallback_super_call_with_block                     apps 10  mean/op over all apps 3.9
  send_fallback_super_not_optimized_method_type           apps 10  mean/op over all apps 2.8
  exit_guard_shape_failure                                apps 10  mean/op over all apps 1.1
  exit_guard_super_method_entry                           apps  9  mean/op over all apps 5.9
  exit_no_profile_send                                    apps  7  mean/op over all apps 0.1
  send_fallback_singleton_class_seen                      apps  6  mean/op over all apps 234.5
  exit_interrupt                                          apps  6  mean/op over all apps 0.1
  exit_patchpoint_stable_constant_names                   apps  5  mean/op over all apps 114.7
  getivar_fallback_megamorphic                            apps  5  mean/op over all apps 10.9
  exit_patchpoint_no_singleton_class                      apps  5  mean/op over all apps 2.2
  exit_no_profile_getivar                                 apps  5  mean/op over all apps 0.0
  exit_patchpoint_method_redefined                        apps  4  mean/op over all apps 3.0
  exit_block_arg_not_nil                                  apps  4  mean/op over all apps 0.0
  exit_guard_less_failure                                 apps  2  mean/op over all apps 0.2
  exit_guard_not_shared_failure                           apps  2  mean/op over all apps 0.2
  setivar_fallback_shape_transition                       apps  1  mean/op over all apps 0.0
  exit_no_profile_setivar                                 apps  1  mean/op over all apps 0.0
