apps: 3 (lobsters, railsbench, shipit)
per-ISEQ sums that differ from the global counter: 0

| # | counter | ISEQ | apps | mean/op | max/op (app) |
|---|---|---|---|---|---|
| 1 | `send_fallback_invokeblock_not_specialized` | `each@<internal:array>:266` | 3 | 182480.4 | 259463.1 (shipit) |
| 2 | `send_fallback_send_block_arg_not_nil` | `_read_attribute@activerecord/lib/active_record/attribute_methods/read.rb:39` | 3 | 53829.7 | 67565.0 (shipit) |
| 3 | `send_fallback_send_megamorphic` | `level@logger/lib/logger.rb:384` | 3 | 22626.0 | 51922.0 (railsbench) |
| 4 | `send_fallback_send_block_arg_not_nil` | `mon_synchronize@monitor.rb:147` | 3 | 20605.2 | 35341.2 (shipit) |
| 5 | `getivar_fallback_no_profile_missing_ic` | `hash@activemodel/lib/active_model/type/value.rb:130` | 3 | 19977.0 | 31731.0 (shipit) |
| 6 | `send_fallback_send_not_optimized_need_permission` | `block in initialize@activesupport/lib/active_support/ordered_options.rb:94` | 3 | 18846.0 | 41805.0 (railsbench) |
| 7 | `send_fallback_send_block_arg_not_nil` | `iterate_guarding_exceptions@activesupport/lib/active_support/notifications/fanout.rb:21` | 3 | 13017.3 | 21948.0 (railsbench) |
| 8 | `send_fallback_send_not_optimized_method_type_optimized` | `visit@activerecord/lib/arel/visitors/visitor.rb:27` | 3 | 12424.0 | 27562.0 (shipit) |
| 9 | `getivar_fallback_no_profile_missing_ic` | `request@actionpack/lib/action_dispatch/middleware/cookies.rb:537` | 3 | 11979.0 | 35766.0 (railsbench) |
| 10 | `send_fallback_send_megamorphic` | `level@activesupport/lib/active_support/logger_thread_safe_level.rb:36` | 3 | 11313.0 | 25961.0 (railsbench) |
| 11 | `send_fallback_send_megamorphic` | `local_level@activesupport/lib/active_support/logger_thread_safe_level.rb:16` | 3 | 11313.0 | 25961.0 (railsbench) |
| 12 | `getivar_fallback_no_side_exits` | `level_override@logger/lib/logger.rb:770` | 3 | 11313.0 | 25961.0 (railsbench) |
| 13 | `getivar_fallback_no_side_exits` | `level@logger/lib/logger.rb:384` | 3 | 11313.0 | 25961.0 (railsbench) |
| 14 | `getivar_fallback_no_profile_missing_ic` | `hash@activerecord/lib/active_record/relation/query_attribute.rb:61` | 3 | 11038.7 | 22834.0 (shipit) |
| 15 | `getivar_fallback_no_profile_missing_ic` | `url_options@actionpack/lib/action_controller/metal/url_for.rb:38` | 3 | 10948.0 | 28714.0 (railsbench) |
| 16 | `send_fallback_send_block_arg_not_nil` | `synchronize@activerecord/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb:96` | 3 | 10053.4 | 23172.2 (shipit) |
| 17 | `send_fallback_sendforward_not_specialized` | `empty?@activerecord/lib/active_record/relation/where_clause.rb:8` | 3 | 8392.7 | 22052.0 (shipit) |
| 18 | `getivar_fallback_no_profile_missing_ic` | `url_options@actionview/lib/action_view/routing_url_for.rb:125` | 3 | 7896.0 | 18114.0 (railsbench) |
| 19 | `getivar_fallback_no_profile_missing_ic` | `optimize_routes_generation?@actionview/lib/action_view/routing_url_for.rb:135` | 3 | 7467.3 | 18114.0 (railsbench) |
| 20 | `send_fallback_send_megamorphic` | `debug?@logger/lib/logger.rb:482` | 3 | 6898.0 | 13987.0 (railsbench) |
| 21 | `send_fallback_send_megamorphic` | `block in debug?@activesupport/lib/active_support/broadcast_logger.rb:142` | 3 | 6898.0 | 13987.0 (railsbench) |
| 22 | `send_fallback_invokeblock_not_specialized` | `block in each_precompressed_filepath@actionpack/lib/action_dispatch/middleware/static.rb:155` | 3 | 6474.0 | 17883.0 (railsbench) |
| 23 | `send_fallback_sendforward_not_specialized` | `current_scope@activerecord/lib/active_record/scoping.rb:77` | 3 | 6018.7 | 13742.0 (shipit) |
| 24 | `send_fallback_send_block_arg_not_nil` | `each@activesupport/lib/active_support/notifications/fanout.rb:124` | 3 | 5286.0 | 9974.0 (railsbench) |
| 25 | `send_fallback_invokeblock_not_specialized` | `loop@<internal:kernel>:153` | 3 | 5194.0 | 6970.0 (railsbench) |

Top by summed cost (any breadth):
| # | counter | ISEQ | apps | mean/op over all apps |
|---|---|---|---|---|
| 1 | `send_fallback_invokeblock_not_specialized` | `each@<internal:array>:266` | 3 | 182480.4 |
| 2 | `send_fallback_send_block_arg_not_nil` | `_read_attribute@activerecord/lib/active_record/attribute_methods/read.rb:39` | 3 | 53829.7 |
| 3 | `getivar_fallback_no_profile_missing_ic` | `<<@activerecord/lib/arel/collectors/composite.rb:21` | 2 | 44745.3 |
| 4 | `getivar_fallback_no_side_exits` | `attribute_types@activemodel/lib/active_model/attribute_registration.rb:38` | 2 | 41868.7 |
| 5 | `send_fallback_send_polymorphic_fallback` | `block in _load_from_sql@activerecord/lib/active_record/querying.rb:77` | 2 | 39758.0 |
| 6 | `getivar_fallback_no_profile_missing_ic` | `[]@activesupport/lib/active_support/isolated_execution_state.rb:32` | 1 | 37389.7 |
| 7 | `send_fallback_send_polymorphic_fallback` | `hash@activemodel/lib/active_model/type/value.rb:130` | 2 | 37154.7 |
| 8 | `send_fallback_invokeblock_not_specialized` | `map@<internal:array>:284` | 2 | 26869.0 |
| 9 | `getivar_fallback_no_profile_missing_ic` | `klass@activerecord/lib/active_record/associations/association.rb:166` | 2 | 26819.7 |
| 10 | `send_fallback_invokeblock_polymorphic_miss` | `map@<internal:array>:284` | 1 | 26549.7 |
| 11 | `getivar_fallback_no_profile_missing_ic` | `hash@activemodel/lib/active_model/attribute.rb:132` | 2 | 25375.0 |
| 12 | `getivar_fallback_no_side_exits` | `block in fetch_value@activemodel/lib/active_model/attribute_set/builder.rb:47` | 1 | 24770.0 |
| 13 | `send_fallback_send_megamorphic` | `level@logger/lib/logger.rb:384` | 3 | 22626.0 |
| 14 | `send_fallback_send_block_arg_not_nil` | `mon_synchronize@monitor.rb:147` | 3 | 20605.2 |
| 15 | `getivar_fallback_no_side_exits` | `_read_attribute@activerecord/lib/active_record/attribute_methods/read.rb:39` | 2 | 20181.2 |
| 16 | `getivar_fallback_no_profile_missing_ic` | `hash@activemodel/lib/active_model/type/value.rb:130` | 3 | 19977.0 |
| 17 | `send_fallback_send_not_optimized_need_permission` | `block in initialize@activesupport/lib/active_support/ordered_options.rb:94` | 3 | 18846.0 |
| 18 | `getivar_fallback_no_side_exits` | `stale_state@activerecord/lib/active_record/associations/belongs_to_association.rb:167` | 2 | 16624.0 |
| 19 | `getivar_fallback_no_profile_missing_ic` | `block in fetch_value@activemodel/lib/active_model/attribute_set/builder.rb:47` | 1 | 14021.0 |
| 20 | `send_fallback_one_or_more_complex_arg_pass` | `fetch_header@rack/lib/rack/request.rb:107` | 1 | 13935.0 |
| 21 | `getivar_fallback_no_profile_missing_ic` | `==@activemodel/lib/active_model/type/value.rb:122` | 2 | 13234.0 |
| 22 | `getivar_fallback_no_profile_missing_ic` | `==@activemodel/lib/active_model/attribute.rb:124` | 2 | 13234.0 |
| 23 | `send_fallback_send_block_arg_not_nil` | `iterate_guarding_exceptions@activesupport/lib/active_support/notifications/fanout.rb:21` | 3 | 13017.3 |
| 24 | `exit_patchpoint_stable_constant_names` | `connection_specification_name@activerecord/lib/active_record/connection_handling.rb:320` | 1 | 12822.0 |
| 25 | `send_fallback_send_polymorphic_fallback` | `current_shard@activerecord/lib/active_record/core.rb:177` | 2 | 12562.0 |

Reasons by apps reached (counter summed over ISEQs):
  getivar_fallback_no_profile_missing_ic                  apps  3  mean/op over all apps 459420.9
  send_fallback_send_polymorphic_fallback                 apps  3  mean/op over all apps 312214.7
  send_fallback_invokeblock_not_specialized               apps  3  mean/op over all apps 261534.7
  getivar_fallback_no_side_exits                          apps  3  mean/op over all apps 212767.3
  send_fallback_send_block_arg_not_nil                    apps  3  mean/op over all apps 138811.2
  send_fallback_send_megamorphic                          apps  3  mean/op over all apps 133561.2
  send_fallback_one_or_more_complex_arg_pass              apps  3  mean/op over all apps 76212.9
  send_fallback_sendforward_not_specialized               apps  3  mean/op over all apps 69287.1
  send_fallback_send_not_optimized_method_type_optimized  apps  3  mean/op over all apps 45942.3
  send_fallback_invokeblock_polymorphic_miss              apps  3  mean/op over all apps 40801.4
  send_fallback_send_not_optimized_need_permission        apps  3  mean/op over all apps 33754.5
  send_fallback_super_complex_args_pass                   apps  3  mean/op over all apps 16598.7
  send_fallback_send_polymorphic                          apps  3  mean/op over all apps 15485.3
  send_fallback_send_not_optimized_method_type            apps  3  mean/op over all apps 15463.0
  exit_patchpoint_stable_constant_names                   apps  3  mean/op over all apps 12832.8
  send_fallback_invokesuperforward_not_specialized        apps  3  mean/op over all apps 9726.7
  setivar_fallback_not_t_object                           apps  3  mean/op over all apps 5565.0
  send_fallback_super_from_block                          apps  3  mean/op over all apps 3371.3
  send_fallback_super_polymorphic                         apps  3  mean/op over all apps 2811.0
  send_fallback_super_call_with_block                     apps  3  mean/op over all apps 2077.3
  exit_guard_type_failure                                 apps  3  mean/op over all apps 1354.8
  send_fallback_super_not_optimized_method_type           apps  3  mean/op over all apps 963.7
  exit_unhandled_block_arg                                apps  3  mean/op over all apps 816.7
  setivar_fallback_no_side_exits                          apps  2  mean/op over all apps 2094.1
  getivar_fallback_polymorphic                            apps  2  mean/op over all apps 895.1
