require "sqlite3"
require "objspace"
require "json"

native = $LOADED_FEATURES.grep(/sqlite3_native\.so$/)
abort "wrong native extension: #{native.inspect}" unless native == [File.join(ENV.fetch("TREE"), "lib/sqlite3/sqlite3_native.so")]
db = SQLite3::Database.new(":memory:")
rows = [1, 2, 3, 4, 7, 8, 15, 16, 17, 31, 32, 33, 80, 81, 127, 128, 129, 2000].map do |width|
  expected = Array.new(width) { |i| (i + 1) * -100_003 }
  stmt = db.prepare("SELECT #{expected.join(',')}")
  stmt.step
  stmt.reset!
  GC.start
  GC.disable
  before = GC.stat(:malloc_increase_bytes)
  result = stmt.step
  allocated = GC.stat(:malloc_increase_bytes) - before
  GC.enable
  abort "wrong values or freeze" unless result == expected && result.frozen?
  details = JSON.parse(ObjectSpace.dump(result))
  observation = {width: width, memsize: ObjectSpace.memsize_of(result), embedded: details["embedded"] == true, malloc_increase: allocated}
  GC.compact
  abort "lost result after compaction" unless result == expected
  stmt.close
  observation
end
db.close
puts JSON.generate(ruby: RUBY_DESCRIPTION, sqlite: SQLite3::SQLITE_VERSION, rows: rows)
