require "json"
require "digest"
require "time"
load "/home/user/workspace/repo/bench/upstream/driver_cpu/sqlite_bind_cases.rb"
tree = File.realpath(ENV.fetch("EXPECTED_SQLITE"))
feature = $LOADED_FEATURES.grep(/sqlite3_native\.so$/).fetch(0)
raise feature unless File.realpath(feature).start_with?(tree + "/")

def snapshot(value)
  case value
  when ActiveRecord::Base then snapshot(value.attributes)
  when String then [value.class.name, value.bytes, value.encoding.name, value.frozen?]
  when Time then [value.class.name, value.iso8601(9), value.utc_offset]
  when Array then [value.frozen?, value.map { snapshot(_1) }]
  when Hash then value.map { |key, item| [snapshot(key), snapshot(item)] }
  else [value.class.name, value.to_s]
  end
end

observations = MICRO.map do |name, factory|
  work = factory.call
  first = work.call
  GC.verify_compaction_references(double_heap: true, toward: :empty)
  before = snapshot(first)
  second = work.call
  GC.verify_compaction_references(double_heap: true, toward: :empty)
  [name, before, snapshot(first), snapshot(second)]
end
data = JSON.generate(observations)
puts JSON.generate(cases: observations.size, sha256: Digest::SHA256.hexdigest(data))
