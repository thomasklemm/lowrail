| App | Workloads | connection_pool objects/op | cp | A/A | All objects/op | cp all | A/A all |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| campfire | 9 | 8.0 | −2.7 | +0.0 | 5696 | −2.6 | +0.0 |
| writebook | 8 | 7.5 | −2.5 | +0.0 | 4936 | −2.4 | +0.0 |
| codetriage | 7 | 12.0 | −4.0 | +0.0 | 2582 | −1.7 | +0.0 |
| docuseal | 13 | 2.8 | −0.9 | +0.0 | 7190 | −2.2 | +0.0 |
| mastodon | 14 | 83.2 | −27.6 | +0.0 | 15884 | −27.8 | +0.0 |
| mastodon-nops | 14 | 83.2 | −27.6 | +0.0 | 15838 | −27.4 | +0.0 |
| loomio | 15 | 0.8 | −0.3 | +0.0 | 9231 | +28.5 | +0.0 |
| flow | 10 | 10.8 | −3.4 | +0.0 | 9908 | +2.0 | +0.0 |
| **All (18 configurations)** | 194 | 13.9 | −4.6 | +0.0 | 8176 | −0.2 | +0.0 |
reached (own delta <= -0.5): 7 configurations, 6 apps; share of all allocations removed: 0.056%
