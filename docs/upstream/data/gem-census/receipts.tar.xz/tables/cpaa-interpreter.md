| App | Workloads | connection_pool objects/op | g | A/A | All objects/op | g all | A/A all |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| campfire | 9 | 4.7 | +0.0 | +0.0 | 5672 | −0.1 | −0.1 |
| writebook | 8 | 4.4 | +0.0 | +0.0 | 4895 | +0.6 | +0.6 |
| codetriage | 7 | 7.0 | +0.0 | +0.0 | 2554 | +0.5 | +0.5 |
| docuseal | 13 | 1.6 | +0.0 | +0.0 | 7131 | −1.4 | −1.4 |
| mastodon | 14 | 48.4 | +0.0 | +0.0 | 15743 | +0.0 | +0.0 |
| mastodon-nops | 14 | 48.4 | +0.0 | +0.0 | 15697 | −0.2 | −0.2 |
| loomio | 15 | 0.5 | +0.0 | +0.0 | 9083 | −6.3 | −6.3 |
| flow | 10 | 6.3 | +0.0 | +0.0 | 9740 | +15.7 | +15.7 |
| **All (18 configurations)** | 194 | 8.1 | +0.0 | +0.0 | 8101 | −24.7 | −24.7 |
reached (own delta <= -0.5): 0 configurations, 0 apps; share of all allocations removed: -0.000%
