| App | Workloads | connection_pool objects/op | g | A/A | All objects/op | g all | A/A all |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| campfire | 9 | 4.7 | +0.0 | +0.0 | 5692 | +0.0 | +0.0 |
| writebook | 8 | 4.4 | +0.0 | +0.0 | 4931 | +0.8 | +0.8 |
| codetriage | 7 | 7.0 | +0.0 | +0.0 | 2576 | +1.2 | +1.2 |
| docuseal | 13 | 1.6 | +0.0 | +0.0 | 7189 | −2.5 | −2.5 |
| mastodon | 14 | 48.4 | +0.0 | +0.0 | 15843 | −0.5 | −0.5 |
| mastodon-nops | 14 | 48.4 | +0.0 | +0.0 | 15796 | +0.2 | +0.2 |
| loomio | 15 | 0.5 | +0.0 | +0.0 | 9180 | −12.3 | −12.3 |
| flow | 10 | 6.3 | +0.0 | +0.0 | 9900 | +4.8 | +4.8 |
| **All (18 configurations)** | 194 | 8.1 | +0.0 | +0.0 | 8164 | −1.7 | −1.7 |
reached (own delta <= -0.5): 0 configurations, 0 apps; share of all allocations removed: -0.000%
