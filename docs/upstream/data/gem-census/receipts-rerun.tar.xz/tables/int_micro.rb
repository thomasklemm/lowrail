$LOAD_PATH.unshift(File.expand_path(ARGV.fetch(0)))
require "i18n"; require "i18n/backend/fallbacks"
I18n::Backend::Simple.include(I18n::Backend::Fallbacks)
I18n.available_locales = %i[en de]; I18n.default_locale = :en
I18n.fallbacks = I18n::Locale::Fallbacks.new(de: :en)
I18n.backend.store_translations(:en, number: { precision: 2 })
[["Integer default, hit", proc { I18n.t(:"number.precision", default: 3) }], ["Integer default, missing key", proc { I18n.t(:"number.missing", default: 3) }]].each do |n, c|
  100.times(&c); GC.disable; b = GC.stat(:total_allocated_objects); 1000.times(&c); a = GC.stat(:total_allocated_objects); GC.enable
  puts format("%-30s %.2f", n, (a - b) / 1000.0)
end
