# Differential: master's extract_non_symbol_default! against the working tree's.
require "i18n"
require "i18n/backend/fallbacks"
OLD = Module.new do
  module_eval(File.read(ARGV.fetch(0))[/^      def extract_non_symbol_default!.*?^      end\n/m])
end
NEW = Module.new do
  const_set(:FLATTEN, Array.instance_method(:flatten))
  module_eval(File.read(ARGV.fetch(1))[/^      def extract_non_symbol_default!.*?^      end\n/m])
end
$log = []
def mk(&b) = Object.new.tap { _1.instance_eval(&b) }
Sub = Class.new(Array) { def flatten(*) = ($log << :sub_flatten; ["overridden"]) }
cases = {
  sym: -> { :a }, str: -> { +"s" }, frozen_str: -> { "s".freeze }, hash: -> { { other: "x" } }, proc: -> { proc { "p" } },
  int: -> { 5 }, flat: -> { [:a, :b, "c", :d] }, flat_syms: -> { [:a, :b] }, nested: -> { [[:a, ["b"]], :c] },
  frozen: -> { [:a, "b"].freeze }, long: -> { (1..20).map { :"k#{_1}" } + ["x"] }, sub: -> { Sub[:a, "b"] },
  nested_sub: -> { [Sub[:a, "b"]] },
  str_to_ary: -> { s = +"literal"; def s.to_ary = ($log << :to_ary; [:alternate, "converted"]); s },
  hash_to_ary: -> { h = { a: 1 }; def h.to_ary = ($log << :to_ary; [:alt]); h },
  str_mm: -> { s = +"literal"; def s.method_missing(n, *a) = n == :to_ary ? ($log << :mm; [:alt, "mm"]) : super; s },
  str_rt_false: -> { s = +"literal"; def s.to_ary = [:x]; def s.respond_to?(n, p = false) = n == :to_ary ? false : super; s },
  str_rtm_true: -> { s = +"literal"; def s.respond_to_missing?(n, p) = n == :to_ary || super; s },
  private_to_ary: -> { mk { def self.to_ary = [:p, "q"]; singleton_class.send(:private, :to_ary) } },
  to_ary_nil: -> { mk { def self.to_ary = ($log << :to_ary; nil) } },
  to_ary_bad: -> { mk { def self.to_ary = 5 } },
  to_ary_nested: -> { mk { def self.to_ary = [[:a], mk2 = Object.new.tap { |o| def o.to_ary = [:z, "w"] }] } },
  is_a_liar: -> { mk { def self.is_a?(c) = ($log << :is_a; c == Symbol || super) } },
  elem_liar: -> { [mk { def self.is_a?(c) = ($log << :is_a; c == Symbol || super) }, "x"] },
  recursive: -> { a = [:a]; a << a; a },
  recursive_inner: -> { a = [:a]; a << a; [a] },
}
fails = 0
cases.each do |name, make|
  res = [OLD, NEW].map do |m|
    $log = []
    obj = Object.new.extend(m)
    d = make.()
    opts = { default: d, x: 1 }
    out = begin
      r = obj.send(:extract_non_symbol_default!, opts)
      [:ok, r.inspect.gsub(/0x\h+/, "0x"), r.equal?(d) ? :same : :other, opts.inspect.gsub(/0x\h+/, "0x"), opts[:default].equal?(d)]
    rescue => e
      [:raise, e.class, e.message]
    end
    [out, $log]
  end
  ok = res[0] == res[1]
  fails += 1 unless ok
  puts "#{ok ? "same" : "DIFF"} #{name}#{ok ? "" : "\n  old #{res[0].inspect}\n  new #{res[1].inspect}"}"
end
puts "#{cases.size} cases, #{fails} differ"
