require "/home/user/workspace/repo/bench/upstream/census/harness"
name = ARGV.fetch(0)
RailsCensus.boot(name)
ops = RailsCensus.workloads(name)
seen = Hash.new(0)
mod = Module.new do
  define_method(:extract_non_symbol_default!) do |options|
    d = options[:default]
    conv = d.is_a?(Array) ? "Array" : (Array.try_convert(d) ? "converts" : "no-convert")
    seen["#{d.class} (#{conv}) caller=#{caller_locations(3, 6).map { _1.to_s[/[^\/]+\/[^\/]+:\d+/] }.find { !_1.to_s.start_with?("i18n") }}"] += 1
    super(options)
  end
end
I18n::Backend::Fallbacks.prepend(mod)
ops.each { |op| op.call.call; RailsCensus.reset_side_effects }
seen.sort_by { -_2 }.first(8).each { |k, n| puts "#{n} #{k}" }
