def load_variant(path, name)
  src = File.read(path)
  eval(src.sub("module ActionDispatch", "module #{name}"), TOPLEVEL_BINDING, path)
  Object.const_get(name)::Journey::Router::Utils
end
which = ARGV[0]
U = load_variant(File.expand_path("~/w/wt/#{which}/actionpack/lib/action_dispatch/journey/router/utils.rb"), "X")
Regexp.timeout = Float(ARGV[1])
n = Integer(ARGV[2])
s = "a" * n
res = 5.times.map do
  t = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  r = begin; x = U.escape_segment(s); "ok(equal?=#{x.equal?(s)})"; rescue Regexp::TimeoutError => e; "#{e.class}: #{e.message}"; end
  "#{r} #{((Process.clock_gettime(Process::CLOCK_MONOTONIC)-t)*1000).round}ms"
end
puts "#{which}: #{res.uniq.size==1 ? res.first : res.inspect}"
puts res
