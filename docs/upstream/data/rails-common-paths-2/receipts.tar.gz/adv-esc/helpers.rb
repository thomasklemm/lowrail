require "bundler/setup"
RAILS = ENV.fetch("RAILS")
%w[activesupport actionpack actionview activemodel].each { |c| $LOAD_PATH.unshift File.join(RAILS, c, "lib") }
require "action_controller"; require "action_view"; require "rack/mock"
ROUTES = ActionDispatch::Routing::RouteSet.new
ROUTES.draw do
  get "/pages/:slug", to: "pages#show", as: :page
  get "/files/*path", to: "f#s", as: :file
  get "/r/:id", to: redirect("/to/%{id}#%{id}")
  get "/g/*rest", to: redirect(path: "/x/%{rest}")
  get "/b/:id", to: redirect { |p, _| "/blk/#{p[:id]}" }
end
class Ctx; include ROUTES.url_helpers; def default_url_options = { host: "example.com" }; end
C = Ctx.new
class Sub < String; end
class ToP; def initialize(v) = @v = v; def to_param = @v; end
vals = ["abc", "a b", "a/b", "é", "a\n", "a\r\n", "a\0b", "\xff".b, Sub.new("ok"), Sub.new("o k"), "fz".freeze, ActiveSupport::SafeBuffer.new("s b"), ActiveSupport::SafeBuffer.new("sb"),
        :sym, :"s y", 42, 1.5, ToP.new("tp"), ToP.new(Sub.new("t p")), ToP.new(:ts), "a"*5000, "a"*5000+" ", ("abc").encode("UTF-16LE"), "a?b#c%d"]
vals.each do |v|
  out = %i[page_path file_path].map { |h| r = C.public_send(h, v) rescue (next "#{$!.class}: #{$!.message[0,80]}"); [r[0,60], r.encoding, r.class] }
  out << (C.page_url("x", anchor: v) rescue "#{$!.class}")[0,60]
  puts "#{v.inspect[0,30]} => #{out.inspect}"
end
app = ROUTES
["/r/abc", "/r/a%20b", "/r/%C3%A9", "/r/a%2Fb", "/g/a/b%20c/d", "/r/%FF", "/g/%FF/x", "/r/a%0Ab", "/b/a%20b"].each do |path|
  s, h, _ = app.call(Rack::MockRequest.env_for("http://example.com#{path}")) rescue (puts "#{path} => #{$!.class}"; next)
  puts "#{path} => #{s} #{h['Location'] || h['location']}"
end
