U = "\\-[:alnum:]._~"; S = "!$&'()*+,;="
NEG  = /[^#{U}#{S}:@]/
STAR = /\A[#{U}#{S}:@]*\z/
POSS = /\A[#{U}#{S}:@]*+\z/
def t(re, s, neg) = (t0 = Process.clock_gettime(Process::CLOCK_MONOTONIC); 5.times { neg ? s.match?(re) : s.match?(re) }; ((Process.clock_gettime(Process::CLOCK_MONOTONIC) - t0) / 5 * 1e3).round(3))
[25, 65536, 1 << 20, 10_000_000].each do |n|
  s = "a" * n; u = "a" * (n - 1) + " "
  raise unless [NEG, STAR, POSS].map { |r| r == NEG ? !s.match?(r) : s.match?(r) }.uniq == [true]
  raise unless [!u.match?(NEG), u.match?(STAR), u.match?(POSS)].uniq == [false]
  puts "n=#{n} safe: neg #{t(NEG, s, 1)} ms  star #{t(STAR, s, nil)} ms  poss #{t(POSS, s, nil)} ms | unsafe-last: neg #{t(NEG, u, 1)}  star #{t(STAR, u, nil)}  poss #{t(POSS, u, nil)}"
end
