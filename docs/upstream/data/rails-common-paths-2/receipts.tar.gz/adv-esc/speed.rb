require "benchmark"
B = { seg: /[^a-zA-Z0-9\-\._~!\$&'\(\)\*\+,;=:@]/ }
N = { seg: /\A[a-zA-Z0-9\-\._~!\$&'\(\)\*\+,;=:@]*\z/ }
[["a"*10_000_000,"ascii"],[("a"*10_000_000).force_encoding("UTF-8"),"utf8"],["a"*10_000_000+"é","utf8-end"],[("a"*10_000_000).b,"bin"]].each do |s,k|
  s.match?(/x/) # coderange
  tb = Benchmark.realtime { s.match?(B[:seg]) }
  tn = Benchmark.realtime { s.match?(N[:seg]) }
  puts "#{k}: main #{(tb*1000).round(2)}ms cand #{(tn*1000).round(2)}ms"
end
