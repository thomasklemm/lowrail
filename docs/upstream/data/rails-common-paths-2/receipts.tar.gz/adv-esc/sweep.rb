B = /[^a-zA-Z0-9\-\._~!\$&'\(\)\*\+,;=:@]/
N = /\A[a-zA-Z0-9\-\._~!\$&'\(\)\*\+,;=:@]*\z/
[8, 32, 128, 512, 4096, 65536].each do |n|
  s = "a" * n; it = [2_000_000 / n, 200].max * 10
  t = ->(re) { x = Process.clock_gettime(Process::CLOCK_MONOTONIC); it.times { s.match?(re) }; (Process.clock_gettime(Process::CLOCK_MONOTONIC) - x) / it * 1e9 }
  t.(B); t.(N)
  puts "n=#{n}: main #{t.(B).round(1)}ns cand #{t.(N).round(1)}ns"
end
