load "/tmp/review-esc/load.rb"
cases = []
safe = "abcAZ09-._~!$&'()*+,;=:@/?"
[0,1,2,3,63,64,65,127,128,129,255,256,1000,4095,4096,4097,65536,100_000].each do |n|
  base = ("a" * n)
  ["\n","\r\n","\0"," ","%","#","é","\xff".b,"\xff","\u3042","\r","[","\\","^"].each do |u|
    [0, n/2, n].uniq.each do |pos|
      s = base.dup; s.insert(pos, u) rescue (s = base.b.insert(pos, u.b))
      cases << s
      cases << s.dup.force_encoding("UTF-8")
      cases << s.b
      cases << s.dup.force_encoding("US-ASCII")
      cases << (s + "\n")
      cases << s.frozen? ? s : s.dup.freeze
    end
  end
  cases << base << base + "\n" << base + "\r\n" << (safe * (n/27 + 1))
end
# encodings with ascii-only content
Encoding.list.each { |e| ["abc", "a b", "", "a\n", "a/b"].each { |s| cases << s.dup.force_encoding(e) } }
# subclass / safebuffer-like
class MyStr < String; end
cases << MyStr.new("abc") << MyStr.new("a b") << MyStr.new("a\n")
mism = 0; total = 0
cases.each do |s|
  METHODS.each do |m|
    total += 1
    b = outcome(B, m, s.dup); n = outcome(N, m, s.dup)
    # identity: compare equal?-to-input with the same object
    b2 = outcome(B, m, s); n2 = outcome(N, m, s)
    if b != n || b2 != n2
      mism += 1; puts "MISMATCH #{m} #{s.inspect[0,80]} #{s.encoding}: #{b.inspect[0,200]} vs #{n.inspect[0,200]}" if mism < 20
    end
  end
end
puts "cases=#{total} mismatches=#{mism}"
