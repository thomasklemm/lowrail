B = /[^a-zA-Z0-9\-\._~!\$&'\(\)\*\+,;=:@]/
N = /\A[a-zA-Z0-9\-\._~!\$&'\(\)\*\+,;=:@]*\z/
Regexp.timeout = 100.0 if ARGV[0] == "to"
[65536, 262144, 1<<20, 4<<20, 10_000_000].each do |n|
  s = "a" * n; it = [20_000_000 / n, 3].max
  t = ->(re) { x = Process.clock_gettime(Process::CLOCK_MONOTONIC); it.times { s.match?(re) }; (Process.clock_gettime(Process::CLOCK_MONOTONIC) - x) / it * 1e3 }
  t.(B); t.(N)
  puts "#{ARGV[0]} n=#{n}: main #{t.(B).round(2)}ms cand #{t.(N).round(2)}ms"
end
