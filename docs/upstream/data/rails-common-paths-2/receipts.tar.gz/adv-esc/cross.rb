U = "\\-[:alnum:]._~"; S = "!$&'()*+,;="
NEG  = /[^#{U}#{S}:@]/
STAR = /\A[#{U}#{S}:@]*\z/
def t(n) = (s = "a" * n; r = [NEG, STAR].map { |re| best = 1e9; 7.times { t0 = Process.clock_gettime(Process::CLOCK_MONOTONIC, :nanosecond); s.match?(re); best = [best, Process.clock_gettime(Process::CLOCK_MONOTONIC, :nanosecond) - t0].min }; best }; r)
[1000, 8192, 32768, 131072, 262144, 393216, 524288, 786432].each { |n| a, b = t(n); puts "n=#{n} neg #{(a/1e3).round(1)} us  anchored #{(b/1e3).round(1)} us  ratio #{(b.fdiv(a)).round(2)}" }
