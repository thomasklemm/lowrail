require "bundler/setup"
RAILS = ENV.fetch("RAILS")
%w[activesupport actionpack actionview activemodel].each { |c| $LOAD_PATH.unshift File.join(RAILS, c, "lib") }
Warning[:experimental] = false
require "action_dispatch"
require "action_dispatch/journey"
U = ActionDispatch::Journey::Router::Utils
E = U::UriEncoder
p shareable: %i[FRAGMENT SEGMENT PATH SAFE_FRAGMENT SAFE_SEGMENT SAFE_PATH].select { E.const_defined?(_1) }.to_h { [_1, Ractor.shareable?(E.const_get(_1))] }, enc: Ractor.shareable?(U::ENCODER)
r = Ractor.new do
  u = ActionDispatch::Journey::Router::Utils
  s = "abc".freeze
  [u.escape_segment("a b/c"), u.escape_path("a b/c"), u.escape_fragment("a b?#"), u::ENCODER.escape_segment(s).equal?(s),
   ActionDispatch::Journey::Format::ESCAPE_SEGMENT.call("x y"), (u.escape_segment("\xff".dup.force_encoding("UTF-8")) rescue $!.class)]
end
p(r.respond_to?(:value) ? r.value : r.take)
