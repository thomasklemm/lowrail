def load_variant(path, name)
  src = File.read(path)
  eval(src.sub("module ActionDispatch", "module #{name}"), TOPLEVEL_BINDING, path)
  Object.const_get(name)::Journey::Router::Utils
end
B = load_variant(File.expand_path("~/w/wt/main/actionpack/lib/action_dispatch/journey/router/utils.rb"), "BaseNS")
N = load_variant(File.expand_path("~/w/wt/esc/actionpack/lib/action_dispatch/journey/router/utils.rb"), "NewNS")
def run(u, m, s)
  t = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  r = u::ENCODER.public_send(m, s)
  [:ok, r.bytesize, (Process.clock_gettime(Process::CLOCK_MONOTONIC)-t).round(4)]
rescue Exception => e
  [:raise, e.class, (Process.clock_gettime(Process::CLOCK_MONOTONIC)-t).round(4)]
end
Regexp.timeout = Float(ARGV[0])
[1_000, 100_000, 1_000_000, 10_000_000].each do |n|
  { "safe"=>"a"*n, "safe_utf8"=>("a"*n).force_encoding("UTF-8"), "safe_nonascii_end"=>"a"*n+"é", "unsafe_end"=>"a"*n+" ", "binary_end"=>("a"*n+"\xff").b, "slash_seg"=>"a/"*(n/2) }.each do |k, s|
    s = s.dup
    %i[escape_segment escape_path escape_fragment].each do |m|
      b = run(B, m, s); c = run(N, m, s)
      puts [n, k, m, b, c, (b[0..1]==c[0..1] ? "" : "DIFF")].inspect
    end
  end
end
