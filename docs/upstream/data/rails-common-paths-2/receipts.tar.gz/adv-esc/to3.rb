def load_variant(path, name)
  src = File.read(path)
  eval(src.sub("module ActionDispatch", "module #{name}"), TOPLEVEL_BINDING, path)
  Object.const_get(name)::Journey::Router::Utils
end
which, to, n, m = ARGV[0], Float(ARGV[1]), Integer(ARGV[2]), (ARGV[3] || "escape_segment")
U = load_variant(File.expand_path("~/w/wt/#{which}/actionpack/lib/action_dispatch/journey/router/utils.rb"), "X")
Regexp.timeout = to
s = "a" * n
ok = 0; err = 0
(ENV["T"]||20).to_i.times { begin; U.public_send(m, s); ok += 1; rescue Regexp::TimeoutError; err += 1; end }
puts "#{RUBY_VERSION} #{which} #{m} timeout=#{to} n=#{n}: ok=#{ok} TimeoutError=#{err}"
