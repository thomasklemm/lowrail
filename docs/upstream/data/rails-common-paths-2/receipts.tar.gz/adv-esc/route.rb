require "bundler/setup"
RAILS = ENV.fetch("RAILS")
%w[activesupport actionpack actionview activemodel].each { |c| $LOAD_PATH.unshift File.join(RAILS, c, "lib") }
require "action_controller"
require "action_view"
ROUTES = ActionDispatch::Routing::RouteSet.new
ROUTES.draw { get "/pages/:slug", to: "pages#show", as: :page; get "/files/*path", to: "f#s", as: :file }
class Ctx; include ROUTES.url_helpers; def default_url_options = { host: "example.com" }; end
C = Ctx.new
C.page_path("warm"); C.file_path("a/b"); C.page_url("x", anchor: "y")
Regexp.timeout = Float(ARGV[0]); n = Integer(ARGV[1])
slug = "a" * n
{ page_path: -> { C.page_path(slug) }, file_path: -> { C.file_path(slug) }, anchor: -> { C.page_url("x", anchor: slug) } }.each do |k, f|
  ok = err = 0
  10.times { begin; f.(); ok += 1; rescue Regexp::TimeoutError; err += 1; end }
  puts "#{File.basename(RAILS)} #{k}: ok=#{ok} TimeoutError=#{err}"
end
