U = "a-zA-Z0-9\\-\\._~"; S = "!\\$&'\\(\\)\\*\\+,;="
NEG = /[^#{U}#{S}:@]/; ANCH = /\A[#{U}#{S}:@]*\z/
GC.disable
[8, 25, 50, 100, 200, 500, 1000, 5000].each do |n|
  s = "a" * n
  r = [NEG, ANCH].map { |re| 3.times { s.match?(re) }; b = GC.stat(:malloc_increase_bytes); 100.times { s.match?(re) }; (GC.stat(:malloc_increase_bytes) - b) / 100 }
  puts "n=#{n} malloc bytes per match: neg=#{r[0]} anchored=#{r[1]}"
end
