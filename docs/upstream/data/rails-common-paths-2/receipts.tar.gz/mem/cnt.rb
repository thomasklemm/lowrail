NEG = /[^a-zA-Z0-9\-\._~!\$&'\(\)\*\+,;=:@]/
CH  = "a-zA-Z0-9._~!$&'()*+,;=:@-"
t = ->(s) { begin; [!s.match?(NEG)]; rescue => e; [e.class, e.message]; end }
c = ->(s) { begin; [s.count(CH) == s.bytesize]; rescue => e; [e.class, e.message]; end }
cases = ["", "abc", "a b", "é", "a\n", "abc\xFF".dup.force_encoding("UTF-8"), "abc".encode("UTF-16LE"), "a b".encode("UTF-16LE"), "\xFF".b, "abc".encode("UTF-32BE"), "a-b".encode("Shift_JIS"), "^", "\\", "-"]
cases.each { |s| a, b = t.(s), c.(s); puts "#{a == b ? "same" : "DIFF"} #{s.inspect} #{s.encoding}: #{a.inspect} vs #{b.inspect}" }
diff = 0; (0..255).each { |x| s = x.chr; diff += 1 if t.(s) != c.(s) }; puts "single bytes diff=#{diff}"
