%w[activesupport activemodel].each { |g| $LOAD_PATH.unshift File.join(ARGV[0], g, "lib") }
require "active_model"
class P; include ActiveModel::Attributes; attribute :name, :string; alias_attribute :nick, :name; end
n = 3_000_000
GC.disable
[:name, "name", :nick].each do |k|
  t = Process.clock_gettime(Process::CLOCK_MONOTONIC); i = 0
  while i < n; P.send(:resolve_attribute_name, k); i += 1; end
  printf("%-6s %.1f ns/call\n", k.inspect, (Process.clock_gettime(Process::CLOCK_MONOTONIC) - t) * 1e9 / n)
end
