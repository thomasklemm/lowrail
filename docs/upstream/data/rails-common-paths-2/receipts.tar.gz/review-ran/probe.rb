root = ARGV[0]
%w[activesupport activemodel].each { |g| $LOAD_PATH.unshift File.join(root, g, "lib") }
require "active_model"
def r(k, n) = (k.send(:resolve_attribute_name, n) rescue "#{$!.class}: #{$!.message}")
calls = []
class P; include ActiveModel::Attributes; attribute :name, :string; alias_attribute :nick, :name; end
out = {}
out[:sym]   = r(P, :nick).inspect
out[:str]   = r(P, "nick").inspect
out[:miss]  = r(P, :zzz).inspect
s = "zzz"; out[:identity_str] = r(P, s).equal?(s)
class MyStr < String; def itself = (raise "itself called"); end
out[:sub] = r(P, MyStr.new("zzz")).class
o = Object.new; def o.to_s = "nick"; out[:obj] = r(P, o)
# to_s returns non-String with singleton itself
w = Object.new; tgt = Object.new; def tgt.itself = (:custom_itself); w.define_singleton_method(:to_s) { tgt }
out[:to_s_nonstring_itself] = r(P, w).inspect[0,40]
n = Object.new; def n.to_s = nil; out[:to_s_nil] = r(P, n).inspect
b = Object.new; bs = BasicObject.new; b.define_singleton_method(:to_s){ bs }; out[:basic] = r(P, b)
# public writer: default proc / falsy / subclass
class Q; include ActiveModel::Attributes; end
Q.attribute_aliases = Hash.new { |h, k| "dflt" }.freeze
out[:default_proc] = r(Q, :x).inspect
Q.attribute_aliases = Hash.new("dflt2")
out[:default_val] = r(Q, :x).inspect
Q.attribute_aliases = { "x" => nil, "y" => false }
out[:falsy_nil] = r(Q, :x).inspect; out[:falsy_false] = r(Q, :y).inspect
class H < Hash; def fetch(k, *) = "fetch"; def [](k) = "brackets"; end
Q.attribute_aliases = H.new
out[:hash_sub] = r(Q, :x).inspect
out[:frozen_result] = r(P, :zzz).frozen?
out.each { |k, v| puts "#{k}: #{v}" }
