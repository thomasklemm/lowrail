import sys,re
f,cls,kind=sys.argv[1:]; s=open(f).read()
line=re.search(r"^ *SAFE_%s *= .*$"%cls, s, re.M).group(0)
m={"caret":line.replace("\\A","^"),"z_dollar":line.replace("\\z","$"),"add_e":line.replace("]*","é]*"),
   "add_space":line.replace("]*"," ]*"),"drop_a":line.replace("#{UNRESERVED}","b-zA-Z0-9\\-\\._~"),
   "drop_tilde":line.replace("#{UNRESERVED}","a-zA-Z0-9\\-\\._"),"plus":line.replace("]*","]+")}[kind]
assert m!=line; open(f,"w").write(s.replace(line,m))
