require "bundler/setup"
R = ENV.fetch("RAILS"); %w[activesupport actionpack].each { $LOAD_PATH.unshift File.join(R, _1, "lib") }
require "action_dispatch"; require "active_support/core_ext/string/output_safety"
U = ActionDispatch::Journey::Router::Utils
f = "abc".dup.force_encoding("UTF-8").freeze
r = U.escape_segment(f); p [:frozen, r.equal?(f), r.frozen?, r.encoding]
sb = ActiveSupport::SafeBuffer.new("abc"); r = U.escape_segment(sb); p [:safebuf, r.equal?(sb), r.html_safe?]
e = ""; p [:empty, U.escape_segment(e).equal?(e)]
t = +"a b"; def t.match?(*) = true;  p [:always_true,  U.escape_segment(t)]
u = +"a b"; def u.match?(*) = false; p [:always_false, U.escape_segment(u)]
