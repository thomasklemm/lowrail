require "bundler/setup"
require_relative File.expand_path("~/w/scratch/setup")
class P1 < ActiveRecord::Base; self.table_name = "posts"; end
n = Object.new
def n.to_s; P1.alias_attribute(:headline, :title) unless P1.attribute_aliases.key?("headline"); "headline"; end
p P1.type_for_attribute(n).type
class P2 < ActiveRecord::Base; self.table_name = "posts"; end
P2.attribute_aliases = Hash.new("title"); p(P2.type_for_attribute("x").type) rescue p $!
class P3 < ActiveRecord::Base; self.table_name = "posts"; end
P3.attribute_aliases = { "title" => nil }; p(P3.type_for_attribute("title").type) rescue p $!
class P4 < ActiveRecord::Base; self.table_name = "posts"; end
P4.attribute_aliases = Hash.new { raise "boom" }; p(P4.type_for_attribute("title").type) rescue p $!
