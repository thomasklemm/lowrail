# frozen_string_literal: true

require "abstract_unit"

module ActionDispatch
  module Journey
    class Router
      class TestUtils < ActiveSupport::TestCase
        def test_path_escape
          assert_equal "a/b%20c+d%25", Utils.escape_path("a/b c+d%")
        end

        def test_segment_escape
          assert_equal "a%2Fb%20c+d%25", Utils.escape_segment("a/b c+d%")
        end

        def test_fragment_escape
          assert_equal "a/b%20c+d%25?e", Utils.escape_fragment("a/b c+d%?e")
        end

        def test_escape_gives_the_same_result_whether_or_not_the_component_needs_escaping
          ((0..127).map(&:chr) + ["\u00E9", "\u00A0"]).each do |char|
            assert_equal Utils.escape_path("#{char}%"), "#{Utils.escape_path(char)}%25"
            assert_equal Utils.escape_segment("#{char}%"), "#{Utils.escape_segment(char)}%25"
            assert_equal Utils.escape_fragment("#{char}%"), "#{Utils.escape_fragment(char)}%25"
          end
        end

        def test_escape_returns_components_without_unsafe_characters_unchanged
          safe = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~!$&'()*+,;=:@"
          { escape_segment: safe, escape_path: "#{safe}/", escape_fragment: "#{safe}/?" }.each do |method, chars|
            [chars.dup.force_encoding(Encoding::UTF_8).freeze, +"", ActiveSupport::SafeBuffer.new(chars)].each do |component|
              assert_same component, Utils.public_send(method, component)
            end
          end
        end

        def test_escape_encodes_unsafe_characters_as_us_ascii
          escaped = Utils.escape_segment("café 1")
          assert_equal "caf%C3%A9%201", escaped
          assert_equal Encoding::US_ASCII, escaped.encoding
        end

        def test_escape_encodes_unsafe_characters_on_any_line
          assert_equal "a%20b%0Ac", Utils.escape_segment("a b\nc")
          assert_equal "a%20b%0Ac", Utils.escape_path("a b\nc")
          assert_equal "a%20b%0Ac", Utils.escape_fragment("a b\nc")
        end

        def test_escape_raises_on_invalid_byte_sequences
          assert_raises(ArgumentError) { Utils.escape_segment((+"abc\xFF").force_encoding(Encoding::UTF_8)) }
        end

        def test_CGI_unescapeURIComponent
          assert_equal "a/b c+d", CGI.unescapeURIComponent("a%2Fb%20c+d")
        end

        def test_CGI_unescapeURIComponent_with_utf8_string
          assert_equal "Šašinková", CGI.unescapeURIComponent((+"%C5%A0a%C5%A1inkov%C3%A1").force_encoding(Encoding::US_ASCII))
        end

        def test_normalize_path_not_greedy
          assert_equal "/foo%20bar%20baz", Utils.normalize_path("/foo%20bar%20baz")
        end

        def test_normalize_path_uppercase
          assert_equal "/foo%AAbar%AAbaz", Utils.normalize_path("/foo%aabar%aabaz")
        end

        def test_normalize_path_uppercases_mixed_case_percent_escapes
          assert_equal "/foo%AAbar%AAbaz", Utils.normalize_path("/foo%aAbar%Aabaz")
        end

        def test_normalize_path_maintains_string_encoding
          path = "/foo%AAbar%AAbaz".b
          assert_equal Encoding::BINARY, Utils.normalize_path(path).encoding
        end

        def test_normalize_path_with_nil
          assert_equal "/", Utils.normalize_path(nil)
        end

        def test_normalized_path_predicate_is_true_only_for_paths_normalize_path_leaves_alone
          ["/", "/foo", "/foo/bar", "/foo.bar-baz_qux~"].each do |path|
            assert Utils.normalized_path?(path), "expected #{path.inspect} to count as normalized"
            assert_equal path, Utils.normalize_path(path)
          end

          [nil, "", "foo", "/foo/", "//foo", "/foo//bar", "/foo%ab", "/foo%aB"].each do |path|
            assert_not Utils.normalized_path?(path), "expected #{path.inspect} not to count as normalized"
            assert_not_equal path, Utils.normalize_path(path)
          end

          # Percent escapes are declined without looking at their case.
          ["/foo%20bar", "/foo%AB"].each do |path|
            assert_not Utils.normalized_path?(path), "expected #{path.inspect} not to count as normalized"
            assert_equal path, Utils.normalize_path(path)
          end
        end
      end
    end
  end
end
