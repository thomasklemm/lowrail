require_relative "load"
mism = 0; n = 0
check = ->(s, label) do
  METHODS.each do |m|
    a = outcome(B, m, s.dup.force_encoding(s.encoding)); b = outcome(N, m, s.dup.force_encoding(s.encoding))
    # identity check against the same object
    s1 = s.dup; s2 = s.dup
    ia = (B::ENCODER.public_send(m, s1).equal?(s1) rescue :raise)
    ib = (N::ENCODER.public_send(m, s2).equal?(s2) rescue :raise)
    n += 1
    if a != b || ia != ib
      mism += 1
      puts "MISMATCH #{label} #{m} #{s.inspect} #{s.encoding}: #{a.inspect} vs #{b.inspect} id #{ia} #{ib}" if mism < 20
    end
  end
end
encs = Encoding.list
# Every single byte, pairs of bytes, in every encoding
bytes = (0..255).map { |i| i.chr.b }
samples = []
samples << "" << "\n" << "a\n" << "\na" << "abc\n" << "foo/bar" << "a b" << "ü" << "日本" << "x?y#z" << "%41" << "a"*1000 << ("a"*1000 + "\n") << ("\n" + "a"*1000)
bytes.each { |b| samples << b; samples << "a#{b}" .b; samples << "#{b}a".b }
bytes.each_slice(1) { |(x)| bytes.sample(20, random: Random.new(x.ord)).each { |y| samples << x + y } }
rng = Random.new(42)
3000.times { samples << Array.new(rng.rand(0..8)) { bytes[rng.rand(256)] }.join.b }
3000.times { samples << Array.new(rng.rand(0..8)) { "azAZ09-._~!$&'()*+,;=:@/?#[] %\n\u00e9\u3042".chars.sample(random: rng) }.join }
encs.each do |enc|
  samples.each do |s|
    t = s.dup.force_encoding(enc)
    check.(t, enc.name)
  end
  # strings transcoded where possible
  ["abc", "a/b", "a b", "é", "", "a\n"].each do |s|
    t = (s.encode(enc) rescue next)
    check.(t, "enc-" + enc.name)
  end
end
puts "cases=#{n} mismatches=#{mism}"
