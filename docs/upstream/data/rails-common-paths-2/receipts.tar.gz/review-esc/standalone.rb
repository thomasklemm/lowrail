require ARGV[0]
U = ActionDispatch::Journey::Router::Utils
p [U.escape_path("a b/c"), U.escape_segment("a/b"), U.escape_fragment("x?y#z"), U.escape_path(:sym), U.escape_segment(42), U.escape_segment(nil)]
