require_relative "load"
u = ARGV[0] == "new" ? N : B
s = { "id" => "12345", "slug" => "my-blog-post-title-2026", "path_seg" => "/users/42/posts/hello-world", "unsafe_end" => "my-blog-post-title-2026 x", "unsafe_start" => " my-blog-post-title-2026" }.fetch(ARGV[1])
n = Integer(ARGV[2]); e = u::ENCODER; m = ARGV[3]&.to_sym || :escape_segment
n.times { e.public_send(m, s) }
