require_relative "load"
show = ->(label, s) { METHODS.each { |m| a = outcome(B, m, s); b = outcome(N, m, s); puts "#{a == b ? 'same' : 'DIFF'} #{label} #{m}: base=#{a.inspect[0,150]}#{a == b ? '' : " new=#{b.inspect[0,150]}"}" } }
show.("utf16le", "abc".encode("UTF-16LE"))
show.("utf16 dummy", "abc".encode("UTF-16"))
show.("utf32be", "a".encode("UTF-32BE"))
show.("iso2022jp dummy", "abc".dup.force_encoding("ISO-2022-JP"))
show.("utf7 dummy", "abc".dup.force_encoding("UTF-7"))
show.("invalid utf8", "a\xffb".dup.force_encoding("UTF-8"))
show.("invalid utf8 safe prefix only", "abc\xff".dup.force_encoding("UTF-8"))
show.("invalid sjis", "\x81".dup.force_encoding("Shift_JIS"))
show.("binary high", "a\xffb".b)
show.("empty frozen", "".freeze)
show.("frozen safe", "abc".freeze)
show.("frozen unsafe", "a b".freeze)
show.("newline", "abc\n")
show.("newline mid", "ab\ncd")
puts "--- regexp props"
%i[FRAGMENT SEGMENT PATH SAFE_FRAGMENT SAFE_SEGMENT SAFE_PATH].each do |c|
  r = N::UriEncoder.const_get(c) rescue next
  puts "#{c} enc=#{r.encoding} fixed=#{r.fixed_encoding?} frozen=#{r.frozen?} shareable=#{Ractor.shareable?(r)} opts=#{r.options} timeout=#{r.timeout.inspect} src=#{r.source}"
end
puts "--- String subclass"
class Sub < String
  def match?(*a) = (($calls ||= []) << [:match?, a.map(&:source)]; super)
  def gsub(*a, &b) = (($calls ||= []) << [:gsub]; super)
end
[["abc", "safe"], ["a b", "unsafe"]].each do |str, l|
  [B, N].each do |u|
    $calls = []; s = Sub.new(str); r = u::ENCODER.escape_path(s)
    puts "#{u == B ? 'base' : 'new '} #{l}: result=#{r.inspect} class=#{r.class} same_obj=#{r.equal?(s)} calls=#{$calls.inspect}"
  end
end
puts "--- singleton match? that does not call super (semantic, not just observational)"
[B, N].each do |u|
  s = +"a b"; def s.match?(re) = false
  r = (u::ENCODER.escape_path(s) rescue $!)
  puts "#{u == B ? 'base' : 'new '}: #{r.inspect}"
end
puts "--- via public Utils with to_s returning subclass / singleton"
o = Object.new; def o.to_s = Sub.new("x y")
[B, N].each { |u| $calls = []; puts "#{u == B ? 'base' : 'new '}: #{u.escape_segment(o).inspect} #{$calls.inspect}" }
