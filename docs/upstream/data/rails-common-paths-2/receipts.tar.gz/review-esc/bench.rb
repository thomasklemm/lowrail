require_relative "load"
inputs = { "id" => "12345", "slug" => "my-blog-post-title-2026", "path" => "/users/42/posts/hello-world", "unsafe_end" => "my-blog-post-title-2026 x", "unsafe_start" => " my-blog-post-title-2026", "long_safe" => "a"*2000, "long_unsafe_end" => "a"*2000+" " }
N_ITER = 300_000
inputs.each do |label, s|
  res = [B, N].map do |u|
    e = u::ENCODER; best = Float::INFINITY
    3.times { t = Process.clock_gettime(Process::CLOCK_MONOTONIC); (label.start_with?("long") ? N_ITER/50 : N_ITER).times { e.escape_segment(s) }; best = [best, Process.clock_gettime(Process::CLOCK_MONOTONIC) - t].min }
    best
  end
  printf "%-16s base=%.3fs new=%.3fs ratio=%.2f\n", label, res[0], res[1], res[1]/res[0]
end
