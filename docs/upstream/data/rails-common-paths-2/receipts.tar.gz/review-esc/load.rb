def load_variant(path, name)
  src = File.read(path)
  eval(src.sub("module ActionDispatch", "module #{name}"), TOPLEVEL_BINDING, path)
  Object.const_get(name)::Journey::Router::Utils
end
B = load_variant(File.expand_path("~/w/wt/main/actionpack/lib/action_dispatch/journey/router/utils.rb"), "BaseNS")
N = load_variant(File.expand_path("~/w/wt/esc/actionpack/lib/action_dispatch/journey/router/utils.rb"), "NewNS")
METHODS = %i[escape_path escape_segment escape_fragment]
def outcome(u, m, s)
  r = u::ENCODER.public_send(m, s)
  [:ok, r, r.encoding, r.equal?(s), r.frozen?, r.class]
rescue Exception => e
  [:raise, e.class, e.message]
end
