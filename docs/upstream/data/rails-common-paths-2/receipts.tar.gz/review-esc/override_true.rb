require_relative "load"
[B, N].each do |u|
  s = +"<script> x"; def s.match?(re) = true   # override that always says "matches"
  puts "#{u == B ? 'base' : 'new '}: #{u::ENCODER.escape_segment(s).inspect}"
end
