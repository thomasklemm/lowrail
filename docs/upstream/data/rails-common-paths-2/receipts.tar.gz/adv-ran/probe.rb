require "bundler/setup"
RAILS = ENV.fetch("RAILS")
%w[activesupport activemodel activerecord].each { |c| $LOAD_PATH.unshift File.join(RAILS, c, "lib") }
require "active_record"
ActiveRecord::Base.establish_connection(adapter: "sqlite3", database: ":memory:")
ActiveRecord::Migration.verbose = false
ActiveRecord::Schema.define do
  create_table(:authors) { |t| t.string :name; t.string :type; t.timestamps }
  create_table(:posts) { |t| t.string :title; t.text :body; t.integer :status, default: 0; t.text :settings; t.integer :author_id; t.timestamps }
  create_table(:cpks, primary_key: [:a, :b]) { |t| t.integer :a; t.integer :b; t.string :name }
end
OUT = []
def rec(label) = OUT << [Array(label).map { _1.is_a?(Module) ? _1.name : _1 }, (begin; r = yield; r.is_a?(Class) ? r.name : r; rescue Exception => e; [e.class, e.message[0, 120]]; end)]

class Author < ActiveRecord::Base; has_many :posts; alias_attribute :nm, :name; end
class SAuthor < Author; end
class Abs < ActiveRecord::Base; self.abstract_class = true; alias_attribute :heading, :title; end
class EarlyChild < Abs; self.table_name = "posts"; end
class Post < Abs
  belongs_to :author, optional: true
  enum :status, { draft: 0, live: 1 }
  store_accessor :settings, :color
  serialize :settings, coder: JSON
  normalizes :title, with: -> { _1.strip }
  alias_attribute :state, :status
  # hue alias to store accessor rejected by Rails
  alias_attribute :hd2, :heading   # alias to alias
  alias_attribute "txt", "body".dup
  alias_attribute Class.new(String).new("t3"), :title
  self.ignored_columns += ["author_id_x"]
end
class LateChild < Post; end
Abs.alias_attribute :later, :body
Post.alias_attribute :later2, :body
class Cpk < ActiveRecord::Base; self.primary_key = [:a, :b]; alias_attribute :nick, :name; end
class OverNil < ActiveRecord::Base; self.table_name = "posts"; def self.attribute_aliases = nil; end
class OverPlain < ActiveRecord::Base; self.table_name = "posts"; def self.attribute_aliases = { "h" => "title" }; end
class OverHWIA < ActiveRecord::Base; self.table_name = "posts"; def self.attribute_aliases = ActiveSupport::HashWithIndifferentAccess.new(h: "title"); end
class Form
  include ActiveModel::Model; include ActiveModel::Attributes
  attribute :name, :string; attribute :n, ActiveModel::Type::Integer.new
  alias_attribute :label, :name
end
class Form2 < Form; alias_attribute :num, :n; end

names = [:title, "title", :heading, "heading", :hd2, :state, "status", :hue, :color, "txt", "t3", :later, :later2,
  :nm, :name, :id, :id_value, "id_value", :a, :nick, :h, :label, :num, :n, :nope, "", :"", 1, nil, Class.new(String).new("heading"), "heading".encode("UTF-16LE")]
[Author, SAuthor, Abs, EarlyChild, Post, LateChild, Cpk, OverNil, OverPlain, OverHWIA, Form, Form2].each do |k|
  names.each do |n|
    rec([k, n, :res]) { v = k.send(:resolve_attribute_name, n); [v, v.class, v.frozen?, v.encoding.to_s] }
    rec([k, n, :type]) { k.type_for_attribute(n).class }
    rec([k, n, :typeblk]) { k.type_for_attribute(n) { |x| [:miss, x] }.then { _1.is_a?(Array) ? _1 : _1.class } }
    rec([k, n, :default]) { k._default_attributes[k.send(:resolve_attribute_name, n)]&.value } if k.respond_to?(:_default_attributes)
  end
end
a = Author.create!(nm: "x"); SAuthor.create!(nm: "y")
p1 = Post.create!(heading: " h ", state: :live, txt: "b", author: a, later: "L")
rec(:where) { Post.where(heading: "h", state: :live, hd2: "h").to_sql }
rec(:wherecnt) { Post.where(heading: "h", state: "live").count }
rec(:not) { Post.where.not(state: :draft, heading: nil).to_sql }
rec(:assoc) { Author.joins(:posts).where(posts: { heading: "h", state: :live }).to_sql }
rec(:assoc2) { Post.where(author: a).where(author: { nm: "x" }).count }
rec(:sti) { SAuthor.where(nm: "y").to_sql }
rec(:findby) { Post.find_by(heading: "h", later: "L")&.id }
rec(:dyn) { Post.find_by_heading("h")&.id }
rec(:ins) { Post.insert_all([{ heading: "i", state: 1 }]); Post.where(title: "i").pluck(:status) }
rec(:ups) { Post.upsert_all([{ id: p1.id, heading: "u", state: 0 }]); Post.find(p1.id).attributes.except("created_at","updated_at") }
rec(:upd) { p1.reload.update!(heading: " z ", color: "b"); [p1.title, p1.color, p1.saved_changes.keys] }
rec(:cpk) { Cpk.create!(a: 1, b: 2, nick: "n"); [Cpk.where(nick: "n").to_sql, Cpk.find_by(id_value: [1, 2])&.name] }
rec(:form) { Form2.new(label: "l", num: "3").attributes }
rec(:pred) { Post.where(id_value: 1, later2: "x").to_sql }
rec(:arel) { Post.arel_table[:heading].eq("x").to_sql rescue $! }
# reload: redefine class
Object.send(:remove_const, :Post2) if defined?(Post2)
2.times do |i|
  Object.send(:remove_const, :Re) if defined?(Re)
  Object.const_set(:Re, Class.new(ActiveRecord::Base) { self.table_name = "posts"; alias_attribute :"r#{i}", :title })
  rec([:reload, i]) { [Re.type_for_attribute("r#{i}").class, Re.where("r#{i}": "a").to_sql, Re.send(:resolve_attribute_name, "r#{1 - i}")] }
end
# threads
th = 8.times.map { |i| Thread.new { 2000.times.map { Post.type_for_attribute(:heading).class }.uniq } }
Post.alias_attribute :thr, :title
rec(:threads) { th.flat_map(&:value).uniq + [Post.type_for_attribute(:thr).class] }
# fibers
rec(:fiber) { f = Fiber.new { Fiber.yield Post.send(:resolve_attribute_name, :heading); Post.send(:resolve_attribute_name, :thr) }; [f.resume, f.resume] }
# to_s raising
bad = Object.new; def bad.to_s = raise(ArgumentError, "boom")
rec(:raise) { Post.type_for_attribute(bad) }
rec(:sym_to_s_identity) { s = +"title"; Post.send(:resolve_attribute_name, s).equal?(s) }
rec(:alias_identity) { Post.send(:resolve_attribute_name, :heading).equal?(Post.attribute_aliases["heading"]) }
File.write(ENV.fetch("OUT"), OUT.map(&:inspect).join("\n") + "\n")
puts OUT.size
