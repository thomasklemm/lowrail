Price per extra operation: send/yield 338 Ir (409.6 M over 1211907 calls), ivar 101 Ir (60.3 M over 594790 reads)

#### Extra generic operations by ZJIT reason (ZJIT fallbacks not matched by a YJIT generic call at the same ISEQ; per iteration)

| reason | ZJIT count | extra vs YJIT | est. M Ir |
|---|---:|---:|---:|
| `send_fallback_send_polymorphic_fallback` | 763074 | 573510 | 193.8 |
| `getivar_fallback_no_profile_missing_ic` | 596549 | 478481 | 48.5 |
| `send_fallback_send_block_arg_not_nil` | 207916 | 195628 | 66.1 |
| `send_fallback_send_megamorphic` | 153490 | 96160 | 32.5 |
| `send_fallback_invokeblock_polymorphic_miss` | 130278 | 95290 | 32.2 |
| `getivar_fallback_no_side_exits` | 326606 | 94754 | 9.6 |
| `send_fallback_invokeblock_not_specialized` | 281407 | 91512 | 30.9 |
| `send_fallback_send_not_optimized_method_type_optimized` | 70380 | 40851 | 13.8 |
| `exit_patchpoint_stable_constant_names` | 39633 | 39633 | – |
| `send_fallback_one_or_more_complex_arg_pass` | 85209 | 38009 | 12.8 |
| `send_fallback_send_not_optimized_need_permission` | 30469 | 30462 | 10.3 |
| `send_fallback_send_polymorphic` | 30219 | 28039 | 9.5 |
| `setivar_fallback_no_side_exits` | 41002 | 18853 | 1.9 |
| `send_fallback_sendforward_not_specialized` | 100882 | 12204 | 4.1 |
| `send_fallback_super_complex_args_pass` | 7317 | 4560 | 1.5 |
| `getivar_fallback_polymorphic` | 2702 | 2702 | 0.3 |
| `send_fallback_super_call_with_block` | 1907 | 1818 | 0.6 |
| `send_fallback_super_polymorphic` | 2132 | 1672 | 0.6 |
| `send_fallback_invokesuperforward_not_specialized` | 6736 | 857 | 0.3 |
| `exit_guard_type_failure` | 816 | 816 | – |
| `send_fallback_super_from_block` | 2717 | 722 | 0.2 |
| `send_fallback_send_not_optimized_method_type` | 9304 | 409 | 0.1 |
| `send_fallback_singleton_class_seen` | 216 | 196 | 0.1 |
| `send_fallback_super_not_optimized_method_type` | 777 | 9 | 0.0 |
| `exit_guard_shape_failure` | 8 | 8 | – |

#### Top sites (per iteration)

| ISEQ | kind | ZJIT fallbacks | YJIT generic calls | extra | est. M Ir | ZJIT reasons |
|---|---|---:|---:|---:|---:|---|
| `block in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb` | send | 114270 | 660 | 113610 | 38.4 | send_polymorphic_fallback 114270 |
| `<<@activerecord-8.1.2/lib/arel/collectors/composite.rb` | ivar | 105476 | 0 | 105476 | 10.7 | no_profile_missing_ic 105476 |
| `each@<internal:array>` | yield | 259463 | 183096 | 76367 | 25.8 | invokeblock_not_specialized 259463 |
| `map@<internal:array>` | yield | 79649 | 10519 | 69130 | 23.4 | invokeblock_polymorphic_miss 79649 |
| `hash@activemodel-8.1.2/lib/active_model/type/value.rb` | send | 67904 | 0 | 67904 | 22.9 | send_polymorphic_fallback 67904 |
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb` | send | 67566 | 0 | 67566 | 22.8 | send_block_arg_not_nil 67566 |
| `hash@activemodel-8.1.2/lib/active_model/attribute.rb` | ivar | 48408 | 0 | 48408 | 4.9 | no_profile_missing_ic 48408 |
| `connection_specification_name@activerecord-8.1.2/lib/active_record/connection_handling.rb` | exit | 39601 | 0 | 39601 | – | exit_patchpoint_stable_constant_names 39601 |
| `==@activemodel-8.1.2/lib/active_model/attribute.rb` | ivar | 39438 | 0 | 39438 | 4.0 | no_profile_missing_ic 39438 |
| `mon_synchronize@monitor.rb` | send | 35341 | 0 | 35341 | 11.9 | send_block_arg_not_nil 35341 |
| `stale_state@activerecord-8.1.2/lib/active_record/associations/belongs_to_association.rb` | ivar | 32848 | 0 | 32848 | 3.3 | no_side_exits 32848 |
| `!=@<internal:basic_object>` | send | 30007 | 0 | 30007 | 10.1 | send_megamorphic 30007 |
| `value_for@activerecord-8.1.2/lib/active_record/scoping.rb` | send | 31704 | 3852 | 27852 | 9.4 | send_polymorphic 17942, send_polymorphic_fallback 13762 |
| `synchronize@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool/q` | send | 23172 | 0 | 23172 | 7.8 | send_block_arg_not_nil 23172 |
| `hash@activerecord-8.1.2/lib/active_record/relation/query_attribute.rb` | ivar | 22834 | 0 | 22834 | 2.3 | no_profile_missing_ic 22834 |
| `empty?@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | ivar | 22052 | 0 | 22052 | 2.2 | no_profile_missing_ic 22052 |
| `connection_pool@activerecord-8.1.2/lib/active_record/connection_handling.rb` | send | 36004 | 14900 | 21104 | 7.1 | send_polymorphic_fallback 36004 |
| `klass@activerecord-8.1.2/lib/active_record/associations/association.rb` | ivar | 20880 | 0 | 20880 | 2.1 | no_profile_missing_ic 20880 |
| `current_role@activerecord-8.1.2/lib/active_record/core.rb` | send | 35274 | 14594 | 20680 | 7.0 | send_polymorphic_fallback 35274 |
| `current_shard@activerecord-8.1.2/lib/active_record/core.rb` | send | 35274 | 14594 | 20680 | 7.0 | send_polymorphic_fallback 35274 |
| `association@activerecord-8.1.2/lib/active_record/associations.rb` | send | 23647 | 3594 | 20053 | 6.8 | send_polymorphic_fallback 23647 |
| `each_attributes@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | ivar | 18306 | 0 | 18306 | 1.9 | no_profile_missing_ic 18306 |
| `merge@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | send | 18306 | 0 | 18306 | 6.2 | send_not_optimized_need_permission 18306 |
| `stale_state@activerecord-8.1.2/lib/active_record/associations/belongs_to_association.rb` | send | 16424 | 175 | 16249 | 5.5 | send_megamorphic 16424 |
| `merge_clauses@activerecord-8.1.2/lib/active_record/relation/merger.rb` | send | 17479 | 1550 | 15929 | 5.4 | send_polymorphic_fallback 17479 |

