Price per extra operation: send/yield 278 Ir (170.1 M over 611651 calls), ivar 41 Ir (7.9 M over 194888 reads)

#### Extra generic operations by ZJIT reason (ZJIT fallbacks not matched by a YJIT generic call at the same ISEQ; per iteration)

| reason | ZJIT count | extra vs YJIT | est. M Ir |
|---|---:|---:|---:|
| `send_fallback_invokeblock_not_specialized` | 333713 | 253534 | 70.5 |
| `getivar_fallback_no_profile_missing_ic` | 197458 | 194858 | 7.9 |
| `send_fallback_send_block_arg_not_nil` | 120000 | 107987 | 30.0 |
| `send_fallback_one_or_more_complex_arg_pass` | 104508 | 71565 | 19.9 |
| `send_fallback_send_not_optimized_need_permission` | 54836 | 54836 | 15.3 |
| `send_fallback_send_not_optimized_method_type_optimized` | 41673 | 41673 | 11.6 |
| `send_fallback_send_polymorphic_fallback` | 30483 | 30483 | 8.5 |
| `send_fallback_super_complex_args_pass` | 39252 | 13030 | 3.6 |
| `send_fallback_invokeblock_polymorphic_miss` | 11287 | 11287 | 3.1 |
| `send_fallback_send_polymorphic` | 5961 | 5961 | 1.7 |
| `send_fallback_sendforward_not_specialized` | 75134 | 5217 | 1.5 |
| `send_fallback_super_polymorphic` | 4026 | 4026 | 1.1 |
| `send_fallback_super_from_block` | 6000 | 4000 | 1.1 |
| `send_fallback_super_call_with_block` | 6039 | 2039 | 0.6 |
| `send_fallback_send_not_optimized_method_type` | 31296 | 2013 | 0.6 |
| `send_fallback_invokesuperforward_not_specialized` | 19970 | 2000 | 0.6 |
| `send_fallback_send_megamorphic` | 189766 | 2000 | 0.6 |
| `setivar_fallback_no_side_exits` | 30 | 30 | 0.0 |
| `exit_guard_shape_failure` | 30 | 30 | – |
| `exit_guard_type_failure` | 0 | 0 | – |
| `send_fallback_super_not_optimized_method_type` | 2000 | 0 | 0.0 |
| `setivar_fallback_not_t_object` | 4030 | 0 | 0.0 |

#### Top sites (per iteration)

| ISEQ | kind | ZJIT fallbacks | YJIT generic calls | extra | est. M Ir | ZJIT reasons |
|---|---|---:|---:|---:|---:|---|
| `each@<internal:array>` | yield | 200651 | 56278 | 144373 | 40.2 | invokeblock_not_specialized 200651 |
| `fetch_header@rack-3.1.17/lib/rack/request.rb` | send | 41805 | 0 | 41805 | 11.6 | one_or_more_complex_arg_pass 41805 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | send | 41805 | 0 | 41805 | 11.6 | send_not_optimized_need_permission 41805 |
| `request@actionpack-8.1.1/lib/action_dispatch/middleware/cookies.rb` | ivar | 35766 | 0 | 35766 | 1.5 | no_profile_missing_ic 35766 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | send | 35550 | 0 | 35550 | 9.9 | send_block_arg_not_nil 35550 |
| `map@<internal:array>` | yield | 41197 | 9300 | 31897 | 8.9 | invokeblock_not_specialized 41197 |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb` | ivar | 28744 | 0 | 28744 | 1.2 | no_profile_missing_ic 28714, no_side_exits 30 |
| `iterate_guarding_exceptions@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | send | 21948 | 0 | 21948 | 6.1 | send_block_arg_not_nil 21948 |
| `mon_synchronize@monitor.rb` | send | 19971 | 0 | 19971 | 5.6 | send_block_arg_not_nil 19971 |
| `url_options@actionview-8.1.1/lib/action_view/routing_url_for.rb` | ivar | 18114 | 0 | 18114 | 0.7 | no_profile_missing_ic 18114 |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb` | ivar | 18114 | 0 | 18114 | 0.7 | no_profile_missing_ic 18114 |
| `block in each_precompressed_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | yield | 17883 | 0 | 17883 | 5.0 | invokeblock_not_specialized 17883 |
| `select@<internal:array>` | yield | 16015 | 0 | 16015 | 4.5 | invokeblock_not_specialized 16015 |
| `block (2 levels) in search_combinations@actionview-8.1.1/lib/action_view/path_set.rb` | yield | 12078 | 0 | 12078 | 3.4 | invokeblock_not_specialized 12078 |
| `before@activesupport-8.1.1/lib/active_support/execution_wrapper.rb` | send | 12000 | 0 | 12000 | 3.3 | send_not_optimized_method_type_optimized 12000 |
| `performed?@actionpack-8.1.1/lib/action_controller/metal.rb` | ivar | 11940 | 0 | 11940 | 0.5 | no_profile_missing_ic 11940 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | ivar | 10357 | 0 | 10357 | 0.4 | no_profile_missing_ic 10357 |
| `each@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | send | 9974 | 0 | 9974 | 2.8 | send_block_arg_not_nil 9974 |
| `optimize_routes_generation?@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | send | 9057 | 0 | 9057 | 2.5 | send_not_optimized_method_type_optimized 9057 |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb` | send | 9057 | 0 | 9057 | 2.5 | send_not_optimized_need_permission 9057 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | send | 9057 | 0 | 9057 | 2.5 | send_polymorphic_fallback 9057 |
| `silenced?@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | send | 8013 | 0 | 8013 | 2.2 | send_polymorphic_fallback 8013 |
| `exists?@actionpack-8.1.1/lib/action_dispatch/request/session.rb` | send | 7948 | 0 | 7948 | 2.2 | send_not_optimized_method_type_optimized 7948 |
| `block in id@actionpack-8.1.1/lib/action_dispatch/request/session.rb` | send | 7948 | 0 | 7948 | 2.2 | send_not_optimized_method_type_optimized 7948 |
| `<<@actionview-8.1.1/lib/action_view/buffers.rb` | send | 7340 | 0 | 7340 | 2.0 | send_polymorphic_fallback 7340 |

