### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 3738.7 | 3738.7 | 0.00% |
| YJIT | 3229.7 | 3229.7 | 0.00% |
| ZJIT − YJIT | | | | +509.1 (+15.76%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| method dispatch (generic send path) | 1036.9 | 707.7 | **+329.3** | 65% | 0.0 |
| JIT code | 713.1 | 573.3 | **+139.8** | 27% | 0.0 |
| ivar and attr access (generic) | 148.2 | 87.9 | **+60.3** | 12% | 0.0 |
| block and proc invocation (generic) | 234.4 | 195.7 | **+38.7** | 8% | 0.0 |
| side exits and frame materialization | 10.9 | 0.2 | **+10.6** | 2% | 0.0 |
| GC (marking, sweeping, freeing) | 68.1 | 66.5 | **+1.5** | 0% | 0.0 |
| invalidation | 0.0 | 0.0 | **+0.0** | 0% | 0.0 |
| compile (ZJIT/YJIT compiler, profiling) | 0.1 | 1.0 | **-0.9** | -0% | 0.0 |
| write barriers | 37.4 | 41.3 | **-3.8** | -1% | 0.0 |
| interpreter (YARV loop and insn helpers) | 39.4 | 51.1 | **-11.7** | -2% | 0.0 |
| other runtime (cfunc bodies, hash, string, regexp, ...) | 1266.0 | 1284.4 | **-18.4** | -4% | 0.0 |
| allocation (objects, malloc) | 184.2 | 220.7 | **-36.5** | -7% | 0.0 |
| total | 3738.7 | 3229.7 | **+509.1** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `<JIT code>` | JIT code | 713.1 | 573.3 | +139.8 |
| `rb_vm_exec` | method dispatch | 171.5 | 86.2 | +85.3 |
| `rb_vm_opt_send_without_block` | method dispatch | 74.8 | 24.8 | +50.0 |
| `vm_invoke_iseq_block` | block and proc invocation | 38.7 | 7.6 | +31.1 |
| `setup_parameters_complex` | method dispatch | 46.6 | 15.8 | +30.9 |
| `vm_call_iseq_setup` | method dispatch | 55.2 | 31.8 | +23.5 |
| `vm_lookup_cc` | method dispatch | 34.9 | 11.5 | +23.4 |
| `rb_ivar_lookup` | ivar and attr access | 37.3 | 16.3 | +21.1 |
| `rb_ec_stack_check` | method dispatch | 55.5 | 35.9 | +19.6 |
| `rb_vm_send` | method dispatch | 23.3 | 5.2 | +18.1 |
| `vm_callee_setup_arg` | method dispatch | 47.8 | 29.9 | +17.8 |
| `rb_shape_get_iv_index` | ivar and attr access | 32.5 | 15.6 | +16.9 |
| `rb_vm_getinstancevariable` | ivar and attr access | 16.3 | 0.0 | +16.3 |
| `vm_search_method_slowpath0` | method dispatch | 24.2 | 7.9 | +16.3 |
| `rb_vm_invokeblock` | block and proc invocation | 30.7 | 16.7 | +14.0 |
| `rb_managed_id_table_lookup` | method dispatch | 44.4 | 31.8 | +12.6 |
| `vm_call_iseq_setup_normal_0start_0params_0locals` | method dispatch | 17.7 | 5.6 | +12.1 |
| `CALLER_SETUP_ARG` | method dispatch | 52.2 | 40.5 | +11.7 |
| `rb_shape_get_iv_index_with_hint` | ivar and attr access | 12.4 | 1.6 | +10.8 |
| `zjit_materialize_frames` | side exits and frame materialization | 10.7 | 0.0 | +10.7 |
| `vm_yield_with_cfunc` | block and proc invocation | 2.7 | 13.2 | -10.4 |
| `vm_call0_body` | method dispatch | 35.3 | 45.4 | -10.1 |
| `rb_funcallv_scope.constprop.0` | method dispatch | 22.9 | 32.5 | -9.6 |
| `rb_ec_newobj_of` | allocation | 13.4 | 22.6 | -9.2 |
| `rb_class_allocate_instance` | allocation | 4.9 | 13.2 | -8.3 |
| `rb_ivar_get_at_no_ractor_check` | ivar and attr access | 0.1 | 8.0 | -7.9 |
| `RCLASS_EXT_WRITABLE` | method dispatch | 16.1 | 23.7 | -7.7 |
| `rb_builtin_ary_at_end` | interpreter | 0.0 | 7.3 | -7.3 |
| `rb_vm_yield_with_cfunc` | block and proc invocation | 7.1 | 0.2 | +6.9 |
| `vm_call_method_each_type` | method dispatch | 11.0 | 4.2 | +6.8 |
| `rb_obj_fields` | ivar and attr access | 21.6 | 27.9 | -6.3 |
| `rb_ec_ary_new_from_values` | allocation | 0.4 | 6.5 | -6.1 |
| `vm_caller_setup_arg_block.isra.0` | block and proc invocation | 10.2 | 4.7 | +5.5 |
| `vm_invoke_ifunc_block` | block and proc invocation | 0.0 | 5.4 | -5.4 |
| `vm_call0_cc` | method dispatch | 23.1 | 28.4 | -5.3 |
| `rb_newobj_of` | allocation | 36.4 | 41.7 | -5.3 |
| `vm_call_ivar` | ivar and attr access | 8.7 | 3.6 | +5.1 |
| `vm_call_iseq_bmethod` | method dispatch | 10.4 | 5.6 | +4.8 |
| `__memset_avx2_unaligned_erms` | other runtime | 24.7 | 29.4 | -4.8 |
| `vm_call_symbol` | method dispatch | 10.7 | 6.1 | +4.5 |

### Unclassified (other runtime) differences above 0.5M
  -4.8 __memset_avx2_unaligned_erms
  -3.7 ary_memcpy0
  +2.5 any_hash
  -2.3 rb_obj_is_kind_of
  +1.6 VM_CF_BLOCK_HANDLER.isra.0
  -1.6 rb_struct_initialize_m
  -1.6 rb_obj_not_equal
  -1.6 rb_hash_aset
  -1.1 rb_sym2str
  -1.0 rb_get_symbol_id
  -0.9 rb_is_instance_id
  +0.8 ar_insert_direct.isra.0
  -0.7 rb_obj_equal
  +0.7 rb_check_id
  -0.7 rb_get_alloc_func
  +0.6 rb_hash_bulk_insert.part.0
  -0.6 onig_search_gpos
  -0.6 rb_current_ec
  +0.5 rb_ary_push

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `entry trampoline` | 41.6 | 0.0 | +41.6 |
| `<unmapped JIT>` | 1.8 | 30.2 | -28.4 |
| `each@<internal:array>` | 33.5 | 26.2 | +7.3 |
| `[]@activesupport-8.1.2/lib/active_support/isolated_execution_state.rb` | 0.5 | 6.4 | -6.0 |
| `attribute_types@activemodel-8.1.2/lib/active_model/attribute_registration.rb` | 10.1 | 5.6 | +4.5 |
| `block in perform_query@activerecord-8.1.2/lib/active_record/connection_adapters/sqlite3/database_statements.rb` | 6.7 | 2.5 | +4.2 |
| `block in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb` | 13.4 | 9.8 | +3.6 |
| `block in merge@activerecord-8.1.2/lib/active_record/relation/merger.rb` | 10.1 | 6.8 | +3.3 |
| `initialize@activerecord-8.1.2/lib/active_record/relation.rb` | 6.9 | 4.0 | +2.9 |
| `checkout@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool.rb` | 4.0 | 1.1 | +2.9 |
| `block in column_types@activerecord-8.1.2/lib/active_record/result.rb` | 8.2 | 5.4 | +2.8 |
| `fetch@concurrent-ruby-1.3.6/lib/concurrent-ruby/concurrent/map.rb` | 5.6 | 3.0 | +2.7 |
| `block in poll@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool/queue.rb` | 3.2 | 0.6 | +2.6 |
| `<<@activerecord-8.1.2/lib/arel/collectors/composite.rb` | 2.1 | 4.7 | -2.6 |
| `map@<internal:array>` | 9.6 | 7.1 | +2.5 |
| `connected_to_stack@activerecord-8.1.2/lib/active_record/core.rb` | 4.1 | 1.8 | +2.3 |
| `type_map@activerecord-8.1.2/lib/active_record/connection_adapters/abstract_adapter.rb` | 0.0 | 2.2 | -2.2 |
| `create@activerecord-8.1.2/lib/active_record/relation/delegation.rb` | 3.7 | 1.5 | +2.2 |
| `visit_Arel_Attributes_Attribute@activerecord-8.1.2/lib/arel/visitors/to_sql.rb` | 4.2 | 2.1 | +2.1 |
| `instance@activerecord-8.1.2/lib/active_record/scoping.rb` | 3.5 | 1.4 | +2.1 |
| `reset@activerecord-8.1.2/lib/active_record/relation.rb` | 3.3 | 1.2 | +2.1 |
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb` | 3.2 | 5.1 | -1.9 |
| `block (2 levels) in checkin@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool.` | 3.9 | 2.0 | +1.9 |
| `connection_handler@activerecord-8.1.2/lib/active_record/core.rb` | 3.2 | 1.4 | +1.8 |
| `where_clause@activerecord-8.1.2/lib/active_record/relation/query_methods.rb` | 3.9 | 2.1 | +1.8 |
| `connection_lease@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool.rb` | 1.3 | 3.1 | -1.8 |
| `release_connection@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool.rb` | 3.5 | 1.8 | +1.7 |
| `get_or_default@concurrent-ruby-1.3.6/lib/concurrent-ruby/concurrent/collection/map/non_concurrent_map_backend.` | 0.0 | 1.7 | -1.7 |
| `merge@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | 5.3 | 3.7 | +1.7 |
| `fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb` | 8.0 | 6.3 | +1.7 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 0.0)


### JIT code by YJIT codegen symbol (run b, M per iteration; total 0.0)


### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `<JIT code>` | 5137879 | 0 | 5137879 | 382230.5 | 0.0 |
| `rb_vm_opt_send_without_block` | 1045850 | 353960 | 691890 | 27988.2 | 13973.5 |
| `rb_ivar_get_at_no_ractor_check` | 10409 | 667777 | -657368 | 1.4 | 35.2 |
| `rb_builtin_ary_at_end` | 0 | 644807 | -644807 | 0.0 | 7.1 |
| `rb_builtin_ary_at` | 0 | 483390 | -483390 | 0.0 | 2.9 |
| `rb_builtin_fixnum_inc` | 0 | 471624 | -471624 | 0.0 | 1.4 |
| `rb_ivar_get` | 668859 | 219832 | 449027 | 85.0 | 36.9 |
| `rb_gc_writebarrier` | 34812 | 477175 | -442363 | 1.3 | 14.1 |
| `rb_vm_getinstancevariable` | 256904 | 0 | 256904 | 28.8 | 0.0 |
| `builtin_inline_class_20` | 0 | 218867 | -218867 | 0.0 | 2.2 |
| `rb_vm_send` | 284170 | 65422 | 218748 | 23599.8 | 3760.8 |
| `rb_get_symbol_id` | 0 | 196644 | -196644 | 0.0 | 2.6 |
| `rb_vm_invokeblock` | 411596 | 224915 | 186681 | 36750.7 | 13698.4 |
| `rb_yarv_ary_entry_internal` | 0 | 171925 | -171925 | 0.0 | 2.7 |
| `rb_obj_alloc` | 27580 | 164267 | -136687 | 4.4 | 26.3 |
| `rb_vm_yield_with_cfunc` | 138789 | 2966 | 135823 | 7371.8 | 221.8 |
| `rb_ec_ary_new_from_values` | 7239 | 140502 | -133264 | 2.5 | 38.1 |
| `rb_obj_is_kind_of` | 170658 | 275559 | -104901 | 7.0 | 10.6 |
| `rb_obj_not_equal` | 0 | 90248 | -90248 | 0.0 | 33.2 |
| `rb_hash_new` | 4416 | 57613 | -53197 | 1.2 | 5.4 |
| `rb_obj_equal` | 0 | 49466 | -49466 | 0.0 | 0.2 |
| `rb_vm_env_write` | 42410 | 1376 | 41034 | 0.4 | 0.1 |
| `rb_zjit_materialize_frames` | 40150 | 0 | 40150 | 7.3 | 0.0 |
| `rb_obj_as_string_result` | 0 | 39850 | -39850 | 0.0 | 0.4 |
| `__memcpy_avx_unaligned_erms` | 925615 | 889027 | 36588 | 13.6 | 13.3 |
| `rb_zjit_defined_ivar` | 32913 | 0 | 32913 | 2.9 | 0.0 |
| `rb_vm_invokesuper` | 14856 | 40059 | -25203 | 39251.7 | 6439.5 |
| `rb_yarv_str_eql_internal` | 31873 | 10891 | 20982 | 1.3 | 0.2 |
| `rb_obj_dummy0` | 0 | 19552 | -19552 | 0.0 | 0.0 |
| `rb_class_superclass` | 1897 | 21419 | -19522 | 0.0 | 0.2 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `attribute_types@activemodel-8.1.2/lib/active_model/attribute_registration.rb` | `rb_vm_getinstancevariable` | 118503 | 0 | 118503 |
| `block in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb` | `rb_vm_opt_send_without_block` | 114270 | 660 | 113610 |
| `each@<internal:array>` | `rb_vm_invokeblock` | 259463 | 183096 | 76367 |
| `map@<internal:array>` | `rb_vm_invokeblock` | 79649 | 10519 | 69130 |
| `hash@activemodel-8.1.2/lib/active_model/type/value.rb` | `rb_vm_opt_send_without_block` | 67904 | 0 | 67904 |
| `hash@activemodel-8.1.2/lib/active_model/attribute.rb` | `rb_ivar_get` | 48408 | 0 | 48408 |
| `==@activemodel-8.1.2/lib/active_model/attribute.rb` | `rb_ivar_get` | 39438 | 0 | 39438 |
| `connected_to_stack@activerecord-8.1.2/lib/active_record/core.rb` | `rb_ivar_get` | 35816 | 0 | 35816 |
| `connected_to_stack@activerecord-8.1.2/lib/active_record/core.rb` | `rb_hash_aref` | 35816 | 0 | 35816 |
| `visit_Arel_Attributes_Attribute@activerecord-8.1.2/lib/arel/visitors/to_sql.rb` | `rb_ivar_get` | 34668 | 0 | 34668 |
| `stale_state@activerecord-8.1.2/lib/active_record/associations/belongs_to_association.rb` | `rb_ivar_get` | 32848 | 0 | 32848 |
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb` | `rb_vm_send` | 31998 | 0 | 31998 |
| `<<@activerecord-8.1.2/lib/arel/collectors/composite.rb` | `rb_ivar_get` | 31016 | 0 | 31016 |
| `!=@<internal:basic_object>` | `rb_vm_opt_send_without_block` | 30007 | 0 | 30007 |
| `value_for@activerecord-8.1.2/lib/active_record/scoping.rb` | `rb_vm_opt_send_without_block` | 31704 | 3852 | 27852 |
| `instance@activerecord-8.1.2/lib/active_record/scoping.rb` | `rb_ivar_get` | 27307 | 0 | 27307 |
| `instance@activerecord-8.1.2/lib/active_record/scoping.rb` | `rb_hash_aref` | 27307 | 0 | 27307 |
| `mon_synchronize@monitor.rb` | `rb_vm_send` | 23263 | 0 | 23263 |
| `hash@activerecord-8.1.2/lib/active_record/relation/query_attribute.rb` | `rb_ivar_get` | 22834 | 0 | 22834 |
| `empty?@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | `rb_ivar_get` | 22052 | 0 | 22052 |
| `current_shard@activerecord-8.1.2/lib/active_record/core.rb` | `rb_vm_opt_send_without_block` | 35274 | 14594 | 20680 |
| `current_role@activerecord-8.1.2/lib/active_record/core.rb` | `rb_vm_opt_send_without_block` | 35274 | 14594 | 20680 |
| `association@activerecord-8.1.2/lib/active_record/associations.rb` | `rb_vm_opt_send_without_block` | 23647 | 3594 | 20053 |
| `primary_key@activerecord-8.1.2/lib/active_record/attribute_methods/primary_key.rb` | `rb_vm_getinstancevariable` | 19062 | 0 | 19062 |
| `each_attributes@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | `rb_ivar_get` | 18306 | 0 | 18306 |
| `merge@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | `rb_vm_opt_send_without_block` | 18306 | 0 | 18306 |
| `get_pool_manager@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_handle` | `rb_hash_aref` | 17908 | 0 | 17908 |
| `connection_handler@activerecord-8.1.2/lib/active_record/core.rb` | `rb_hash_aref` | 17677 | 0 | 17677 |
| `connection_handler@activerecord-8.1.2/lib/active_record/core.rb` | `rb_ivar_get` | 17677 | 0 | 17677 |
| `connection_specification_name@activerecord-8.1.2/lib/active_record/connection_handling.rb` | `rb_vm_getinstancevariable` | 17032 | 0 | 17032 |
| `stale_state@activerecord-8.1.2/lib/active_record/associations/belongs_to_association.rb` | `rb_vm_send` | 16424 | 175 | 16249 |
| `merge_clauses@activerecord-8.1.2/lib/active_record/relation/merger.rb` | `rb_vm_opt_send_without_block` | 17479 | 1550 | 15929 |
| `except_predicates@activerecord-8.1.2/lib/active_record/relation/where_clause.rb` | `rb_ivar_get` | 14163 | 0 | 14163 |
| `build_arel@activerecord-8.1.2/lib/active_record/relation/query_methods.rb` | `rb_vm_opt_send_without_block` | 16669 | 3113 | 13556 |
| `create@activerecord-8.1.2/lib/active_record/relation/delegation.rb` | `rb_vm_opt_send_without_block` | 13081 | 0 | 13081 |
| `iterate_guarding_exceptions@activesupport-8.1.2/lib/active_support/notifications/fanout.rb` | `rb_vm_send` | 13081 | 0 | 13081 |
| `merge_multi_values@activerecord-8.1.2/lib/active_record/relation/merger.rb` | `rb_vm_opt_send_without_block` | 14023 | 961 | 13062 |
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb` | `rb_vm_getinstancevariable` | 12297 | 0 | 12297 |
| `visit@activerecord-8.1.2/lib/arel/visitors/visitor.rb` | `rb_vm_opt_send_without_block` | 44631 | 32584 | 12047 |
| `fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb` | `rb_vm_send` | 11920 | 0 | 11920 |

