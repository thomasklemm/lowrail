### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 3267.1 | 3267.1 | 0.00% |
| YJIT | 3075.4 | 3075.4 | 0.00% |
| ZJIT − YJIT | | | | +191.8 (+6.24%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| method dispatch (generic send path) | 459.6 | 360.3 | **+99.3** | 52% | 0.0 |
| JIT code | 338.8 | 268.5 | **+70.3** | 37% | 0.0 |
| ivar and attr access (generic) | 59.7 | 38.4 | **+21.3** | 11% | 0.0 |
| block and proc invocation (generic) | 102.5 | 83.6 | **+19.0** | 10% | 0.0 |
| GC (marking, sweeping, freeing) | 60.7 | 51.2 | **+9.5** | 5% | 0.0 |
| other runtime (cfunc bodies, hash, string, regexp, ...) | 2051.6 | 2045.9 | **+5.6** | 3% | 0.0 |
| side exits and frame materialization | 4.9 | 0.4 | **+4.5** | 2% | 0.0 |
| invalidation | 0.1 | 0.0 | **+0.1** | 0% | 0.0 |
| compile (ZJIT/YJIT compiler, profiling) | 0.3 | 0.3 | **+0.0** | 0% | 0.0 |
| write barriers | 16.7 | 20.2 | **-3.5** | -2% | 0.0 |
| allocation (objects, malloc) | 153.8 | 166.1 | **-12.3** | -6% | 0.0 |
| interpreter (YARV loop and insn helpers) | 18.2 | 40.4 | **-22.2** | -12% | 0.0 |
| total | 3267.1 | 3075.4 | **+191.8** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `<JIT code>` | JIT code | 338.8 | 268.5 | +70.3 |
| `rb_vm_exec` | method dispatch | 74.3 | 44.9 | +29.5 |
| `rb_vm_opt_send_without_block` | method dispatch | 30.9 | 13.7 | +17.1 |
| `vm_exec_core` | interpreter | 10.3 | 26.2 | -15.8 |
| `vm_invoke_iseq_block` | block and proc invocation | 15.6 | 2.5 | +13.1 |
| `setup_parameters_complex` | method dispatch | 21.3 | 9.2 | +12.1 |
| `vm_call_iseq_setup` | method dispatch | 27.4 | 17.8 | +9.6 |
| `rb_vm_send` | method dispatch | 11.2 | 2.5 | +8.7 |
| `rb_shape_get_iv_index` | ivar and attr access | 13.9 | 5.6 | +8.3 |
| `rb_ivar_lookup` | ivar and attr access | 14.1 | 6.1 | +8.0 |
| `rb_ec_stack_check` | method dispatch | 25.1 | 17.8 | +7.4 |
| `vm_callee_setup_arg` | method dispatch | 24.3 | 17.1 | +7.2 |
| `rb_vm_invokeblock` | block and proc invocation | 12.5 | 5.5 | +7.1 |
| `rb_vm_getinstancevariable` | ivar and attr access | 6.4 | 0.0 | +6.4 |
| `vm_lookup_cc` | method dispatch | 10.8 | 5.5 | +5.2 |
| `rb_ec_newobj_of` | allocation | 14.2 | 19.4 | -5.2 |
| `gc_sweep_page` | GC | 35.6 | 30.6 | +5.0 |
| `CALLER_SETUP_ARG` | method dispatch | 23.1 | 18.2 | +4.9 |
| `zjit_materialize_frames` | side exits and frame materialization | 4.9 | 0.0 | +4.8 |
| `vm_search_super_method` | method dispatch | 1.6 | 5.9 | -4.3 |
| `rb_class_allocate_instance` | allocation | 2.6 | 6.6 | -4.0 |
| `vm_search_method_slowpath0` | method dispatch | 7.6 | 3.8 | +3.8 |
| `rb_vm_invokesuper` | method dispatch | 1.1 | 4.8 | -3.7 |
| `_int_malloc` | allocation | 29.3 | 25.6 | +3.6 |
| `rb_gc_writebarrier` | write barriers | 16.3 | 19.7 | -3.5 |
| `rb_managed_id_table_lookup` | method dispatch | 16.3 | 13.1 | +3.2 |
| `rb_newobj_of` | allocation | 14.5 | 17.4 | -3.0 |
| `search_nonascii` | other runtime | 5.8 | 3.0 | +2.8 |
| `rb_str_concat` | other runtime | 2.8 | 0.0 | +2.8 |
| `rb_ec_ary_new_from_values` | allocation | 0.4 | 3.1 | -2.7 |
| `rb_builtin_ary_at_end` | interpreter | 0.0 | 2.7 | -2.7 |
| `rb_str_buf_append` | other runtime | 3.4 | 0.8 | +2.7 |
| `vm_yield_with_cfunc` | block and proc invocation | 1.0 | 3.6 | -2.7 |
| `rb_ivar_get_at_no_ractor_check` | ivar and attr access | 0.2 | 2.7 | -2.5 |
| `vm_call0_body` | method dispatch | 21.3 | 23.8 | -2.5 |
| `rb_funcallv_scope.constprop.0` | method dispatch | 13.7 | 16.1 | -2.4 |
| `RCLASS_EXT_WRITABLE` | method dispatch | 5.7 | 8.1 | -2.3 |
| `rb_shape_get_iv_index_with_hint` | ivar and attr access | 4.0 | 1.7 | +2.3 |
| `vm_call_ivar` | ivar and attr access | 4.9 | 2.9 | +2.1 |
| `rb_hash_aset` | other runtime | 21.1 | 23.2 | -2.0 |

### Unclassified (other runtime) differences above 0.5M
  +2.8 search_nonascii
  +2.8 rb_str_concat
  +2.7 rb_str_buf_append
  -2.0 rb_hash_aset
  +2.0 __memset_avx2_unaligned_erms
  -1.9 rb_obj_is_kind_of
  -1.8 ary_memcpy0
  -1.0 rb_str_cat
  +0.9 ar_insert_direct.isra.0
  +0.9 __memcpy_avx_unaligned_erms
  +0.9 str_modify_keep_cr
  +0.8 rb_string_value
  -0.7 rb_str_modify
  +0.7 rb_hash_bulk_insert.part.0
  -0.7 rb_obj_as_string_result
  +0.6 rb_enc_from_index

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `entry trampoline` | 17.6 | 0.0 | +17.6 |
| `<unmapped JIT>` | 1.7 | 14.7 | -13.0 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 7.5 | 5.0 | +2.5 |
| `each@<internal:array>` | 10.6 | 8.5 | +2.1 |
| `[]@activesupport-8.1.1/lib/active_support/isolated_execution_state.rb` | 0.2 | 2.0 | -1.8 |
| `<<@actionview-8.1.1/lib/action_view/buffers.rb` | 3.6 | 1.8 | +1.8 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | 3.5 | 5.0 | -1.5 |
| `block in perform_query@activerecord-8.1.1/lib/active_record/connection_adapters/sqlite3/database_statements.rb` | 2.2 | 0.8 | +1.4 |
| `map@<internal:array>` | 4.5 | 3.3 | +1.3 |
| `zone@activesupport-8.1.1/lib/active_support/time_with_zone.rb` | 2.0 | 0.8 | +1.3 |
| `change@activesupport-8.1.1/lib/active_support/core_ext/time/calculations.rb` | 2.7 | 1.5 | +1.2 |
| `association_instance_get@activerecord-8.1.1/lib/active_record/associations.rb` | 2.7 | 1.5 | +1.2 |
| `fetch@concurrent-ruby-1.3.5/lib/concurrent-ruby/concurrent/map.rb` | 1.8 | 0.7 | +1.2 |
| `_app_views_layouts_application_html_erb___2135693142920261643_14376@/home/user/w/rbc/lobsters-callgrind-lobste` | 1.1 | 0.0 | +1.1 |
| `for@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | 2.5 | 1.4 | +1.1 |
| `_app_views_comments__comment_html_erb___1714394254924763923_16256@/home/user/w/rbc/lobsters-callgrind-lobsters` | 1.0 | 0.0 | +1.0 |
| `initialize@activerecord-8.1.1/lib/active_record/relation.rb` | 1.8 | 0.8 | +1.0 |
| `optimized_helper@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | 1.2 | 0.3 | +0.9 |
| `for_time@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | 2.3 | 1.4 | +0.9 |
| `evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 0.0 | 0.8 | -0.8 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | 2.3 | 1.5 | +0.8 |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 4.0 | 3.2 | +0.8 |
| `new!@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | 0.0 | 0.8 | -0.8 |
| `blank?@activesupport-8.1.1/lib/active_support/core_ext/object/blank.rb` | 0.3 | 1.1 | -0.8 |
| `block in periods_for_local@tzinfo-2.0.6/lib/tzinfo/data_sources/transitions_data_timezone_info.rb` | 3.0 | 2.3 | +0.8 |
| `type_map@activerecord-8.1.1/lib/active_record/connection_adapters/abstract_adapter.rb` | 0.0 | 0.7 | -0.7 |
| `!=@<internal:basic_object>` | 0.7 | 0.0 | +0.7 |
| `klass@activerecord-8.1.1/lib/active_record/reflection.rb` | 1.3 | 0.6 | +0.7 |
| `find@<internal:array>` | 1.4 | 0.7 | +0.7 |
| `reader@activerecord-8.1.1/lib/active_record/associations/singular_association.rb` | 0.2 | 0.9 | -0.7 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 0.0)


### JIT code by YJIT codegen symbol (run b, M per iteration; total 0.0)


### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `<JIT code>` | 2363684 | 0 | 2363684 | 239992.1 | 0.0 |
| `rb_builtin_ary_at_end` | 0 | 237864 | -237864 | 0.0 | 2.6 |
| `rb_vm_opt_send_without_block` | 429183 | 196184 | 232999 | 7232.3 | 8757.4 |
| `rb_ivar_get_at_no_ractor_check` | 17276 | 227006 | -209730 | 1.9 | 12.7 |
| `rb_gc_writebarrier` | 4596 | 210399 | -205803 | 0.2 | 6.1 |
| `rb_builtin_ary_at` | 0 | 177494 | -177494 | 0.0 | 1.1 |
| `rb_builtin_fixnum_inc` | 0 | 169501 | -169501 | 0.0 | 0.5 |
| `rb_ivar_get` | 253155 | 97152 | 156003 | 34.5 | 15.2 |
| `rb_vm_getinstancevariable` | 108188 | 0 | 108188 | 11.6 | 0.0 |
| `rb_vm_send` | 138969 | 31641 | 107328 | 16886.3 | 10349.6 |
| `rb_vm_invokeblock` | 167070 | 72306 | 94764 | 20206.4 | 9245.7 |
| `builtin_inline_class_20` | 0 | 79109 | -79109 | 0.0 | 0.8 |
| `rb_yarv_ary_entry_internal` | 0 | 72522 | -72522 | 0.0 | 1.2 |
| `rb_obj_alloc` | 13799 | 79854 | -66055 | 3.2 | 13.3 |
| `rb_obj_is_kind_of` | 128689 | 193772 | -65083 | 5.2 | 8.3 |
| `rb_obj_as_string_result` | 0 | 63378 | -63378 | 0.0 | 0.7 |
| `rb_str_concat` | 59155 | 0 | 59155 | 25.5 | 0.0 |
| `rb_get_symbol_id` | 0 | 58757 | -58757 | 0.0 | 0.7 |
| `rb_ec_ary_new_from_values` | 7222 | 65748 | -58526 | 2.3 | 17.7 |
| `rb_jit_str_simple_append` | 28216 | 85849 | -57633 | 4.7 | 20.7 |
| `rb_vm_invokesuper` | 11248 | 53071 | -41823 | 21677.6 | 3651.0 |
| `rb_obj_equal` | 0 | 40917 | -40917 | 0.0 | 0.2 |
| `rb_vm_yield_with_cfunc` | 38001 | 3372 | 34629 | 3791.8 | 195.5 |
| `rb_hash_new` | 3094 | 26155 | -23061 | 0.6 | 2.3 |
| `rb_obj_not_equal` | 0 | 22823 | -22823 | 0.0 | 8.7 |
| `erb_escape_html` | 22800 | 0 | 22800 | 5.7 | 0.0 |
| `rb_vm_env_write` | 18781 | 2176 | 16605 | 0.2 | 0.1 |
| `rb_zjit_defined_ivar` | 15398 | 0 | 15398 | 1.5 | 0.0 |
| `rb_ec_str_resurrect` | 2094 | 16556 | -14462 | 0.5 | 5.0 |
| `rb_vm_setinstancevariable` | 11343 | 24844 | -13501 | 4.9 | 6.3 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `each@<internal:array>` | `rb_vm_invokeblock` | 87327 | 50278 | 37049 |
| `map@<internal:array>` | `rb_vm_invokeblock` | 39410 | 5649 | 33761 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | `rb_vm_send` | 27931 | 0 | 27931 |
| `hash@activemodel-8.1.1/lib/active_model/attribute.rb` | `rb_ivar_get` | 27717 | 0 | 27717 |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb` | `rb_vm_opt_send_without_block` | 41909 | 18478 | 23431 |
| `association_instance_get@activerecord-8.1.1/lib/active_record/associations.rb` | `rb_vm_getinstancevariable` | 21838 | 0 | 21838 |
| `association@activerecord-8.1.1/lib/active_record/associations.rb` | `rb_vm_opt_send_without_block` | 21290 | 1233 | 20057 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | `rb_vm_getinstancevariable` | 19821 | 0 | 19821 |
| `<<@activerecord-8.1.1/lib/arel/collectors/composite.rb` | `rb_ivar_get` | 19242 | 0 | 19242 |
| `stale_state@activerecord-8.1.1/lib/active_record/associations/belongs_to_association.rb` | `rb_ivar_get` | 17024 | 0 | 17024 |
| `build_arel@activerecord-8.1.1/lib/active_record/relation/query_methods.rb` | `rb_vm_opt_send_without_block` | 13807 | 2338 | 11469 |
| `cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | `rb_ivar_get` | 11214 | 0 | 11214 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | `rb_vm_opt_send_without_block` | 9543 | 0 | 9543 |
| `association_primary_key@activerecord-8.1.1/lib/active_record/reflection.rb` | `rb_ivar_get` | 9058 | 0 | 9058 |
| `cast@activemodel-8.1.1/lib/active_model/type/value.rb` | `rb_vm_opt_send_without_block` | 8895 | 0 | 8895 |
| `_app_views_comments__comment_html_erb___1714394254924763923_16256@/home/user/w/rbc/lobsters-callgrin` | `rb_vm_getinstancevariable` | 7888 | 0 | 7888 |
| `type_cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | `rb_ivar_get` | 7476 | 0 | 7476 |
| `klass@activerecord-8.1.1/lib/active_record/associations/association.rb` | `rb_ivar_get` | 7467 | 0 | 7467 |
| `hash@activerecord-8.1.1/lib/active_record/relation/query_attribute.rb` | `rb_ivar_get` | 7387 | 0 | 7387 |
| `for_time@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | `rb_vm_opt_send_without_block` | 7326 | 0 | 7326 |
| `_app_views_layouts_application_html_erb___2135693142920261643_14376@/home/user/w/rbc/lobsters-callgr` | `rb_vm_getinstancevariable` | 6842 | 0 | 6842 |
| `associate_records_to_owner@activerecord-8.1.1/lib/active_record/associations/preloader/association.r` | `rb_ivar_get` | 6828 | 0 | 6828 |
| `block in grouped_records@activerecord-8.1.1/lib/active_record/associations/preloader/branch.rb` | `rb_vm_opt_send_without_block` | 7025 | 448 | 6577 |
| `stale_target?@activerecord-8.1.1/lib/active_record/associations/association.rb` | `rb_vm_opt_send_without_block` | 6452 | 0 | 6452 |
| `downto@<internal:numeric>` | `rb_vm_invokeblock` | 6152 | 0 | 6152 |
| `instance@activerecord-8.1.1/lib/active_record/scoping.rb` | `rb_hash_aref` | 5826 | 0 | 5826 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 8622 | 2874 | 5748 |
| `visit@activerecord-8.1.1/lib/arel/visitors/visitor.rb` | `rb_vm_opt_send_without_block` | 13988 | 8259 | 5729 |
| `association_key_name@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | `rb_ivar_get` | 5695 | 0 | 5695 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | `rb_vm_send` | 5596 | 0 | 5596 |
| `connected_to_stack@activerecord-8.1.1/lib/active_record/core.rb` | `rb_hash_aref` | 5522 | 0 | 5522 |
| `deserialize@activemodel-8.1.1/lib/active_model/type/value.rb` | `rb_vm_opt_send_without_block` | 5637 | 126 | 5511 |
| `block in load_records@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | `rb_ivar_get` | 4758 | 0 | 4758 |
| `_app_views_comments__comment_html_erb___1714394254924763923_16512@/home/user/w/rbc/lobsters-callgrin` | `rb_vm_getinstancevariable` | 4400 | 0 | 4400 |
| `find_minimum_transition@tzinfo-2.0.6/lib/tzinfo/data_sources/transitions_data_timezone_info.rb` | `rb_vm_send` | 4370 | 0 | 4370 |
| `zone@activesupport-8.1.1/lib/active_support/time_with_zone.rb` | `rb_ivar_get` | 4370 | 0 | 4370 |
| `accept@psych-5.2.6/lib/psych/visitors/visitor.rb` | `rb_vm_opt_send_without_block` | 4278 | 0 | 4278 |
| `accept@psych-5.2.6/lib/psych/visitors/visitor.rb` | `rb_hash_aref` | 4275 | 0 | 4275 |
| `accept@psych-5.2.6/lib/psych/visitors/to_ruby.rb` | `rb_ivar_get` | 4272 | 0 | 4272 |
| `association_class@activerecord-8.1.1/lib/active_record/reflection.rb` | `rb_ivar_get` | 4126 | 0 | 4126 |

