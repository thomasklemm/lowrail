### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 4833.6 | 4833.6 | 0.00% |
| YJIT | 4675.2 | 4675.2 | 0.00% |
| ZJIT − YJIT | | | | +158.4 (+3.39%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| JIT code | 662.2 | 561.2 | **+101.0** | 64% | 0.0 |
| method dispatch (generic send path) | 817.6 | 724.0 | **+93.6** | 59% | 0.0 |
| block and proc invocation (generic) | 217.4 | 170.3 | **+47.1** | 30% | 0.0 |
| side exits and frame materialization | 14.7 | 1.1 | **+13.6** | 9% | 0.0 |
| ivar and attr access (generic) | 57.7 | 49.8 | **+7.9** | 5% | 0.0 |
| invalidation | 0.0 | 0.0 | **-0.0** | -0% | 0.0 |
| compile (ZJIT/YJIT compiler, profiling) | 0.0 | 0.1 | **-0.1** | -0% | 0.0 |
| GC (marking, sweeping, freeing) | 112.8 | 113.1 | **-0.2** | -0% | 0.0 |
| other runtime (cfunc bodies, hash, string, regexp, ...) | 2563.0 | 2574.9 | **-11.9** | -8% | 0.0 |
| write barriers | 41.9 | 54.9 | **-13.0** | -8% | 0.0 |
| interpreter (YARV loop and insn helpers) | 46.5 | 77.4 | **-30.9** | -20% | 0.0 |
| allocation (objects, malloc) | 299.9 | 348.5 | **-48.6** | -31% | 0.0 |
| total | 4833.6 | 4675.2 | **+158.4** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `<JIT code>` | JIT code | 662.2 | 561.2 | +101.0 |
| `rb_vm_exec` | method dispatch | 125.7 | 91.2 | +34.5 |
| `vm_invoke_iseq_block` | block and proc invocation | 33.6 | 6.3 | +27.2 |
| `vm_exec_core` | interpreter | 22.7 | 43.2 | -20.5 |
| `rb_vm_invokeblock` | block and proc invocation | 26.2 | 6.2 | +19.9 |
| `zjit_materialize_frames` | side exits and frame materialization | 14.5 | 0.1 | +14.5 |
| `rb_vm_send` | method dispatch | 18.7 | 5.3 | +13.4 |
| `rb_gc_writebarrier` | write barriers | 40.1 | 53.1 | -13.0 |
| `CALLER_SETUP_ARG` | method dispatch | 43.7 | 31.3 | +12.4 |
| `rb_ec_newobj_of` | allocation | 41.6 | 52.6 | -10.9 |
| `vm_call_iseq_setup` | method dispatch | 42.1 | 32.1 | +10.0 |
| `rb_ivar_lookup` | ivar and attr access | 14.8 | 4.8 | +9.9 |
| `rb_shape_get_iv_index` | ivar and attr access | 12.8 | 2.9 | +9.9 |
| `rb_newobj_of` | allocation | 36.7 | 46.4 | -9.7 |
| `rb_class_allocate_instance` | allocation | 4.0 | 12.9 | -8.9 |
| `rb_ec_stack_check` | method dispatch | 41.2 | 32.6 | +8.6 |
| `vm_callee_setup_arg` | method dispatch | 36.9 | 28.6 | +8.3 |
| `setup_parameters_complex` | method dispatch | 44.9 | 36.9 | +7.9 |
| `rb_vm_opt_send_without_block` | method dispatch | 23.6 | 16.0 | +7.5 |
| `rb_obj_fields` | ivar and attr access | 11.2 | 18.5 | -7.3 |
| `rb_ec_ary_new_from_values` | allocation | 0.4 | 7.1 | -6.7 |
| `vm_search_super_method` | method dispatch | 9.0 | 15.0 | -6.1 |
| `ary_memcpy0` | other runtime | 8.4 | 14.2 | -5.9 |
| `rb_ivar_get_at_no_ractor_check` | ivar and attr access | 0.5 | 6.2 | -5.6 |
| `rb_vm_invokesuper` | method dispatch | 5.5 | 11.1 | -5.6 |
| `rb_obj_is_kind_of` | other runtime | 10.4 | 15.8 | -5.3 |
| `RCLASS_EXT_WRITABLE` | method dispatch | 13.9 | 19.2 | -5.3 |
| `rb_gc_get_objspace` | allocation | 21.0 | 26.0 | -5.0 |
| `vm_call0_body` | method dispatch | 38.9 | 43.9 | -5.0 |
| `rb_builtin_ary_at_end` | interpreter | 0.0 | 4.9 | -4.9 |
| `vm_call_method_each_type` | method dispatch | 9.6 | 4.8 | +4.9 |
| `rb_funcallv_scope.constprop.0` | method dispatch | 27.3 | 32.1 | -4.8 |
| `vm_call_method` | method dispatch | 7.9 | 3.4 | +4.5 |
| `vm_call_symbol` | method dispatch | 8.7 | 5.1 | +3.6 |
| `vm_base_ptr` | method dispatch | 3.7 | 6.8 | -3.1 |
| `rb_hash_aset` | other runtime | 71.7 | 74.6 | -3.0 |
| `rb_obj_alloc` | allocation | 1.8 | 4.5 | -2.6 |
| `vm_call0_cc` | method dispatch | 23.3 | 25.9 | -2.6 |
| `rb_obj_as_string_result` | other runtime | 0.0 | 2.6 | -2.6 |
| `rb_str_buf_append` | other runtime | 8.3 | 5.8 | +2.6 |

### Unclassified (other runtime) differences above 0.5M
  -5.9 ary_memcpy0
  -5.3 rb_obj_is_kind_of
  -3.0 rb_hash_aset
  -2.6 rb_obj_as_string_result
  +2.6 rb_str_buf_append
  +2.5 rb_str_concat
  +2.5 any_hash
  +1.4 ar_insert_direct.isra.0
  -1.4 __memset_avx2_unaligned_erms
  -1.3 find_table_entry_ind
  -1.3 rb_struct_initialize_m
  +1.2 rb_hash_bulk_insert.part.0
  +0.9 search_nonascii
  -0.9 rb_str_cat
  -0.9 rb_obj_not_equal
  +0.8 str_modify_keep_cr
  +0.8 VM_CF_BLOCK_HANDLER.isra.0
  -0.8 rb_ary_store
  +0.8 rb_string_value
  -0.7 rb_obj_equal
  +0.7 coderange_scan
  -0.7 rb_str_modify
  -0.7 rb_get_alloc_func
  +0.7 rb_enc_from_index
  -0.6 rb_current_ec
  +0.6 rb_vm_method_cfunc_is
  -0.5 ary_make_partial
  +0.5 rb_check_id

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `entry trampoline` | 29.5 | 0.0 | +29.5 |
| `<unmapped JIT>` | 5.1 | 20.4 | -15.4 |
| `get_header@rack-3.1.17/lib/rack/request.rb` | 2.9 | 10.1 | -7.2 |
| `[]@activesupport-8.1.1/lib/active_support/isolated_execution_state.rb` | 0.6 | 5.1 | -4.4 |
| `each@<internal:array>` | 20.7 | 16.9 | +3.7 |
| `build_handle@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | 3.5 | 0.4 | +3.2 |
| `block in try_precompressed_files@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | 3.9 | 0.9 | +3.0 |
| `evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 0.0 | 2.9 | -2.9 |
| `optimized_helper@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | 3.7 | 0.9 | +2.9 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | 3.6 | 0.8 | +2.8 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 6.0 | 3.3 | +2.6 |
| `compute_if_absent@concurrent-ruby-1.3.5/lib/concurrent-ruby/concurrent/collection/map/mri_map_backend.rb` | 2.8 | 0.3 | +2.5 |
| `blank?@activesupport-8.1.1/lib/active_support/core_ext/object/blank.rb` | 0.5 | 2.8 | -2.3 |
| `instrument@activesupport-8.1.1/lib/active_support/notifications/instrumenter.rb` | 2.5 | 0.3 | +2.2 |
| `file_readable?@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | 0.0 | 2.2 | -2.2 |
| `move@actionpack-8.1.1/lib/action_dispatch/journey/gtg/transition_table.rb` | 4.4 | 2.2 | +2.2 |
| `call@activesupport-8.1.1/lib/active_support/callbacks.rb` | 8.0 | 5.8 | +2.2 |
| `_app_views_posts_show_html_erb___4478908533362565439_8528@/home/user/w/rbc/railsbench-callgrind-railsbench-a-m` | 2.1 | 0.0 | +2.1 |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | 0.2 | 2.3 | -2.1 |
| `session_exists?@rack-session-2.1.1/lib/rack/session/abstract/id.rb` | 2.5 | 0.4 | +2.1 |
| `block in perform_query@activerecord-8.1.1/lib/active_record/connection_adapters/sqlite3/database_statements.rb` | 3.0 | 1.0 | +2.0 |
| `instrument@activesupport-8.1.1/lib/active_support/notifications.rb` | 3.5 | 1.6 | +1.9 |
| `block in <class:Format>@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 2.3 | 0.4 | +1.9 |
| `_find_all@actionview-8.1.1/lib/action_view/template/resolver.rb` | 3.1 | 1.2 | +1.9 |
| `_app_views_posts_show_html_erb__4454336039397333132_8528@/home/user/w/rbc/railsbench-callgrind-railsbench-a-m-` | 0.0 | 1.8 | -1.8 |
| `block in _app_views_posts_index_html_erb__2149574827343250576_8912@/home/user/w/rbc/railsbench-callgrind-rails` | 1.8 | 0.0 | +1.8 |
| `initialize@rack-3.1.17/lib/rack/request.rb` | 0.0 | 1.8 | -1.8 |
| `fetch_header@rack-3.1.17/lib/rack/request.rb` | 1.0 | 2.8 | -1.8 |
| `map@<internal:array>` | 6.0 | 4.2 | +1.8 |
| `local_level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | 3.1 | 1.4 | +1.7 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 0.0)


### JIT code by YJIT codegen symbol (run b, M per iteration; total 0.0)


### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `<JIT code>` | 4441656 | 0 | 4441656 | 240940.0 | 0.0 |
| `rb_gc_writebarrier` | 6000 | 491808 | -485808 | 0.2 | 14.3 |
| `rb_ivar_get_at_no_ractor_check` | 45805 | 515952 | -470147 | 7.1 | 30.9 |
| `rb_builtin_ary_at_end` | 0 | 433809 | -433809 | 0.0 | 4.8 |
| `rb_builtin_ary_at` | 0 | 271140 | -271140 | 0.0 | 1.6 |
| `rb_vm_invokeblock` | 344998 | 82149 | 262849 | 32593.9 | 11050.7 |
| `rb_builtin_fixnum_inc` | 0 | 244030 | -244030 | 0.0 | 0.7 |
| `rb_obj_as_string_result` | 0 | 240018 | -240018 | 0.0 | 2.6 |
| `rb_obj_is_kind_of` | 162235 | 362714 | -200479 | 6.5 | 16.8 |
| `rb_ivar_get` | 199458 | 0 | 199458 | 26.2 | 0.0 |
| `rb_vm_send` | 232404 | 65313 | 167091 | 13849.0 | 5495.6 |
| `rb_yarv_ary_entry_internal` | 0 | 142652 | -142652 | 0.0 | 2.3 |
| `rb_obj_alloc` | 56457 | 194899 | -138442 | 20.4 | 39.5 |
| `rb_ec_ary_new_from_values` | 5289 | 143494 | -138205 | 50.5 | 36.3 |
| `builtin_inline_class_20` | 0 | 125051 | -125051 | 0.0 | 1.3 |
| `rb_vm_opt_send_without_block` | 344148 | 234239 | 109909 | 1338.2 | 1711.8 |
| `rb_vm_env_write` | 129361 | 21970 | 107391 | 1.6 | 0.9 |
| `rb_obj_equal` | 0 | 105054 | -105054 | 0.0 | 0.5 |
| `rb_hash_new` | 3231 | 86602 | -83371 | 4.4 | 11.1 |
| `rb_vm_invokesuper` | 57317 | 120465 | -63148 | 20991.7 | 394.2 |
| `rb_jit_str_simple_append` | 58030 | 112141 | -54111 | 16.4 | 32.5 |
| `rb_str_concat` | 54111 | 0 | 54111 | 23.5 | 0.0 |
| `rb_obj_not_equal` | 0 | 47974 | -47974 | 0.0 | 19.8 |
| `rb_hash_aref` | 1126132 | 1173850 | -47718 | 278.8 | 306.8 |
| `erb_escape_html` | 42172 | 0 | 42172 | 9.8 | 0.0 |
| `rb_get_symbol_id` | 0 | 41853 | -41853 | 0.0 | 0.2 |
| `rb_str_dup` | 0 | 39579 | -39579 | 0.0 | 28.8 |
| `rb_builtin_ary_first` | 0 | 31236 | -31236 | 0.0 | 0.2 |
| `rb_obj_dummy0` | 0 | 30090 | -30090 | 0.0 | 0.1 |
| `rb_hash_new_capa` | 1468 | 31205 | -29737 | 2.0 | 4.4 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `each@<internal:array>` | `rb_vm_invokeblock` | 200651 | 56278 | 144373 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 77883 | 25961 | 51922 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | `rb_vm_opt_send_without_block` | 41805 | 0 | 41805 |
| `map@<internal:array>` | `rb_vm_invokeblock` | 41197 | 9300 | 31897 |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb` | `rb_ivar_get` | 28714 | 0 | 28714 |
| `local_level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_hash_aref` | 25961 | 0 | 25961 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_hash_aref` | 25961 | 0 | 25961 |
| `iterate_guarding_exceptions@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | `rb_vm_send` | 21948 | 0 | 21948 |
| `url_options@actionview-8.1.1/lib/action_view/routing_url_for.rb` | `rb_ivar_get` | 18114 | 0 | 18114 |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb` | `rb_ivar_get` | 18114 | 0 | 18114 |
| `block in each_precompressed_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb` | `rb_vm_invokeblock` | 17883 | 0 | 17883 |
| `select@<internal:array>` | `rb_vm_invokeblock` | 16013 | 0 | 16013 |
| `request@actionpack-8.1.1/lib/action_dispatch/middleware/cookies.rb` | `rb_ivar_get` | 15896 | 0 | 15896 |
| `block in initialize@rack-3.1.17/lib/rack/response.rb` | `rb_hash_aref` | 15896 | 0 | 15896 |
| `id@activerecord-8.1.1/lib/active_record/attribute_methods/primary_key.rb` | `rb_vm_send` | 15440 | 0 | 15440 |
| `script_name@rack-3.1.17/lib/rack/request.rb` | `rb_hash_aref` | 14357 | 0 | 14357 |
| `fetch_header@rack-3.1.17/lib/rack/request.rb` | `rb_vm_send` | 13961 | 0 | 13961 |
| `routes@actionpack-8.1.1/lib/action_dispatch/http/request.rb` | `rb_hash_aref` | 12357 | 0 | 12357 |
| `block (2 levels) in search_combinations@actionview-8.1.1/lib/action_view/path_set.rb` | `rb_vm_invokeblock` | 12078 | 0 | 12078 |
| `before@activesupport-8.1.1/lib/active_support/execution_wrapper.rb` | `rb_vm_opt_send_without_block` | 12000 | 0 | 12000 |
| `find@actionpack-8.1.1/lib/action_dispatch/request/session.rb` | `rb_hash_aref` | 11935 | 0 | 11935 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | `rb_ivar_get` | 10357 | 0 | 10357 |
| `block in initialize@actionpack-8.1.1/lib/action_dispatch/http/response.rb` | `rb_hash_aref` | 10000 | 0 | 10000 |
| `parameters@actionpack-8.1.1/lib/action_dispatch/http/parameters.rb` | `rb_hash_aref` | 9983 | 0 | 9983 |
| `optimize_routes_generation?@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | `rb_vm_opt_send_without_block` | 9057 | 0 | 9057 |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb` | `rb_vm_opt_send_without_block` | 9057 | 0 | 9057 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | `rb_vm_opt_send_without_block` | 9057 | 0 | 9057 |
| `block in listening?@activesupport-8.1.1/lib/active_support/notifications/fanout.rb` | `rb_vm_opt_send_without_block` | 8013 | 0 | 8013 |
| `raw_host_with_port@actionpack-8.1.1/lib/action_dispatch/http/url.rb` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `policy_present?@actionpack-8.1.1/lib/action_dispatch/http/content_security_policy.rb` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `instrumenter@activesupport-8.1.1/lib/active_support/notifications.rb` | `rb_hash_aref` | 15974 | 7987 | 7987 |
| `scheme@rack-3.1.17/lib/rack/request.rb` | `rb_hash_aref` | 7974 | 0 | 7974 |
| `exists?@actionpack-8.1.1/lib/action_dispatch/request/session.rb` | `rb_vm_opt_send_without_block` | 7948 | 0 | 7948 |
| `block in id@actionpack-8.1.1/lib/action_dispatch/request/session.rb` | `rb_vm_opt_send_without_block` | 7948 | 0 | 7948 |
| `block in extract_session_id@actionpack-8.1.1/lib/action_dispatch/middleware/session/cookie_store.rb` | `rb_vm_send` | 7948 | 0 | 7948 |
| `valid_accept_header@actionpack-8.1.1/lib/action_dispatch/http/mime_negotiation.rb` | `rb_hash_aref` | 7948 | 0 | 7948 |
| `upgrade_legacy_hmac_aes_cbc_cookies?@actionpack-8.1.1/lib/action_dispatch/middleware/cookies.rb` | `rb_ivar_get` | 7948 | 0 | 7948 |
| `session_exists?@rack-session-2.1.1/lib/rack/session/abstract/id.rb` | `rb_hash_aref` | 7948 | 0 | 7948 |
| `connected_to_stack@activerecord-8.1.1/lib/active_record/core.rb` | `rb_hash_aref` | 7940 | 0 | 7940 |
| `block (2 levels) in <module:Callbacks>@actionpack-8.1.1/lib/abstract_controller/callbacks.rb` | `rb_ivar_get` | 7940 | 0 | 7940 |

