Price per extra operation: send/yield 285 Ir (135.8 M over 476655 calls), ivar 78 Ir (21.3 M over 271354 reads)

#### Extra generic operations by ZJIT reason (ZJIT fallbacks not matched by a YJIT generic call at the same ISEQ; per iteration)

| reason | ZJIT count | extra vs YJIT | est. M Ir |
|---|---:|---:|---:|
| `getivar_fallback_no_profile_missing_ic` | 209621 | 193027 | 15.1 |
| `send_fallback_send_polymorphic_fallback` | 272799 | 171300 | 48.8 |
| `send_fallback_invokeblock_not_specialized` | 153577 | 89339 | 25.5 |
| `send_fallback_send_block_arg_not_nil` | 94965 | 87944 | 25.1 |
| `getivar_fallback_no_side_exits` | 150349 | 75169 | 5.9 |
| `send_fallback_send_megamorphic` | 109078 | 42750 | 12.2 |
| `send_fallback_one_or_more_complex_arg_pass` | 41777 | 21311 | 6.1 |
| `send_fallback_send_not_optimized_method_type_optimized` | 25766 | 19843 | 5.7 |
| `send_fallback_send_not_optimized_need_permission` | 15959 | 15567 | 4.4 |
| `send_fallback_send_polymorphic` | 10966 | 10133 | 2.9 |
| `send_fallback_invokeblock_polymorphic_miss` | 13368 | 5534 | 1.6 |
| `send_fallback_sendforward_not_specialized` | 31883 | 5040 | 1.4 |
| `send_fallback_super_polymorphic` | 2661 | 2641 | 0.8 |
| `setivar_fallback_no_side_exits` | 5951 | 2203 | 0.2 |
| `send_fallback_super_complex_args_pass` | 3227 | 2151 | 0.6 |
| `send_fallback_send_not_optimized_method_type` | 5789 | 1036 | 0.3 |
| `exit_guard_type_failure` | 986 | 986 | – |
| `send_fallback_singleton_class_seen` | 1168 | 827 | 0.2 |
| `send_fallback_super_call_with_block` | 738 | 491 | 0.1 |
| `exit_patchpoint_method_redefined` | 483 | 483 | – |
| `send_fallback_super_from_block` | 1397 | 384 | 0.1 |
| `getivar_fallback_polymorphic` | 347 | 347 | 0.0 |
| `getivar_fallback_megamorphic` | 322 | 322 | 0.0 |
| `send_fallback_invokesuperforward_not_specialized` | 2474 | 318 | 0.1 |
| `setivar_fallback_complex` | 332 | 283 | 0.0 |

#### Top sites (per iteration)

| ISEQ | kind | ZJIT fallbacks | YJIT generic calls | extra | est. M Ir | ZJIT reasons |
|---|---|---:|---:|---:|---:|---|
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb` | send | 58495 | 0 | 58495 | 16.7 | send_block_arg_not_nil 58380, send_polymorphic_fallback 115 |
| `each@<internal:array>` | yield | 87327 | 50278 | 37049 | 10.6 | invokeblock_not_specialized 87327 |
| `map@<internal:array>` | yield | 39410 | 5649 | 33761 | 9.6 | invokeblock_not_specialized 39410 |
| `<<@activerecord-8.1.1/lib/arel/collectors/composite.rb` | ivar | 28760 | 0 | 28760 | 2.3 | no_profile_missing_ic 28760 |
| `hash@activemodel-8.1.1/lib/active_model/attribute.rb` | ivar | 27717 | 0 | 27717 | 2.2 | no_profile_missing_ic 27717 |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb` | send | 41909 | 18478 | 23431 | 6.7 | send_polymorphic_fallback 41909 |
| `association@activerecord-8.1.1/lib/active_record/associations.rb` | send | 21290 | 1233 | 20057 | 5.7 | send_polymorphic_fallback 21290 |
| `stale_state@activerecord-8.1.1/lib/active_record/associations/belongs_to_association.rb` | ivar | 17024 | 0 | 17024 | 1.3 | no_side_exits 17024 |
| `_app_views_comments__comment_html_erb@benchmarks/lobsters/app/views/comments/_comment.html.erb` | ivar | 16094 | 0 | 16094 | 1.3 | no_side_exits 15378, no_profile_missing_ic 454, complex 262 |
| `cast@activemodel-8.1.1/lib/active_model/type/value.rb` | send | 13728 | 0 | 13728 | 3.9 | send_polymorphic_fallback 13728 |
| `build_arel@activerecord-8.1.1/lib/active_record/relation/query_methods.rb` | send | 13807 | 2338 | 11469 | 3.3 | send_megamorphic 12438, send_polymorphic_fallback 1356, one_or_more_complex_arg_pass 13 |
| `cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | ivar | 11214 | 0 | 11214 | 0.9 | no_profile_missing_ic 11214 |
| `klass@activerecord-8.1.1/lib/active_record/associations/association.rb` | ivar | 9898 | 0 | 9898 | 0.8 | no_side_exits 5084, no_profile_missing_ic 4814 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | send | 9543 | 0 | 9543 | 2.7 | send_not_optimized_need_permission 9543 |
| `association_key_name@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | ivar | 9342 | 0 | 9342 | 0.7 | no_profile_missing_ic 9342 |
| `association_primary_key@activerecord-8.1.1/lib/active_record/reflection.rb` | ivar | 9058 | 0 | 9058 | 0.7 | no_profile_missing_ic 9058 |
| `type_cast@activerecord-typedstore-1.6.0/lib/active_record/typed_store/field.rb` | ivar | 7476 | 0 | 7476 | 0.6 | no_profile_missing_ic 7476 |
| `new!@tzinfo-2.0.6/lib/tzinfo/timestamp.rb` | send | 7326 | 0 | 7326 | 2.1 | send_not_optimized_method_type_optimized 7326 |
| `find_minimum_transition@tzinfo-2.0.6/lib/tzinfo/data_sources/transitions_data_timezone_info.rb` | send | 7326 | 0 | 7326 | 2.1 | one_or_more_complex_arg_pass 7326 |
| `loaded?@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb` | ivar | 7127 | 0 | 7127 | 0.6 | no_profile_missing_ic 7031, polymorphic 96 |
| `query_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/query.rb` | send | 6990 | 0 | 6990 | 2.0 | send_polymorphic_fallback 6990 |
| `associate_records_to_owner@activerecord-8.1.1/lib/active_record/associations/preloader/associat` | ivar | 6828 | 0 | 6828 | 0.5 | no_side_exits 6353, no_profile_missing_ic 475 |
| `block in grouped_records@activerecord-8.1.1/lib/active_record/associations/preloader/branch.rb` | send | 7025 | 448 | 6577 | 1.9 | send_polymorphic_fallback 7025 |
| `mon_synchronize@monitor.rb` | send | 6504 | 0 | 6504 | 1.9 | send_block_arg_not_nil 6504 |
| `polymorphic?@activerecord-8.1.1/lib/active_record/reflection.rb` | ivar | 6470 | 0 | 6470 | 0.5 | no_profile_missing_ic 6430, polymorphic 40 |

