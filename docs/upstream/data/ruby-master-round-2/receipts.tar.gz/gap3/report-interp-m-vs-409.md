### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 7301.4 | 7301.4 | 0.00% |
| YJIT | 7338.1 | 7338.1 | 0.00% |
| ZJIT − YJIT | | | | -36.7 (-0.50%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| other runtime (cfunc bodies, hash, string, regexp, ...) | 2655.9 | 2565.4 | **+90.5** | -247% | 0.0 |
| interpreter (YARV loop and insn helpers) | 1819.3 | 1745.4 | **+73.9** | -201% | 0.0 |
| method dispatch (generic send path) | 1812.0 | 1776.1 | **+35.9** | -98% | 0.0 |
| allocation (objects, malloc) | 351.0 | 343.6 | **+7.4** | -20% | 0.0 |
| side exits and frame materialization | 0.1 | 0.0 | **+0.1** | -0% | 0.0 |
| JIT code | 5.4 | 5.9 | **-0.4** | 1% | 0.0 |
| invalidation | 0.0 | 0.5 | **-0.5** | 1% | 0.0 |
| block and proc invocation (generic) | 259.9 | 264.8 | **-4.8** | 13% | 0.0 |
| ivar and attr access (generic) | 222.9 | 243.3 | **-20.4** | 56% | 0.0 |
| write barriers | 64.6 | 89.5 | **-24.8** | 68% | 0.0 |
| GC (marking, sweeping, freeing) | 110.1 | 303.7 | **-193.6** | 527% | 0.0 |
| total | 7301.4 | 7338.1 | **-36.7** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `__memset_avx2_unaligned_erms` | other runtime | 137.8 | 5.6 | +132.1 |
| `gc_sweep_step` | GC | 0.1 | 128.3 | -128.2 |
| `rb_wb_protected_newobj_of` | allocation | 0.0 | 114.1 | -114.1 |
| `vm_setivar` | ivar and attr access | 0.0 | 85.9 | -85.9 |
| `gc_sweep_page` | GC | 82.9 | 0.0 | +82.9 |
| `vm_setivar.isra.0` | ivar and attr access | 77.8 | 0.0 | +77.8 |
| `vm_sendish.constprop.0` | method dispatch | 0.0 | 77.1 | -77.1 |
| `any_hash` | other runtime | 74.8 | 0.0 | +74.8 |
| `vm_exec_core` | interpreter | 1700.6 | 1628.9 | +71.6 |
| `vm_base_ptr` | method dispatch | 192.7 | 121.2 | +71.5 |
| `rb_gc_impl_writebarrier` | write barriers | 0.0 | 69.9 | -69.9 |
| `ar_update` | other runtime | 0.0 | 54.9 | -54.9 |
| `rb_gc_obj_free` | GC | 10.8 | 63.5 | -52.8 |
| `rb_ec_newobj_of` | allocation | 50.2 | 0.0 | +50.2 |
| `rb_newobj_of` | allocation | 48.4 | 0.0 | +48.4 |
| `rb_gc_obj_free_vm_weak_references` | GC | 5.2 | 52.9 | -47.7 |
| `rb_hash_aset` | other runtime | 74.6 | 28.4 | +46.2 |
| `ar_find_entry_hint` | other runtime | 45.8 | 0.0 | +45.8 |
| `rb_gc_writebarrier` | write barriers | 62.9 | 17.1 | +45.7 |
| `tbl_update.isra.0` | other runtime | 0.0 | 37.2 | -37.2 |
| `rb_hash_aref` | other runtime | 36.4 | 68.2 | -31.8 |
| `rb_gc_get_objspace` | allocation | 29.1 | 0.0 | +29.1 |
| `rb_any_hash` | other runtime | 3.2 | 29.1 | -25.9 |
| `rb_enc_mbclen` | other runtime | 0.0 | 25.6 | -25.6 |
| `vm_search_method_slowpath0` | method dispatch | 23.8 | 0.0 | +23.8 |
| `rb_str_buf_append` | other runtime | 11.1 | 32.6 | -21.5 |
| `rb_check_frozen_inline` | other runtime | 20.9 | 0.0 | +20.9 |
| `rb_file_join` | other runtime | 0.0 | 20.8 | -20.8 |
| `rb_st_lookup` | other runtime | 86.7 | 66.3 | +20.4 |
| `rb_st_update` | other runtime | 57.0 | 39.3 | +17.7 |
| `vm_search_cc` | method dispatch | 0.0 | 16.8 | -16.8 |
| `st_general_delete` | other runtime | 15.8 | 0.0 | +15.8 |
| `rb_st_delete` | other runtime | 0.2 | 15.9 | -15.7 |
| `rb_str_concat_literals` | other runtime | 28.2 | 12.6 | +15.6 |
| `tbl_update_modify` | other runtime | 21.6 | 36.1 | -14.6 |
| `rb_obj_class` | other runtime | 19.4 | 32.3 | -12.9 |
| `rb_enc_str_coderange` | other runtime | 0.0 | 12.5 | -12.5 |
| `opt_equality_specialized` | other runtime | 0.0 | 12.4 | -12.4 |
| `setup_parameters_complex` | method dispatch | 99.8 | 87.5 | +12.2 |
| `reg_prepare_re` | other runtime | 12.2 | 0.0 | +12.2 |

### Unclassified (other runtime) differences above 0.5M
  +132.1 __memset_avx2_unaligned_erms
  +74.8 any_hash
  -54.9 ar_update
  +46.2 rb_hash_aset
  +45.8 ar_find_entry_hint
  -37.2 tbl_update.isra.0
  -31.8 rb_hash_aref
  -25.9 rb_any_hash
  -25.6 rb_enc_mbclen
  -21.5 rb_str_buf_append
  +20.9 rb_check_frozen_inline
  -20.8 rb_file_join
  +20.4 rb_st_lookup
  +17.7 rb_st_update
  +15.8 st_general_delete
  -15.7 rb_st_delete
  +15.6 rb_str_concat_literals
  -14.6 tbl_update_modify
  -12.9 rb_obj_class
  -12.5 rb_enc_str_coderange
  -12.4 opt_equality_specialized
  +12.2 reg_prepare_re
  -10.6 rb_reg_prepare_re
  +10.0 rb_current_ec
  +10.0 rb_class_of
  +10.0 ar_add_direct_i
  -9.8 rb_eql
  +9.8 ar_force_convert_table
  +9.1 st_general_foreach
  -9.0 hash_foreach_call
  +8.2 rb_ary_includes_by_eql
  -8.0 ar_force_convert_table.isra.0
  +7.8 rb_ec_yield
  -7.6 opt_equality_by_mid_slowpath
  +7.3 typed_data_alloc_in
  -7.2 rb_check_convert_type_with_id
  -6.9 ar_lookup
  -6.9 optimized_escape_html
  -6.6 rb_get_alloc_func
  -6.5 rb_hash_has_key
  -6.5 rb_eql_opt
  +6.0 rb_enc_associate_index
  +5.8 rb_obj_freeze_inline.part.0
  -5.7 rb_st_foreach_check
  -5.6 ar_insert.isra.0
  +5.4 find_table_entry_ind
  -5.2 vm_invokeblock_i
  -4.9 rb_gc_obj_slot_size
  -4.8 rb_hash_update_i
  -4.7 rb_enc_get
  -4.6 rb_ary_entry
  +4.6 ar_insert_direct.isra.0
  +4.5 rb_ary_join
  -4.4 rb_ary_diff
  +4.1 rebuild_table_with
  -4.1 rb_obj_freeze_inline
  +4.0 rb_any_cmp
  +3.8 rbimpl_enc_str_coderange_scan
  +3.8 rb_obj_shape_slot_size
  +3.4 rb_st_foreach_with_hash
  -3.2 rb_data_typed_object_zalloc
  +3.1 must_encindex
  -3.0 onigenc_single_byte_mbc_enc_len
  -2.9 rb_equal
  -2.8 rb_hash
  +2.6 VM_CF_BLOCK_HANDLER.isra.0
  +2.6 rb_obj_shape_transition_add_ivar
  -2.6 rb_hash_transform_keys_bang
  +2.5 ar_compact_table
  +2.5 rb_st_init_existing_table_with_size
  -2.4 rb_hash_delete_entry
  -2.4 rb_freeze_singleton_class
  -2.4 rb_hash_lookup2
  -2.4 rb_class_new_instance_pass_kw
  -2.3 rb_enc_set_index
  +2.3 match_set_regs
  +2.2 rb_check_convert_type_with_id_slow
  -2.2 str_buf_cat4.part.0
  +2.2 rb_backref_set
  +2.2 ar_copy.isra.0
  -2.2 rb_method_call_status.isra.0
  +2.2 rb_newobj
  +2.1 rb_file_s_join
  -2.1 onig_region_free
  -1.9 rb_sym2str
  -1.9 str_null_check
  +1.9 rb_hash_merge
  +1.9 rb_hash_foreach
  +1.9 match_alloc_or_reuse
  +1.9 rb_str_alloc_enc_capa
  +1.8 rb_class_owned_p
  +1.8 find_table_bin_ind
  +1.8 str_init
  -1.7 rb_is_instance_id
  -1.7 rb_gc_heap_id_for_size
  -1.6 rb_enc_cr_str_buf_cat
  +1.5 rb_st_add_direct_with_hash
  +1.5 rb_enc_cr_str_buf_cat.constprop.0
  +1.5 str_new_frozen_buffer
  -1.5 str_replace_shared_without_enc.isra.0
  -1.5 rb_sym_to_s
  +1.4 blocking_region_end
  -1.4 rb_equal_opt
  +1.4 rebuild_table
  +1.4 ruby_sip_hash13
  -1.4 rb_enc_get_index
  -1.4 eql_i
  -1.4 rb_str_init
  -1.4 str_enc_new
  -1.3 rb_hash_stlike_lookup
  -1.3 rb_obj_call_init_kw
  -1.3 rb_enc_check
  +1.3 enc_set_index
  +1.3 rb_reg_search_set_match
  -1.3 ary_join_0
  -1.3 rb_str_s_new
  -1.3 hash_i
  +1.2 ar_equal
  -1.2 rb_enc_copy
  -1.2 rb_enc_associate
  -1.2 rb_reg_match_m_p
  -1.2 onig_region_resize
  +1.2 rb_ary_each
  +1.2 rb_monitor_synchronize
  +1.1 rb_stat
  -1.1 empty_str_alloc
  +1.1 str_subseq
  -1.1 rb_hash_update_call
  -1.1 rb_obj_dup
  -1.1 monitor_synchronize
  +1.1 rb_ary_includes
  -1.1 rb_hash_dup
  +1.1 rb_str_hash
  -1.0 ary_memcpy0
  +1.0 thread_sched_setup_running_threads.isra.0
  -1.0 rb_concurrent_set_find
  +1.0 rb_const_lookup_copy
  +1.0 __memcpy_avx_unaligned_erms
  +1.0 hash_foreach_iter
  -0.9 rb_string_value_cstr
  -0.9 onigenc_single_byte_ascii_only_case_map
  +0.9 rb_hash_bulk_insert.part.0
  -0.9 rb_str_casemap
  +0.9 rb_check_ivar_modifiable
  +0.9 onig_name_to_group_numbers
  -0.9 match_at
  -0.9 rb_gc_copy_attributes
  +0.9 match_name_to_backref_number
  -0.8 onig_name_to_backref_number
  +0.8 rb_str_format_ary
  -0.8 thread_sched_to_running
  -0.8 get_encoding
  -0.8 rb_str_format
  +0.8 rbimpl_check_typeddata.constprop.0
  -0.8 rb_file_file_p
  +0.7 str_duplicate
  +0.7 imemo_fields_copy_append
  +0.7 ary_make_partial
  -0.7 OPENSSL_cleanse
  -0.7 rb_mutex_unlock
  +0.6 rb_obj_set_fields
  -0.6 empty_hash_alloc
  -0.6 rb_const_get_0
  -0.6 rb_mutex_lock
  +0.6 rb_str_capitalize
  -0.6 rb_hash_replace
  +0.6 rb_str_modify
  +0.6 search_nonascii
  -0.6 get_next_shape_internal
  -0.6 coderange_scan
  +0.6 obj_field_set
  -0.6 rb_ractor_blocking_threads_inc
  +0.6 rb_hash_alloc_copy
  +0.6 onig_search_gpos
  +0.5 do_regsub
  -0.5 generic_field_set
  +0.5 ary_ensure_room_for_push
  -0.5 rb_fstring
  -0.5 rb_typeddata_is_kind_of
  +0.5 rb_check_to_array
  -0.5 rb_reg_regsub
  +0.5 rb_str_null_check

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `<unmapped JIT>` | 5.4 | 5.9 | -0.4 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 0.0)


### JIT code by YJIT codegen symbol (run b, M per iteration; total 0.0)


### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `__memcmp_avx2_movbe` | 0 | 317889 | -317889 | 0.0 | 5.2 |
| `free` | 1789021 | 1930711 | -141691 | 46.9 | 56.2 |
| `malloc` | 264657 | 374398 | -109741 | 39.6 | 50.8 |
| `__memcpy_avx_unaligned_erms` | 2343063 | 2257581 | 85482 | 34.4 | 33.5 |
| `__memset_avx2_unaligned_erms` | 353967 | 294832 | 59135 | 135.8 | 3.7 |
| `CRYPTO_free` | 115142 | 122583 | -7441 | 10.9 | 12.6 |
| `EVP_KEYMGMT_free` | 13222 | 13647 | -425 | 0.2 | 0.2 |
| `BN_free` | 5617 | 5830 | -213 | 0.0 | 0.0 |
| `clock_gettime@@GLIBC_2.17` | 18329 | 18444 | -115 | 0.2 | 0.2 |
| `calloc` | 74087 | 74073 | 14 | 13.9 | 12.4 |
| `realloc` | 18186 | 18192 | -6 | 10.7 | 14.9 |
| `__errno_location` | 91572 | 91578 | -6 | 0.3 | 0.3 |
| `munmap` | 1 | 7 | -6 | 0.0 | 0.0 |
| `OPENSSL_strcasecmp` | 59610 | 59610 | 0 | 6.7 | 6.7 |
| `CRYPTO_malloc` | 91402 | 91402 | 0 | 16.4 | 15.6 |
| `OPENSSL_LH_strhash` | 21857 | 21857 | 0 | 0.3 | 0.3 |
| `__strcmp_avx2` | 152999 | 152999 | 0 | 4.1 | 4.1 |
| `__strlen_avx2` | 4000 | 4000 | 0 | 0.1 | 0.1 |
| `getrandom` | 7961 | 7961 | 0 | 0.7 | 0.7 |
| `EVP_PKEY_new` | 1987 | 1987 | 0 | 1.3 | 1.3 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|

