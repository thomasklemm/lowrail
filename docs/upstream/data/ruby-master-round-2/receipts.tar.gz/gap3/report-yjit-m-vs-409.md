### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 4675.2 | 4675.2 | 0.00% |
| YJIT | 4727.4 | 4727.4 | 0.00% |
| ZJIT − YJIT | | | | -52.2 (-1.10%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| other runtime (cfunc bodies, hash, string, regexp, ...) | 2574.9 | 2482.2 | **+92.7** | -177% | 0.0 |
| method dispatch (generic send path) | 724.0 | 677.0 | **+47.0** | -90% | 0.0 |
| allocation (objects, malloc) | 348.5 | 338.9 | **+9.6** | -18% | 0.0 |
| JIT code | 561.2 | 555.5 | **+5.8** | -11% | 0.0 |
| block and proc invocation (generic) | 170.3 | 167.1 | **+3.2** | -6% | 0.0 |
| side exits and frame materialization | 1.1 | 1.0 | **+0.1** | -0% | 0.0 |
| invalidation | 0.0 | 0.0 | **-0.0** | 0% | 0.0 |
| compile (ZJIT/YJIT compiler, profiling) | 0.1 | 0.3 | **-0.3** | 1% | 0.0 |
| interpreter (YARV loop and insn helpers) | 77.4 | 78.8 | **-1.4** | 3% | 0.0 |
| ivar and attr access (generic) | 49.8 | 58.6 | **-8.8** | 17% | 0.0 |
| write barriers | 54.9 | 77.0 | **-22.1** | 42% | 0.0 |
| GC (marking, sweeping, freeing) | 113.1 | 291.0 | **-177.9** | 341% | 0.0 |
| total | 4675.2 | 4727.4 | **-52.2** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `__memset_avx2_unaligned_erms` | other runtime | 138.6 | 5.6 | +133.0 |
| `gc_sweep_step` | GC | 0.1 | 120.4 | -120.3 |
| `rb_wb_protected_newobj_of` | allocation | 0.0 | 114.6 | -114.6 |
| `gc_sweep_page` | GC | 85.3 | 0.0 | +85.3 |
| `any_hash` | other runtime | 72.0 | 0.0 | +72.0 |
| `rb_gc_impl_writebarrier` | write barriers | 0.0 | 59.7 | -59.7 |
| `ar_update` | other runtime | 0.0 | 54.4 | -54.4 |
| `rb_ec_newobj_of` | allocation | 52.6 | 0.0 | +52.6 |
| `rb_gc_obj_free` | GC | 11.1 | 59.5 | -48.4 |
| `rb_newobj_of` | allocation | 46.4 | 0.0 | +46.4 |
| `rb_hash_aset` | other runtime | 74.6 | 28.4 | +46.2 |
| `ar_find_entry_hint` | other runtime | 45.7 | 0.0 | +45.7 |
| `rb_gc_obj_free_vm_weak_references` | GC | 5.3 | 49.5 | -44.2 |
| `rb_gc_writebarrier` | write barriers | 53.1 | 14.8 | +38.3 |
| `tbl_update.isra.0` | other runtime | 0.0 | 37.2 | -37.2 |
| `rb_hash_aref` | other runtime | 36.4 | 67.8 | -31.4 |
| `rb_gc_get_objspace` | allocation | 26.0 | 0.0 | +26.0 |
| `rb_any_hash` | other runtime | 3.2 | 28.4 | -25.3 |
| `rb_enc_mbclen` | other runtime | 0.0 | 24.9 | -24.9 |
| `rb_str_buf_append` | other runtime | 5.8 | 27.2 | -21.4 |
| `rb_check_frozen_inline` | other runtime | 20.9 | 0.0 | +20.9 |
| `rb_st_lookup` | other runtime | 83.6 | 63.2 | +20.4 |
| `rb_file_join` | other runtime | 0.0 | 20.4 | -20.4 |
| `rb_st_update` | other runtime | 56.8 | 39.1 | +17.7 |
| `rb_vm_exec` | method dispatch | 91.2 | 73.8 | +17.4 |
| `rb_ec_stack_check` | method dispatch | 32.6 | 15.9 | +16.7 |
| `rb_str_concat_literals` | other runtime | 28.6 | 12.6 | +16.0 |
| `st_general_delete` | other runtime | 15.8 | 0.0 | +15.8 |
| `rb_st_delete` | other runtime | 0.2 | 15.9 | -15.7 |
| `tbl_update_modify` | other runtime | 21.6 | 36.1 | -14.6 |
| `objspace_malloc_increase_body.isra.0` | allocation | 27.4 | 14.9 | +12.5 |
| `reg_prepare_re` | other runtime | 12.2 | 0.0 | +12.2 |
| `rb_enc_str_coderange` | other runtime | 0.0 | 11.6 | -11.6 |
| `rb_obj_fields` | ivar and attr access | 18.5 | 7.3 | +11.2 |
| `rb_obj_class` | other runtime | 16.7 | 27.6 | -10.9 |
| `rb_reg_prepare_re` | other runtime | 0.0 | 10.6 | -10.6 |
| `rb_ivar_get_at_no_ractor_check` | ivar and attr access | 6.2 | 16.7 | -10.5 |
| `builtin_inline_class_227` | interpreter | 0.0 | 10.3 | -10.3 |
| `ar_add_direct_i` | other runtime | 10.0 | 0.0 | +10.0 |
| `rb_eql` | other runtime | 0.0 | 9.8 | -9.8 |

### Unclassified (other runtime) differences above 0.5M
  +133.0 __memset_avx2_unaligned_erms
  +72.0 any_hash
  -54.4 ar_update
  +46.2 rb_hash_aset
  +45.7 ar_find_entry_hint
  -37.2 tbl_update.isra.0
  -31.4 rb_hash_aref
  -25.3 rb_any_hash
  -24.9 rb_enc_mbclen
  -21.4 rb_str_buf_append
  +20.9 rb_check_frozen_inline
  +20.4 rb_st_lookup
  -20.4 rb_file_join
  +17.7 rb_st_update
  +16.0 rb_str_concat_literals
  +15.8 st_general_delete
  -15.7 rb_st_delete
  -14.6 tbl_update_modify
  +12.2 reg_prepare_re
  -11.6 rb_enc_str_coderange
  -10.9 rb_obj_class
  -10.6 rb_reg_prepare_re
  +10.0 ar_add_direct_i
  -9.8 rb_eql
  +9.8 ar_force_convert_table
  +9.1 st_general_foreach
  +9.1 rb_current_ec
  -9.0 hash_foreach_call
  +8.2 rb_ary_includes_by_eql
  -8.0 ar_force_convert_table.isra.0
  +7.3 typed_data_alloc_in
  -7.2 rb_check_convert_type_with_id
  -7.0 ar_lookup
  -6.9 optimized_escape_html
  -6.5 rb_eql_opt
  -6.4 rb_hash_has_key
  -6.3 rb_get_alloc_func
  +6.0 rb_enc_associate_index
  +5.8 rb_obj_freeze_inline.part.0
  -5.8 opt_equality_by_mid_slowpath
  -5.7 rb_st_foreach_check
  -5.5 ar_insert.isra.0
  -4.9 rb_gc_obj_slot_size
  +4.8 find_table_entry_ind
  -4.8 rb_hash_update_i
  -4.7 rb_enc_get
  -4.6 rb_ary_entry
  +4.6 ar_insert_direct.isra.0
  +4.5 rb_ary_join
  -4.4 rb_ary_diff
  +4.1 rebuild_table_with
  -4.1 rb_obj_freeze_inline
  +3.9 rb_any_cmp
  +3.8 rb_obj_shape_slot_size
  +3.4 rb_st_foreach_with_hash
  +3.2 str_duplicate
  -3.2 rb_data_typed_object_zalloc
  +3.2 rb_optimized_call
  +3.1 must_encindex
  +3.0 rbimpl_enc_str_coderange_scan
  -2.9 onigenc_single_byte_mbc_enc_len
  -2.8 vm_invokeblock_i
  -2.7 rb_hash
  -2.6 rb_hash_transform_keys_bang
  +2.5 ar_compact_table
  +2.5 rb_st_init_existing_table_with_size
  -2.5 rb_ary_push
  -2.5 rb_equal
  -2.4 rb_hash_delete_entry
  -2.4 rb_freeze_singleton_class
  -2.4 rb_hash_lookup2
  -2.3 rb_enc_set_index
  +2.3 match_set_regs
  -2.3 rb_str_dup
  +2.2 rb_check_convert_type_with_id_slow
  -2.2 str_buf_cat4.part.0
  +2.2 ar_copy.isra.0
  +2.2 rb_newobj
  -2.1 onig_region_free
  +2.1 rb_file_s_join
  +2.0 rb_str_modify
  +2.0 rb_backref_set
  -1.9 rb_sym2str
  -1.9 str_null_check
  +1.9 rb_hash_merge
  +1.9 rb_hash_foreach
  +1.9 match_alloc_or_reuse
  +1.8 str_init
  -1.7 rb_gc_heap_id_for_size
  +1.7 find_table_bin_ind
  -1.6 rb_enc_cr_str_buf_cat
  +1.5 rb_st_add_direct_with_hash
  -1.5 rb_id2sym
  -1.5 rb_str_init
  +1.5 str_new_frozen_buffer
  +1.5 ar_equal
  +1.5 rb_enc_cr_str_buf_cat.constprop.0
  -1.5 str_replace_shared_without_enc.isra.0
  -1.5 rb_sym_to_s
  +1.4 blocking_region_end
  -1.4 rb_struct_aset
  +1.4 ruby_sip_hash13
  +1.4 rebuild_table
  -1.4 rb_enc_get_index
  -1.4 str_enc_new
  -1.3 eql_i
  -1.3 rb_enc_check
  +1.3 enc_set_index
  +1.3 rb_reg_search_set_match
  -1.3 ary_join_0
  -1.2 rb_enc_copy
  -1.2 rb_enc_associate
  -1.2 rb_concurrent_set_find
  +1.2 rb_obj_shape_transition_add_ivar
  -1.2 rb_is_instance_id
  -1.2 rb_reg_match_m_p
  -1.2 onig_region_resize
  +1.2 rb_monitor_synchronize
  +1.1 rb_stat
  -1.1 hash_i
  +1.1 str_subseq
  -1.1 rb_hash_update_call
  -1.1 rb_obj_dup
  -1.1 monitor_synchronize
  +1.1 rb_ary_includes
  -1.1 rb_hash_dup
  +1.1 rb_str_hash
  -1.0 opt_equality_specialized
  -1.0 ary_memcpy0
  +1.0 thread_sched_setup_running_threads.isra.0
  +1.0 rb_const_lookup_copy
  +1.0 __memcpy_avx_unaligned_erms
  +1.0 hash_foreach_iter
  -0.9 rb_string_value_cstr
  -0.9 onigenc_single_byte_ascii_only_case_map
  -0.9 rb_class_new_instance_pass_kw
  +0.9 rb_hash_bulk_insert.part.0
  -0.9 rb_str_casemap
  +0.9 onig_name_to_group_numbers
  -0.9 match_at
  -0.9 rb_gc_copy_attributes
  +0.9 match_name_to_backref_number
  +0.8 rb_proc_refinements_cref_for_call
  -0.8 onig_name_to_backref_number
  -0.8 rb_equal_opt
  +0.8 rb_str_format_ary
  +0.8 rb_str_alloc_enc_capa
  -0.8 thread_sched_to_running
  -0.8 get_encoding
  -0.8 rb_str_format
  -0.8 rb_str_cat
  +0.8 rbimpl_check_typeddata.constprop.0
  -0.8 rb_file_file_p
  +0.7 imemo_fields_copy_append
  +0.7 ary_make_partial
  -0.7 rb_yjit_str_simple_append
  +0.7 rb_ec_yield
  -0.7 rb_mutex_unlock
  +0.6 rb_obj_set_fields
  -0.6 rb_const_get_0
  -0.6 rb_mutex_lock
  +0.6 rb_str_capitalize
  -0.6 rb_hash_replace
  +0.6 rb_hash_s_new
  -0.6 rb_typeddata_is_kind_of
  +0.6 onig_search_gpos
  -0.6 get_next_shape_internal
  -0.6 rb_backref_get
  -0.6 coderange_scan
  -0.6 rb_ractor_blocking_threads_inc
  +0.6 rb_hash_alloc_copy
  +0.5 do_regsub
  -0.5 generic_field_set
  +0.5 ary_ensure_room_for_push
  -0.5 rb_fstring
  +0.5 rb_check_to_array
  -0.5 rb_reg_regsub
  +0.5 rb_obj_equal
  +0.5 search_nonascii
  +0.5 rb_str_null_check

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `get_header@rack-3.1.17/lib/rack/request.rb` | 10.1 | 0.0 | +10.1 |
| `get_header@rack-3.1.17/lib/rack/request.rb` | 0.0 | 8.5 | -8.5 |
| `xor_byte_strings@actionpack-8.1.1/lib/action_controller/metal/request_forgery_protection.rb` | 0.0 | 7.4 | -7.4 |
| `xor_byte_strings@actionpack-8.1.1/lib/action_controller/metal/request_forgery_protection.rb` | 7.4 | 0.0 | +7.4 |
| `call@activesupport-8.1.1/lib/active_support/callbacks.rb` | 5.8 | 0.0 | +5.8 |
| `call@activesupport-8.1.1/lib/active_support/callbacks.rb` | 0.0 | 5.7 | -5.7 |
| `block in tag_options@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb` | 5.4 | 0.0 | +5.4 |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 0.0 | 5.3 | -5.3 |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 5.2 | 0.0 | +5.2 |
| `tag_option@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb` | 5.1 | 0.0 | +5.1 |
| `[]@activesupport-8.1.1/lib/active_support/isolated_execution_state.rb` | 5.1 | 0.0 | +5.1 |
| `[]@activesupport-8.1.1/lib/active_support/isolated_execution_state.rb` | 0.0 | 5.1 | -5.1 |
| `tag_option@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb` | 0.0 | 5.0 | -5.0 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | 0.0 | 4.9 | -4.9 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | 4.9 | 0.0 | +4.9 |
| `block in tag_options@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb` | 0.0 | 3.9 | -3.9 |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb` | 0.0 | 3.7 | -3.7 |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb` | 3.7 | 0.0 | +3.7 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 0.0 | 3.3 | -3.3 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 3.3 | 0.0 | +3.3 |
| `method_missing@activesupport-8.1.1/lib/active_support/ordered_options.rb` | 3.3 | 0.0 | +3.3 |
| `method_missing@activesupport-8.1.1/lib/active_support/ordered_options.rb` | 0.0 | 3.3 | -3.3 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 0.0 | 3.1 | -3.1 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | 3.1 | 0.0 | +3.1 |
| `<<@actionview-8.1.1/lib/action_view/buffers.rb` | 3.0 | 0.0 | +3.0 |
| `<<@actionview-8.1.1/lib/action_view/buffers.rb` | 0.0 | 2.9 | -2.9 |
| `evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 0.0 | 2.9 | -2.9 |
| `path_for@actionpack-8.1.1/lib/action_dispatch/http/url.rb` | 2.9 | 0.0 | +2.9 |
| `path_for@actionpack-8.1.1/lib/action_dispatch/http/url.rb` | 0.0 | 2.9 | -2.9 |
| `evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | 2.9 | 0.0 | +2.9 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 0.0)


### JIT code by YJIT codegen symbol (run b, M per iteration; total 0.0)


### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `rb_builtin_ary_at_end` | 433809 | 0 | 433809 | 4.8 | 0.0 |
| `builtin_inline_class_227` | 0 | 328426 | -328426 | 0.0 | 10.0 |
| `__memcmp_avx2_movbe` | 0 | 317761 | -317761 | 0.0 | 5.1 |
| `rb_builtin_ary_at` | 271140 | 0 | 271140 | 1.6 | 0.0 |
| `rb_builtin_fixnum_inc` | 244030 | 0 | 244030 | 0.7 | 0.0 |
| `free` | 1794361 | 1914906 | -120545 | 48.5 | 53.0 |
| `rb_jit_str_simple_append` | 112141 | 0 | 112141 | 32.5 | 0.0 |
| `rb_yjit_str_simple_append` | 0 | 110841 | -110841 | 0.0 | 33.3 |
| `malloc` | 264658 | 374137 | -109480 | 38.8 | 49.4 |
| `rb_obj_equal` | 105054 | 0 | 105054 | 0.5 | 0.0 |
| `__memcpy_avx_unaligned_erms` | 1911528 | 1825425 | 86102 | 29.5 | 28.6 |
| `rb_vm_ic_hit_p` | 0 | 85475 | -85475 | 0.0 | 3.1 |
| `__memset_avx2_unaligned_erms` | 377081 | 294574 | 82507 | 136.7 | 3.7 |
| `builtin_inline_class_13` | 74971 | 0 | 74971 | 3.8 | 0.0 |
| `builtin_inline_class_247` | 0 | 71292 | -71292 | 0.0 | 2.1 |
| `rb_ary_push` | 35276 | 88473 | -53197 | 3.6 | 9.8 |
| `rb_jit_ary_push` | 53197 | 0 | 53197 | 6.1 | 0.0 |
| `builtin_inline_class_28` | 0 | 39288 | -39288 | 0.0 | 3.3 |
| `builtin_inline_class_12` | 0 | 35683 | -35683 | 0.0 | 14.9 |
| `builtin_inline_class_272` | 0 | 34091 | -34091 | 0.0 | 1.0 |
| `builtin_inline_class_132` | 0 | 31236 | -31236 | 0.0 | 0.2 |
| `rb_builtin_ary_first` | 31236 | 0 | 31236 | 0.2 | 0.0 |
| `rb_hash_new_with_size` | 0 | 31205 | -31205 | 0.0 | 3.4 |
| `rb_hash_new_capa` | 31205 | 0 | 31205 | 4.4 | 0.0 |
| `rb_RSTRUCT_SET` | 0 | 25970 | -25970 | 0.0 | 1.5 |
| `rb_hash_s_new` | 21944 | 0 | 21944 | 65.8 | 0.0 |
| `monitor_synchronize` | 0 | 19970 | -19970 | 0.0 | 49.6 |
| `rb_monitor_synchronize` | 19970 | 0 | 19970 | 48.3 | 0.0 |
| `rb_obj_alloc` | 194899 | 214830 | -19931 | 39.5 | 56.1 |
| `rb_yjit_ruby2_keywords_splat_p` | 0 | 19287 | -19287 | 0.0 | 0.4 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `get_header@rack-3.1.17/lib/rack/request.rb` | `rb_hash_aref` | 206125 | 0 | 206125 |
| `[]@activesupport-8.1.1/lib/active_support/isolated_execution_state.rb` | `rb_hash_aref` | 80488 | 0 | 80488 |
| `level@logger-1.7.0/lib/logger.rb` | `rb_vm_opt_send_without_block` | 51922 | 0 | 51922 |
| `html_escape@activesupport-8.1.1/lib/active_support/core_ext/erb/util.rb` | `rb_vm_invokesuper` | 42172 | 0 | 42172 |
| `[]=@rack-3.1.17/lib/rack/headers.rb` | `rb_hash_aref` | 41870 | 0 | 41870 |
| `block in initialize@activesupport-8.1.1/lib/active_support/ordered_options.rb` | `rb_hash_aref` | 41805 | 0 | 41805 |
| `downcase_key@rack-3.1.17/lib/rack/headers.rb` | `rb_hash_aref` | 39987 | 0 | 39987 |
| `fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | `rb_hash_aref` | 35550 | 0 | 35550 |
| `path_for@actionpack-8.1.1/lib/action_dispatch/http/url.rb` | `rb_hash_aref` | 32371 | 0 | 32371 |
| `[]@rack-3.1.17/lib/rack/headers.rb` | `rb_hash_aref` | 31987 | 0 | 31987 |
| `[]@concurrent-ruby-1.3.5/lib/concurrent-ruby/concurrent/collection/map/non_concurrent_map_backend.rb` | `rb_hash_aref` | 29278 | 0 | 29278 |
| `matches?@actionview-8.1.1/lib/action_view/template_details.rb` | `rb_hash_aref` | 28013 | 0 | 28013 |
| `move@actionpack-8.1.1/lib/action_dispatch/journey/gtg/transition_table.rb` | `rb_hash_aref` | 27868 | 0 | 27868 |
| `level@logger-1.7.0/lib/logger.rb` | `rb_hash_aref` | 25961 | 0 | 25961 |
| `local_level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 25961 | 0 | 25961 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_invokesuper` | 25961 | 0 | 25961 |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 25961 | 0 | 25961 |
| `block in make_lambda@activesupport-8.1.1/lib/active_support/callbacks.rb` | `rb_vm_send` | 23970 | 0 | 23970 |
| `[]@activesupport-8.1.1/lib/active_support/ordered_options.rb` | `rb_hash_aref` | 23922 | 0 | 23922 |
| `fetch@activerecord-8.1.1/lib/active_record/result.rb` | `rb_hash_aref` | 22480 | 0 | 22480 |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb` | `rb_hash_aref` | 22480 | 0 | 22480 |
| `block in tag_options@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb` | `rb_hash_aref` | 22105 | 0 | 22105 |
| `set_cookie_header@rack-3.1.17/lib/rack/utils.rb` | `rb_hash_aref` | 21857 | 0 | 21857 |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb` | `rb_hash_aref` | 18727 | 0 | 18727 |
| `path_parameters@actionpack-8.1.1/lib/action_dispatch/http/parameters.rb` | `rb_hash_aref` | 18000 | 0 | 18000 |
| `[]@actionpack-8.1.1/lib/action_dispatch/request/session.rb` | `rb_hash_aref` | 17922 | 0 | 17922 |
| `initialize@activesupport-8.1.1/lib/active_support/messages/codec.rb` | `rb_hash_aref` | 17883 | 0 | 17883 |
| `block in initialize_details@actionview-8.1.1/lib/action_view/lookup_context.rb` | `rb_hash_aref` | 16000 | 0 | 16000 |
| `env_for@rack-3.1.17/lib/rack/mock_request.rb` | `rb_hash_aref` | 14000 | 0 | 14000 |
| `block in debug?@activesupport-8.1.1/lib/active_support/broadcast_logger.rb` | `rb_vm_opt_send_without_block` | 13987 | 0 | 13987 |
| `debug?@logger-1.7.0/lib/logger.rb` | `rb_vm_opt_send_without_block` | 13987 | 0 | 13987 |
| `silenced?@activesupport-8.1.1/lib/active_support/log_subscriber.rb` | `rb_hash_aref` | 13987 | 0 | 13987 |
| `logger@actionpack-8.1.1/lib/abstract_controller/logger.rb` | `rb_vm_sendforward` | 12000 | 0 | 12000 |
| `handle_options@actionpack-8.1.1/lib/action_dispatch/middleware/cookies.rb` | `rb_hash_aref` | 11922 | 0 | 11922 |
| `new@concurrent-ruby-1.3.5/lib/concurrent-ruby/concurrent/synchronization/safe_initialization.rb` | `rb_vm_invokesuper` | 10000 | 0 | 10000 |
| `info?@logger-1.7.0/lib/logger.rb` | `rb_vm_opt_send_without_block` | 9974 | 0 | 9974 |
| `block in info?@activesupport-8.1.1/lib/active_support/broadcast_logger.rb` | `rb_vm_opt_send_without_block` | 9974 | 0 | 9974 |
| `initialize@activesupport-8.1.1/lib/active_support/hash_with_indifferent_access.rb` | `rb_vm_invokesuper` | 9970 | 0 | 9970 |
| `content_tag_string@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb` | `rb_hash_aref` | 9057 | 0 | 9057 |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb` | `rb_hash_aref` | 9057 | 0 | 9057 |

