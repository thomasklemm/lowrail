### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 2765.6 | 2765.6 | 0.00% |
| YJIT | 2807.8 | 2807.8 | 0.00% |
| ZJIT − YJIT | | | | -42.2 (-1.50%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| side exits and frame materialization | 0.3 | 0.3 | **+0.0** | -0% | 0.0 |
| compile (ZJIT/YJIT compiler, profiling) | 0.0 | 0.0 | **+0.0** | -0% | 0.0 |
| invalidation | 0.0 | 0.0 | **+0.0** | -0% | 0.0 |
| ivar and attr access (generic) | 44.2 | 44.4 | **-0.2** | 1% | 0.0 |
| method dispatch (generic send path) | 473.2 | 474.0 | **-0.8** | 2% | 0.0 |
| write barriers | 35.5 | 36.5 | **-1.0** | 2% | 0.0 |
| GC (marking, sweeping, freeing) | 40.3 | 41.4 | **-1.1** | 3% | 0.0 |
| block and proc invocation (generic) | 111.2 | 112.5 | **-1.3** | 3% | 0.0 |
| JIT code | 473.8 | 476.6 | **-2.8** | 7% | 0.0 |
| allocation (objects, malloc) | 155.9 | 159.6 | **-3.7** | 9% | 0.0 |
| interpreter (YARV loop and insn helpers) | 31.9 | 37.3 | **-5.4** | 13% | 0.0 |
| other runtime (cfunc bodies, hash, string, regexp, ...) | 1399.2 | 1425.0 | **-25.8** | 61% | 0.0 |
| total | 2765.6 | 2807.8 | **-42.2** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `vm_exec_core` | interpreter | 13.4 | 19.3 | -5.8 |
| `ar_find_entry_hint` | other runtime | 35.8 | 41.6 | -5.8 |
| `rb_hash_aref` | other runtime | 30.6 | 34.7 | -4.0 |
| `setup_parameters_complex` | method dispatch | 23.0 | 26.6 | -3.5 |
| `__memset_avx2_unaligned_erms` | other runtime | 63.5 | 66.5 | -3.0 |
| `<JIT code>` | JIT code | 473.8 | 476.6 | -2.8 |
| `rb_str_hash` | other runtime | 24.4 | 27.0 | -2.7 |
| `any_hash` | other runtime | 52.5 | 55.1 | -2.6 |
| `ruby_sip_hash13` | other runtime | 37.0 | 39.4 | -2.4 |
| `rb_hash_aset` | other runtime | 45.1 | 46.9 | -1.8 |
| `rb_vm_send` | method dispatch | 7.4 | 5.5 | +1.8 |
| `invoke_block_from_c_bh` | block and proc invocation | 37.3 | 39.0 | -1.7 |
| `vm_lookup_cc` | method dispatch | 2.8 | 1.3 | +1.5 |
| `ar_equal` | other runtime | 4.8 | 6.2 | -1.4 |
| `rb_managed_id_table_lookup` | method dispatch | 17.0 | 15.7 | +1.3 |
| `vm_caller_setup_arg_block.isra.0` | block and proc invocation | 5.5 | 4.2 | +1.3 |
| `rb_st_lookup` | other runtime | 59.7 | 58.4 | +1.2 |
| `rb_ary_fetch` | other runtime | 1.2 | 0.0 | +1.2 |
| `vm_call_iseq_setup` | method dispatch | 23.3 | 24.5 | -1.1 |
| `gccct_method_search_slowpath` | method dispatch | 1.0 | 0.0 | +1.0 |
| `rb_newobj_of` | allocation | 22.8 | 23.8 | -1.0 |
| `rb_gc_writebarrier` | write barriers | 35.2 | 36.2 | -1.0 |
| `rb_hash_fetch_m` | other runtime | 3.8 | 4.7 | -0.9 |
| `callable_method_entry_or_negative` | method dispatch | 17.9 | 17.0 | +0.9 |
| `vm_call_iseq_setup_normal_0start_1params_1locals` | method dispatch | 0.4 | 1.3 | -0.9 |
| `gc_sweep_page` | GC | 28.7 | 29.6 | -0.9 |
| `vm_call_iseq_setup_normal_0start_2params_2locals` | method dispatch | 1.0 | 0.2 | +0.8 |
| `vm_callee_setup_arg` | method dispatch | 21.8 | 22.5 | -0.8 |
| `vm_call_iseq_bmethod` | method dispatch | 0.2 | 0.9 | -0.7 |
| `ary_memcpy0` | other runtime | 7.5 | 8.2 | -0.7 |
| `vm_base_ptr` | method dispatch | 2.2 | 2.8 | -0.6 |
| `rb_hash_default_value` | other runtime | 7.5 | 8.1 | -0.6 |
| `rb_class_allocate_instance` | allocation | 9.6 | 10.2 | -0.6 |
| `rb_yarv_ary_entry_internal` | interpreter | 2.7 | 2.2 | +0.6 |
| `rb_vm_exec` | method dispatch | 60.9 | 60.4 | +0.6 |
| `rb_ary_to_h` | other runtime | 0.0 | 0.5 | -0.5 |
| `args_setup_kw_parameters` | method dispatch | 4.0 | 4.5 | -0.5 |
| `vm_callee_setup_block_arg` | block and proc invocation | 15.3 | 15.8 | -0.5 |
| `yjit_compile` | method dispatch | 0.4 | 0.9 | -0.5 |
| `rb_yield_force_blockarg` | block and proc invocation | 0.0 | 0.5 | -0.5 |

### Unclassified (other runtime) differences above 0.5M
  -5.8 ar_find_entry_hint
  -4.0 rb_hash_aref
  -3.0 __memset_avx2_unaligned_erms
  -2.7 rb_str_hash
  -2.6 any_hash
  -2.4 ruby_sip_hash13
  -1.8 rb_hash_aset
  -1.4 ar_equal
  +1.2 rb_st_lookup
  +1.2 rb_ary_fetch
  -0.9 rb_hash_fetch_m
  -0.7 ary_memcpy0
  -0.6 rb_hash_default_value
  -0.5 rb_ary_to_h

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `call@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/route_set.rb` | 6.3 | 0.0 | +6.3 |
| `call@rails-c48c154e3f52/actionpack/lib/action_dispatch/routing/route_set.rb` | 0.0 | 6.3 | -6.3 |
| `block in fetch_value!@rails-c48c154e3f52/activemodel/lib/active_model/attribute_set.rb` | 0.0 | 5.6 | -5.6 |
| `[]@rails-c48c154e3f52/activesupport/lib/active_support/isolated_execution_state.rb` | 0.0 | 5.3 | -5.3 |
| `[]@rails-50c54eed065b/activesupport/lib/active_support/isolated_execution_state.rb` | 5.3 | 0.0 | +5.3 |
| `block in tag_options@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | 5.2 | 0.0 | +5.2 |
| `call@rails-50c54eed065b/activesupport/lib/active_support/callbacks.rb` | 5.1 | 0.0 | +5.1 |
| `call@rails-c48c154e3f52/activesupport/lib/active_support/callbacks.rb` | 0.0 | 5.1 | -5.1 |
| `block in tag_options@rails-c48c154e3f52/actionview/lib/action_view/helpers/tag_helper.rb` | 0.0 | 5.0 | -5.0 |
| `fetch@rails-c48c154e3f52/activemodel/lib/active_model/indexed_row.rb` | 0.0 | 4.6 | -4.6 |
| `append_tag_option@rails-c48c154e3f52/actionview/lib/action_view/helpers/tag_helper.rb` | 0.0 | 4.4 | -4.4 |
| `append_tag_option@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | 4.4 | 0.0 | +4.4 |
| `blank?@rails-c48c154e3f52/activesupport/lib/active_support/core_ext/object/blank.rb` | 0.0 | 4.3 | -4.3 |
| `blank?@rails-50c54eed065b/activesupport/lib/active_support/core_ext/object/blank.rb` | 4.3 | 0.0 | +4.3 |
| `block in add_to@rails-c48c154e3f52/actionpack/lib/action_dispatch/journey/visitors.rb` | 0.0 | 4.1 | -4.1 |
| `block in add_to@rails-50c54eed065b/actionpack/lib/action_dispatch/journey/visitors.rb` | 4.1 | 0.0 | +4.1 |
| `cast_value@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | 4.0 | 0.0 | +4.0 |
| `url_options@rails-50c54eed065b/actionpack/lib/action_controller/metal/url_for.rb` | 3.3 | 0.0 | +3.3 |
| `content_tag_string@rails-c48c154e3f52/actionview/lib/action_view/helpers/tag_helper.rb` | 0.0 | 3.2 | -3.2 |
| `content_tag_string@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | 2.9 | 0.0 | +2.9 |
| `block (2 levels) in generate_url_helpers@rails-c48c154e3f52/actionpack/lib/action_dispatch/routing/route_set.r` | 0.0 | 2.8 | -2.8 |
| `block (2 levels) in generate_url_helpers@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/route_set.r` | 2.8 | 0.0 | +2.8 |
| `path_for@rails-c48c154e3f52/actionpack/lib/action_dispatch/http/url.rb` | 0.0 | 2.8 | -2.8 |
| `path_for@rails-50c54eed065b/actionpack/lib/action_dispatch/http/url.rb` | 2.8 | 0.0 | +2.8 |
| `<<@rails-c48c154e3f52/actionview/lib/action_view/buffers.rb` | 0.0 | 2.7 | -2.7 |
| `<<@rails-50c54eed065b/actionview/lib/action_view/buffers.rb` | 2.7 | 0.0 | +2.7 |
| `memos@rails-c48c154e3f52/actionpack/lib/action_dispatch/journey/gtg/simulator.rb` | 0.0 | 2.6 | -2.6 |
| `run_callbacks@rails-50c54eed065b/activesupport/lib/active_support/callbacks.rb` | 2.6 | 0.0 | +2.6 |
| `run_callbacks@rails-c48c154e3f52/activesupport/lib/active_support/callbacks.rb` | 0.0 | 2.6 | -2.6 |
| `fetch_value_at!@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | 2.6 | 0.0 | +2.6 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 0.0)


### JIT code by YJIT codegen symbol (run b, M per iteration; total 0.0)


### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `rb_hash_aref` | 940176 | 1042289 | -102113 | 232.3 | 249.0 |
| `rb_gc_writebarrier` | 399001 | 435791 | -36790 | 11.6 | 12.7 |
| `rb_yarv_ary_entry_internal` | 171208 | 135918 | 35290 | 2.7 | 2.2 |
| `rb_ary_fetch` | 27180 | 0 | 27180 | 1.9 | 0.0 |
| `rb_vm_send` | 91024 | 68544 | 22480 | 2939.5 | 3030.4 |
| `rb_hash_fetch_m` | 93568 | 116048 | -22480 | 241.5 | 239.3 |
| `__memcpy_avx_unaligned_erms` | 1007943 | 1024913 | -16971 | 14.9 | 15.1 |
| `rb_hash_has_key` | 138436 | 150436 | -12000 | 19.9 | 21.8 |
| `rb_ec_str_resurrect` | 17357 | 6617 | 10740 | 4.3 | 1.8 |
| `rb_obj_alloc` | 140847 | 148787 | -7940 | 29.1 | 30.4 |
| `rb_builtin_ary_at_end` | 309246 | 316216 | -6970 | 3.4 | 3.5 |
| `rb_ec_ary_new_from_values` | 89147 | 95507 | -6360 | 27.2 | 21.6 |
| `rb_hash_new` | 67031 | 72001 | -4970 | 9.2 | 10.1 |
| `rb_jit_ary_push` | 34184 | 39154 | -4970 | 3.9 | 4.5 |
| `rb_builtin_fixnum_inc` | 196257 | 201227 | -4970 | 0.6 | 0.6 |
| `rb_builtin_ary_at` | 198240 | 203210 | -4970 | 1.2 | 1.2 |
| `rb_ary_store` | 23446 | 28416 | -4970 | 2.2 | 2.5 |
| `rb_vm_opt_send_without_block` | 108939 | 112209 | -3270 | 1468.7 | 1423.5 |
| `ary_sized_alloc` | 19944 | 21944 | -2000 | 3.3 | 3.2 |
| `rb_ary_freeze` | 4030 | 6030 | -2000 | 0.2 | 0.3 |
| `rb_ary_to_h` | 0 | 2000 | -2000 | 0.0 | 14.5 |
| `rb_hash_new_capa` | 21683 | 19983 | 1700 | 3.9 | 3.6 |
| `rb_hash_bulk_insert` | 21683 | 19983 | 1700 | 16.4 | 15.9 |
| `free` | 388888 | 389010 | -121 | 14.8 | 14.8 |
| `__memset_avx2_unaligned_erms` | 142033 | 142080 | -47 | 63.3 | 66.3 |
| `clock_gettime@@GLIBC_2.17` | 34022 | 34019 | 3 | 0.3 | 0.3 |
| `malloc` | 123169 | 123170 | -1 | 20.0 | 20.0 |
| `getrandom` | 2000 | 2000 | 0 | 0.2 | 0.2 |
| `rb_str_concat_multi` | 1300 | 1300 | 0 | 0.5 | 0.5 |
| `rb_str_equal` | 9800 | 9800 | 0 | 0.4 | 0.4 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `[]@rails-50c54eed065b/activesupport/lib/active_support/isolated_execution_state.rb` | `rb_hash_aref` | 84540 | 0 | 84540 |
| `block in emitting?@rails-50c54eed065b/activesupport/lib/active_support/event_reporter.rb` | `rb_hash_aref` | 32000 | 0 | 32000 |
| `path_for@rails-50c54eed065b/actionpack/lib/action_dispatch/http/url.rb` | `rb_hash_aref` | 31071 | 0 | 31071 |
| `block in add_to@rails-50c54eed065b/actionpack/lib/action_dispatch/journey/visitors.rb` | `rb_hash_aref` | 28397 | 0 | 28397 |
| `block in subscription_filter@rails-50c54eed065b/activesupport/lib/active_support/event_reporter/log_` | `rb_hash_aref` | 28000 | 0 | 28000 |
| `move@rails-50c54eed065b/actionpack/lib/action_dispatch/journey/gtg/transition_table.rb` | `rb_hash_aref` | 27749 | 0 | 27749 |
| `block in initialize@rails-50c54eed065b/activesupport/lib/active_support/ordered_options.rb` | `rb_hash_aref` | 25883 | 0 | 25883 |
| `block in make_lambda@rails-50c54eed065b/activesupport/lib/active_support/callbacks.rb` | `rb_vm_send` | 23970 | 0 | 23970 |
| `html_escape@rails-50c54eed065b/activesupport/lib/active_support/core_ext/erb/util.rb` | `rb_vm_invokesuper` | 23214 | 0 | 23214 |
| `[]@rails-50c54eed065b/activesupport/lib/active_support/ordered_options.rb` | `rb_hash_aref` | 19948 | 0 | 19948 |
| `fetch_value_at!@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | `rb_vm_send` | 17510 | 0 | 17510 |
| `path_parameters@rails-50c54eed065b/actionpack/lib/action_dispatch/http/parameters.rb` | `rb_hash_aref` | 16000 | 0 | 16000 |
| `block in initialize_details@rails-50c54eed065b/actionview/lib/action_view/lookup_context.rb` | `rb_hash_aref` | 16000 | 0 | 16000 |
| `block in tag_options@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | `rb_hash_aref` | 14157 | 0 | 14157 |
| `block in initialize@rails-50c54eed065b/activerecord/lib/active_record/result.rb` | `rb_hash_aref` | 12000 | 0 | 12000 |
| `call@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/route_set.rb` | `rb_hash_aref` | 11657 | 0 | 11657 |
| `rank_for@rails-50c54eed065b/actionview/lib/action_view/template_details.rb` | `rb_hash_aref` | 10000 | 0 | 10000 |
| `initialize@rails-50c54eed065b/activesupport/lib/active_support/hash_with_indifferent_access.rb` | `rb_vm_invokesuper` | 9970 | 0 | 9970 |
| `index_for_name@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | `rb_hash_aref` | 9670 | 0 | 9670 |
| `link_to@rails-50c54eed065b/actionview/lib/action_view/helpers/navigation_helper.rb` | `rb_hash_aref` | 9057 | 0 | 9057 |
| `content_tag_string@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | `rb_hash_aref` | 9057 | 0 | 9057 |
| `url_options@rails-50c54eed065b/actionpack/lib/action_controller/metal/url_for.rb` | `rb_hash_aref` | 8357 | 0 | 8357 |
| `block in extract_details@rails-50c54eed065b/actionview/lib/action_view/renderer/abstract_renderer.rb` | `rb_hash_aref` | 8052 | 0 | 8052 |
| `instrumenter@rails-50c54eed065b/activesupport/lib/active_support/notifications.rb` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `log_level_satisfied?@rails-50c54eed065b/activesupport/lib/active_support/event_reporter/log_subscrib` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `local_level@rails-50c54eed065b/activesupport/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 8000 | 0 | 8000 |
| `run_callbacks@rails-50c54eed065b/activesupport/lib/active_support/callbacks.rb` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `call@rails-50c54eed065b/activerecord/lib/active_record/runtime_registry.rb` | `rb_hash_aref` | 8000 | 0 | 8000 |
| `level@rails-50c54eed065b/activesupport/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_invokesuper` | 8000 | 0 | 8000 |
| `level@rails-50c54eed065b/activesupport/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 8000 | 0 | 8000 |
| `[]@rails-50c54eed065b/actionpack/lib/action_dispatch/http/session.rb` | `rb_hash_aref` | 7987 | 0 | 7987 |
| `session@rails-50c54eed065b/actionpack/lib/action_controller/metal.rb` | `rb_vm_sendforward` | 7948 | 0 | 7948 |
| `get_pool_config@rails-50c54eed065b/activerecord/lib/active_record/connection_adapters/pool_manager.r` | `rb_hash_aref` | 7940 | 0 | 7940 |
| `path@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/polymorphic_routes.rb` | `rb_hash_aref` | 6800 | 0 | 6800 |
| `before@rails-50c54eed065b/activesupport/lib/active_support/execution_wrapper.rb` | `rb_hash_aref` | 6000 | 0 | 6000 |
| `block in info?@rails-50c54eed065b/activesupport/lib/active_support/broadcast_logger.rb` | `rb_vm_opt_send_without_block` | 6000 | 0 | 6000 |
| `method_missing@rails-50c54eed065b/activesupport/lib/active_support/broadcast_logger.rb` | `rb_vm_send` | 6000 | 0 | 6000 |
| `block in method_missing@rails-50c54eed065b/activesupport/lib/active_support/broadcast_logger.rb` | `rb_vm_opt_send_without_block` | 6000 | 0 | 6000 |
| `get_view_paths@rails-50c54eed065b/actionview/lib/action_view/path_registry.rb` | `rb_hash_aref` | 6000 | 0 | 6000 |
| `matches?@rails-50c54eed065b/actionview/lib/action_view/template_details.rb` | `rb_hash_aref` | 6000 | 0 | 6000 |

