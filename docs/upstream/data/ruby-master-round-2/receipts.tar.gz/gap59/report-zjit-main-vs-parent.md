### Totals (M Ir per iteration)

| mode | run a | run b | run c | mean | spread |
|---|---:|---:|---:|---:|---:|
| ZJIT | 2893.2 | 2893.2 | 0.00% |
| YJIT | 2925.4 | 2925.4 | 0.00% |
| ZJIT − YJIT | | | | -32.1 (-1.10%) | |

### Buckets (M Ir per iteration, mean of 3 runs per mode)

| bucket | ZJIT | YJIT | ZJIT − YJIT | share of gap | run spread |
|---|---:|---:|---:|---:|---:|
| method dispatch (generic send path) | 548.4 | 544.6 | **+3.7** | -12% | 0.0 |
| ivar and attr access (generic) | 46.8 | 46.4 | **+0.4** | -1% | 0.0 |
| interpreter (YARV loop and insn helpers) | 24.0 | 24.0 | **+0.0** | -0% | 0.0 |
| side exits and frame materialization | 3.9 | 3.9 | **+0.0** | -0% | 0.0 |
| write barriers | 25.1 | 25.3 | **-0.3** | 1% | 0.0 |
| allocation (objects, malloc) | 121.2 | 121.7 | **-0.5** | 2% | 0.0 |
| GC (marking, sweeping, freeing) | 40.7 | 41.7 | **-1.0** | 3% | 0.0 |
| block and proc invocation (generic) | 143.1 | 147.5 | **-4.4** | 14% | 0.0 |
| JIT code | 552.7 | 559.0 | **-6.4** | 20% | 0.0 |
| other runtime (cfunc bodies, hash, string, regexp, ...) | 1387.5 | 1411.2 | **-23.8** | 74% | 0.0 |
| total | 2893.2 | 2925.4 | **-32.1** | 100% | |

### Largest function differences (self Ir, M per iteration)

| function | bucket | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `<JIT code>` | JIT code | 552.7 | 559.0 | -6.4 |
| `ar_find_entry_hint` | other runtime | 35.9 | 41.8 | -5.8 |
| `rb_hash_aref` | other runtime | 30.5 | 34.6 | -4.0 |
| `rb_str_hash` | other runtime | 24.4 | 27.0 | -2.7 |
| `ruby_sip_hash13` | other runtime | 37.0 | 39.4 | -2.4 |
| `any_hash` | other runtime | 50.9 | 53.3 | -2.4 |
| `rb_hash_aset` | other runtime | 43.0 | 44.8 | -1.8 |
| `rb_vm_send` | method dispatch | 18.1 | 16.3 | +1.8 |
| `invoke_block_from_c_bh` | block and proc invocation | 37.3 | 39.0 | -1.7 |
| `vm_invoke_iseq_block` | block and proc invocation | 21.6 | 23.2 | -1.6 |
| `rb_vm_invokeblock` | block and proc invocation | 16.6 | 18.0 | -1.4 |
| `ar_equal` | other runtime | 4.7 | 6.1 | -1.4 |
| `vm_caller_setup_arg_block.isra.0` | block and proc invocation | 8.8 | 7.5 | +1.3 |
| `__memset_avx2_unaligned_erms` | other runtime | 62.4 | 63.7 | -1.2 |
| `rb_st_lookup` | other runtime | 60.0 | 58.8 | +1.2 |
| `rb_ary_fetch` | other runtime | 1.2 | 0.0 | +1.2 |
| `rb_managed_id_table_lookup` | method dispatch | 18.7 | 17.4 | +1.2 |
| `CALLER_SETUP_ARG` | method dispatch | 30.8 | 31.9 | -1.0 |
| `callable_method_entry_or_negative` | method dispatch | 19.5 | 18.6 | +0.9 |
| `rb_hash_fetch_m` | other runtime | 3.8 | 4.7 | -0.9 |
| `gc_sweep_page` | GC | 28.6 | 29.5 | -0.9 |
| `vm_call_iseq_setup_normal_0start_2params_2locals` | method dispatch | 1.3 | 0.4 | +0.8 |
| `rb_hash_default_value` | other runtime | 7.5 | 8.1 | -0.6 |
| `find_table_bin_ind` | other runtime | 7.3 | 7.9 | -0.6 |
| `rb_concurrent_set_find` | other runtime | 3.1 | 2.5 | +0.6 |
| `rb_ary_to_h` | other runtime | 0.0 | 0.5 | -0.5 |
| `rb_vm_exec` | method dispatch | 88.9 | 89.4 | -0.5 |
| `vm_callee_setup_block_arg` | block and proc invocation | 15.3 | 15.8 | -0.5 |
| `rb_yield_force_blockarg` | block and proc invocation | 0.0 | 0.5 | -0.5 |
| `RCLASS_EXT_WRITABLE` | method dispatch | 8.3 | 7.9 | +0.4 |
| `rb_any_cmp` | other runtime | 4.2 | 4.6 | -0.4 |
| `vm_env_cref` | method dispatch | 1.0 | 0.5 | +0.4 |
| `vm_call_cfunc_with_frame_` | method dispatch | 16.9 | 17.3 | -0.4 |
| `rb_hash_has_key` | other runtime | 4.1 | 4.5 | -0.4 |
| `rb_id_table_lookup` | method dispatch | 1.7 | 1.4 | +0.3 |
| `vm_lookup_cc` | method dispatch | 2.8 | 2.5 | +0.3 |
| `rb_newobj_of` | allocation | 15.1 | 15.4 | -0.3 |
| `rb_check_frozen_inline` | other runtime | 12.0 | 12.3 | -0.3 |
| `rb_gc_writebarrier` | write barriers | 24.7 | 25.0 | -0.3 |
| `ary_ensure_room_for_push` | other runtime | 8.2 | 8.4 | -0.2 |

### Unclassified (other runtime) differences above 0.5M
  -5.8 ar_find_entry_hint
  -4.0 rb_hash_aref
  -2.7 rb_str_hash
  -2.4 ruby_sip_hash13
  -2.4 any_hash
  -1.8 rb_hash_aset
  -1.4 ar_equal
  -1.2 __memset_avx2_unaligned_erms
  +1.2 rb_st_lookup
  +1.2 rb_ary_fetch
  -0.9 rb_hash_fetch_m
  -0.6 rb_hash_default_value
  -0.6 find_table_bin_ind
  +0.6 rb_concurrent_set_find
  -0.5 rb_ary_to_h

### JIT code self Ir by ISEQ (run a; M per iteration)

| ISEQ | ZJIT | YJIT | ZJIT − YJIT |
|---|---:|---:|---:|
| `call@rails-c48c154e3f52/actionpack/lib/action_dispatch/routing/route_set.rb` | 0.0 | 9.8 | -9.8 |
| `call@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/route_set.rb` | 9.8 | 0.0 | +9.8 |
| `cast_value@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | 8.8 | 0.0 | +8.8 |
| `blank?@rails-c48c154e3f52/activesupport/lib/active_support/core_ext/object/blank.rb` | 0.0 | 7.4 | -7.4 |
| `blank?@rails-50c54eed065b/activesupport/lib/active_support/core_ext/object/blank.rb` | 7.4 | 0.0 | +7.4 |
| `fetch@rails-c48c154e3f52/activemodel/lib/active_model/indexed_row.rb` | 0.0 | 7.1 | -7.1 |
| `block in fetch_value!@rails-c48c154e3f52/activemodel/lib/active_model/attribute_set.rb` | 0.0 | 7.0 | -7.0 |
| `append_tag_option@rails-c48c154e3f52/actionview/lib/action_view/helpers/tag_helper.rb` | 0.0 | 5.7 | -5.7 |
| `append_tag_option@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | 5.7 | 0.0 | +5.7 |
| `block in add_to@rails-c48c154e3f52/actionpack/lib/action_dispatch/journey/visitors.rb` | 0.0 | 5.6 | -5.6 |
| `block in add_to@rails-50c54eed065b/actionpack/lib/action_dispatch/journey/visitors.rb` | 5.6 | 0.0 | +5.6 |
| `block in tag_options@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | 5.4 | 0.0 | +5.4 |
| `block in tag_options@rails-c48c154e3f52/actionview/lib/action_view/helpers/tag_helper.rb` | 0.0 | 5.4 | -5.4 |
| `call@rails-50c54eed065b/activesupport/lib/active_support/callbacks.rb` | 5.2 | 0.0 | +5.2 |
| `call@rails-c48c154e3f52/activesupport/lib/active_support/callbacks.rb` | 0.0 | 5.2 | -5.2 |
| `url_options@rails-c48c154e3f52/actionpack/lib/action_controller/metal/url_for.rb` | 0.0 | 4.4 | -4.4 |
| `url_options@rails-50c54eed065b/actionpack/lib/action_controller/metal/url_for.rb` | 4.4 | 0.0 | +4.4 |
| `move@rails-50c54eed065b/actionpack/lib/action_dispatch/journey/gtg/transition_table.rb` | 4.3 | 0.0 | +4.3 |
| `move@rails-c48c154e3f52/actionpack/lib/action_dispatch/journey/gtg/transition_table.rb` | 0.0 | 4.3 | -4.3 |
| `search_combinations@rails-c48c154e3f52/actionview/lib/action_view/path_set.rb` | 0.0 | 3.7 | -3.7 |
| `search_combinations@rails-50c54eed065b/actionview/lib/action_view/path_set.rb` | 3.7 | 0.0 | +3.7 |
| `fetch_value_at!@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | 3.7 | 0.0 | +3.7 |
| `<<@rails-c48c154e3f52/actionview/lib/action_view/buffers.rb` | 0.0 | 3.6 | -3.6 |
| `<<@rails-50c54eed065b/actionview/lib/action_view/buffers.rb` | 3.6 | 0.0 | +3.6 |
| `content_tag_string@rails-c48c154e3f52/actionview/lib/action_view/helpers/tag_helper.rb` | 0.0 | 3.5 | -3.5 |
| `content_tag_string@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | 3.5 | 0.0 | +3.5 |
| `optimize_routes_generation?@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/url_for.rb` | 3.5 | 0.0 | +3.5 |
| `optimize_routes_generation?@rails-c48c154e3f52/actionpack/lib/action_dispatch/routing/url_for.rb` | 0.0 | 3.5 | -3.5 |
| `run_callbacks@rails-c48c154e3f52/activesupport/lib/active_support/callbacks.rb` | 0.0 | 3.5 | -3.5 |
| `run_callbacks@rails-50c54eed065b/activesupport/lib/active_support/callbacks.rb` | 3.5 | 0.0 | +3.5 |

### JIT code by ZJIT HIR instruction (run b, M per iteration; total 0.0)


### JIT code by YJIT codegen symbol (run b, M per iteration; total 0.0)


### C functions called from JIT code (calls per iteration; inclusive Ir includes callees)

| callee | ZJIT calls | YJIT calls | ZJIT − YJIT calls | ZJIT incl M | YJIT incl M |
|---|---:|---:|---:|---:|---:|
| `rb_hash_aref` | 908944 | 1011057 | -102113 | 218.7 | 233.5 |
| `<JIT code>` | 3777686 | 3835289 | -57603 | 143899.7 | 146835.7 |
| `rb_ary_fetch` | 27180 | 0 | 27180 | 1.9 | 0.0 |
| `rb_vm_send` | 225491 | 203011 | 22480 | 8713.7 | 8836.5 |
| `rb_hash_fetch_m` | 53711 | 76191 | -22480 | 158.5 | 160.1 |
| `rb_vm_invokeblock` | 222164 | 239134 | -16970 | 15546.4 | 15817.0 |
| `__memcpy_avx_unaligned_erms` | 1008313 | 1020316 | -12003 | 14.9 | 15.0 |
| `rb_hash_has_key` | 138436 | 150436 | -12000 | 19.7 | 21.8 |
| `rb_int_equal` | 20970 | 8970 | 12000 | 12.3 | 12.1 |
| `rb_jit_ary_push` | 34184 | 39154 | -4970 | 3.9 | 4.5 |
| `rb_vm_opt_send_without_block` | 273286 | 275986 | -2700 | 385.8 | 383.5 |
| `rb_ivar_get` | 211912 | 209312 | 2600 | 27.7 | 27.3 |
| `ary_sized_alloc` | 19944 | 21944 | -2000 | 3.3 | 3.5 |
| `rb_ary_freeze` | 4030 | 6030 | -2000 | 0.2 | 0.3 |
| `rb_ary_to_h` | 0 | 2000 | -2000 | 0.0 | 16.2 |
| `rb_ec_ary_new_from_values` | 3066 | 3440 | -374 | 29.7 | 18.2 |
| `rb_hash_new` | 2092 | 2155 | -63 | 4.2 | 4.3 |
| `rb_hash_new_capa` | 2818 | 2792 | 26 | 2.4 | 2.2 |
| `__memset_avx2_unaligned_erms` | 142017 | 142036 | -19 | 62.2 | 63.5 |
| `rb_class_allocate_instance` | 2650 | 2666 | -16 | 4.5 | 8.4 |
| `free` | 389008 | 389018 | -10 | 14.7 | 14.8 |
| `rb_ary_resurrect` | 256 | 266 | -9 | 0.6 | 0.3 |
| `rb_ec_str_resurrect` | 376 | 379 | -3 | 6.4 | 1.1 |
| `rb_range_new` | 61 | 60 | 1 | 0.1 | 0.1 |
| `rb_ary_all_p` | 32000 | 32000 | 0 | 9.0 | 9.0 |
| `rb_str_dup_m` | 4600 | 4600 | 0 | 1.0 | 0.8 |
| `m_core_hash_merge_bang_ptr` | 2000 | 2000 | 0 | 3.1 | 2.8 |
| `rb_int_plus` | 2000 | 2000 | 0 | 0.1 | 0.1 |
| `rb_obj_is_instance_of` | 5213 | 5213 | 0 | 0.1 | 0.1 |
| `rb_zjit_defined_ivar` | 8090 | 8090 | 0 | 0.7 | 0.7 |

### Generic calls from JIT code by ISEQ (run a; calls per iteration)

| ISEQ | callee | ZJIT | YJIT | ZJIT − YJIT |
|---|---|---:|---:|---:|
| `block in emitting?@rails-50c54eed065b/activesupport/lib/active_support/event_reporter.rb` | `rb_hash_aref` | 32000 | 0 | 32000 |
| `block (2 levels) in generate_url_helpers@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/r` | `rb_ivar_get` | 31071 | 0 | 31071 |
| `path_for@rails-50c54eed065b/actionpack/lib/action_dispatch/http/url.rb` | `rb_hash_aref` | 31071 | 0 | 31071 |
| `url_options@rails-50c54eed065b/actionpack/lib/action_controller/metal/url_for.rb` | `rb_ivar_get` | 28714 | 0 | 28714 |
| `block in add_to@rails-50c54eed065b/actionpack/lib/action_dispatch/journey/visitors.rb` | `rb_hash_aref` | 28397 | 0 | 28397 |
| `block in tag_options@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | `rb_vm_opt_send_without_block` | 28314 | 0 | 28314 |
| `block in subscription_filter@rails-50c54eed065b/activesupport/lib/active_support/event_reporter/log_` | `rb_hash_aref` | 28000 | 0 | 28000 |
| `block in make_lambda@rails-50c54eed065b/activesupport/lib/active_support/callbacks.rb` | `rb_vm_send` | 27970 | 0 | 27970 |
| `move@rails-50c54eed065b/actionpack/lib/action_dispatch/journey/gtg/transition_table.rb` | `rb_hash_aref` | 27749 | 0 | 27749 |
| `block in initialize@rails-50c54eed065b/activesupport/lib/active_support/ordered_options.rb` | `rb_vm_opt_send_without_block` | 25883 | 0 | 25883 |
| `level@rails-50c54eed065b/activesupport/lib/active_support/logger_thread_safe_level.rb` | `rb_vm_opt_send_without_block` | 24000 | 0 | 24000 |
| `cast_value@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | `rb_vm_opt_send_without_block` | 22480 | 0 | 22480 |
| `url_options@rails-50c54eed065b/actionview/lib/action_view/routing_url_for.rb` | `rb_ivar_get` | 20714 | 0 | 20714 |
| `optimize_routes_generation?@rails-50c54eed065b/actionview/lib/action_view/routing_url_for.rb` | `rb_ivar_get` | 20714 | 0 | 20714 |
| `block in add_to@rails-50c54eed065b/actionpack/lib/action_dispatch/journey/visitors.rb` | `rb_vm_opt_send_without_block` | 19414 | 0 | 19414 |
| `iterate_guarding_exceptions@rails-50c54eed065b/activesupport/lib/active_support/notifications/fanout` | `rb_vm_send` | 18000 | 0 | 18000 |
| `fetch_value_at!@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | `rb_vm_send` | 17510 | 0 | 17510 |
| `block in initialize_details@rails-50c54eed065b/actionview/lib/action_view/lookup_context.rb` | `rb_hash_aref` | 16000 | 0 | 16000 |
| `instrumenter@rails-50c54eed065b/activesupport/lib/active_support/notifications.rb` | `rb_hash_aref` | 16000 | 0 | 16000 |
| `block in tag_options@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | `rb_hash_aref` | 14157 | 0 | 14157 |
| `call@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/route_set.rb` | `rb_hash_aref` | 13657 | 0 | 13657 |
| `routes@rails-50c54eed065b/actionpack/lib/action_dispatch/http/request.rb` | `rb_hash_aref` | 12357 | 0 | 12357 |
| `block in initialize@rails-50c54eed065b/activerecord/lib/active_record/result.rb` | `rb_hash_aref` | 12000 | 0 | 12000 |
| `before@rails-50c54eed065b/activesupport/lib/active_support/execution_wrapper.rb` | `rb_vm_opt_send_without_block` | 12000 | 0 | 12000 |
| `config@rails-50c54eed065b/actionpack/lib/abstract_controller/base.rb` | `rb_vm_opt_send_without_block` | 11974 | 0 | 11974 |
| `call_direct@rails-50c54eed065b/actionpack/lib/abstract_controller/callbacks.rb` | `rb_ivar_get` | 11940 | 0 | 11940 |
| `call@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/route_set.rb` | `rb_ivar_get` | 10357 | 0 | 10357 |
| `optimize_routes_generation?@rails-50c54eed065b/actionview/lib/action_view/routing_url_for.rb` | `rb_vm_opt_send_without_block` | 10357 | 0 | 10357 |
| `optimize_routes_generation?@rails-50c54eed065b/actionpack/lib/action_dispatch/routing/route_set.rb` | `rb_vm_opt_send_without_block` | 10357 | 0 | 10357 |
| `rank_for@rails-50c54eed065b/actionview/lib/action_view/template_details.rb` | `rb_hash_aref` | 10000 | 0 | 10000 |
| `parameters@rails-50c54eed065b/actionpack/lib/action_dispatch/http/parameters.rb` | `rb_hash_aref` | 9983 | 0 | 9983 |
| `[]@rails-50c54eed065b/activesupport/lib/active_support/isolated_execution_state.rb` | `rb_hash_aref` | 9970 | 0 | 9970 |
| `[]@rails-50c54eed065b/activesupport/lib/active_support/ordered_options.rb` | `rb_hash_aref` | 9961 | 0 | 9961 |
| `connected_to_stack@rails-50c54eed065b/activerecord/lib/active_record/core.rb` | `rb_hash_aref` | 9940 | 0 | 9940 |
| `link_to@rails-50c54eed065b/actionview/lib/action_view/helpers/navigation_helper.rb` | `rb_hash_aref` | 9057 | 0 | 9057 |
| `content_tag_string@rails-50c54eed065b/actionview/lib/action_view/helpers/tag_helper.rb` | `rb_hash_aref` | 9057 | 0 | 9057 |
| `index_for_name@rails-50c54eed065b/activemodel/lib/active_model/attribute_set.rb` | `rb_hash_aref` | 8370 | 0 | 8370 |
| `url_options@rails-50c54eed065b/actionpack/lib/action_controller/metal/url_for.rb` | `rb_hash_aref` | 8357 | 0 | 8357 |
| `block in extract_details@rails-50c54eed065b/actionview/lib/action_view/renderer/abstract_renderer.rb` | `rb_hash_aref` | 8052 | 0 | 8052 |
| `matches?@rails-50c54eed065b/actionview/lib/action_view/template_details.rb` | `rb_hash_aref` | 8013 | 0 | 8013 |

