# attr_reader whose receiver profile has 2 shapes of one class (like Thread
# objects with different ivar sets at IsolatedExecutionState.[]).
class Box
  attr_reader :v
  def initialize(v, extra) = (@extra = 1 if extra; @v = v)
end
BOXES = [Box.new(1, false), Box.new(2, true)]
def read(b) = b.v
N = 10_000
200.times { |i| read(BOXES[i % 2]) }
RubyVM::ZJIT.reset_stats!
N.times { read(BOXES[0]) }
s = RubyVM::ZJIT.stats
puts %i[dynamic_getivar_count getivar_fallback_no_profile_missing_ic getivar_fallback_no_side_exits].map { |k| "#{k}=#{(s[k].to_f / N).round(2)}" }.join(" ")
