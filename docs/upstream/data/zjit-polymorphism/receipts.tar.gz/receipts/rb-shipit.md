Apps: shipit (means are over 1 apps, per operation)
Fallback receivers found in the interpreter distribution: 100.0%

| Reason | Fallbacks/op | caught N=1 | N=2 | N=4 | N=8 | one resolved method |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `getivar_no_profile_missing_ic` | 836857 | 590546 (71%) | 772399 (92%) | 832053 (99%) | 836361 (100%) | – |
| `send_polymorphic_fallback` | 663227 | 175459 (26%) | 367565 (55%) | 536415 (81%) | 652531 (98%) | 635151 (96%) |
| `getivar_no_side_exits` | 410794 | 235699 (57%) | 296156 (72%) | 358698 (87%) | 386244 (94%) | – |
| `invokeblock_not_specialized` | 301286 | 39683 (13%) | 168802 (56%) | 234127 (78%) | 259058 (86%) | – |
| `send_megamorphic` | 111231 | 56372 (51%) | 83598 (75%) | 89206 (80%) | 103650 (93%) | 79746 (72%) |
| `invokeblock_polymorphic_miss` | 98246 | 35337 (36%) | 48449 (49%) | 60476 (62%) | 77461 (79%) | – |
| `send_polymorphic` | 30432 | 17848 (59%) | 23583 (77%) | 28253 (93%) | 30184 (99%) | 0 (0%) |
| `getivar_polymorphic` | 1432 | 1154 (81%) | 1154 (81%) | 1184 (83%) | 1335 (93%) | – |

### getivar_no_profile_missing_ic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | ivar index | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `[]@activesupport-8.1.2/lib/active_support/isolated_execution_state.rb:32 active_support_execution_state` | 1 | 112169.0 | 112169.0 | 1 | 1 | 100% / 100% / 100% | 112169.0 | 0 () | Thread 100% |
| `klass@activerecord-8.1.2/lib/active_record/associations/association.rb:166 reflection` | 1 | 64455.0 | 64455.0 | 2 | 3 | 90% / 100% / 100% | 64455.0 | 0 () | ActiveRecord::Associations::BelongsToAssociation 68%, ActiveRecord::Associations::HasManyAssociation 23%, ActiveRecord::Associations::HasManyAssociation 10% |
| `<<@activerecord-8.1.2/lib/arel/collectors/composite.rb:22 right` | 1 | 52738.0 | 52738.0 | 1 | 1 | 100% / 100% / 100% | 52738.0 | 0 () | Arel::Collectors::Composite 100% |
| `<<@activerecord-8.1.2/lib/arel/collectors/composite.rb:21 left` | 1 | 52738.0 | 52738.0 | 1 | 1 | 100% / 100% / 100% | 52738.0 | 0 () | Arel::Collectors::Composite 100% |
| `empty?@activerecord-8.1.2/lib/active_record/relation/where_clause.rb:8 predicates` | 1 | 22052.0 | 22052.0 | 1 | 2 | 100% / 100% / 100% | 22052.0 | 0 () | ActiveRecord::Relation::WhereClause 91%, ActiveRecord::Relation::WhereClause 9% |
| `each_attributes@activerecord-8.1.2/lib/active_record/relation/where_clause.rb:127 predicates` | 1 | 18306.0 | 18306.0 | 1 | 2 | 100% / 100% / 100% | 18306.0 | 0 () | ActiveRecord::Relation::WhereClause 77%, ActiveRecord::Relation::WhereClause 23% |

### send_polymorphic_fallback

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `block in _load_from_sql@activerecord-8.1.2/lib/active_record/querying.rb:77 attribute_types` | 1 | 113980.0 | 114970.0 | 7 | 7 | 73% / 99% / 100% | 113980.0 | 1 (ActiveModel::AttributeRegistration::ClassMethods#attribute_types) | #<Class:Shipit::Commit> 46%, #<Class:Shipit::Task> 27%, #<Class:Shipit::User> 23%, #<Class:Shipit::Status> 4% |
| `current_shard@activerecord-8.1.2/lib/active_record/core.rb:182 default_shard` | 1 | 17637.0 | 17908.0 | 11 | 11 | 62% / 86% / 99% | 15336.0 | 1 (#<Class:ActiveRecord::Base>#default_shard) | #<Class:Shipit::Commit> 33%, #<Class:Shipit::User> 29%, #<Class:Shipit::CheckRun> 15%, #<Class:Shipit::Status> 9% |
| `default_shard@activerecord-8.1.2/lib/active_record/core.rb:101 __class_attr_default_shard` | 1 | 17637.0 | 17908.0 | 11 | 11 | 62% / 86% / 99% | 15336.0 | 1 (#<Class:ActiveRecord::Base>#__class_attr_default_shard) | #<Class:Shipit::Commit> 33%, #<Class:Shipit::User> 29%, #<Class:Shipit::CheckRun> 15%, #<Class:Shipit::Status> 9% |
| `current_shard@activerecord-8.1.2/lib/active_record/core.rb:177 connected_to_stack` | 1 | 17637.0 | 17908.0 | 11 | 11 | 62% / 86% / 99% | 15336.0 | 1 (#<Class:ActiveRecord::Base>#connected_to_stack) | #<Class:Shipit::Commit> 33%, #<Class:Shipit::User> 29%, #<Class:Shipit::CheckRun> 15%, #<Class:Shipit::Status> 9% |
| `current_role@activerecord-8.1.2/lib/active_record/core.rb:164 default_role` | 1 | 17637.0 | 17908.0 | 11 | 11 | 62% / 86% / 99% | 15336.0 | 1 (#<Class:ActiveRecord::Base>#default_role) | #<Class:Shipit::Commit> 33%, #<Class:Shipit::User> 29%, #<Class:Shipit::CheckRun> 15%, #<Class:Shipit::Status> 9% |
| `current_role@activerecord-8.1.2/lib/active_record/core.rb:159 connected_to_stack` | 1 | 17637.0 | 17908.0 | 11 | 11 | 62% / 86% / 99% | 15336.0 | 1 (#<Class:ActiveRecord::Base>#connected_to_stack) | #<Class:Shipit::Commit> 33%, #<Class:Shipit::User> 29%, #<Class:Shipit::CheckRun> 15%, #<Class:Shipit::Status> 9% |

### getivar_no_side_exits

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | ivar index | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `attribute_types@activemodel-8.1.2/lib/active_model/attribute_registration.rb:38 @attribute_types` | 1 | 119969.0 | 126754.0 | 9 | 9 | 71% / 98% / 100% | 118970.0 | 1 (idx=16/RClass) | #<Class:Shipit::Commit> 44%, #<Class:Shipit::Task> 27%, #<Class:Shipit::User> 23%, #<Class:Shipit::Status> 4% |
| `block in fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb:48 values` | 1 | 24770.0 | 24770.0 | 1 | 1 | 100% / 100% / 100% | 24770.0 | 0 () | ActiveModel::LazyAttributeSet 100% |
| `block in fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb:51 additional_types` | 1 | 24769.8 | 24770.0 | 1 | 1 | 100% / 100% / 100% | 24769.8 | 0 () | ActiveModel::LazyAttributeSet 100% |
| `block in fetch_value@activemodel-8.1.2/lib/active_model/attribute_set/builder.rb:51 types` | 1 | 24769.8 | 24770.0 | 1 | 1 | 100% / 100% / 100% | 24769.8 | 0 () | ActiveModel::LazyAttributeSet 100% |
| `_read_attribute@activerecord-8.1.2/lib/active_record/attribute_methods/read.rb:39 @attributes` | 1 | 23351.0 | 67566.0 | 9 | 22 | 29% / 48% / 70% | 7978.0 | 1 (idx=1/RObject) | Shipit::User 17%, Shipit::Deploy 12%, Shipit::Stack 12%, Shipit::Status 7% |
| `connection_specification_name@activerecord-8.1.2/lib/active_record/connection_handling.rb:320 @connection_specification_name` | 1 | 17082.0 | 57636.0 | 14 | 14 | 63% / 82% / 98% | 11056.0 | 2 (undefined/RClass) | #<Class:Shipit::Record> 31%, #<Class:ActiveRecord::Base> 31%, #<Class:Shipit::Commit> 10%, #<Class:Shipit::User> 9% |

### invokeblock_not_specialized

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `each@<internal:array>:271 yield` | 1 | 259463.2 | 395214.3 | 68 | 68 | 67% / 83% / 89% | 192734.0 | 0 () | <ifunc> 34%, iseq:block in merge@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/relation/merger.rb:60 32%, iseq:block in url_for@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.2/lib/action_dispatch/routing/route_set.rb:875 9%, :-@ 8% |
| `find@<internal:array>:348 yield` | 1 | 21879.2 | 21879.7 | 8 | 8 | 96% / 99% / 100% | 21732.0 | 0 () | iseq:block in handler_for@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/relation/predicate_builder.rb:188 93%, iseq:block (3 levels) in populate_keys_to_load_and_already_loaded_records@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/associations/preloader/association.rb:80 3%, iseq:block (2 levels) in normalize_options@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.2/lib/active_support/cache.rb:951 2%, iseq:block in extract_non_symbol_default!@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/i18n-1.14.8/lib/i18n/backend/fallbacks.rb:91 1% |
| `loop@<internal:kernel>:159 yield` | 1 | 4430.0 | 4430.0 | 1 | 1 | 100% / 100% / 100% | 4430.0 | 0 () | iseq:block in each@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/sqlite3-2.7.3/lib/sqlite3/statement.rb:124 100% |
| `add_bind@activerecord-8.1.2/lib/arel/collectors/sql_string.rb:16 yield` | 1 | 3381.0 | 3381.0 | 1 | 1 | 100% / 100% / 100% | 3381.0 | 0 () | <proc> 100% |
| `check_if_method_has_arguments!@activerecord-8.1.2/lib/active_record/relation/query_methods.rb:2228 yield` | 1 | 3006.0 | 3006.0 | 1 | 1 | 100% / 100% / 100% | 3006.0 | 0 () | iseq:block in order@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/relation/query_methods.rb:658 100% |
| `match_route@actionpack-8.1.2/lib/action_dispatch/journey/formatter.rb:149 yield` | 1 | 2790.0 | 2790.0 | 1 | 1 | 100% / 100% / 100% | 2790.0 | 0 () | iseq:block in generate@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.2/lib/action_dispatch/journey/formatter.rb:73 100% |

### send_megamorphic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `!=@<internal:basic_object>:14 ==` | 1 | 30256.5 | 110853.7 | 20 | 28 | 55% / 74% / 91% | 11219.0 | 9 (BasicObject#==) | Object 39%, Integer 16%, Thread 10%, Symbol 8% |
| `association@activerecord-8.1.2/lib/active_record/associations.rb:54 association_instance_get` | 1 | 24328.0 | 24328.0 | 7 | 20 | 70% / 90% / 100% | 21809.0 | 1 (ActiveRecord::Associations#association_instance_get) | Shipit::Commit 46%, Shipit::Stack 24%, Shipit::Deploy 14%, Shipit::Status 6% |
| `named_routes@actionpack-8.1.2/lib/action_dispatch/journey/formatter.rb:144 named_routes` | 1 | 5630.0 | 5630.0 | 2 | 2 | 100% / 100% / 100% | 5630.0 | 1 (ActionDispatch::Routing::RouteSet#named_routes) | ActionDispatch::Routing::RouteSet 50%, singleton:obj(ActionDispatch::Routing::RouteSet) 50% |
| `level@logger-1.7.0/lib/logger.rb:384 level_override` | 1 | 5104.0 | 5104.0 | 1 | 1 | 100% / 100% / 100% | 5104.0 | 1 (Logger#level_override) | singleton:obj(ActiveSupport::Logger) 100% |
| `level@activesupport-8.1.2/lib/active_support/logger_thread_safe_level.rb:36 local_level` | 1 | 5104.0 | 5104.0 | 1 | 1 | 100% / 100% / 100% | 5104.0 | 1 (ActiveSupport::LoggerThreadSafeLevel#local_level) | singleton:obj(ActiveSupport::Logger) 100% |
| `local_level@activesupport-8.1.2/lib/active_support/logger_thread_safe_level.rb:16 local_level_key` | 1 | 5104.0 | 5104.0 | 1 | 1 | 100% / 100% / 100% | 5104.0 | 1 (ActiveSupport::LoggerThreadSafeLevel#local_level_key) | singleton:obj(ActiveSupport::Logger) 100% |

### invokeblock_polymorphic_miss

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `map@<internal:array>:291 yield` | 1 | 79649.0 | 79724.0 | 49 | 49 | 44% / 55% / 74% | 43792.0 | 0 () | iseq:block in perform_query@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/connection_adapters/sqlite3/database_statements.rb:123 38%, iseq:block in indexed_rows@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/result.rb:244 6%, iseq:block in type_casted_binds@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/connection_adapters/abstract/quoting.rb:221 6%, <proc> 5% |
| `with_connection@activerecord-8.1.2/lib/active_record/connection_adapters/abstract/connection_pool.rb:463 yield` | 1 | 6362.0 | 11586.0 | 7 | 7 | 50% / 86% / 100% | 4848.0 | 0 () | iseq:block in create@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/associations/alias_tracker.rb:11 29%, iseq:block in association_scope_cache@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/reflection.rb:550 21%, iseq:block in find_target@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/associations/association.rb:269 21%, iseq:block (2 levels) in exec_main_query@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/relation.rb:1473 15% |
| `instrument@activesupport-8.1.2/lib/active_support/notifications/instrumenter.rb:58 yield` | 1 | 5984.0 | 7954.0 | 4 | 4 | 75% / 100% / 100% | 5984.0 | 0 () | iseq:block in _load_from_sql@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/querying.rb:88 45%, iseq:block in instrument@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.2/lib/active_support/notifications.rb:210 30%, iseq:block in raw_execute@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/connection_adapters/abstract/database_statements.rb:570 25%, iseq:block in instantiate@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/associations/join_dependency.rb:143 1% |
| `block in extract!@activesupport-8.1.2/lib/active_support/core_ext/array/extract.rb:16 yield` | 1 | 3011.0 | 7726.0 | 2 | 2 | 100% / 100% / 100% | 3011.0 | 0 () | iseq:block in except_predicates@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/relation/where_clause.rb:181 61%, iseq:block in call@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/relation/predicate_builder/array_handler.rb:17 39% |
| `instrument@activesupport-8.1.2/lib/active_support/notifications.rb:212 yield` | 1 | 1717.0 | 1820.0 | 8 | 8 | 62% / 88% / 100% | 1595.0 | 0 () | iseq:block in serializable_object_with_notification@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/active_model_serializers-0.9.13/lib/active_model/serializable.rb:26 43%, iseq:block in render@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.2/lib/action_view/template.rb:273 19%, iseq:block in _instrument@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.2/lib/active_support/cache.rb:1091 15%, iseq:block in read_fragment@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.2/lib/abstract_controller/caching/fragments.rb:98 11% |
| `select@<internal:array>:318 yield` | 1 | 946.2 | 955.6 | 9 | 9 | 76% / 99% / 100% | 944.0 | 0 () | iseq:block in load_records@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.2/lib/active_record/associations/preloader/association.rb:203 50%, iseq:block in filter_and_sort_by_details@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.2/lib/action_view/template/resolver.rb:182 25%, iseq:block in method_missing@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.2/lib/active_support/broadcast_logger.rb:223 18%, :present? 5% |

### send_polymorphic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `value_for@activerecord-8.1.2/lib/active_record/scoping.rb:121 ==` | 1 | 17942.0 | 17942.0 | 9 | 9 | 63% / 89% / 100% | 15986.0 | 1 (Module#==) | #<Class:Shipit::Commit> 34%, #<Class:Shipit::User> 29%, #<Class:Shipit::Task> 14%, #<Class:Shipit::CheckRun> 12% |
| `stale_target?@activerecord-8.1.2/lib/active_record/associations/association.rb:98 ==` | 1 | 11804.0 | 11804.0 | 2 | 2 | 100% / 100% / 100% | 11804.0 | 2 (Integer#==) | Integer 95%, NilClass 5% |
| `namespace_key@activesupport-8.1.2/lib/active_support/cache.rb:1023 ==` | 1 | 249.0 | 249.0 | 1 | 2 | 100% / 100% / 100% | 249.0 | 1 (BasicObject#==) | Encoding 100% |
| `block in each_precompressed_filepath@actionpack-8.1.2/lib/action_dispatch/middleware/static.rb:156 ` | 1 | 171.0 | 0.0 | 0 | 0 | 0% / 0% / 0% | 0.0 | 0 () |  |
| `[]=@rack-2.2.22/lib/rack/utils.rb:481 ==` | 1 | 89.0 | 89.0 | 1 | 2 | 100% / 100% / 100% | 89.0 | 1 (String#==) | String 100% |
| `[]=@actionpack-8.1.2/lib/action_dispatch/middleware/cookies.rb:390 ==` | 1 | 57.0 | 57.0 | 1 | 2 | 100% / 100% / 100% | 57.0 | 1 (String#==) | String 100% |

### getivar_polymorphic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | ivar index | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `base_class?@activerecord-8.1.2/lib/active_record/inheritance.rb:120 base_class` | 1 | 1155.1 | 1454.0 | 3 | 3 | 93% / 100% / 100% | 1155.1 | 0 () | #<Class:Shipit::Task> 79%, #<Class:Shipit::ReleaseStatus> 14%, #<Class:Shipit::Stack> 7% |
| `spawn@activerecord-8.1.2/lib/active_record/relation/spawn_methods.rb:10 model` | 1 | 233.0 | 7012.0 | 9 | 15 | 50% / 78% / 95% | 25.0 | 0 () | Shipit::Task::ActiveRecord_AssociationRelation 34%, Shipit::CheckRun::ActiveRecord_Relation 16%, Shipit::Commit::ActiveRecord_AssociationRelation 15%, Shipit::Status::ActiveRecord_Relation 12% |
| `performed?@actionpack-8.1.2/lib/action_controller/metal.rb:246 response_body` | 1 | 25.0 | 247.0 | 5 | 15 | 36% / 52% / 78% | 0.0 | 0 () | Shipit::StacksController 18%, Shipit::StacksController 18%, Shipit::Api::DeploysController 8%, Shipit::TasksController 8% |
| `load@activerecord-8.1.2/lib/active_record/relation.rb:1200 loaded?` | 1 | 15.0 | 1891.0 | 10 | 10 | 59% / 85% / 97% | 0.0 | 0 () | Shipit::Task::ActiveRecord_AssociationRelation 32%, Shipit::CheckRun::ActiveRecord_AssociationRelation 27%, Shipit::Commit::ActiveRecord_AssociationRelation 14%, Shipit::Status::ActiveRecord_AssociationRelation 12% |
| `object_has_errors?@actionview-8.1.2/lib/action_view/helpers/active_model_helper.rb:42 object` | 1 | 2.0 | 24.0 | 4 | 4 | 75% / 100% / 100% | 2.0 | 0 () | ActionView::Helpers::Tags::Label 50%, ActionView::Helpers::Tags::CheckBox 25%, ActionView::Helpers::Tags::TextField 17%, ActionView::Helpers::Tags::TextArea 8% |
| `object_has_errors?@actionview-8.1.2/lib/action_view/helpers/active_model_helper.rb:42 object` | 1 | 2.0 | 24.0 | 4 | 4 | 75% / 100% / 100% | 2.0 | 0 () | ActionView::Helpers::Tags::Label 50%, ActionView::Helpers::Tags::CheckBox 25%, ActionView::Helpers::Tags::TextField 17%, ActionView::Helpers::Tags::TextArea 8% |
