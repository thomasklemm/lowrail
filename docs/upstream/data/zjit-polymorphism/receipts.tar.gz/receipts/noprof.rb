# Arel::Collectors::Composite#<< / LazyAttributeSet#fetch_value shape: a
# monomorphic attr_reader in a callee that ZJIT first reaches from JIT code.
class Composite
  attr_reader :left
  def initialize(l) = @left = l
  def push(x) = left        # site under test (1 class, 1 shape)
end
C = Composite.new(1)
def visit(c, warm) = (c.push(1) if warm)
N = 10_000
# Compile visit before push has ever run in the interpreter.
100.times { visit(C, false) }
RubyVM::ZJIT.reset_stats!
N.times { visit(C, true) }
s = RubyVM::ZJIT.stats
puts %i[dynamic_getivar_count getivar_fallback_no_profile_missing_ic dynamic_send_count].map { |k| "#{k}=#{(s[k].to_f / N).round(2)}" }.join(" ")
