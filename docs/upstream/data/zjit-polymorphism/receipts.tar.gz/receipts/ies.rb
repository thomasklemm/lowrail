# IsolatedExecutionState.[]: attr_reader on the result of Thread.current
class Thread; attr_accessor :state_x; end
Thread.current.state_x = {a: 1}
def read = Thread.current.state_x
N = 10_000
100.times { read }
RubyVM::ZJIT.reset_stats!
N.times { read }
s = RubyVM::ZJIT.stats
puts %i[dynamic_getivar_count getivar_fallback_no_profile_missing_ic getivar_fallback_no_side_exits dynamic_send_count].map { |k| "#{k}=#{(s[k].to_f / N).round(2)}" }.join(" ")
