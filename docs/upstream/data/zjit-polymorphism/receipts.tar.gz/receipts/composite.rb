# Arel::Collectors::Composite#<< shape: attr_reader on self inside a method
# that callers reach through a polymorphic collector site.
class SQLString; def initialize = @s = +""; def <<(x) = (@s.clear << x; self); end
class Binds; def initialize = @b = []; def <<(x) = (@b.clear << x; self); end
class Composite
  attr_reader :left, :right
  def initialize(l, r) = (@left = l; @right = r)
  def <<(str) = (left << str; right << str; self)
end
COLLECTORS = [Composite.new(SQLString.new, Binds.new), SQLString.new]
def visit(c) = c << "x"
N = 10_000
(N / 10).times { |i| visit(COLLECTORS[i % 2]) }
RubyVM::ZJIT.reset_stats!
N.times { |i| visit(COLLECTORS[0]) }
s = RubyVM::ZJIT.stats
keys = %i[dynamic_getivar_count getivar_fallback_no_profile_missing_ic getivar_fallback_no_side_exits send_fallback_send_polymorphic_fallback dynamic_send_count]
puts keys.map { |k| "#{k}=#{(s[k].to_f / N).round(2)}" }.join(" ")
