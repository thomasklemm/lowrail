Apps: railsbench (means are over 1 apps, per operation)
Fallback receivers found in the interpreter distribution: 98.9%

| Reason | Fallbacks/op | caught N=1 | N=2 | N=4 | N=8 | one resolved method |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `invokeblock_not_specialized` | 329726 | 103901 (32%) | 119889 (36%) | 168440 (51%) | 230403 (70%) | – |
| `getivar_no_profile_missing_ic` | 221098 | 170595 (77%) | 213090 (96%) | 221098 (100%) | 221098 (100%) | – |
| `send_megamorphic` | 189766 | 189766 (100%) | 189766 (100%) | 189766 (100%) | 189766 (100%) | 189766 (100%) |
| `getivar_no_side_exits` | 73922 | 73922 (100%) | 73922 (100%) | 73922 (100%) | 73922 (100%) | – |
| `send_polymorphic_fallback` | 26500 | 6000 (23%) | 15147 (57%) | 26111 (99%) | 26500 (100%) | 9760 (37%) |
| `invokeblock_polymorphic_miss` | 11287 | 9274 (82%) | 9274 (82%) | 11287 (100%) | 11287 (100%) | – |
| `send_polymorphic` | 5961 | 0 (0%) | 0 (0%) | 0 (0%) | 0 (0%) | 0 (0%) |

### invokeblock_not_specialized

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `each@<internal:array>:271 yield` | 1 | 200651.2 | 219984.0 | 32 | 32 | 18% / 35% / 57% | 56610.0 | 0 () | iseq:block in invoke_before@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/callbacks.rb:560 9%, <ifunc> 9%, iseq:block in evaluate@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb:42 9%, iseq:block in each_precompressed_filepath@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.1/lib/action_dispatch/middleware/static.rb:155 8% |
| `map@<internal:array>:291 yield` | 1 | 41197.0 | 41197.0 | 12 | 12 | 44% / 68% / 92% | 27940.0 | 0 () | iseq:block in perform_query@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/connection_adapters/sqlite3/database_statements.rb:123 29%, iseq:block in _find_all@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.1/lib/action_view/template/resolver.rb:142 15%, iseq:block (2 levels) in _load_from_sql@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/querying.rb:92 12%, iseq:block in indexed_rows@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/result.rb:244 12% |
| `block in each_precompressed_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb:156 yield` | 1 | 17883.0 | 17883.0 | 1 | 1 | 100% / 100% / 100% | 17883.0 | 0 () | iseq:block in try_precompressed_files@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.1/lib/action_dispatch/middleware/static.rb:123 100% |
| `select@<internal:array>:318 yield` | 1 | 16014.8 | 16026.2 | 7 | 7 | 100% / 100% / 100% | 16014.2 | 0 () | iseq:block in filter_and_sort_by_details@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.1/lib/action_view/template/resolver.rb:182 62%, iseq:block in method_missing@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/broadcast_logger.rb:223 37%, iseq:block (3 levels) in sequential_maintenance@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/connection_adapters/abstract/connection_pool.rb:953 0%, <proc> 0% |
| `block (2 levels) in search_combinations@actionview-8.1.1/lib/action_view/path_set.rb:62 yield` | 1 | 12078.0 | 12078.0 | 1 | 1 | 100% / 100% / 100% | 12078.0 | 0 () | iseq:block in find_all@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.1/lib/action_view/path_set.rb:46 100% |
| `times@<internal:numeric>:262 yield` | 1 | 7071.0 | 7071.0 | 2 | 2 | 100% / 100% / 100% | 7071.0 | 0 () | iseq:block in parameterize_args@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb:250 100%, iseq:block in run_benchmark@/home/user/w/ruby-bench/harness/polyprobe.rb:11 0% |

### getivar_no_profile_missing_ic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | ivar index | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `request@actionpack-8.1.1/lib/action_dispatch/middleware/cookies.rb:537 request` | 1 | 35766.0 | 35766.0 | 1 | 2 | 100% / 100% / 100% | 35766.0 | 0 () | ActionDispatch::Cookies::CookieJar 83%, ActionDispatch::Cookies::CookieJar 17% |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb:54 request` | 1 | 10357.0 | 10357.0 | 1 | 2 | 100% / 100% / 100% | 10357.0 | 0 () | PostsController 62%, PostsController 38% |
| `url_options@actionpack-8.1.1/lib/action_controller/metal/url_for.rb:45 request` | 1 | 10357.0 | 10357.0 | 1 | 2 | 100% / 100% / 100% | 10357.0 | 0 () | PostsController 62%, PostsController 38% |
| `call@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb:213 arg_size` | 1 | 10357.0 | 10357.0 | 1 | 2 | 100% / 100% / 100% | 10357.0 | 0 () | ActionDispatch::Routing::RouteSet::NamedRouteCollection::UrlHelper::OptimizedUrlHelper 81%, ActionDispatch::Routing::RouteSet::NamedRouteCollection::UrlHelper::OptimizedUrlHelper 19% |
| `optimize_routes_generation?@actionview-8.1.1/lib/action_view/routing_url_for.rb:136 controller` | 1 | 9057.0 | 9057.0 | 1 | 4 | 78% / 100% / 100% | 9057.0 | 0 () | #<Class(Unknown):0x?> 56%, #<Class(Unknown):0x?> 22%, #<Class(Unknown):0x?> 22%, #<Class(Unknown):0x?> 0% |
| `url_options@actionview-8.1.1/lib/action_view/routing_url_for.rb:125 controller` | 1 | 9057.0 | 10357.0 | 1 | 4 | 68% / 100% / 100% | 9057.0 | 0 () | #<Class(Unknown):0x?> 49%, #<Class(Unknown):0x?> 19%, #<Class(Unknown):0x?> 19%, #<Class(Unknown):0x?> 13% |

### send_megamorphic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `level@logger-1.7.0/lib/logger.rb:384 level_key` | 1 | 25961.0 | 25961.0 | 1 | 1 | 100% / 100% / 100% | 25961.0 | 1 (Logger#level_key) | singleton:obj(ActiveSupport::Logger) 100% |
| `local_level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb:16 local_level_key` | 1 | 25961.0 | 25961.0 | 1 | 1 | 100% / 100% / 100% | 25961.0 | 1 (ActiveSupport::LoggerThreadSafeLevel#local_level_key) | singleton:obj(ActiveSupport::Logger) 100% |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb:36 local_level` | 1 | 25961.0 | 25961.0 | 1 | 1 | 100% / 100% / 100% | 25961.0 | 1 (ActiveSupport::LoggerThreadSafeLevel#local_level) | singleton:obj(ActiveSupport::Logger) 100% |
| `level@logger-1.7.0/lib/logger.rb:384 level_override` | 1 | 25961.0 | 25961.0 | 1 | 1 | 100% / 100% / 100% | 25961.0 | 1 (Logger#level_override) | singleton:obj(ActiveSupport::Logger) 100% |
| `block in debug?@activesupport-8.1.1/lib/active_support/broadcast_logger.rb:142 debug?` | 1 | 13987.0 | 13987.0 | 1 | 1 | 100% / 100% / 100% | 13987.0 | 1 (Logger#debug?) | singleton:obj(ActiveSupport::Logger) 100% |
| `debug?@logger-1.7.0/lib/logger.rb:482 level` | 1 | 13987.0 | 13987.0 | 1 | 1 | 100% / 100% / 100% | 13987.0 | 1 (ActiveSupport::LoggerThreadSafeLevel#level) | singleton:obj(ActiveSupport::Logger) 100% |

### getivar_no_side_exits

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | ivar index | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `level@logger-1.7.0/lib/logger.rb:384 @level` | 1 | 25961.0 | 25961.0 | 1 | 1 | 100% / 100% / 100% | 25961.0 | 1 (idx=0/RObject) | singleton:obj(ActiveSupport::Logger) 100% |
| `level_override@logger-1.7.0/lib/logger.rb:779 @level_override` | 1 | 25961.0 | 25961.0 | 1 | 1 | 100% / 100% / 100% | 25961.0 | 1 (idx=5/RObject) | singleton:obj(ActiveSupport::Logger) 100% |
| `tag_stack@activesupport-8.1.1/lib/active_support/tagged_logging.rb:57 @thread_key` | 1 | 6000.0 | 6000.0 | 1 | 1 | 100% / 100% / 100% | 6000.0 | 1 (idx=2/Extended) | singleton:obj(Logger::Formatter) 100% |
| `[]@activesupport-8.1.1/lib/active_support/isolated_execution_state.rb:32 active_support_execution_state` | 1 | 6000.0 | 80488.0 | 1 | 1 | 100% / 100% / 100% | 6000.0 | 0 () | Thread 100% |
| `tag_stack@activesupport-8.1.1/lib/active_support/tagged_logging.rb:58 @thread_key` | 1 | 6000.0 | 6000.0 | 1 | 1 | 100% / 100% / 100% | 6000.0 | 1 (idx=2/Extended) | singleton:obj(Logger::Formatter) 100% |
| `add@logger-1.7.0/lib/logger.rb:677 @logdev` | 1 | 2000.0 | 2000.0 | 1 | 1 | 100% / 100% / 100% | 2000.0 | 1 (idx=4/RObject) | singleton:obj(ActiveSupport::Logger) 100% |

### send_polymorphic_fallback

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `block in evaluate@actionpack-8.1.1/lib/action_dispatch/journey/visitors.rb:45 nil?` | 1 | 9057.0 | 18727.0 | 2 | 3 | 100% / 100% / 100% | 9057.0 | 2 (Kernel#nil?) | String 52%, NilClass 48% |
| `silenced?@activesupport-8.1.1/lib/active_support/notifications/fanout.rb:427 silenced?` | 1 | 8013.0 | 16000.0 | 5 | 5 | 50% / 100% / 100% | 8000.0 | 3 (ActiveSupport::LogSubscriber#silenced?) | ActionController::LogSubscriber 25%, ActionView::LogSubscriber 25%, ActionController::StructuredEventSubscriber 25%, ActionView::LogSubscriber::Start 25% |
| `<<@actionview-8.1.1/lib/action_view/buffers.rb:43 nil?` | 1 | 3670.0 | 28015.0 | 5 | 5 | 73% / 99% / 100% | 3294.0 | 2 (Kernel#nil?) | ActiveSupport::SafeBuffer 47%, String 26%, NilClass 14%, TrueClass 12% |
| `<<@actionview-8.1.1/lib/action_view/buffers.rb:44 to_s` | 1 | 3670.0 | 24041.0 | 4 | 4 | 85% / 100% / 100% | 3670.0 | 4 (ActiveSupport::SafeBuffer#to_s) | ActiveSupport::SafeBuffer 54%, String 31%, TrueClass 14%, FalseClass 2% |
| `changed?@actionview-8.1.1/lib/action_view/base.rb:219 compiled_method_container` | 1 | 2000.0 | 2000.0 | 1 | 1 | 100% / 100% / 100% | 2000.0 | 1 (#<Class:#<Class(ActionView::Base):0x?>>#compiled_method_container) | #<Class:#<Class(#<Class(ActionView::Base):0x?>):0x?>> 100% |
| `to_sql_and_binds@activerecord-8.1.1/lib/active_record/connection_adapters/abstract/database_statements.rb:19 respond_to?` | 1 | 30.0 | 4000.0 | 2 | 3 | 100% / 100% / 100% | 30.0 | 1 (Kernel#respond_to?) | String 99%, Arel::SelectManager 1% |

### invokeblock_polymorphic_miss

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `instrument@activesupport-8.1.1/lib/active_support/notifications/instrumenter.rb:58 yield` | 1 | 5987.0 | 7987.0 | 3 | 3 | 75% / 100% / 100% | 5987.0 | 0 () | iseq:block in instrument@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/notifications.rb:210 50%, iseq:block in raw_execute@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/connection_adapters/abstract/database_statements.rb:570 25%, iseq:block in _load_from_sql@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/querying.rb:88 25% |
| `instrument@activesupport-8.1.1/lib/active_support/notifications.rb:212 yield` | 1 | 5300.0 | 7300.0 | 3 | 3 | 100% / 100% / 100% | 5300.0 | 0 () | iseq:block in render@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.1/lib/action_view/template.rb:273 72%, iseq:block in process_action@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.1/lib/action_controller/metal/instrumentation.rb:76 27%, iseq:block in render_collection@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.1/lib/action_view/renderer/collection_renderer.rb:160 0% |

### send_polymorphic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `block in each_precompressed_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb:156 ` | 1 | 5961.0 | 0.0 | 0 | 0 | 0% / 0% / 0% | 0.0 | 0 () |  |
