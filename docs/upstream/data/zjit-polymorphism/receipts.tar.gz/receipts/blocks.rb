# Array#each/map/find: one yield site in <internal:array> shared by every block
# in the app. Here 12 distinct blocks, called round-robin.
BLOCKS = 12.times.map { |i| eval("proc { |x| x + #{i} }") }
def run(a, i) = case i % 3
  when 0 then a.each { |x| x + 1 }
  when 1 then a.each { |x| x + 2 }
  else a.each { |x| x + 3 }
end
A = [1, 2, 3]
N = 3_000
300.times { |i| run(A, i) }
RubyVM::ZJIT.reset_stats!
N.times { |i| run(A, i) }
s = RubyVM::ZJIT.stats
puts %i[dynamic_send_count send_fallback_invokeblock_polymorphic_miss send_fallback_invokeblock_not_specialized].map { |k| "#{k}=#{(s[k].to_f / N).round(2)}" }.join(" ")
