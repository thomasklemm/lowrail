# ActiveSupport::Logger#level shape: receiver has its own singleton class
# (extend on one object). The profiler skips such receivers, so the site has no
# usable profile, although it only ever sees one object.
class Lg; def initialize = @level = 1; def level = @level; def lk = :k; def lvl = (lk; @level); end
module Ext; end
L = Lg.new.extend(Ext)
def read = L.lvl
N = 10_000
200.times { read }
RubyVM::ZJIT.reset_stats!
N.times { read }
s = RubyVM::ZJIT.stats
puts %i[dynamic_getivar_count getivar_fallback_no_side_exits getivar_fallback_megamorphic send_fallback_send_megamorphic dynamic_send_count].map { |k| "#{k}=#{(s[k].to_f / N).round(2)}" }.join(" ")
