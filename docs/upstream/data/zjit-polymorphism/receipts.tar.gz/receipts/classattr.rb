# Base._reflections / attribute_aliases / schema_context: a class-level method
# called on many model classes. Every receiver is a different singleton class,
# but all resolve to the same method entry.
class Base
  def self.reflections = @reflections ||= {}
  def self.lookup(name) = reflections[name]   # call site under test
end
MODELS = 12.times.map { |i| Class.new(Base) }
def find(k) = k.lookup(:x)
N = 12_000
1200.times { |i| find(MODELS[i % 12]) }
RubyVM::ZJIT.reset_stats!
N.times { |i| find(MODELS[i % 12]) }
s = RubyVM::ZJIT.stats
puts %i[dynamic_send_count send_fallback_send_polymorphic_fallback send_fallback_send_megamorphic send_fallback_send_polymorphic dynamic_getivar_count getivar_fallback_no_side_exits getivar_fallback_megamorphic].map { |k| "#{k}=#{(s[k].to_f / N).round(2)}" }.join(" ")
