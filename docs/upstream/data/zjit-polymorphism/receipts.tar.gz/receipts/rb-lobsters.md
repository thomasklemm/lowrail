Apps: lobsters (means are over 1 apps, per operation)
Fallback receivers found in the interpreter distribution: 96.9%

| Reason | Fallbacks/op | caught N=1 | N=2 | N=4 | N=8 | one resolved method |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `getivar_no_profile_missing_ic` | 320308 | 246716 (77%) | 292634 (91%) | 311362 (97%) | 317948 (99%) | – |
| `send_polymorphic_fallback` | 246917 | 55185 (22%) | 114553 (46%) | 172990 (70%) | 223318 (90%) | 220062 (89%) |
| `getivar_no_side_exits` | 153590 | 68197 (44%) | 82183 (54%) | 106554 (69%) | 118194 (77%) | – |
| `invokeblock_not_specialized` | 153581 | 32466 (21%) | 57476 (37%) | 84363 (55%) | 112195 (73%) | – |
| `send_megamorphic` | 99685 | 55388 (56%) | 70048 (70%) | 80181 (80%) | 91386 (92%) | 94881 (95%) |
| `invokeblock_polymorphic_miss` | 12872 | 7173 (56%) | 10955 (85%) | 12126 (94%) | 12742 (99%) | – |
| `send_polymorphic` | 10063 | 6815 (68%) | 7913 (79%) | 8423 (84%) | 9021 (90%) | 0 (0%) |
| `getivar_polymorphic` | 1253 | 199 (16%) | 328 (26%) | 712 (57%) | 950 (76%) | – |

### getivar_no_profile_missing_ic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | ivar index | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `klass@activerecord-8.1.1/lib/active_record/associations/association.rb:166 reflection` | 1 | 16004.0 | 16018.0 | 4 | 9 | 83% / 93% / 100% | 14968.0 | 0 () | ActiveRecord::Associations::BelongsToAssociation 70%, ActiveRecord::Associations::HasManyAssociation 13%, ActiveRecord::Associations::HasManyAssociation 6%, ActiveRecord::Associations::HasManyThroughAssociation 4% |
| `<<@activerecord-8.1.1/lib/arel/collectors/composite.rb:21 left` | 1 | 14380.0 | 14383.4 | 1 | 1 | 100% / 100% / 100% | 14380.0 | 0 () | Arel::Collectors::Composite 100% |
| `<<@activerecord-8.1.1/lib/arel/collectors/composite.rb:22 right` | 1 | 14380.0 | 14383.4 | 1 | 1 | 100% / 100% / 100% | 14380.0 | 0 () | Arel::Collectors::Composite 100% |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb:51 additional_types` | 1 | 14021.0 | 14021.0 | 1 | 1 | 100% / 100% / 100% | 14021.0 | 0 () | ActiveModel::LazyAttributeSet 100% |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb:48 values` | 1 | 14021.0 | 14021.0 | 1 | 1 | 100% / 100% / 100% | 14021.0 | 0 () | ActiveModel::LazyAttributeSet 100% |
| `block in fetch_value@activemodel-8.1.1/lib/active_model/attribute_set/builder.rb:51 types` | 1 | 14021.0 | 14021.0 | 1 | 1 | 100% / 100% / 100% | 14021.0 | 0 () | ActiveModel::LazyAttributeSet 100% |

### send_polymorphic_fallback

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `association@activerecord-8.1.1/lib/active_record/associations.rb:54 association_instance_get` | 1 | 13090.0 | 25665.0 | 8 | 25 | 82% / 99% / 100% | 12848.0 | 1 (ActiveRecord::Associations#association_instance_get) | Story 49%, Comment 33%, Tagging 12%, Vote 5% |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb:130 limit` | 1 | 10890.0 | 12411.2 | 4 | 5 | 88% / 100% / 100% | 10890.0 | 1 (ActiveModel::Type::Value#limit) | ActiveModel::Type::Value 74%, ActiveRecord::ConnectionAdapters::SQLite3Adapter::SQLite3Integer 13%, ActiveModel::Type::String 7%, ActiveModel::Type::Boolean 6% |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb:130 class` | 1 | 10890.0 | 12411.2 | 4 | 5 | 88% / 100% / 100% | 10890.0 | 1 (Kernel#class) | ActiveModel::Type::Value 74%, ActiveRecord::ConnectionAdapters::SQLite3Adapter::SQLite3Integer 13%, ActiveModel::Type::String 7%, ActiveModel::Type::Boolean 6% |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb:130 precision` | 1 | 10890.0 | 12411.2 | 4 | 5 | 88% / 100% / 100% | 10890.0 | 1 (ActiveModel::Type::Value#precision) | ActiveModel::Type::Value 74%, ActiveRecord::ConnectionAdapters::SQLite3Adapter::SQLite3Integer 13%, ActiveModel::Type::String 7%, ActiveModel::Type::Boolean 6% |
| `hash@activemodel-8.1.1/lib/active_model/type/value.rb:130 scale` | 1 | 10890.0 | 12411.2 | 4 | 5 | 88% / 100% / 100% | 10890.0 | 1 (ActiveModel::Type::Value#scale) | ActiveModel::Type::Value 74%, ActiveRecord::ConnectionAdapters::SQLite3Adapter::SQLite3Integer 13%, ActiveModel::Type::String 7%, ActiveModel::Type::Boolean 6% |
| `cast@activemodel-8.1.1/lib/active_model/type/value.rb:58 nil?` | 1 | 7434.0 | 15817.6 | 7 | 14 | 70% / 97% / 100% | 7402.0 | 2 (Kernel#nil?) | Integer 38%, String 31%, FalseClass 19%, NilClass 8% |

### getivar_no_side_exits

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | ivar index | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `_read_attribute@activerecord-8.1.1/lib/active_record/attribute_methods/read.rb:39 @attributes` | 1 | 37192.5 | 58496.2 | 11 | 34 | 47% / 71% / 87% | 29858.5 | 1 (idx=1/RObject) | Story 26%, User 20%, Comment 12%, Comment 12% |
| `association_instance_get@activerecord-8.1.1/lib/active_record/associations.rb:84 @association_cache` | 1 | 21838.0 | 25665.0 | 8 | 25 | 64% / 78% / 92% | 20088.0 | 1 (idx=18/RObject) | Story 42%, Comment 22%, Tagging 9%, Comment 6% |
| `stale_state@activerecord-8.1.1/lib/active_record/associations/belongs_to_association.rb:174 owner` | 1 | 8512.0 | 8512.0 | 1 | 1 | 100% / 100% / 100% | 8512.0 | 0 () | ActiveRecord::Associations::BelongsToAssociation 100% |
| `stale_state@activerecord-8.1.1/lib/active_record/associations/belongs_to_association.rb:167 reflection` | 1 | 8512.0 | 8512.0 | 1 | 1 | 100% / 100% / 100% | 8512.0 | 0 () | ActiveRecord::Associations::BelongsToAssociation 100% |
| `attribute_types@activemodel-8.1.1/lib/active_model/attribute_registration.rb:38 @attribute_types` | 1 | 5637.0 | 21224.8 | 16 | 16 | 74% / 85% / 94% | 5226.0 | 1 (idx=16/RClass) | #<Class:User> 60%, #<Class:Story> 14%, #<Class:Comment> 6%, #<Class:Vote> 5% |
| `block (2 levels) in generate_url_helpers@actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb:615 @_routes` | 1 | 4826.0 | 7005.0 | 8 | 28 | 33% / 53% / 76% | 1571.0 | 3 (idx=2/RObject) | HomeController 20%, #<Class(Unknown):0x?> 14%, #<Class(Unknown):0x?> 11%, RepliesController 9% |

### invokeblock_not_specialized

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `each@<internal:array>:271 yield` | 1 | 87327.1 | 121747.0 | 88 | 88 | 43% / 58% / 73% | 36526.0 | 0 () | <ifunc> 28%, iseq:block in apply_inflections@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/inflector/methods.rb:382 14%, :-@ 8%, iseq:block in url_for@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.1/lib/action_dispatch/routing/route_set.rb:875 7% |
| `map@<internal:array>:291 yield` | 1 | 39410.0 | 39627.6 | 50 | 50 | 37% / 55% / 79% | 21598.0 | 0 () | iseq:block in perform_query@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/connection_adapters/sqlite3/database_statements.rb:123 26%, iseq:block in type_casted_binds@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/connection_adapters/abstract/quoting.rb:221 12%, iseq:block in defaults_hash@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-typedstore-1.6.0/lib/active_record/typed_store/typed_hash.rb:16 9%, iseq:block in casted_values@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/arel/nodes/homogeneous_in.rb:43 8% |
| `select@<internal:array>:318 yield` | 1 | 10462.9 | 10467.1 | 12 | 12 | 88% / 97% / 100% | 10153.0 | 0 () | :has_default? 65%, iseq:block in load_records@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/associations/preloader/association.rb:203 23%, iseq:block in filter_and_sort_by_details@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.1/lib/action_view/template/resolver.rb:182 6%, iseq:block in method_missing@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/broadcast_logger.rb:223 3% |
| `downto@<internal:numeric>:345 yield` | 1 | 5928.0 | 5928.0 | 1 | 1 | 100% / 100% / 100% | 5928.0 | 0 () | iseq:block in periods_for_local@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/tzinfo-2.0.6/lib/tzinfo/data_sources/transitions_data_timezone_info.rb:90 100% |
| `loop@<internal:kernel>:159 yield` | 1 | 4182.0 | 4182.4 | 2 | 2 | 100% / 100% / 100% | 4182.0 | 0 () | iseq:block in each@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/sqlite3-2.7.3/lib/sqlite3/statement.rb:124 99%, iseq:block in batch_on_unloaded_relation@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/relation/batches.rb:434 1% |
| `add_bind@activerecord-8.1.1/lib/arel/collectors/sql_string.rb:16 yield` | 1 | 1281.0 | 1281.4 | 1 | 1 | 100% / 100% / 100% | 1281.0 | 0 () | <proc> 100% |

### send_megamorphic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `attribute_aliases@activemodel-8.1.1/lib/active_model/attribute_methods.rb:71 __class_attr_attribute_aliases` | 1 | 5891.0 | 9398.6 | 16 | 16 | 40% / 64% / 85% | 2821.0 | 12 (#<Class:ActiveRecord::Base>#__class_attr_attribute_aliases) | #<Class:User> 21%, #<Class:Vote> 19%, #<Class:Story> 14%, #<Class:Keystore> 10% |
| `create@activerecord-8.1.1/lib/active_record/relation/delegation.rb:139 new` | 1 | 3186.0 | 3186.2 | 3 | 3 | 94% / 100% / 100% | 2812.0 | 1 (Class#new) | #<Class:#<Class(ActiveRecord::Relation):0x?>> 82%, #<Class:#<Class(ActiveRecord::Associations::CollectionProxy):0x?>> 12%, #<Class:#<Class(ActiveRecord::AssociationRelation):0x?>> 6% |
| `initialize_copy@activerecord-8.1.1/lib/active_record/relation.rb:99 reset` | 1 | 2983.0 | 2983.4 | 17 | 30 | 37% / 60% / 86% | 1801.0 | 1 (ActiveRecord::Relation#reset) | Story::ActiveRecord_Relation 23%, Vote::ActiveRecord_Relation 14%, Keystore::ActiveRecord_Relation 14%, Tag::ActiveRecord_Relation 10% |
| `level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb:36 local_level` | 1 | 2874.0 | 2874.2 | 1 | 1 | 100% / 100% / 100% | 2874.0 | 1 (ActiveSupport::LoggerThreadSafeLevel#local_level) | singleton:obj(ActiveSupport::Logger) 100% |
| `level@logger-1.7.0/lib/logger.rb:384 level_key` | 1 | 2874.0 | 2874.2 | 1 | 1 | 100% / 100% / 100% | 2874.0 | 1 (Logger#level_key) | singleton:obj(ActiveSupport::Logger) 100% |
| `local_level@activesupport-8.1.1/lib/active_support/logger_thread_safe_level.rb:16 local_level_key` | 1 | 2874.0 | 2874.2 | 1 | 1 | 100% / 100% / 100% | 2874.0 | 1 (ActiveSupport::LoggerThreadSafeLevel#local_level_key) | singleton:obj(ActiveSupport::Logger) 100% |

### invokeblock_polymorphic_miss

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `find@<internal:array>:348 yield` | 1 | 9574.0 | 9576.8 | 6 | 6 | 96% / 100% / 100% | 9553.0 | 0 () | iseq:block in handler_for@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/relation/predicate_builder.rb:188 68%, iseq:block (3 levels) in populate_keys_to_load_and_already_loaded_records@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/associations/preloader/association.rb:80 29%, iseq:block (2 levels) in normalize_options@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/cache.rb:951 3%, iseq:block in extract_params@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/nokogiri-1.18.9/lib/nokogiri/xml/searchable.rb:212 0% |
| `instrument@activesupport-8.1.1/lib/active_support/notifications.rb:212 yield` | 1 | 1354.0 | 1468.2 | 5 | 5 | 72% / 98% / 100% | 1318.0 | 0 () | iseq:block in render@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.1/lib/action_view/template.rb:273 47%, iseq:block in render_partial_template@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionview-8.1.1/lib/action_view/renderer/partial_renderer.rb:268 25%, iseq:block in _instrument@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/cache.rb:1091 18%, iseq:block in process_action@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/actionpack-8.1.1/lib/action_controller/metal/instrumentation.rb:76 8% |
| `instrument@activesupport-8.1.1/lib/active_support/notifications/instrumenter.rb:58 yield` | 1 | 702.0 | 1732.2 | 3 | 3 | 86% / 100% / 100% | 702.0 | 0 () | iseq:block in raw_execute@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/connection_adapters/abstract/database_statements.rb:570 59%, iseq:block in _load_from_sql@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/querying.rb:88 27%, iseq:block in instrument@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/notifications.rb:210 14% |
| `tap@<internal:kernel>:81 yield` | 1 | 527.0 | 1887.8 | 13 | 13 | 56% / 68% / 92% | 286.0 | 0 () | iseq:block in store_accessor_for@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/store.rb:227 47%, :compact! 9%, iseq:block in run!@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activesupport-8.1.1/lib/active_support/execution_wrapper.rb:75 6%, :start_session 6% |
| `with_connection@activerecord-8.1.1/lib/active_record/connection_adapters/abstract/connection_pool.rb:463 yield` | 1 | 454.0 | 1494.2 | 13 | 13 | 44% / 67% / 97% | 152.0 | 0 () | iseq:block (2 levels) in exec_main_query@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/relation.rb:1473 29%, iseq:block in create@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/associations/alias_tracker.rb:11 14%, iseq:block (2 levels) in pluck@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/relation/calculations.rb:326 13%, iseq:block in cached_find_by@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/core.rb:444 10% |
| `_scoping@activerecord-8.1.1/lib/active_record/relation.rb:1393 yield` | 1 | 154.0 | 594.0 | 19 | 19 | 68% / 79% / 90% | 47.0 | 0 () | iseq:block in _exec_scope@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/relation.rb:565 56%, iseq:block in not_deleted@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/relation/delegation.rb:80 12%, iseq:block in unmerged@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/relation/delegation.rb:80 6%, iseq:block in filter_tags@/home/user/w/rm/lib/ruby/gems/4.1.0+6/gems/activerecord-8.1.1/lib/active_record/relation/delegation.rb:80 5% |

### send_polymorphic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | methods | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `stale_target?@activerecord-8.1.1/lib/active_record/associations/association.rb:98 ==` | 1 | 6353.0 | 6353.0 | 2 | 2 | 100% / 100% / 100% | 6353.0 | 2 (Integer#==) | Integer 89%, NilClass 11% |
| `value_for@activerecord-8.1.1/lib/active_record/scoping.rb:121 ==` | 1 | 2511.0 | 2511.2 | 16 | 16 | 34% / 54% / 78% | 1364.0 | 1 (Module#==) | #<Class:Story> 18%, #<Class:User> 16%, #<Class:Tag> 12%, #<Class:Comment> 8% |
| `_encode_uri_component@uri-1.1.1/lib/uri/common.rb:449 ==` | 1 | 372.0 | 372.2 | 1 | 2 | 100% / 100% / 100% | 372.0 | 1 (BasicObject#==) | Encoding 100% |
| `block in each_precompressed_filepath@actionpack-8.1.1/lib/action_dispatch/middleware/static.rb:156 ` | 1 | 342.0 | 0.0 | 0 | 0 | 0% / 0% / 0% | 0.0 | 0 () |  |
| `[]=@rack-2.2.19/lib/rack/utils.rb:481 ==` | 1 | 217.0 | 217.0 | 1 | 2 | 100% / 100% / 100% | 217.0 | 1 (String#==) | String 100% |
| `tag@actionview-8.1.1/lib/action_view/helpers/tag_helper.rb:481 ` | 1 | 146.0 | 0.0 | 0 | 0 | 0% / 0% / 0% | 0.0 | 0 () |  |

### getivar_polymorphic

| Site | Apps | Fallbacks/op | Calls/op | Classes | Shapes | Top-2 / 4 / 8 cover | N=4 catches | ivar index | Top receivers |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | --- |
| `loaded?@activerecord-8.1.1/lib/active_record/associations/preloader/association.rb:177 reflection` | 1 | 387.0 | 6177.0 | 2 | 7 | 89% / 98% / 100% | 275.0 | 0 () | ActiveRecord::Associations::Preloader::Association 45%, ActiveRecord::Associations::Preloader::Association 44%, ActiveRecord::Associations::Preloader::ThroughAssociation 5%, ActiveRecord::Associations::Preloader::ThroughAssociation 4% |
| `spawn@activerecord-8.1.1/lib/active_record/relation/spawn_methods.rb:10 model` | 1 | 273.9 | 2721.4 | 17 | 29 | 26% / 44% / 65% | 34.0 | 0 () | Story::ActiveRecord_Relation 16%, Keystore::ActiveRecord_Relation 10%, Tag::ActiveRecord_Relation 9%, Vote::ActiveRecord_Relation 9% |
| `already_in_scope?@activerecord-8.1.1/lib/active_record/relation.rb:1358 model` | 1 | 179.0 | 334.0 | 8 | 12 | 56% / 74% / 90% | 179.0 | 0 () | Story::ActiveRecord_Relation 43%, Story::ActiveRecord_Relation 13%, Comment::ActiveRecord_Relation 12%, Comment::ActiveRecord_AssociationRelation 6% |
| `base_class?@activerecord-8.1.1/lib/active_record/inheritance.rb:120 base_class` | 1 | 145.0 | 155.0 | 5 | 5 | 55% / 94% / 100% | 145.0 | 0 () | #<Class:ReadRibbon> 29%, #<Class:Vote> 26%, #<Class:Story> 19%, #<Class:User> 19% |
| `polymorphic?@activerecord-8.1.1/lib/active_record/reflection.rb:730 options` | 1 | 87.0 | 6553.0 | 3 | 9 | 96% / 99% / 100% | 49.0 | 0 () | ActiveRecord::Reflection::BelongsToReflection 88%, ActiveRecord::Reflection::BelongsToReflection 8%, ActiveRecord::Reflection::BelongsToReflection 2%, ActiveRecord::Reflection::HasManyReflection 1% |
| `load@activerecord-8.1.1/lib/active_record/relation.rb:1200 loaded?` | 1 | 76.0 | 733.0 | 14 | 14 | 37% / 60% / 84% | 0.0 | 0 () | User::ActiveRecord_Relation 20%, Vote::ActiveRecord_Relation 18%, Story::ActiveRecord_Relation 16%, Comment::ActiveRecord_Relation 7% |
