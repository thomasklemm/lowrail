pr58957: Rails /home/user/rails-fw@measure/pr58957 9e4c5f313b, ruby 4.0.7 (2026-09-15 revision 229531a6cf) +PRISM [x86_64-linux]
pr58957sub: Rails /home/user/rails-fw@measure/pr58957-subscriber a0d0100493, ruby 4.0.7 (2026-09-15 revision 229531a6cf) +PRISM [x86_64-linux]
| App | pr58957sub |
| --- | ---: |
| blog | +0.0 / +0.0 |
| campfire | +0.0 / +0.8 |
| codetriage | −9.0 / −14.6 |
| fizzy | −27.0 / −27.1 |
| fizzy-mysql | −20.0 / −20.0 |
| lobsters | +0.0 / +0.0 |
| pingcrm | −4.5 / +3.8 |
| react-starter-kit | +0.4 / +0.0 |
| redprints-cfp | +0.9 / +0.4 |
| writebook | +0.6 / −1.4 |
| **All workloads** | **−2.0 / −1.0** |
| Moved ≤ −1 / ≥ +1 | 54 / 14 · 49 / 18 |
