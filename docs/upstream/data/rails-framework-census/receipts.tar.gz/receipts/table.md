base2: Rails 5810776eecc5b2e50b58e81ee0c26c02c718fdf0 5810776eec, ruby 4.0.7 (2026-09-15 revision 229531a6cf) +PRISM [x86_64-linux]
base: Rails 5810776eecc5b2e50b58e81ee0c26c02c718fdf0 5810776eec, ruby 4.0.7 (2026-09-15 revision 229531a6cf) +PRISM [x86_64-linux]
threadmattr: Rails thomasklemm/rails@thomasklemm/thread-mattr-key-literal e367362490, ruby 4.0.7 (2026-09-15 revision 229531a6cf) +PRISM [x86_64-linux]
subscriber: Rails thomasklemm/rails@thomasklemm/subscriber-event-method-names 48d7ea10bf, ruby 4.0.7 (2026-09-15 revision 229531a6cf) +PRISM [x86_64-linux]
urlmerge: Rails thomasklemm/rails@thomasklemm/url-helper-merge-defaults-once 299787dabb, ruby 4.0.7 (2026-09-15 revision 229531a6cf) +PRISM [x86_64-linux]
capture: Rails thomasklemm/rails@thomasklemm/output-buffer-capture-anonymous-rest bafe198616, ruby 4.0.7 (2026-09-15 revision 229531a6cf) +PRISM [x86_64-linux]
| App | A/A | threadmattr | subscriber | urlmerge | capture |
| --- | ---: | ---: | ---: | ---: | ---: |
| blog | +0.0 / +0.0 | −11.9 / −12.0 | −2.0 / −1.6 | −3.0 / −2.2 | +0.0 / +0.3 |
| campfire | +0.0 / +0.0 | −12.0 / −12.0 | −2.0 / −2.8 | −1.0 / +0.0 | +0.0 / +0.0 |
| codetriage | +0.8 / −7.2 | −7.1 / −3.1 | −23.1 / −16.6 | −10.3 / −6.1 | −2.3 / −0.0 |
| fizzy | +0.0 / +0.0 | −14.0 / −10.0 | −23.0 / −29.0 | −0.1 / +0.0 | +0.0 / +0.0 |
| fizzy-mysql | +0.0 / +0.0 | −14.0 / −14.0 | −29.0 / −29.0 | +0.0 / +0.0 | −1.0 / +1.0 |
| lobsters | −0.4 / +0.0 | −40.7 / −41.1 | −0.8 / −2.0 | −24.3 / −20.6 | −2.1 / +0.0 |
| pingcrm | −4.3 / +0.4 | +5.6 / −3.8 | +1.8 / −2.5 | +5.8 / +0.3 | +1.0 / −3.6 |
| react-starter-kit | +0.7 / −0.6 | −6.1 / −5.0 | −2.9 / −0.7 | +1.3 / +0.1 | +0.1 / +0.8 |
| redprints-cfp | +0.1 / +0.3 | −8.5 / −8.4 | −2.8 / −1.3 | +0.1 / −0.6 | −1.3 / +0.8 |
| writebook | +0.0 / +0.0 | −10.5 / −11.0 | −3.0 / −1.0 | −1.9 / +0.0 | −3.7 / +1.1 |
| **All workloads** | **+0.0 / +0.0** | **−10.8 / −10.0** | **−3.3 / −4.0** | **−1.0 / −1.1** | **−0.2 / +0.0** |
| Moved ≤ −1 / ≥ +1 | 26 / 17 · 27 / 17 | 83 / 8 · 85 / 5 | 75 / 14 · 76 / 8 | 52 / 17 · 54 / 17 | 46 / 15 · 24 / 28 |
