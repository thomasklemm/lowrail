require File.expand_path("../../harness/harness-common", File.dirname(File.expand_path($PROGRAM_NAME)))
def run_benchmark(_hint, **, &block)
  15.times { block.call }
  3.times { GC.start }
  3.times { block.call }
  s = RubyVM::ZJIT.stats
  puts "OOMCHECK code_region_MiB=#{(s[:code_region_bytes].to_f / 1048576).round(1)} total_mem_MiB=#{(s[:total_mem_bytes].to_f / 1048576).round(1)} oom=#{s[:compile_error_out_of_memory].inspect} compile_error=#{s[:exit_compile_error].inspect}"
end
