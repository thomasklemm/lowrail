| Benchmark | Mode | Objects/iter without → with | Δ | A/A with, without | GC/iter without → with | major/iter without → with |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| railsbench | interpreter | 983931 → 922444 | -6.25% | +0.00%, +0.00% | 1.30 → 1.20 | 0.00 → 0.00 |
| railsbench | YJIT | 989269 → 927782 | -6.22% | +0.00%, +0.00% | 1.30 → 1.30 | 0.00 → 0.00 |
| lobsters | interpreter | 541004 → 513507 | -5.08% | +0.00%, +0.00% | 0.60 → 0.60 | 0.00 → 0.00 |
| lobsters | YJIT | 544353 → 516866 | -5.05% | -0.00%, -0.00% | 0.60 → 0.60 | 0.00 → 0.00 |
| shipit | interpreter | 977710 → 825232 | -15.60% | -0.00%, -0.00% | 1.50 → 1.35 | 0.00 → 0.00 |
| shipit | YJIT | 990858 → 838391 | -15.39% | +0.00%, +0.00% | 1.50 → 1.40 | 0.00 → 0.00 |
