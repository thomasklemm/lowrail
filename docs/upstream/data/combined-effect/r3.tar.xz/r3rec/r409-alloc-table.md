| Benchmark | Mode | Objects/iter without → with | Δ | A/A with, without | GC/iter without → with | major/iter without → with |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| railsbench | interpreter | 983931 → 922444 | -6.25% | +0.00%, +0.00% | 1.30 → 1.20 | 0.00 → 0.00 |
| railsbench | YJIT | 989269 → 927782 | -6.22% | +0.00%, +0.00% | 1.30 → 1.20 | 0.00 → 0.00 |
| lobsters | interpreter | 541211 → 518469 | -4.20% | -0.00%, -0.00% | 0.60 → 0.60 | 0.00 → 0.00 |
| lobsters | YJIT | 544673 → 521933 | -4.17% | +0.01%, +0.01% | 0.60 → 0.60 | 0.00 → 0.00 |
| shipit | interpreter | 981026 → 856374 | -12.71% | -0.00%, -0.00% | 1.60 → 1.40 | 0.00 → 0.00 |
| shipit | YJIT | 994230 → 869556 | -12.54% | -0.00%, +0.00% | 1.60 → 1.40 | 0.00 → 0.00 |
